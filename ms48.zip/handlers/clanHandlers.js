'use strict';

const clan = require('../game/clan');
const clansDb = require('../db/clans');
const players = require('../db/players');
const calc = require('../game/calc');
const C = require('../game/constants');
const msg = require('../utils/messages');

async function requireRegistered(ctx) {
  const player = await players.getPlayer(ctx.senderId);
  if (!player || player.registration_step !== 'done') {
    await ctx.send('⛔ Вы ещё не зарегистрированы. Напишите !старт');
    return null;
  }
  return player;
}

// Кастомное фото/видео клана (выдаёт админ, см. !админ кланфото / !админ кланвидео).
// Если заданы оба — показываем фото (приоритетнее видео). Прикладываем ко всем
// сообщениям, связанным с существующим кланом, чтобы медиа было видно везде.
async function sendClanReply(ctx, clanId, text) {
  const clanData = clanId ? await clansDb.getClanById(clanId) : null;
  const attachment = clanData ? clanData.clan_photo || clanData.clan_video || null : null;

  if (attachment) {
    await ctx.send({ message: text, attachment });
  } else {
    await ctx.send(text);
  }
}

async function handleCreate(ctx, name) {
  const player = await requireRegistered(ctx);
  if (!player) return;

  if (!name) {
    await ctx.send('⛔ Укажите название: !клан создать [название]');
    return;
  }

  const result = await clan.createClan(ctx.senderId, name);
  if (!result.ok) {
    const reasons = {
      invalid_name_length: `⛔ Название клана должно быть от ${C.CLAN_NAME_MIN} до ${C.CLAN_NAME_MAX} символов.`,
      already_in_clan: '⛔ Вы уже состоите в клане.',
      name_taken: '⛔ Это название уже занято.',
    };
    await ctx.send(reasons[result.reason] || '⛔ Не удалось создать клан.');
    return;
  }

  await sendClanReply(ctx, result.clan.id, `✅ Клан «${result.clan.name}» создан бесплатно! Вы — глава клана.`);
}

async function handleInvite(ctx, targetId) {
  const player = await requireRegistered(ctx);
  if (!player) return;

  if (!targetId) {
    await ctx.send('⛔ Укажите игрока: !клан пригласить @юзер');
    return;
  }

  const result = await clan.invite(ctx.senderId, targetId);
  if (!result.ok) {
    const reasons = {
      not_leader: '⛔ Только глава клана может приглашать.',
      target_not_registered: '⛔ Этот игрок не зарегистрирован.',
      target_already_in_clan: '⛔ Этот игрок уже состоит в клане.',
    };
    await ctx.send(reasons[result.reason] || '⛔ Не удалось пригласить игрока.');
    return;
  }

  await sendClanReply(ctx, result.clanId, '✅ Приглашение отправлено!');

  if (ctx.bot) {
    const clanData = await clansDb.getClanById(result.clanId);
    await ctx.bot
      .notifyUser(targetId, `👥 Вас пригласили в клан «${clanData.name}»! Введите: !клан вступить ${clanData.name}`)
      .catch(() => {});
  }
}

async function handleJoin(ctx, name) {
  const player = await requireRegistered(ctx);
  if (!player) return;

  if (!name) {
    await ctx.send('⛔ Укажите название клана: !клан вступить [название]');
    return;
  }

  const result = await clan.join(ctx.senderId, name);
  if (!result.ok) {
    const reasons = {
      already_in_clan: '⛔ Вы уже состоите в клане.',
      clan_not_found: '⛔ Клан с таким названием не найден.',
      no_invite: '⛔ У вас нет приглашения в этот клан.',
    };
    await ctx.send(reasons[result.reason] || '⛔ Не удалось вступить в клан.');
    return;
  }

  await sendClanReply(ctx, result.clan.id, `✅ Вы вступили в клан «${result.clan.name}»!`);
}

async function handleKick(ctx, targetId) {
  const player = await requireRegistered(ctx);
  if (!player) return;

  if (!targetId) {
    await ctx.send('⛔ Укажите игрока: !клан кик @юзер');
    return;
  }

  const result = await clan.kick(ctx.senderId, targetId);
  if (!result.ok) {
    const reasons = {
      not_leader: '⛔ Только глава клана может исключать участников.',
      not_member: '⛔ Этот игрок не состоит в вашем клане.',
      cannot_kick_self: '⛔ Нельзя исключить самого себя.',
    };
    await ctx.send(reasons[result.reason] || '⛔ Не удалось исключить игрока.');
    return;
  }

  await sendClanReply(ctx, player.clan_id, '✅ Игрок исключён из клана.');
  if (ctx.bot) {
    await ctx.bot.notifyUser(targetId, '👥 Вас исключили из клана.').catch(() => {});
  }
}

async function handleLeave(ctx) {
  const player = await requireRegistered(ctx);
  if (!player) return;

  const result = await clan.leave(ctx.senderId);
  if (!result.ok) {
    const reasons = {
      not_in_clan: '⛔ Вы не состоите в клане.',
      leader_last_member: '⛔ Вы единственный в клане — передавать главенство некому. Чтобы уйти, распустите клан: клан удалить [название]',
    };
    await ctx.send(reasons[result.reason] || '⛔ Не удалось покинуть клан.');
    return;
  }

  if (result.transferredTo) {
    await sendClanReply(
      ctx,
      player.clan_id,
      `✅ Вы покинули клан. Главенство передано игроку «${result.transferredToName}».`
    );
    if (ctx.bot) {
      await ctx.bot
        .notifyUser(result.transferredTo, '👑 Вы стали новым главой клана — прежний глава покинул клан.')
        .catch(() => {});
    }
  } else {
    await sendClanReply(ctx, player.clan_id, '✅ Вы покинули клан.');
  }
}

async function handleDisband(ctx, confirmName) {
  const player = await requireRegistered(ctx);
  if (!player) return;

  const result = await clan.disbandClan(ctx.senderId, confirmName);
  if (!result.ok) {
    if (result.reason === 'not_leader') {
      await ctx.send('⛔ Только глава клана может распустить клан.');
    } else if (result.reason === 'confirm_required') {
      await ctx.send(
        `⚠️ Это необратимо: все участники будут исключены, клан удалён.\n` +
          `Для подтверждения повторите точное название клана: клан удалить ${result.clanName}`
      );
    } else if (result.reason === 'vault_not_empty') {
      await ctx.send(
        `⛔ В сейфе клана ещё ${calc.formatNumber(result.vault)} вирт. Сначала снимите их: клан сейф забрать ${result.vault}`
      );
    } else {
      await ctx.send('⛔ Не удалось распустить клан.');
    }
    return;
  }

  await ctx.send(`✅ Клан «${result.clanName}» распущен. Все участники исключены.`);

  if (ctx.bot) {
    for (const memberId of result.notifyMemberIds) {
      await ctx.bot
        .notifyUser(memberId, `👥 Клан «${result.clanName}» распущен главой. Вы больше не состоите в клане.`)
        .catch(() => {});
    }
  }
}

async function handleBonus(ctx, bonusName) {
  const player = await requireRegistered(ctx);
  if (!player) return;

  if (!bonusName) {
    await ctx.send('⛔ Укажите бонус: !клан бонус [форсаж/эшелон/индустриализация]');
    return;
  }

  const result = await clan.useBonus(ctx.senderId, bonusName);
  if (!result.ok) {
    if (result.reason === 'not_leader') {
      await ctx.send('⛔ Только глава клана может покупать бонусы.');
    } else if (result.reason === 'unknown_bonus') {
      await ctx.send('⛔ Неизвестный бонус. Доступны: Форсаж, Эшелон, Индустриализация.');
    } else if (result.reason === 'cooldown') {
      await ctx.send(`⛔ Бонус на кулдауне до ${msg.formatTimeMsk(result.until)} (МСК).`);
    } else if (result.reason === 'not_enough_vault') {
      await ctx.send(
        `⛔ Недостаточно средств в сейфе. Нужно ${calc.formatNumber(result.cost)}, есть ${calc.formatNumber(
          result.have
        )}.`
      );
    } else {
      await ctx.send('⛔ Не удалось применить бонус.');
    }
    return;
  }

  await sendClanReply(ctx, player.clan_id, `✅ Бонус «${result.bonus.name}» активирован на ${result.bonus.durationHours} ч!\n${result.bonus.description}\nСтоимость: ${calc.formatNumber(
      result.cost
    )} вирт из сейфа.`
  );
}

async function handleVault(ctx) {
  const player = await requireRegistered(ctx);
  if (!player) return;

  if (!player.clan_id) {
    await ctx.send('⛔ Вы не состоите в клане.');
    return;
  }

  const info = await clan.getClanVaultInfo(player.clan_id);

  const progressLine =
    info.level >= C.CLAN_VAULT_MAX_LEVEL
      ? '🏆 Максимальный уровень сейфа достигнут!'
      : `📈 До следующего уровня: ${calc.formatNumber(
          info.nextLevelTotal - info.totalCollected
        )} вирт (всего собрано ${calc.formatNumber(info.totalCollected)} из ${calc.formatNumber(
          info.nextLevelTotal
        )})`;

  const text =
    `👥 СЕЙФ КЛАНА «${info.clan.name}»\n` +
      `💰 Баланс: ${calc.formatNumber(info.clan.vault)} / ${calc.formatNumber(info.effectiveMaxVault)} вирт\n` +
      `🏦 Уровень сейфа: ${info.level}/${C.CLAN_VAULT_MAX_LEVEL} (+${(info.capacityBonus * 100).toFixed(1).replace(/\.0$/, '')}% к вместимости)\n` +
      `${progressLine}\n\n` +
      `➕ Пополнить может любой участник: клан сейф пополнить [сумма]\n` +
      `➖ Снять на свой баланс может глава или зам: клан сейф забрать [сумма]`;

  const attachment = info.clan.clan_photo || info.clan.clan_video || null;
  if (attachment) {
    await ctx.send({ message: text, attachment });
  } else {
    await ctx.send(text);
  }
}

async function handleDeposit(ctx, amountArg) {
  const player = await requireRegistered(ctx);
  if (!player) return;

  if (!amountArg || !/^\d+$/.test(amountArg)) {
    await ctx.send('⛔ Укажите сумму: клан сейф пополнить [сумма]');
    return;
  }

  const result = await clan.depositVault(ctx.senderId, amountArg);
  if (!result.ok) {
    const reasons = {
      not_in_clan: '⛔ Вы не состоите в клане.',
      invalid_amount: '⛔ Укажите положительную сумму.',
      vault_full: '⛔ Сейф клана уже заполнен до максимума.',
      not_enough_money: `⛔ Недостаточно вирт. У вас ${calc.formatNumber(result.have)}.`,
    };
    await ctx.send(reasons[result.reason] || '⛔ Не удалось пополнить сейф.');
    return;
  }

  const cappedLine = result.capped
    ? `\n⚠️ Сейф был почти полон, зачислена только часть суммы (${calc.formatNumber(result.deposited)}).`
    : '';
  const levelLine = result.leveledUp
    ? `\n🏦 Сейф клана «${result.clanName}» повысил уровень: ${result.level}/${C.CLAN_VAULT_MAX_LEVEL}!`
    : '';

  await sendClanReply(
    ctx,
    player.clan_id,
    `✅ Вы пополнили сейф клана «${result.clanName}» на ${calc.formatNumber(result.deposited)} вирт.\n` +
      `💰 В сейфе теперь: ${calc.formatNumber(result.vault)} / ${calc.formatNumber(result.maxVault)} вирт.` +
      cappedLine +
      levelLine
  );
}

async function handleWithdraw(ctx, amountArg) {
  const player = await requireRegistered(ctx);
  if (!player) return;

  if (!amountArg || !/^\d+$/.test(amountArg)) {
    await ctx.send('⛔ Укажите сумму: клан сейф забрать [сумма]');
    return;
  }

  const result = await clan.withdrawVault(ctx.senderId, amountArg);
  if (!result.ok) {
    const reasons = {
      not_leader: '⛔ Снимать средства из сейфа может только глава клана или зам.',
      invalid_amount: '⛔ Укажите положительную сумму.',
      not_enough_vault: `⛔ В сейфе недостаточно средств. Есть: ${calc.formatNumber(result.have)}.`,
    };
    await ctx.send(reasons[result.reason] || '⛔ Не удалось снять средства из сейфа.');
    return;
  }

  await sendClanReply(
    ctx,
    player.clan_id,
    `✅ Вы сняли ${calc.formatNumber(result.amount)} вирт из сейфа клана «${result.clanName}» на свой баланс.\n` +
      `💰 В сейфе осталось: ${calc.formatNumber(result.vault)} вирт.`
  );
}

async function handlePromoteDeputy(ctx, targetId) {
  const player = await requireRegistered(ctx);
  if (!player) return;

  if (!targetId) {
    await ctx.send('⛔ Укажите игрока: клан зам @юзер');
    return;
  }

  const result = await clan.promoteDeputy(ctx.senderId, targetId);
  if (!result.ok) {
    const reasons = {
      not_leader: '⛔ Только глава клана может назначать замов.',
      not_member: '⛔ Этот игрок не состоит в вашем клане.',
      cannot_target_self: '⛔ Нельзя назначить замом самого себя.',
      already_deputy: '⛔ Этот игрок уже зам.',
    };
    await ctx.send(reasons[result.reason] || '⛔ Не удалось назначить зама.');
    return;
  }

  await sendClanReply(ctx, player.clan_id, '✅ Игрок назначен замом клана. Теперь он может снимать средства из сейфа.');
  if (ctx.bot) {
    await ctx.bot.notifyUser(targetId, '🎖️ Вас назначили замом клана! Теперь вы можете снимать средства из сейфа: клан сейф забрать [сумма]').catch(() => {});
  }
}

async function handleDemoteDeputy(ctx, targetId) {
  const player = await requireRegistered(ctx);
  if (!player) return;

  if (!targetId) {
    await ctx.send('⛔ Укажите игрока: клан снять_зама @юзер');
    return;
  }

  const result = await clan.demoteDeputy(ctx.senderId, targetId);
  if (!result.ok) {
    const reasons = {
      not_leader: '⛔ Только глава клана может снимать замов.',
      not_member: '⛔ Этот игрок не состоит в вашем клане.',
      not_deputy: '⛔ Этот игрок не является замом.',
    };
    await ctx.send(reasons[result.reason] || '⛔ Не удалось снять зама.');
    return;
  }

  await sendClanReply(ctx, player.clan_id, '✅ Игрок больше не зам клана.');
  if (ctx.bot) {
    await ctx.bot.notifyUser(targetId, '🎖️ Вас сняли с должности зама клана.').catch(() => {});
  }
}

async function handleInfo(ctx) {
  const player = await requireRegistered(ctx);
  if (!player) return;

  if (!player.clan_id) {
    await ctx.send('⛔ Вы не состоите в клане.');
    return;
  }

  const info = await clan.getClanVaultInfo(player.clan_id);
  const members = await clansDb.getClanMembers(player.clan_id);

  let text = `👥 КЛАН «${info.clan.name}»\n`;
  text += `🏦 Сейф: ${calc.formatNumber(info.clan.vault)} / ${calc.formatNumber(info.effectiveMaxVault)} вирт (уровень ${info.level}/${C.CLAN_VAULT_MAX_LEVEL})\n\n`;
  for (const m of members) {
    const role = m.clan_role === 'leader' ? '👑 Глава' : m.clan_role === 'deputy' ? '🎖️ Зам' : 'Участник';
    text += `${role}: ${m.state_name} — 🏭 ${m.factories} заводов\n`;
  }

  // Кастомное фото/видео клана, выданное админом (см. !админ кланфото / !админ кланвидео).
  // Если заданы оба — показываем фото (приоритетнее видео).
  const clanAttachment = info.clan.clan_photo || info.clan.clan_video || null;

  if (clanAttachment) {
    await ctx.send({ message: text.trim(), attachment: clanAttachment });
  } else {
    await ctx.send(text.trim());
  }
}

module.exports = {
  handleCreate,
  handleInvite,
  handleJoin,
  handleKick,
  handleLeave,
  handleDisband,
  handleBonus,
  handleVault,
  handleDeposit,
  handleWithdraw,
  handlePromoteDeputy,
  handleDemoteDeputy,
  handleInfo,
};
