'use strict';

const C = require('./constants');
const calc = require('./calc');
const players = require('../db/players');
const gameDate = require('./gameDate');

async function buildCenter(vkId) {
  const player = await players.getPlayer(vkId);
  if (!player) return { ok: false, reason: 'not_registered' };

  const limit = calc.currentScienceLimit(player.science_limit_level);
  if ((player.science_centers || 0) >= limit) {
    return { ok: false, reason: 'limit_reached', limit };
  }

  if (player.factories < C.SCIENCE_BUILD_FACTORY_COST) {
    return {
      ok: false,
      reason: 'not_enough_factories',
      need: C.SCIENCE_BUILD_FACTORY_COST,
      have: player.factories,
    };
  }

  // Цена растёт каждые SCIENCE_BUILD_COST_STEP_SIZE построенных центров (см. calc.scienceBuildCost)
  const cost = calc.scienceBuildCost(player.science_centers || 0);
  if (Number(player.balance) < cost) {
    return {
      ok: false,
      reason: 'not_enough_money',
      cost,
      missing: cost - Number(player.balance),
    };
  }

  await players.decrementFactories(vkId, C.SCIENCE_BUILD_FACTORY_COST);
  await players.updateBalance(vkId, -cost);
  await players.addScienceCenters(vkId, 1);

  return { ok: true, cost };
}

async function expandLimit(vkId) {
  const player = await players.getPlayer(vkId);
  if (!player) return { ok: false, reason: 'not_registered' };

  const currentLevel = player.science_limit_level || 1;
  const nextRow = C.SCIENCE_LIMIT_LEVELS.find((l) => l.level === currentLevel + 1);
  if (!nextRow) {
    return { ok: false, reason: 'max_level' };
  }

  if (Number(player.balance) < nextRow.cost) {
    return { ok: false, reason: 'not_enough_money', cost: nextRow.cost, missing: nextRow.cost - Number(player.balance) };
  }

  await players.updateBalance(vkId, -nextRow.cost);
  await players.setScienceLimitLevel(vkId, nextRow.level);

  return { ok: true, newLevel: nextRow.level, newLimit: nextRow.limit, cost: nextRow.cost };
}

// Тот же принцип сброса дневного счётчика в 00:00 МСК, что и в game/warehouse.js
// (ensureDayReset) — продублировано здесь, чтобы не тянуть в science.js зависимость
// от warehouse.js ради одной вспомогательной функции.
async function ensureDayReset(player, countField, dayField, resetFn) {
  const today = gameDate.todayStr();
  const storedDay = player[dayField] ? String(player[dayField]).slice(0, 10) : null;
  if (storedDay !== today) {
    await resetFn(player.vk_id, today);
    player[countField] = 0;
    player[dayField] = today;
  }
  return player;
}

// Обратный обмен: научные центры -> заводы. Курс — доля SCIENCE_TO_FACTORY_RATE от цены
// постройки в заводах (SCIENCE_BUILD_FACTORY_COST), округление вниз, не меньше 1 завода
// за центр. Вирты, потраченные при постройке центра, НЕ возвращаются — обмен обратно всегда
// в убыток, чтобы не превращать науку в бесплатный обход дневного/часового лимита постройки
// заводов. Нельзя опускаться ниже порога защиты новичков по науке (центры нужны и для
// защиты от science_strike — см. combat.js), и обмен ограничен отдельным дневным лимитом.
async function exchangeToFactories(vkId, count) {
  if (!Number.isInteger(count) || count <= 0) {
    return { ok: false, reason: 'invalid_quantity' };
  }

  let player = await players.getPlayer(vkId);
  if (!player) return { ok: false, reason: 'not_registered' };

  player = await ensureDayReset(
    player,
    'exchange_science_to_factory_count_today',
    'exchange_science_to_factory_day',
    players.resetExchangeScienceToFactoryDay
  );

  const usedToday = player.exchange_science_to_factory_count_today || 0;
  const remainingToday = C.SCIENCE_TO_FACTORY_MAX_PER_DAY - usedToday;
  if (remainingToday <= 0) {
    return { ok: false, reason: 'daily_limit', limit: C.SCIENCE_TO_FACTORY_MAX_PER_DAY };
  }
  if (count > remainingToday) {
    return { ok: false, reason: 'exceeds_daily_limit', remainingToday, requested: count };
  }

  const available = (player.science_centers || 0) - C.NEWBIE_PROTECTION_SCIENCE_CENTERS;
  if (available < count) {
    return {
      ok: false,
      reason: 'not_enough_science',
      have: player.science_centers || 0,
      protectedFloor: C.NEWBIE_PROTECTION_SCIENCE_CENTERS,
      maxExchangeable: Math.max(0, available),
    };
  }

  const factoriesPerCenter = Math.max(1, Math.floor(C.SCIENCE_BUILD_FACTORY_COST * C.SCIENCE_TO_FACTORY_RATE));
  const factoriesGained = factoriesPerCenter * count;

  await players.decrementScienceCenters(vkId, count);
  await players.addFactories(vkId, factoriesGained, false);

  // Инкрементируем дневной счётчик по одному разу за каждый обменянный центр — так лимит
  // "3 в день" считает именно центры, а не вызовы команды (обменять 3 разом = использован лимит).
  for (let i = 0; i < count; i++) {
    await players.incrementExchangeScienceToFactoryCount(vkId, gameDate.todayStr());
  }

  const remainingAfter = remainingToday - count;

  return {
    ok: true,
    centersSpent: count,
    factoriesGained,
    factoriesPerCenter,
    remainingToday: remainingAfter,
  };
}

module.exports = { buildCenter, expandLimit, exchangeToFactories };
