'use strict';

const { Keyboard } = require('vk-io');
const players = require('../db/players');
const clansDb = require('../db/clans');
const clanGame = require('../game/clan');
const msg = require('../utils/messages');

async function handleTopFactories(ctx) {
  const list = await players.getTopByFactories(10);
  const viewer = await players.getPlayer(ctx.senderId);
  const viewerCoords = viewer && viewer.registration_step === 'done' ? { x: viewer.x, y: viewer.y } : null;
  await ctx.send(msg.topFactoriesMessage(list, viewerCoords));
}

async function handleTopBalance(ctx) {
  const list = await players.getTopByBalance(10);
  await ctx.send(msg.topBalanceMessage(list));
}

async function handleTopClans(ctx) {
  const list = await clanGame.getTopClansByIncome(10);
  await ctx.send(msg.topClansMessage(list));
}

async function handleTopRobot(ctx) {
  const list = await players.getTopByRobotLevel(10);
  await ctx.send(msg.topRobotMessage(list));
}

async function handleTopSuperRobot(ctx) {
  const list = await players.getTopBySuperRobotLevel(10);
  await ctx.send(msg.topSuperRobotMessage(list));
}

function buildHelpKeyboard() {
  const rows = [];
  const order = msg.HELP_SECTION_ORDER;
  for (let i = 0; i < order.length; i += 2) {
    const row = order.slice(i, i + 2).map((key) =>
      Keyboard.textButton({
        label: msg.HELP_SECTIONS[key].label,
        payload: { cmd: 'help_section', section: key },
        color: Keyboard.PRIMARY_COLOR,
      })
    );
    rows.push(row);
  }
  return Keyboard.keyboard(rows).inline();
}

async function handleHelp(ctx) {
  await ctx.send({
    message: msg.HELP_INTRO,
    keyboard: buildHelpKeyboard(),
  });
}

async function handleHelpSection(ctx, sectionKey) {
  const section = msg.HELP_SECTIONS[sectionKey];
  if (!section) {
    // Устаревшая/битая кнопка — просто показываем меню заново
    await handleHelp(ctx);
    return;
  }
  await ctx.send({
    message: section.text,
    keyboard: buildHelpKeyboard(),
  });
}

module.exports = {
  handleTopFactories,
  handleTopBalance,
  handleTopClans,
  handleTopRobot,
  handleTopSuperRobot,
  handleHelp,
  handleHelpSection,
};
