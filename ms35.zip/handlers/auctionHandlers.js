'use strict';

const players = require('../db/players');
const auctionsDb = require('../db/auctions');
const auction = require('../game/auction');
const calc = require('../game/calc');
const C = require('../game/constants');
const { isAdmin } = require('./adminHandlers');

function sellHelpText() {
  const weapons = Object.keys(C.WEAPONS).join(', ');
  const airDefense = Object.keys(C.AIR_DEFENSE).join(', ');
  return (
    `Формат: продать [товар] [кол-во] [стартовая_цена] [шаг] [часов]\n\n` +
    `📦 Что можно выставить:\n` +
    `⚔️ Оружие: ${weapons}\n` +
    `🛅 ПВО: ${airDefense}\n` +
    `🏭 Заводы: завод\n` +
    `🔬 Научные центры: наука`
  );
}

async function requireRegistered(ctx) {
  const player = await players.getPlayer(ctx.senderId);
  if (!player || player.registration_step !== 'done') {
    await ctx.send('⛔ Вы ещё не зарегистрированы. Напишите старт');
    return null;
  }
  return player;
}

function formatTimeLeft(endTime) {
  const ms = new Date(endTime).getTime() - Date.now();
  return calc.formatDuration(Math.max(ms, 0));
}

async function handleList(ctx) {
  if (!(await requireRegistered(ctx))) return;

  const lots = await auctionsDb.getActiveAuctions();
  if (!lots.length) {
    await ctx.send(`🛎️ Сейчас на аукционе нет активных лотов.\n\n${sellHelpText()}`);
    return;
  }

  const bidderIds = lots.map((lot) => lot.current_bidder_id).filter(Boolean);
  const biddersMap = await players.getPlayersByIds(bidderIds);

  let text = `🛎️ АУКЦИОН — АКТИВНЫЕ ЛОТЫ\n\n`;
  for (const lot of lots) {
    const bidLine = lot.current_bid ? `Ставка: ${calc.formatNumber(lot.current_bid)} вирт` : `Старт: ${calc.formatNumber(lot.start_price)} вирт`;
    const bidder = lot.current_bidder_id ? biddersMap[lot.current_bidder_id] : null;
    const leaderLine = bidder ? `\nЛидирует: [id${bidder.vk_id}|${bidder.state_name}]` : '';
    text += `№${lot.id} — ${lot.item_name} x${lot.quantity}\n${bidLine} | ⏳ ${formatTimeLeft(lot.end_time)}${leaderLine}\n\n`;
  }
  text += `Подробнее: аукцион [номер]\nСтавка: ставка [номер] [сумма]\n\n${sellHelpText()}`;

  await ctx.send(text);
}

async function handleDetails(ctx, idArg) {
  if (!(await requireRegistered(ctx))) return;

  const id = parseInt(idArg, 10);
  const lot = id ? await auctionsDb.getAuctionById(id) : null;
  if (!lot) {
    await ctx.send('⛔ Лот не найден. Формат: аукцион [номер]');
    return;
  }

  const seller = await players.getPlayer(lot.seller_id);
  const bidder = lot.current_bidder_id ? await players.getPlayer(lot.current_bidder_id) : null;
  const minNext = lot.current_bid ? Number(lot.current_bid) + Number(lot.min_step) : Number(lot.start_price);

  let text =
    `🛎️ ЛОТ №${lot.id} [${lot.status}]\n` +
    `Продавец: [id${lot.seller_id}|${seller ? seller.state_name : 'неизвестно'}]\n` +
    `Товар: ${lot.item_name} x${lot.quantity}\n` +
    `Старт: ${calc.formatNumber(lot.start_price)} вирт | Шаг: ${calc.formatNumber(lot.min_step)}\n`;

  if (lot.status === 'active') {
    text += `Текущая ставка: ${lot.current_bid ? calc.formatNumber(lot.current_bid) + ' вирт' : '—'}\n`;
    text += `Лидирует: ${bidder ? `[id${bidder.vk_id}|${bidder.state_name}]` : '— пока никто'}\n`;
    text += `⏳ Осталось: ${formatTimeLeft(lot.end_time)}\n\n`;
    text += `Минимальная следующая ставка: ${calc.formatNumber(minNext)}\nСтавка: ставка ${lot.id} [сумма]`;
  }

  await ctx.send(text);
}

async function handleCreate(ctx, itemName, qtyArg, startArg, stepArg, hoursArg) {
  if (!(await requireRegistered(ctx))) return;

  if (!isAdmin(ctx.senderId)) {
    await ctx.send('⛔ Выставлять лоты на аукцион может только администратор.');
    return;
  }

  const quantity = parseInt(qtyArg, 10);
  const startPrice = parseInt(startArg, 10);
  const minStep = parseInt(stepArg, 10);
  const hours = parseFloat(hoursArg);

  if (!itemName || !quantity || !startPrice || !minStep || !hours) {
    await ctx.send(`⛔ ${sellHelpText()}`);
    return;
  }

  const result = await auction.createLot(ctx.senderId, itemName, quantity, startPrice, minStep, hours);
  if (!result.ok) {
    const reasons = {
      unknown_item: `⛔ Неизвестный товар.\n\n${sellHelpText()}`,
      invalid_quantity: '⛔ Некорректное количество.',
      invalid_price: '⛔ Некорректная стартовая цена.',
      invalid_step: '⛔ Некорректный шаг ставки.',
      invalid_duration: `⛔ Длительность от 1 до ${result.max || ''} часов.`,
      not_enough_items: `⛔ У вас недостаточно этого товара (есть: ${result.have}).`,
    };
    await ctx.send(reasons[result.reason] || '⛔ Не удалось выставить лот.');
    return;
  }

  await ctx.send(`✅ Лот №${result.auction.id} выставлен на аукцион: ${itemName} x${quantity}, старт ${calc.formatNumber(startPrice)} вирт.`);
}

async function handleBid(ctx, idArg, amountArg) {
  if (!(await requireRegistered(ctx))) return;

  const id = parseInt(idArg, 10);
  const amount = parseInt(amountArg, 10);
  if (!id || !amount) {
    await ctx.send('⛔ Формат: ставка [номер] [сумма]');
    return;
  }

  const result = await auction.placeBid(ctx.senderId, id, amount, ctx.bot);
  if (!result.ok) {
    const reasons = {
      not_found: '⛔ Лот не найден или уже завершён.',
      ended: '⛔ Торги по этому лоту уже завершились.',
      own_lot: '⛔ Нельзя делать ставки на собственный лот.',
      bid_too_low: `⛔ Минимальная ставка сейчас: ${result.minRequired}.`,
      not_enough_money: `⛔ Недостаточно вирт. Не хватает ${calc.formatNumber(result.missing)}.`,
    };
    await ctx.send(reasons[result.reason] || '⛔ Не удалось сделать ставку.');
    return;
  }

  let text = `✅ Ставка ${calc.formatNumber(amount)} вирт принята на лот №${id}!`;
  if (result.extended) text += `\n⏳ Аукцион продлён на 5 минут (ставка в последнюю минуту).`;
  await ctx.send(text);
}

async function handleCancel(ctx, idArg) {
  if (!(await requireRegistered(ctx))) return;

  const id = parseInt(idArg, 10);
  if (!id) {
    await ctx.send('⛔ Формат: отмена [номер]');
    return;
  }

  const result = await auction.cancelLot(ctx.senderId, id);
  if (!result.ok) {
    const reasons = {
      not_found: '⛔ Лот не найден или уже завершён.',
      not_owner: '⛔ Это не ваш лот.',
      has_bids: '⛔ Нельзя отменить лот — по нему уже есть ставки.',
    };
    await ctx.send(reasons[result.reason] || '⛔ Не удалось отменить лот.');
    return;
  }

  await ctx.send(`✅ Лот №${id} отменён, товар возвращён в ваш арсенал.`);
}

async function handleMyLots(ctx) {
  if (!(await requireRegistered(ctx))) return;

  const lots = await auctionsDb.getMyLots(ctx.senderId);
  if (!lots.length) {
    await ctx.send('У вас пока нет лотов на аукционе.');
    return;
  }

  const bidderIds = lots.map((lot) => lot.current_bidder_id).filter(Boolean);
  const biddersMap = await players.getPlayersByIds(bidderIds);

  let text = `📋 ВАШИ ЛОТЫ\n\n`;
  for (const lot of lots) {
    text += `№${lot.id} — ${lot.item_name} x${lot.quantity} [${lot.status}]\n`;
    if (lot.status === 'active') {
      const bidder = lot.current_bidder_id ? biddersMap[lot.current_bidder_id] : null;
      text += `Ставка: ${lot.current_bid ? calc.formatNumber(lot.current_bid) + ' вирт' : '—'} | ⏳ ${formatTimeLeft(lot.end_time)}\n`;
      text += `Лидирует: ${bidder ? `[id${bidder.vk_id}|${bidder.state_name}]` : '— пока никто'}\n`;
    }
    text += '\n';
  }

  await ctx.send(text.trim());
}

module.exports = { handleList, handleDetails, handleCreate, handleBid, handleCancel, handleMyLots };
