-- ===================== СХЕМА БАЗЫ ДАННЫХ =====================

CREATE TABLE IF NOT EXISTS players (
    vk_id BIGINT PRIMARY KEY,
    state_name TEXT UNIQUE,               -- название государства
    x INTEGER,                            -- координата X
    y INTEGER,                            -- координата Y
    balance BIGINT NOT NULL DEFAULT 100,  -- вирты
    factories INTEGER NOT NULL DEFAULT 0, -- количество активных (не уничтоженных) заводов
    gold_mines INTEGER[] DEFAULT '{}',    -- индексы заводов "золотая жила" (условно, храним как счётчик ниже)
    gold_mine_count INTEGER NOT NULL DEFAULT 0, -- сколько из заводов — золотые жилы (x2 дохода)
    destroyed_factories INTEGER NOT NULL DEFAULT 0, -- статистика: сколько заводов у игрока снесли навсегда (восстановление отключено)
    arsenal JSONB NOT NULL DEFAULT '{}',        -- {"Герань-2": 3, "Калибр": 1}
    air_defense JSONB NOT NULL DEFAULT '{}',    -- {"Бук-М3": 1}
    air_defense_damage JSONB NOT NULL DEFAULT '{}', -- накопленный урон по "прочности" текущей единицы ПВО каждого типа, см. AIR_DEFENSE.durability
    blocked_factories JSONB NOT NULL DEFAULT '[]', -- [{"count": 3, "unblock_at": "ISO"}]
    radiation_until TIMESTAMPTZ,           -- радиация действует до
    clan_id INTEGER,
    clan_role TEXT,                        -- 'leader' | 'member'
    registration_step TEXT NOT NULL DEFAULT 'done', -- 'awaiting_name' | 'done'
    factory_damage INTEGER NOT NULL DEFAULT 0, -- накопленные "единицы урона" по заводам для системы ХП (см. HITS_TO_DESTROY)
    enemy_factories_destroyed INTEGER NOT NULL DEFAULT 0, -- статистика: сколько вражеских заводов снёс безвозвратно
    last_daily_bonus TIMESTAMPTZ,          -- когда последний раз забирали ежедневный бонус
    vip_until TIMESTAMPTZ,                 -- VIP-статус активен до этой даты (донат-бонусы)
    robot_level INTEGER NOT NULL DEFAULT 1,        -- уровень робота (1-50)
    robot_last_farm_at TIMESTAMPTZ,                -- когда робот последний раз мгновенно приносил вирты (команда "робот")
    robot_last_send_at TIMESTAMPTZ,                -- когда робота последний раз "отправляли" за жетонами (команда "отправить")
    last_seen TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_players_factories ON players (factories DESC);
CREATE INDEX IF NOT EXISTS idx_players_balance ON players (balance DESC);

-- Восстановление заводов отключено, таблица больше не используется в новой логике,
-- но оставлена для обратной совместимости со старыми БД (данные не удаляются).
CREATE TABLE IF NOT EXISTS destroyed_factories (
    id SERIAL PRIMARY KEY,
    player_id BIGINT NOT NULL REFERENCES players(vk_id) ON DELETE CASCADE,
    destroyed_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    restore_at TIMESTAMPTZ NOT NULL
);

-- Клановые данные
CREATE TABLE IF NOT EXISTS clans (
    id SERIAL PRIMARY KEY,
    name TEXT UNIQUE NOT NULL,
    leader_id BIGINT NOT NULL REFERENCES players(vk_id),
    vault BIGINT NOT NULL DEFAULT 0,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    bonus_forsazh_until TIMESTAMPTZ,
    bonus_eshelon_until TIMESTAMPTZ,
    bonus_industry_until TIMESTAMPTZ,
    bonus_forsazh_cooldown TIMESTAMPTZ,
    bonus_eshelon_cooldown TIMESTAMPTZ,
    bonus_industry_cooldown TIMESTAMPTZ
);

-- Приглашения в клан
CREATE TABLE IF NOT EXISTS clan_invites (
    id SERIAL PRIMARY KEY,
    clan_id INTEGER NOT NULL REFERENCES clans(id) ON DELETE CASCADE,
    player_id BIGINT NOT NULL REFERENCES players(vk_id) ON DELETE CASCADE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE(clan_id, player_id)
);

-- Очереди производства
CREATE TABLE IF NOT EXISTS production_queue (
    id SERIAL PRIMARY KEY,
    player_id BIGINT NOT NULL REFERENCES players(vk_id) ON DELETE CASCADE,
    weapon TEXT NOT NULL,
    quantity INTEGER NOT NULL,
    factories_used INTEGER NOT NULL,
    started_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    ready_at TIMESTAMPTZ NOT NULL,
    collected BOOLEAN NOT NULL DEFAULT FALSE
);

-- Атаки в полёте
CREATE TABLE IF NOT EXISTS attacks_in_flight (
    id SERIAL PRIMARY KEY,
    attacker_id BIGINT NOT NULL REFERENCES players(vk_id) ON DELETE CASCADE,
    defender_id BIGINT NOT NULL REFERENCES players(vk_id) ON DELETE CASCADE,
    weapon TEXT NOT NULL,
    quantity INTEGER NOT NULL,
    distance_km NUMERIC NOT NULL,
    launched_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    arrival_at TIMESTAMPTZ NOT NULL,
    resolved BOOLEAN NOT NULL DEFAULT FALSE,
    peer_id BIGINT -- id беседы для глобального лога, если атака была инициирована из беседы (иначе NULL)
);

-- Кулдауны атак на конкретную цель
CREATE TABLE IF NOT EXISTS attack_cooldowns (
    attacker_id BIGINT NOT NULL REFERENCES players(vk_id) ON DELETE CASCADE,
    defender_id BIGINT NOT NULL REFERENCES players(vk_id) ON DELETE CASCADE,
    last_attack_at TIMESTAMPTZ NOT NULL,
    PRIMARY KEY (attacker_id, defender_id)
);

-- Кулдауны переводов вирт одному и тому же игроку (1 раз в 2 часа на получателя)
CREATE TABLE IF NOT EXISTS transfer_cooldowns (
    sender_id BIGINT NOT NULL REFERENCES players(vk_id) ON DELETE CASCADE,
    receiver_id BIGINT NOT NULL REFERENCES players(vk_id) ON DELETE CASCADE,
    last_transfer_at TIMESTAMPTZ NOT NULL,
    PRIMARY KEY (sender_id, receiver_id)
);

-- Лог построек заводов, для лимита "не более 10 заводов в час"
CREATE TABLE IF NOT EXISTS factory_build_log (
    id SERIAL PRIMARY KEY,
    player_id BIGINT NOT NULL REFERENCES players(vk_id) ON DELETE CASCADE,
    built_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_factory_build_log_player_time ON factory_build_log (player_id, built_at);

-- На случай если таблица players уже существовала до добавления новых колонок (миграция)
ALTER TABLE players ADD COLUMN IF NOT EXISTS factory_damage INTEGER NOT NULL DEFAULT 0;
ALTER TABLE players ADD COLUMN IF NOT EXISTS last_daily_bonus TIMESTAMPTZ;
ALTER TABLE players ADD COLUMN IF NOT EXISTS enemy_factories_destroyed INTEGER NOT NULL DEFAULT 0;

-- ===================== РОБОТ (переработан, старый питомец-майнер удалён) =====================
-- Раньше был "питомец": запускался в добычу, доход копился и его нужно было забирать отдельной
-- командой. Новый робот работает мгновенно: команда "робот" сразу зачисляет доход (раз в час),
-- а "отправить" сразу выдаёт жетоны (тоже раз в час). Переносим уровень со старой колонки
-- pet_level в robot_level, если апгрейд идёт со старой БД, и убираем колонки старого механизма
-- добычи, которые больше не используются.
DO $$
BEGIN
  IF EXISTS (
    SELECT 1 FROM information_schema.columns WHERE table_name = 'players' AND column_name = 'pet_level'
  ) AND NOT EXISTS (
    SELECT 1 FROM information_schema.columns WHERE table_name = 'players' AND column_name = 'robot_level'
  ) THEN
    ALTER TABLE players RENAME COLUMN pet_level TO robot_level;
  END IF;
END $$;
ALTER TABLE players ADD COLUMN IF NOT EXISTS robot_level INTEGER NOT NULL DEFAULT 1;
ALTER TABLE players ADD COLUMN IF NOT EXISTS robot_last_farm_at TIMESTAMPTZ;
ALTER TABLE players ADD COLUMN IF NOT EXISTS robot_last_send_at TIMESTAMPTZ;
ALTER TABLE players DROP COLUMN IF EXISTS pet_mining_started_at;
ALTER TABLE players DROP COLUMN IF EXISTS pet_last_collected_at;

-- Магазин (текущий ассортимент)
CREATE TABLE IF NOT EXISTS shop_state (
    id INTEGER PRIMARY KEY DEFAULT 1,
    items JSONB NOT NULL DEFAULT '[]', -- [{"key": "Герань-2", "type": "weapon", "qty": 3}]
    refreshed_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    locked_until TIMESTAMPTZ -- блокировка магазина после покупки ядерки
);

INSERT INTO shop_state (id, items) VALUES (1, '[]') ON CONFLICT (id) DO NOTHING;

-- Глобальный peer_id беседы для трансляции логов (если бот добавлен в беседу)
CREATE TABLE IF NOT EXISTS broadcast_chats (
    peer_id BIGINT PRIMARY KEY
);

-- Метаданные (последний раз выданы ежедневные награды и т.п.)
CREATE TABLE IF NOT EXISTS game_meta (
    key TEXT PRIMARY KEY,
    value TEXT
);

-- ===================== НОВЫЕ МЕХАНИКИ =====================

-- Работа и жетоны (мгновенная награда через мини-игру)
ALTER TABLE players ADD COLUMN IF NOT EXISTS tokens INTEGER NOT NULL DEFAULT 0;
ALTER TABLE players DROP COLUMN IF EXISTS work_started_at; -- механика ожидания смены удалена
ALTER TABLE players ADD COLUMN IF NOT EXISTS last_work_time TIMESTAMPTZ;
ALTER TABLE players ADD COLUMN IF NOT EXISTS work_count_today INTEGER NOT NULL DEFAULT 0;
ALTER TABLE players ADD COLUMN IF NOT EXISTS work_day DATE;
-- Текущая сессия мини-игры "работа": {round, boxes, correctIndex, expiresAt}, NULL если игра не идёт
ALTER TABLE players ADD COLUMN IF NOT EXISTS work_session JSONB;

-- Дневные лимиты обмена жетонов (склад-"кейс" и обмен на заводы), сбрасываются
-- в 00:00 МСК по тому же принципу, что и work_count_today/work_day выше.
ALTER TABLE players ADD COLUMN IF NOT EXISTS exchange_factory_count_today INTEGER NOT NULL DEFAULT 0;
ALTER TABLE players ADD COLUMN IF NOT EXISTS exchange_factory_day DATE;
ALTER TABLE players ADD COLUMN IF NOT EXISTS exchange_case_count_today INTEGER NOT NULL DEFAULT 0;
ALTER TABLE players ADD COLUMN IF NOT EXISTS exchange_case_day DATE;
ALTER TABLE players ADD COLUMN IF NOT EXISTS exchange_science_count_today INTEGER NOT NULL DEFAULT 0;
ALTER TABLE players ADD COLUMN IF NOT EXISTS exchange_science_day DATE;

-- Обратный обмен: научные центры -> заводы (game/science.js exchangeToFactories), тот же
-- принцип сброса в 00:00 МСК, что и остальные дневные лимиты обмена выше.
ALTER TABLE players ADD COLUMN IF NOT EXISTS exchange_science_to_factory_count_today INTEGER NOT NULL DEFAULT 0;
ALTER TABLE players ADD COLUMN IF NOT EXISTS exchange_science_to_factory_day DATE;

-- Реферальная программа: кто пригласил + начислена ли уже награда
ALTER TABLE players ADD COLUMN IF NOT EXISTS referred_by BIGINT;
ALTER TABLE players ADD COLUMN IF NOT EXISTS referral_rewarded BOOLEAN NOT NULL DEFAULT FALSE;

-- Научные центры
ALTER TABLE players ADD COLUMN IF NOT EXISTS science_centers INTEGER NOT NULL DEFAULT 0;
ALTER TABLE players ADD COLUMN IF NOT EXISTS science_limit_level INTEGER NOT NULL DEFAULT 1;

-- Торговые посты — механика удалена, колонка вычищается из старых БД
ALTER TABLE players DROP COLUMN IF EXISTS trade_post_level;

-- Расширение лимита заводов
ALTER TABLE players ADD COLUMN IF NOT EXISTS factory_limit_level INTEGER NOT NULL DEFAULT 0;

-- Аукцион между игроками
CREATE TABLE IF NOT EXISTS auctions (
    id SERIAL PRIMARY KEY,
    seller_id BIGINT NOT NULL REFERENCES players(vk_id) ON DELETE CASCADE,
    item_type TEXT NOT NULL,        -- 'weapon' | 'air_defense' | 'factory' | 'science'
    item_name TEXT NOT NULL,
    quantity INTEGER NOT NULL,
    start_price BIGINT NOT NULL,
    min_step BIGINT NOT NULL,
    end_time TIMESTAMPTZ NOT NULL,
    current_bid BIGINT,
    current_bidder_id BIGINT REFERENCES players(vk_id),
    status TEXT NOT NULL DEFAULT 'active', -- 'active' | 'completed' | 'cancelled'
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_auctions_status ON auctions (status, end_time);

-- Промокоды
CREATE TABLE IF NOT EXISTS promocodes (
    code TEXT PRIMARY KEY,
    reward_type TEXT NOT NULL,      -- 'weapon' | 'air_defense' | 'virts' | 'tokens' | 'science'
    reward_name TEXT,               -- название оружия/ПВО (для остальных типов не нужно)
    reward_quantity INTEGER NOT NULL DEFAULT 1,
    max_uses INTEGER NOT NULL DEFAULT 1,
    used_count INTEGER NOT NULL DEFAULT 0,
    expires_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Кто уже активировал какой промокод (1 раз на игрока)
CREATE TABLE IF NOT EXISTS promocode_redemptions (
    code TEXT NOT NULL REFERENCES promocodes(code) ON DELETE CASCADE,
    player_id BIGINT NOT NULL REFERENCES players(vk_id) ON DELETE CASCADE,
    redeemed_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    PRIMARY KEY (code, player_id)
);

-- Кулдауны запуска оружия по категориям (не привязаны к цели — см. game/combat.js)
ALTER TABLE players ADD COLUMN IF NOT EXISTS last_drone_attack_at TIMESTAMPTZ;
ALTER TABLE players ADD COLUMN IF NOT EXISTS last_missile_attack_at TIMESTAMPTZ;
ALTER TABLE players ADD COLUMN IF NOT EXISTS last_nuke_attack_at TIMESTAMPTZ;

-- Возможность отключить общую рассылку "кто-кого атаковал", которая приходит всем игрокам
ALTER TABLE players ADD COLUMN IF NOT EXISTS attack_log_notifications BOOLEAN NOT NULL DEFAULT TRUE;

-- ===================== VIP (донат-статус) =====================
-- Действует до этой даты; NULL / прошедшая дата = VIP не активен.
-- Выдаётся вручную админом после оплаты (см. !админ vip). Даёт бонус к доходу,
-- ускоренные кулдауны робота и увеличенный лимит построек в час — см. game/calc.js, game/robot.js, game/economy.js.
ALTER TABLE players ADD COLUMN IF NOT EXISTS vip_until TIMESTAMPTZ;

-- ===================== МАЙНЕР (донат-предмет) =====================
-- Действует до этой даты; NULL / прошедшая дата = майнер не активен. Выдаётся вручную админом
-- после оплаты (см. !админ майнер), аналогично VIP. Пока активен — раз в час пассивно
-- начисляет немного вирт и с шансом жетон (см. game/miner.js, game/constants.js).
ALTER TABLE players ADD COLUMN IF NOT EXISTS miner_until TIMESTAMPTZ;

-- ===================== СУПЕРРОБОТ =====================
-- Отдельный от обычного робота боевой юнит (50 уровней, качается жетонами, тяжело).
-- 0 = ещё не построен/не прокачан ни разу. Умеет атаковать других игроков (снос заводов),
-- в отличие от обычного робота. См. game/superRobot.js.
ALTER TABLE players ADD COLUMN IF NOT EXISTS super_robot_level INTEGER NOT NULL DEFAULT 0;
ALTER TABLE players ADD COLUMN IF NOT EXISTS super_robot_last_attack_at TIMESTAMPTZ;

-- Система "прочности" ПВО (см. game/constants.js: AIR_DEFENSE.durability, WEAPONS.*.adWear):
-- накопленный урон по текущей "изнашиваемой" единице ПВО каждого типа. Когда накопленный
-- урон достигает durability этого типа ПВО — одна физическая единица реально уничтожается.
ALTER TABLE players ADD COLUMN IF NOT EXISTS air_defense_damage JSONB NOT NULL DEFAULT '{}';

-- Уровень сейфа клана: копится от ВСЕХ поступлений в сейф (налог с дохода + ручные пополнения)
-- и никогда не уменьшается тратами/снятием — это "прогресс" клана, а не баланс.
-- vault_total_collected — сколько всего когда-либо поступило в сейф (нарастающим итогом).
-- vault_level — текущий уровень (0-100), кэш от vault_total_collected / 10000, обновляется при пополнении.
ALTER TABLE clans ADD COLUMN IF NOT EXISTS vault_total_collected BIGINT NOT NULL DEFAULT 0;
ALTER TABLE clans ADD COLUMN IF NOT EXISTS vault_level INTEGER NOT NULL DEFAULT 0;

-- Часовые лимиты производства/получения оружия и ПВО (см. game/hourlyLimit.js).
-- Счётчик хранится "по часовому окну": hour_bucket = date_trunc('hour', NOW()) на момент
-- последнего расхода. Если текущий час не совпадает с hour_bucket — счётчик считается нулевым
-- (сброс не требует отдельной cron-задачи, просто игнорируем устаревшее значение при чтении/записи).
CREATE TABLE IF NOT EXISTS hourly_production_limits (
    player_id BIGINT NOT NULL REFERENCES players(vk_id) ON DELETE CASCADE,
    category TEXT NOT NULL, -- 'drone' | 'missile' | 'nuke' | 'air_defense'
    hour_bucket TIMESTAMPTZ NOT NULL,
    quantity INTEGER NOT NULL DEFAULT 0,
    PRIMARY KEY (player_id, category)
);
