'use strict';

const players = require('../db/players');
const clansDb = require('../db/clans');
const production = require('../db/production');
const calc = require('../game/calc');
const C = require('../game/constants');
const msg = require('../utils/messages');
const events = require('../game/events');
const donateBuffs = require('../game/donateBuffs');
const styles = require('../game/styles');
const postLikes = require('../game/postLikes');

function isAdmin(vkId) {
  return C.ADMIN_IDS.includes(vkId);
}

function findWeaponKey(name) {
  const lower = (name || '').toLowerCase();
  return Object.keys(C.WEAPONS).find((k) => k.toLowerCase() === lower);
}

function findAirDefenseKey(name) {
  const lower = (name || '').toLowerCase();
  return Object.keys(C.AIR_DEFENSE).find((k) => k.toLowerCase() === lower);
}

const ADMIN_HELP_PART1 = `🛠️ АДМИН-КОМАНДЫ

!админ баланс @юзер [сумма] — прибавить/отнять вирты (можно с минусом)
!админ завод @юзер [кол-во] — выдать заводы
!админ снести @юзер [кол-во] — принудительно снести заводы (без защиты новичков)
!админ оружие @юзер [название] [кол-во] — выдать оружие
!админ пво @юзер [название] [кол-во] — выдать ПВО
!админ разблок @юзер — снять все блокировки заводов
!админ инфо @юзер — полная информация об игроке
!админ обнулить @юзер — сбросить весь игровой прогресс игрока (баланс/заводы/оружие/жетоны/лимиты/питомец)
!админ обнулить всех — сбросить прогресс АБСОЛЮТНО ВСЕМ игрокам (осторожно!)
!админ вернутьдоход @юзер — разово вернуть 50% от текущего часового дохода игрока на баланс
!админ вернутьдоход всех — то же самое разом всем активным игрокам
!админ vip @юзер [дни] — выдать/продлить VIP-статус на N дней (после получения оплаты)
!админ vip @юзер снять — досрочно снять VIP-статус
!админ майнер @юзер [дни] — выдать/продлить майнер (донат) на N дней (после получения оплаты)
!админ майнер @юзер снять — досрочно снять майнер
!админ суперробот @юзер [уровень] — выдать/повысить уровень суперробота (макс. ${C.SUPER_ROBOT_MAX_LEVEL})
!админ суперробот @юзер снять — снести суперробота (уровень 0)
!админ фото @юзер — выдать кастомное фото профиля (прикрепите фото К ЭТОМУ ЖЕ сообщению) — добавляется в инвентарь стилей игрока
!админ фото @юзер снять — убрать фото профиля (полный сброс, включая принудительную фиксацию)
!админ видео @юзер — выдать кастомное видео профиля (прикрепите видео К ЭТОМУ ЖЕ сообщению) — добавляется в инвентарь стилей игрока
!админ видео @юзер снять — убрать видео профиля (полный сброс, включая принудительную фиксацию)
!админ стильфикс @юзер — принудительно поставить фото/видео-стиль (с вложением) — игрок НЕ сможет сам его сменить или продать
!админ стильфикс @юзер снять — снять принудительную фиксацию стиля (отмена команды выше)
!админ кланфото [название клана] — выдать кастомное фото клана (прикрепите фото К ЭТОМУ ЖЕ сообщению)
!админ кланфото [название клана] снять — убрать фото клана
!админ кланвидео [название клана] — выдать кастомное видео клана (прикрепите видео К ЭТОМУ ЖЕ сообщению)
!админ кланвидео [название клана] снять — убрать видео клана
!админ игроки [страница] — список всех игроков: кликабельные ссылки + игровые данные (по 15 на странице)
!админ рассылка [текст] — сообщение всем активным игрокам
!админ помощь — этот список

📄 Продолжение (донат-товары, ивенты, промокоды): !админ помощь2`;

const ADMIN_HELP_PART2 = `🛠️ АДМИН-КОМАНДЫ (продолжение)

💸 Расходуемые донат-товары (мгновенные ускорители — разовые, сгорают сразу; дневные баффы —
истекают через N часов/дней и стимулируют покупать снова; см. game/constants.js: DONATE_*):

⚡ Мгновенные ускорители:
!админ сброс @юзер [робот|суперробот|дозор] — мгновенный сброс кулдауна (${C.DONATE_INSTANT_COOLDOWN_PRICE_RUB}₽)
!админ финиш @юзер — мгновенное завершение текущего производства (${C.DONATE_INSTANT_PRODUCTION_PRICE_RUB}₽)
!админ работа @юзер [кол-во=${C.DONATE_WORK_EXTRA_ATTEMPTS}] — доп. попытки "работы" сверх дневного лимита сегодня (${C.DONATE_WORK_EXTRA_PRICE_RUB}₽)
!админ обмен @юзер — снять сегодняшний лимит обмена жетонов на завод/науку (${C.DONATE_EXCHANGE_LIMIT_LIFT_PRICE_RUB}₽)

🔥 Дневные баффы (действуют по стрику — см. !донат):
!админ доход @юзер [1.5|2] [часы=${C.DONATE_INCOME_BOOST_DURATION_HOURS}] — буст дохода x1.5 (${C.DONATE_INCOME_BOOST_PRICE_RUB_X15}₽) или x2 (${C.DONATE_INCOME_BOOST_PRICE_RUB_X2}₽)
!админ щит @юзер [дни=${C.DONATE_SHIELD_DURATION_DAYS}] — щит от НЕядерного оружия (${C.DONATE_SHIELD_PRICE_RUB}₽/${C.DONATE_SHIELD_DURATION_DAYS}дн; ядерное оружие щит не блокирует!)
!админ дубль @юзер [часы=${C.DONATE_WORK_DOUBLE_DURATION_HOURS}] — x2 жетонов за "работу" (${C.DONATE_WORK_DOUBLE_PRICE_RUB}₽)
!админ ускорение @юзер [часы=${C.DONATE_FARM_BOOST_DURATION_HOURS}] — ускоренная добыча на ферме x${C.DONATE_FARM_BOOST_MULTIPLIER} (${C.DONATE_FARM_BOOST_PRICE_RUB}₽)
!админ vip @юзер 1 — "VIP-день" (${C.DONATE_VIP_DAY_PRICE_RUB}₽), та же команда, что и обычный VIP, просто на 1 день
!админ боссбафф @юзер — x2 к награде за попадание по мировому боссу, строго на 1 день (${C.DONATE_BOSS_DOUBLE_PRICE_RUB}₽)

👹 Мировой босс (кооп-ивент — см. игрокам команда "босс"):
!админ босс старт — запустить босса + разослать всем активным игрокам
!админ босс финиш — завершить босса и выдать всем участникам награды
!админ босс статус — текущая статистика/топ по попаданиям

🔥 Глобальный ивент-буст дохода (см. игрокам просто рассылку — постоянной команды статуса нет):
!админ буст [множитель] [минут] — временно умножить доход ВСЕХ игроков (заводы + наука) при следующем часовом начислении + разослать всем
!админ буст снять — досрочно снять глобальный буст

👍 Система штрафа за нелайкнутые посты (см. game/postLikes.js):
!админ лайки вкл — включить систему
!админ лайки выкл — выключить систему (штраф сразу снимается со всех)
!админ лайки статус — текущее состояние (вкл/выкл + интервал)
!админ лайки интервал [5ч|день|3дня|5дней|30дней|60дней|все] — за какой период учитывать посты

💱 Курс фермы (нанокоин → вирты, см. game/farm.js):
!админ курсферма [мин] [макс] — задать коридор курса, например !админ курсферма 20 50. Раз в час курс случайно
  скачет на одну из двух границ коридора (50/50 — либо мин, либо макс), а не плавно блуждает. Меняется сразу же.

🎯 Флеш-акция (ежедневное окно предложения, FOMO):
!админ акция [товар] [скидка%] [минут] — запустить акцию + разослать всем активным игрокам
!админ акция снять — снять текущую акцию досрочно

🎉 Сезонные ивенты:
!админ ивент [зима|весна|лето|осень] — запустить сезон (валюта начинает капать за действия игроков)
!админ ивент стоп — выключить текущий ивент (валюта капать перестаёт, накопленное остаётся)
!админ ивентмагазин открыть — открыть ивент-магазин (обмен валюты на заводы/науку/VIP)
!админ ивентмагазин закрыть — закрыть ивент-магазин (валюту продолжают копить, купить нельзя)

🎟️ Промокоды:
промо создать [код] [тип] [название|-] [кол-во] [лимит] [часов_жизни|0] [vip] — создать промокод (доп. "vip" в конце — активировать смогут только игроки с активным VIP)
  типы: weapon, air_defense, virts, tokens, science
промо список — активные промокоды
промо удалить [код] — удалить промокод
промо vip [код] [вкл|выкл] — включить/выключить ограничение "только VIP" у уже созданного промокода задним числом (без пересоздания — если при создании забыли добавить "vip" в конце)`;

async function requireTarget(ctx, targetId) {
  if (!targetId) {
    await ctx.send('⛔ Укажите игрока: !админ [команда] @юзер ...');
    return null;
  }
  const target = await players.getPlayer(targetId);
  if (!target || target.registration_step !== 'done') {
    await ctx.send('⛔ Этот игрок не зарегистрирован.');
    return null;
  }
  return target;
}

async function handleAdmin(ctx, sub, targetId, rest) {
  const vkId = ctx.senderId;
  if (!isAdmin(vkId)) {
    await ctx.send('⛔ Команда недоступна.');
    return;
  }

  switch (sub) {
    case 'помощь': {
      await ctx.send(ADMIN_HELP_PART1);
      return;
    }

    case 'помощь2': {
      await ctx.send(ADMIN_HELP_PART2);
      return;
    }

    case 'баланс': {
      const target = await requireTarget(ctx, targetId);
      if (!target) return;
      const amount = parseInt(rest[0], 10);
      if (!Number.isInteger(amount)) {
        await ctx.send('⛔ Формат: !админ баланс @юзер [сумма]');
        return;
      }
      const newBalance = await players.updateBalance(targetId, amount);
      await ctx.send(
        `✅ Баланс «${target.state_name}» изменён на ${amount > 0 ? '+' : ''}${amount}. Текущий баланс: ${calc.formatNumber(
          newBalance
        )} вирт.`
      );
      return;
    }

    case 'завод': {
      const target = await requireTarget(ctx, targetId);
      if (!target) return;
      const amount = parseInt(rest[0], 10);
      if (!Number.isInteger(amount) || amount <= 0) {
        await ctx.send('⛔ Формат: !админ завод @юзер [кол-во]');
        return;
      }
      await players.addFactories(targetId, amount, false);
      await ctx.send(`✅ Игроку «${target.state_name}» выдано ${amount} ${msg.pluralFactories(amount)}.`);
      return;
    }

    case 'снести': {
      const target = await requireTarget(ctx, targetId);
      if (!target) return;
      const amount = parseInt(rest[0], 10);
      if (!Number.isInteger(amount) || amount <= 0) {
        await ctx.send('⛔ Формат: !админ снести @юзер [кол-во]');
        return;
      }
      let destroyed = 0;
      for (let i = 0; i < amount; i++) {
        const current = await players.getPlayer(targetId);
        if (!current || current.factories <= 0) break;
        await players.destroyOneFactory(targetId);
        destroyed++;
      }
      await ctx.send(`✅ У игрока «${target.state_name}» снесено ${destroyed} ${msg.pluralFactories(destroyed)}.`);
      return;
    }

    case 'оружие': {
      const target = await requireTarget(ctx, targetId);
      if (!target) return;
      const qty = parseInt(rest[rest.length - 1], 10);
      const weaponName = rest.slice(0, -1).join(' ');
      const weaponKey = findWeaponKey(weaponName);
      if (!weaponKey || !Number.isInteger(qty) || qty <= 0) {
        await ctx.send('⛔ Формат: !админ оружие @юзер [название] [кол-во]');
        return;
      }
      await players.addToArsenal(targetId, weaponKey, qty);
      await ctx.send(`✅ Игроку «${target.state_name}» выдано ${weaponKey} x${qty}.`);
      return;
    }

    case 'пво': {
      const target = await requireTarget(ctx, targetId);
      if (!target) return;
      const qty = parseInt(rest[rest.length - 1], 10);
      const adName = rest.slice(0, -1).join(' ');
      const adKey = findAirDefenseKey(adName);
      if (!adKey || !Number.isInteger(qty) || qty <= 0) {
        await ctx.send('⛔ Формат: !админ пво @юзер [название] [кол-во]');
        return;
      }
      await players.addToAirDefense(targetId, adKey, qty);
      await ctx.send(`✅ Игроку «${target.state_name}» выдано ПВО ${adKey} x${qty}.`);
      return;
    }

    case 'vip': {
      const target = await requireTarget(ctx, targetId);
      if (!target) return;

      if ((rest[0] || '').toLowerCase() === 'снять') {
        await players.setVipUntil(targetId, null);
        await ctx.send(`✅ VIP-статус игрока «${target.state_name}» снят.`);
        return;
      }

      const days = parseInt(rest[0], 10);
      if (!Number.isInteger(days) || days <= 0) {
        await ctx.send('⛔ Формат: !админ vip @юзер [дни] или !админ vip @юзер снять');
        return;
      }

      const now = new Date();
      const currentUntil = target.vip_until && new Date(target.vip_until) > now ? new Date(target.vip_until) : now;
      const newUntil = new Date(currentUntil.getTime() + days * 24 * 60 * 60 * 1000);
      await players.setVipUntil(targetId, newUntil);

      await ctx.send(
        `✅ VIP-статус игрока «${target.state_name}» активен до ${msg.formatDateTimeMsk(newUntil)} (+${days} дн.).`
      );
      if (ctx.bot) {
        await ctx.bot
          .notifyUser(
            targetId,
            `👑 Вам выдан VIP-статус до ${msg.formatDateTimeMsk(newUntil)}!\n` +
              `Бонусы: +${Math.round(C.VIP_INCOME_BONUS * 100)}% к доходу, кулдауны робота короче на ${Math.round(
                (1 - C.VIP_ROBOT_COOLDOWN_MULT) * 100
              )}%, +${C.VIP_BUILD_LIMIT_BONUS} построек завода в час.\nПроверить статус: мой робот`
          )
          .catch(() => {});
      }
      return;
    }

    case 'майнер': {
      const target = await requireTarget(ctx, targetId);
      if (!target) return;

      if ((rest[0] || '').toLowerCase() === 'снять') {
        await players.setMinerUntil(targetId, null);
        await ctx.send(`✅ Майнер игрока «${target.state_name}» снят.`);
        return;
      }

      // Майнер теперь разовая донат-покупка НАВСЕГДА (см. !донат), а не подписка на месяц —
      // ставим miner_until на MINER_FOREVER_YEARS лет вперёд, что везде в интерфейсе
      // (calc.isMinerForever) отображается игроку как "навсегда", а не конкретной датой.
      if ((rest[0] || '').toLowerCase() === 'навсегда') {
        const until = new Date(Date.now() + C.MINER_FOREVER_YEARS * 365 * 24 * 60 * 60 * 1000);
        await players.setMinerUntil(targetId, until);

        await ctx.send(`✅ Майнер игрока «${target.state_name}» выдан НАВСЕГДА.`);
        if (ctx.bot) {
          await ctx.bot
            .notifyUser(
              targetId,
              `⛏️ Вам выдан майнер НАВСЕГДА!\n` +
                `Каждый час пассивно приносит ${calc.formatNumber(C.MINER_HOURLY_VIRTS_MIN)} вирт и ${
                  C.MINER_HOURLY_TOKENS
                } жетонов. Проверить статус: майнер`
            )
            .catch(() => {});
        }
        return;
      }

      const days = parseInt(rest[0], 10);
      if (!Number.isInteger(days) || days <= 0) {
        await ctx.send('⛔ Формат: !админ майнер @юзер навсегда / [дни] / снять');
        return;
      }

      const now = new Date();
      const currentUntil =
        target.miner_until && new Date(target.miner_until) > now ? new Date(target.miner_until) : now;
      const newUntil = new Date(currentUntil.getTime() + days * 24 * 60 * 60 * 1000);
      await players.setMinerUntil(targetId, newUntil);

      await ctx.send(
        `✅ Майнер игрока «${target.state_name}» активен до ${msg.formatDateTimeMsk(newUntil)} (+${days} дн.).`
      );
      if (ctx.bot) {
        await ctx.bot
          .notifyUser(
            targetId,
            `⛏️ Вам выдан майнер до ${msg.formatDateTimeMsk(newUntil)}!\n` +
              `Каждый час пассивно приносит ${calc.formatNumber(C.MINER_HOURLY_VIRTS_MIN)} вирт и ${
                C.MINER_HOURLY_TOKENS
              } жетонов. Проверить статус: майнер`
          )
          .catch(() => {});
      }
      return;
    }

    case 'суперробот': {
      const target = await requireTarget(ctx, targetId);
      if (!target) return;

      if ((rest[0] || '').toLowerCase() === 'снять') {
        await players.setSuperRobotLevel(targetId, 0);
        await ctx.send(`✅ Суперробот игрока «${target.state_name}» снесён (уровень 0).`);
        return;
      }

      const level = parseInt(rest[0], 10);
      if (!Number.isInteger(level) || level <= 0) {
        await ctx.send('⛔ Формат: !админ суперробот @юзер [уровень] или !админ суперробот @юзер снять');
        return;
      }
      const clampedLevel = Math.min(level, C.SUPER_ROBOT_MAX_LEVEL);
      await players.setSuperRobotLevel(targetId, clampedLevel);

      await ctx.send(
        `✅ Суперроботу игрока «${target.state_name}» выдан уровень ${clampedLevel}${
          clampedLevel < level ? ` (ограничено максимумом ${C.SUPER_ROBOT_MAX_LEVEL})` : ''
        }.`
      );
      if (ctx.bot) {
        await ctx.bot
          .notifyUser(targetId, `🤖 Вам выдан суперробот уровня ${clampedLevel}!\nПроверить статус: суперробот`)
          .catch(() => {});
      }
      return;
    }

    case 'фото': {
      const target = await requireTarget(ctx, targetId);
      if (!target) return;

      if ((rest[0] || '').toLowerCase() === 'снять') {
        await players.setActiveStyle(targetId, null, null, null);
        await players.setStyleLocked(targetId, false);
        await ctx.send(`✅ Фото профиля игрока «${target.state_name}» убрано.`);
        return;
      }

      const photo = (ctx.attachments || []).find((a) => a.type === 'photo');
      if (!photo) {
        await ctx.send(
          '⛔ Прикрепите фото к этому же сообщению: !админ фото @юзер (с вложенной фотографией).'
        );
        return;
      }

      const attachmentString = photo.toString();
      const style = await styles.grantStyle(targetId, 'photo', attachmentString);
      await ctx.send(`✅ Игроку «${target.state_name}» выдано кастомное фото профиля (стиль #${style.id}, добавлен в инвентарь).`);
      if (ctx.bot) {
        await ctx.bot
          .notifyUser(targetId, `🖼️ Вам выдано кастомное фото профиля (стиль #${style.id})! Посмотреть: профиль. Все свои стили: стиль`)
          .catch(() => {});
      }
      return;
    }

    case 'видео': {
      const target = await requireTarget(ctx, targetId);
      if (!target) return;

      if ((rest[0] || '').toLowerCase() === 'снять') {
        await players.setActiveStyle(targetId, null, null, null);
        await players.setStyleLocked(targetId, false);
        await ctx.send(`✅ Видео профиля игрока «${target.state_name}» убрано.`);
        return;
      }

      const video = (ctx.attachments || []).find((a) => a.type === 'video');
      if (!video) {
        await ctx.send(
          '⛔ Прикрепите видео к этому же сообщению: !админ видео @юзер (с вложенным видео).'
        );
        return;
      }

      const attachmentString = video.toString();
      const style = await styles.grantStyle(targetId, 'video', attachmentString);
      await ctx.send(`✅ Игроку «${target.state_name}» выдано кастомное видео профиля (стиль #${style.id}, добавлен в инвентарь).`);
      if (ctx.bot) {
        await ctx.bot
          .notifyUser(targetId, `🎬 Вам выдано кастомное видео профиля (стиль #${style.id})! Посмотреть: профиль. Все свои стили: стиль`)
          .catch(() => {});
      }
      return;
    }

    case 'стильфикс': {
      // Принудительный стиль — игрок НЕ может его снять/сменить/продать, пока админ
      // явно не отменит фиксацию этой же командой с "снять".
      const target = await requireTarget(ctx, targetId);
      if (!target) return;

      if ((rest[0] || '').toLowerCase() === 'снять') {
        const result = await styles.unlockForcedStyle(targetId);
        if (!result.ok) {
          await ctx.send(result.reason === 'not_locked' ? '⛔ У игрока сейчас нет принудительного стиля.' : '⛔ Не удалось снять фиксацию.');
          return;
        }
        await ctx.send(`✅ Принудительная фиксация стиля у игрока «${target.state_name}» снята — теперь может менять/продавать стили сам.`);
        if (ctx.bot) {
          await ctx.bot.notifyUser(targetId, '🔓 Администратор снял фиксацию вашего стиля — теперь вы можете сами менять и продавать стили.').catch(() => {});
        }
        return;
      }

      const photo = (ctx.attachments || []).find((a) => a.type === 'photo');
      const video = (ctx.attachments || []).find((a) => a.type === 'video');
      if (!photo && !video) {
        await ctx.send(
          '⛔ Прикрепите фото или видео к этому же сообщению: !админ стильфикс @юзер (с вложением). Снять: !админ стильфикс @юзер снять'
        );
        return;
      }

      const kind = photo ? 'photo' : 'video';
      const attachmentString = (photo || video).toString();
      const style = await styles.grantForcedStyle(targetId, kind, attachmentString);
      await ctx.send(
        `✅ Игроку «${target.state_name}» принудительно установлен ${kind === 'photo' ? 'фото' : 'видео'}-стиль #${style.id}. ` +
          `Он НЕ сможет его сменить или продать, пока вы не снимете фиксацию: !админ стильфикс @юзер снять`
      );
      if (ctx.bot) {
        await ctx.bot
          .notifyUser(targetId, `🔒 Администратор установил вам стиль профиля принудительно — сменить его самостоятельно нельзя.`)
          .catch(() => {});
      }
      return;
    }

    case 'кланфото': {
      if (!rest.length) {
        await ctx.send('⛔ Укажите клан: !админ кланфото [название клана]');
        return;
      }
      const remove = rest[rest.length - 1].toLowerCase() === 'снять';
      const clanName = (remove ? rest.slice(0, -1) : rest).join(' ');
      if (!clanName) {
        await ctx.send('⛔ Укажите клан: !админ кланфото [название клана]');
        return;
      }
      const targetClan = await clansDb.getClanByName(clanName);
      if (!targetClan) {
        await ctx.send('⛔ Клан с таким названием не найден.');
        return;
      }

      if (remove) {
        await clansDb.setClanPhoto(targetClan.id, null);
        await ctx.send(`✅ Фото клана «${targetClan.name}» убрано.`);
        return;
      }

      const photo = (ctx.attachments || []).find((a) => a.type === 'photo');
      if (!photo) {
        await ctx.send(
          '⛔ Прикрепите фото к этому же сообщению: !админ кланфото [название клана] (с вложенной фотографией).'
        );
        return;
      }

      const attachmentString = photo.toString();
      await clansDb.setClanPhoto(targetClan.id, attachmentString);
      await ctx.send(`✅ Клану «${targetClan.name}» выдано кастомное фото. Посмотреть: клан инфо`);
      if (ctx.bot) {
        const leader = targetClan.leader_id;
        await ctx.bot
          .notifyUser(leader, `🖼️ Вашему клану «${targetClan.name}» выдано кастомное фото! Посмотреть: клан инфо`)
          .catch(() => {});
      }
      return;
    }

    case 'кланвидео': {
      if (!rest.length) {
        await ctx.send('⛔ Укажите клан: !админ кланвидео [название клана]');
        return;
      }
      const remove = rest[rest.length - 1].toLowerCase() === 'снять';
      const clanName = (remove ? rest.slice(0, -1) : rest).join(' ');
      if (!clanName) {
        await ctx.send('⛔ Укажите клан: !админ кланвидео [название клана]');
        return;
      }
      const targetClan = await clansDb.getClanByName(clanName);
      if (!targetClan) {
        await ctx.send('⛔ Клан с таким названием не найден.');
        return;
      }

      if (remove) {
        await clansDb.setClanVideo(targetClan.id, null);
        await ctx.send(`✅ Видео клана «${targetClan.name}» убрано.`);
        return;
      }

      const video = (ctx.attachments || []).find((a) => a.type === 'video');
      if (!video) {
        await ctx.send(
          '⛔ Прикрепите видео к этому же сообщению: !админ кланвидео [название клана] (с вложенным видео).'
        );
        return;
      }

      const attachmentString = video.toString();
      await clansDb.setClanVideo(targetClan.id, attachmentString);
      await ctx.send(`✅ Клану «${targetClan.name}» выдано кастомное видео. Посмотреть: клан инфо`);
      if (ctx.bot) {
        const leader = targetClan.leader_id;
        await ctx.bot
          .notifyUser(leader, `🎬 Вашему клану «${targetClan.name}» выдано кастомное видео! Посмотреть: клан инфо`)
          .catch(() => {});
      }
      return;
    }

    case 'разблок': {
      const target = await requireTarget(ctx, targetId);
      if (!target) return;
      await players.setBlockedFactories(targetId, []);
      await ctx.send(`✅ Все блокировки заводов «${target.state_name}» сняты.`);
      return;
    }

    case 'инфо': {
      const target = await requireTarget(ctx, targetId);
      if (!target) return;
      let clanName = null;
      if (target.clan_id) {
        const clan = await clansDb.getClanById(target.clan_id);
        clanName = clan ? clan.name : null;
      }
      await ctx.send(
        `🛠️ ИНФО: ${target.state_name} (id${target.vk_id})\n` +
          `Баланс: ${calc.formatNumber(target.balance)}\n` +
          `Заводов: ${target.factories} (золотых: ${target.gold_mine_count})\n` +
          `Уничтожено (получено): ${target.destroyed_factories}\n` +
          `Снесено врагу: ${target.enemy_factories_destroyed || 0}\n` +
          `Урон накоплен на заводах: ${target.factory_damage || 0}\n` +
          `Клан: ${clanName || 'нет'}\n` +
          `Робот: ур. ${target.robot_level || 1} | Суперробот: ур. ${target.super_robot_level || 0}\n` +
          `Майнер: ${target.miner_until && new Date(target.miner_until) > new Date() ? 'активен до ' + msg.formatDateTimeMsk(target.miner_until) : 'нет'}\n` +
          `VIP: ${calc.isVipActive(target) ? 'активен до ' + msg.formatDateTimeMsk(target.vip_until) : 'нет'}\n` +
          `Донат-баффы: ${
            [
              calc.isIncomeBoostActive(target) ? `доход x${target.income_boost_mult} до ${msg.formatDateTimeMsk(target.income_boost_until)}` : null,
              calc.isShieldActive(target) ? `щит до ${msg.formatDateTimeMsk(target.shield_until)}` : null,
              calc.isWorkDoubleActive(target) ? `x2 жетонов до ${msg.formatDateTimeMsk(target.work_double_until)}` : null,
              calc.isFarmBoostActive(target) ? `ускорение фермы до ${msg.formatDateTimeMsk(target.farm_boost_until)}` : null,
            ]
              .filter(Boolean)
              .join(', ') || 'нет'
          }\n` +
          `Стрик доната: ${target.donate_streak || 0} дн.\n` +
          `Координаты: (${target.x}, ${target.y})\n` +
          `Последний визит: ${msg.formatDateTimeMsk(target.last_seen)}`
      );
      return;
    }

    case 'обнулить': {
      if (targetId === 'всех') {
        const count = await players.resetAllPlayersProgress();
        await ctx.send(`✅ Прогресс сброшен АБСОЛЮТНО ВСЕМ игрокам (${count} шт.).`);
        return;
      }
      const target = await requireTarget(ctx, targetId);
      if (!target) return;
      await players.resetPlayerProgress(targetId);
      await ctx.send(`✅ Игровой прогресс игрока «${target.state_name}» полностью сброшен.`);
      if (ctx.bot) {
        await ctx.bot.notifyUser(targetId, '⚠️ Ваш игровой прогресс был сброшен администратором.').catch(() => {});
      }
      return;
    }

    case 'рассылка': {
      const text = rest.join(' ');
      if (!text) {
        await ctx.send('⛔ Формат: !админ рассылка [текст]');
        return;
      }
      const all = await players.getAllActivePlayers();
      let sent = 0;
      for (const p of all) {
        if (ctx.bot) {
          await ctx.bot.notifyUser(p.vk_id, `📢 ОБЪЯВЛЕНИЕ:\n${text}`).catch(() => {});
          sent++;
        }
      }
      await ctx.send(`✅ Рассылка отправлена ${sent} игрокам.`);
      return;
    }

    case 'вернутьдоход': {
      // Разовая компенсация: 50% от ТЕКУЩЕГО часового дохода игрока (тот же расчёт, что и в
      // реальном часовом тике — game/economy.js: hourlyTick / calc.incomePerHour), начисляется
      // на баланс сразу, одной выплатой. Не трогает сам часовой доход и штраф за нелайкнутые
      // посты (like_penalty_active) — это просто ручной возврат части дохода по решению админа.
      // !админ вернутьдоход @юзер — одному игроку
      // !админ вернутьдоход всех — всем активным игрокам разом
      if (targetId === 'всех') {
        const all = await players.getAllActivePlayers();
        let affected = 0;
        let totalRefunded = 0;
        for (const p of all) {
          const factoriesInProd = await production.getFactoriesInUse(p.vk_id);
          const income = calc.incomePerHour(p, factoriesInProd);
          const refund = Math.round(income * 0.5);
          if (refund <= 0) continue;
          await players.updateBalance(p.vk_id, refund);
          affected++;
          totalRefunded += refund;
          if (ctx.bot) {
            await ctx.bot
              .notifyUser(
                p.vk_id,
                `💸 Вам возвращено ${calc.formatNumber(refund)} вирт (50% от часового дохода) — компенсация от администрации.`
              )
              .catch(() => {});
          }
        }
        await ctx.send(
          `✅ Возврат 50% дохода начислен ${affected} игрокам (с ненулевым доходом), суммарно ${calc.formatNumber(
            totalRefunded
          )} вирт.`
        );
        return;
      }

      const target = await requireTarget(ctx, targetId);
      if (!target) return;

      const factoriesInProd = await production.getFactoriesInUse(targetId);
      const income = calc.incomePerHour(target, factoriesInProd);
      const refund = Math.round(income * 0.5);
      if (refund <= 0) {
        await ctx.send(`⛔ У игрока «${target.state_name}» сейчас нулевой доход в час — возвращать нечего.`);
        return;
      }
      const newBalance = await players.updateBalance(targetId, refund);
      await ctx.send(
        `✅ Игроку «${target.state_name}» возвращено ${calc.formatNumber(refund)} вирт (50% от часового дохода). ` +
          `Текущий баланс: ${calc.formatNumber(newBalance)} вирт.`
      );
      if (ctx.bot) {
        await ctx.bot
          .notifyUser(
            targetId,
            `💸 Вам возвращено ${calc.formatNumber(refund)} вирт (50% от часового дохода) — компенсация от администрации.`
          )
          .catch(() => {});
      }
      return;
    }

    case 'игроки': {
      const PAGE_SIZE = 15;
      const pageArg = parseInt(rest[0], 10);
      const page = Number.isInteger(pageArg) && pageArg > 0 ? pageArg : 1;

      const total = await players.getPlayersCount();
      if (!total) {
        await ctx.send('📋 Зарегистрированных игроков пока нет.');
        return;
      }

      const totalPages = Math.max(1, Math.ceil(total / PAGE_SIZE));
      const safePage = Math.min(page, totalPages);
      const offset = (safePage - 1) * PAGE_SIZE;
      const list = await players.getPlayersPage(offset, PAGE_SIZE);

      let text = `📋 ВСЕ ИГРОКИ (стр. ${safePage}/${totalPages}, всего: ${total})\n\n`;
      list.forEach((p, i) => {
        const num = offset + i + 1;
        let clanPart = '';
        if (p.clan_id) clanPart = ` | клан: есть`;
        text +=
          `${num}. ${msg.mentionLink(p.vk_id, p.state_name)} (id${p.vk_id})\n` +
          `   💰 ${calc.formatNumber(p.balance)} вирт | 🏭 ${p.factories} завод. | 🤖 ур.${p.robot_level || 1} | 🪙 ${
            p.tokens || 0
          } жетонов${clanPart}\n`;
      });

      if (safePage < totalPages) {
        text += `\n➡️ Следующая страница: !админ игроки ${safePage + 1}`;
      }

      await ctx.send(text.trim());
      return;
    }

    case 'ивент': {
      const arg = (rest[0] || '').toLowerCase();

      if (arg === 'стоп') {
        await events.setActiveSeason(null);
        await ctx.send('✅ Сезонный ивент выключен. Валюта за действия капать перестала (накопленное осталось у игроков).');
        return;
      }

      const seasonKey = events.findSeasonKey(arg);
      if (!seasonKey) {
        await ctx.send('⛔ Формат: !админ ивент [зима|весна|лето|осень|стоп]');
        return;
      }

      const season = await events.setActiveSeason(seasonKey);
      await ctx.send(
        `✅ Запущен ивент: ${season.emoji} ${season.name}.\n` +
          `Теперь за постройку заводов, науки, сбор бонуса и атаки на игроков будет случайно капать ${season.emoji} (1–3 за действие).\n` +
          `Магазин обмена: !админ ивентмагазин открыть / закрыть`
      );
      return;
    }

    case 'ивентмагазин': {
      const arg = (rest[0] || '').toLowerCase();
      if (arg === 'открыть') {
        await events.setShopOpen(true);
        await ctx.send('✅ Ивент-магазин ОТКРЫТ. Игроки теперь могут обменивать валюту: ивент купить [товар] [кол-во]');
        return;
      }
      if (arg === 'закрыть') {
        await events.setShopOpen(false);
        await ctx.send('✅ Ивент-магазин ЗАКРЫТ. Игроки продолжают копить валюту, но купить ничего не смогут.');
        return;
      }
      await ctx.send('⛔ Формат: !админ ивентмагазин [открыть|закрыть]');
      return;
    }

    case 'сброс': {
      // Мгновенный сброс кулдауна робота/суперробота/дозора (донат-ускоритель, разовый).
      const target = await requireTarget(ctx, targetId);
      if (!target) return;

      const what = (rest[0] || '').toLowerCase();
      if (what === 'робот') {
        await donateBuffs.resetRobotCooldown(targetId);
        await donateBuffs.resetRobotAttackCooldown(targetId);
        await ctx.send(`✅ Кулдауны робота-питомца игрока «${target.state_name}» сброшены.`);
      } else if (what === 'суперробот') {
        await donateBuffs.resetSuperRobotCooldown(targetId);
        await ctx.send(`✅ Кулдаун атаки суперробота игрока «${target.state_name}» сброшен.`);
      } else if (what === 'дозор') {
        await donateBuffs.resetPatrolCooldown(targetId);
        await ctx.send(`✅ Кулдаун дозора игрока «${target.state_name}» сброшен.`);
      } else {
        await ctx.send('⛔ Формат: !админ сброс @юзер [робот|суперробот|дозор]');
        return;
      }
      if (ctx.bot) {
        await ctx.bot.notifyUser(targetId, `⚡ Кулдаун (${what}) мгновенно сброшен донат-ускорителем!`).catch(() => {});
      }
      return;
    }

    case 'финиш': {
      // Мгновенное завершение текущего производства (донат-ускоритель, разовый).
      const target = await requireTarget(ctx, targetId);
      if (!target) return;

      const { count } = await donateBuffs.finishProductionNow(targetId);
      if (count === 0) {
        await ctx.send(`⚠️ У игрока «${target.state_name}» нет производства в ожидании.`);
        return;
      }
      await ctx.send(`✅ Производство игрока «${target.state_name}» завершено мгновенно (${count} партий). Собрать: "собрать".`);
      if (ctx.bot) {
        await ctx.bot
          .notifyUser(targetId, `⚡ Ваше производство завершено мгновенно донат-ускорителем! Заберите: "собрать"`)
          .catch(() => {});
      }
      return;
    }

    case 'работа': {
      // Доп. попытки "работы" сверх дневного лимита (донат-ускоритель, разовый).
      const target = await requireTarget(ctx, targetId);
      if (!target) return;

      const amount = rest[0] ? parseInt(rest[0], 10) : C.DONATE_WORK_EXTRA_ATTEMPTS;
      if (!Number.isInteger(amount) || amount <= 0) {
        await ctx.send('⛔ Формат: !админ работа @юзер [кол-во]');
        return;
      }
      const { total } = await donateBuffs.grantWorkExtraAttempts(targetId, amount);
      await ctx.send(`✅ Игроку «${target.state_name}» выдано +${amount} попыток "работы" сверх лимита сегодня (бонус сегодня: ${total}).`);
      if (ctx.bot) {
        await ctx.bot.notifyUser(targetId, `⚡ Вам выдано +${amount} попыток "работы" сверх дневного лимита сегодня!`).catch(() => {});
      }
      return;
    }

    case 'обмен': {
      // Снятие сегодняшнего лимита обмена жетонов на завод/науку (донат-ускоритель, разовый).
      const target = await requireTarget(ctx, targetId);
      if (!target) return;

      await donateBuffs.liftExchangeLimitsToday(targetId);
      await ctx.send(`✅ Сегодняшний лимит обмена жетонов на завод/науку игрока «${target.state_name}» снят.`);
      if (ctx.bot) {
        await ctx.bot.notifyUser(targetId, `⚡ Сегодняшний лимит обмена жетонов на завод/науку снят донат-ускорителем!`).catch(() => {});
      }
      return;
    }

    case 'доход': {
      // Донат-бафф: доход x1.5/x2 на N часов (см. DONATE_INCOME_BOOST_* в constants.js).
      const target = await requireTarget(ctx, targetId);
      if (!target) return;

      const mult = parseFloat(rest[0]);
      const hours = rest[1] ? parseFloat(rest[1]) : C.DONATE_INCOME_BOOST_DURATION_HOURS;
      if (![1.5, 2].includes(mult) || !(hours > 0)) {
        await ctx.send('⛔ Формат: !админ доход @юзер [1.5|2] [часы]');
        return;
      }
      const result = await donateBuffs.grantIncomeBoost(targetId, mult, hours);
      await ctx.send(
        `✅ Игроку «${target.state_name}» выдан буст дохода x${mult} до ${msg.formatDateTimeMsk(result.until)}` +
          (result.streak > 1 ? ` (стрик: ${result.streak} дн., бонус +${Math.round(result.bonusMs / 3600000)}ч)` : '.')
      );
      if (ctx.bot) {
        await ctx.bot
          .notifyUser(targetId, `💰 Вам выдан буст дохода x${mult} до ${msg.formatDateTimeMsk(result.until)}!`)
          .catch(() => {});
      }
      return;
    }

    case 'щит': {
      // Донат-бафф: щит от НЕядерного оружия на N дней (см. DONATE_SHIELD_* в constants.js).
      const target = await requireTarget(ctx, targetId);
      if (!target) return;

      const days = rest[0] ? parseFloat(rest[0]) : C.DONATE_SHIELD_DURATION_DAYS;
      if (!(days > 0)) {
        await ctx.send('⛔ Формат: !админ щит @юзер [дни]');
        return;
      }
      const result = await donateBuffs.grantShield(targetId, days);
      await ctx.send(
        `✅ Игроку «${target.state_name}» выдан щит (защита от НЕядерного оружия) до ${msg.formatDateTimeMsk(result.until)}` +
          (result.streak > 1 ? ` (стрик: ${result.streak} дн., бонус +${Math.round(result.bonusMs / 3600000)}ч)` : '.')
      );
      if (ctx.bot) {
        await ctx.bot
          .notifyUser(
            targetId,
            `🛡️ Вам выдан щит до ${msg.formatDateTimeMsk(result.until)}! Защищает заводы от обычного оружия, кроме ядерного.`
          )
          .catch(() => {});
      }
      return;
    }

    case 'дубль': {
      // Донат-бафф: x2 жетонов/науки за "работу" на N часов (см. DONATE_WORK_DOUBLE_* в constants.js).
      const target = await requireTarget(ctx, targetId);
      if (!target) return;

      const hours = rest[0] ? parseFloat(rest[0]) : C.DONATE_WORK_DOUBLE_DURATION_HOURS;
      if (!(hours > 0)) {
        await ctx.send('⛔ Формат: !админ дубль @юзер [часы]');
        return;
      }
      const result = await donateBuffs.grantWorkDouble(targetId, hours);
      await ctx.send(
        `✅ Игроку «${target.state_name}» выданы двойные жетоны за "работу" до ${msg.formatDateTimeMsk(result.until)}` +
          (result.streak > 1 ? ` (стрик: ${result.streak} дн., бонус +${Math.round(result.bonusMs / 3600000)}ч)` : '.')
      );
      if (ctx.bot) {
        await ctx.bot
          .notifyUser(targetId, `🪙 Вам выданы двойные жетоны за "работу" до ${msg.formatDateTimeMsk(result.until)}!`)
          .catch(() => {});
      }
      return;
    }

    case 'ускорение': {
      // Донат-бафф: ускоренная добыча на майнинг-ферме на N часов (см. DONATE_FARM_BOOST_* в constants.js).
      const target = await requireTarget(ctx, targetId);
      if (!target) return;

      const hours = rest[0] ? parseFloat(rest[0]) : C.DONATE_FARM_BOOST_DURATION_HOURS;
      if (!(hours > 0)) {
        await ctx.send('⛔ Формат: !админ ускорение @юзер [часы]');
        return;
      }
      const result = await donateBuffs.grantFarmBoost(targetId, hours);
      await ctx.send(
        `✅ Игроку «${target.state_name}» выдано ускорение фермы (x${C.DONATE_FARM_BOOST_MULTIPLIER}) до ${msg.formatDateTimeMsk(
          result.until
        )}` + (result.streak > 1 ? ` (стрик: ${result.streak} дн., бонус +${Math.round(result.bonusMs / 3600000)}ч)` : '.')
      );
      if (ctx.bot) {
        await ctx.bot
          .notifyUser(targetId, `⛏️ Вам выдано ускорение фермы до ${msg.formatDateTimeMsk(result.until)}!`)
          .catch(() => {});
      }
      return;
    }

    case 'босс': {
      // Мировой босс — общий ивент, без цели-игрока (см. handlers/dispatcher.js: маршрутизация
      // без резолва @упоминания). Формат: !админ босс старт / !админ босс финиш / !админ босс статус
      const boss = require('../game/boss');
      const action = (rest[0] || '').toLowerCase();

      if (action === 'старт') {
        const alreadyActive = await boss.isActive();
        if (alreadyActive) {
          await ctx.send('⛔ Босс уже активен. Сначала завершите его: !админ босс финиш');
          return;
        }
        await boss.startBoss();
        await ctx.send(
          `✅ Мировой босс запущен! Игроки могут покупать ракеты «${C.BOSS_ROCKET_NAME}» (${C.BOSS_ROCKET_PRICE} вирт/шт) командой «босс [кол-во]».`
        );
        if (ctx.bot) {
          const all = await players.getAllActivePlayers();
          const text =
            `👹 ПОЯВИЛСЯ МИРОВОЙ БОСС!\n\n` +
            `Покупайте ракеты «${C.BOSS_ROCKET_NAME}» за ${C.BOSS_ROCKET_PRICE} вирт и бейте по боссу командой «босс [кол-во]».\n` +
            `Награда за попадание: ${C.BOSS_HIT_REWARD_MIN}-${C.BOSS_HIT_REWARD_MAX} вирт. Осторожно — при промахе можно потерять завод или научный центр!\n` +
            `Лимит: ${C.BOSS_MAX_ROCKETS_PER_DAY} ракет/день. Подробности: босс`;
          for (const p of all) {
            await ctx.bot.notifyUser(p.vk_id, text).catch(() => {});
          }
        }
        return;
      }

      if (action === 'финиш') {
        const result = await boss.finishBoss();
        if (!result.ok) {
          await ctx.send('⛔ Сейчас нет активного босса.');
          return;
        }
        const rewardLines = result.rewards
          .map((r) => `${r.place}. игрок ${r.vkId} — ${r.hits} попаданий, награда +${calc.formatNumber(r.bonus)} вирт`)
          .join('\n');
        await ctx.send(
          `✅ Босс завершён!\n\n` +
            `Всего попаданий: ${result.totalHits}, промахов: ${result.totalMisses}, ракет выпущено: ${result.totalRocketsFired}\n` +
            `Участников: ${result.participantsCount}\n\n` +
            `💰 Награды выданы:\n${rewardLines || 'участников не было'}`
        );
        if (ctx.bot) {
          for (const r of result.rewards) {
            await ctx.bot
              .notifyUser(r.vkId, `👹 Мировой босс завершён! За участие (${r.hits} попаданий) вам начислено +${calc.formatNumber(r.bonus)} вирт.`)
              .catch(() => {});
          }
        }
        return;
      }

      if (action === 'статус' || !action) {
        const state = await boss.getState();
        if (!state) {
          await ctx.send('👹 Босс ещё ни разу не запускался.');
          return;
        }
        const top = boss.topParticipants(state, 10);
        const topLines = top
          .map((p, i) => `${i + 1}. игрок ${p.vkId} — ${p.hits} попаданий (${p.fired} ракет, промахов: ${p.misses})`)
          .join('\n');
        await ctx.send(
          `👹 БОСС: ${state.active ? 'АКТИВЕН' : 'завершён'}\n\n` +
            `Всего попаданий: ${state.totalHits}, промахов: ${state.totalMisses}, ракет: ${state.totalRocketsFired}\n\n` +
            `🏆 Топ по попаданиям:\n${topLines || 'участников пока нет'}`
        );
        return;
      }

      await ctx.send('⛔ Формат: !админ босс старт / финиш / статус');
      return;
    }

    case 'боссбафф': {
      // Донат: x2 к награде за попадание по боссу, строго на 1 день (см. DONATE_BOSS_DOUBLE_*).
      const target = await requireTarget(ctx, targetId);
      if (!target) return;

      const result = await donateBuffs.grantBossDouble(targetId);
      await ctx.send(`✅ Игроку «${target.state_name}» выдан бафф x2 к награде за попадание по боссу до ${msg.formatDateTimeMsk(result.until)}.`);
      if (ctx.bot) {
        await ctx.bot
          .notifyUser(targetId, `👹 Вам выдан бафф x2 к награде за попадание по мировому боссу до ${msg.formatDateTimeMsk(result.until)}!`)
          .catch(() => {});
      }
      return;
    }

    case 'буст': {
      // Глобальный ивент-буст дохода на ВСЕХ игроков сразу (см. game/globalBoost.js) —
      // не путать с личным донат-баффом "доход" (тот множит только одному игроку).
      // Формат: !админ буст [множитель] [минут] / !админ буст снять
      const globalBoost = require('../game/globalBoost');

      if ((rest[0] || '').toLowerCase() === 'снять') {
        await globalBoost.clearBoost();
        await ctx.send('✅ Глобальный буст дохода снят.');
        return;
      }

      const multiplier = parseFloat(rest[0]);
      const minutes = parseFloat(rest[1]);
      if (!(multiplier > 1) || !(minutes > 0)) {
        await ctx.send('⛔ Формат: !админ буст [множитель > 1] [минут] или !админ буст снять');
        return;
      }

      const boost = await globalBoost.setBoost(multiplier, minutes);
      await ctx.send(
        `✅ Глобальный буст дохода x${multiplier} запущен на ${calc.formatDuration(minutes * 60 * 1000)} ` +
          `(до ${msg.formatDateTimeMsk(boost.expiresAt)}). Начисляется при следующем часовом тике дохода всем активным игрокам.`
      );
      if (ctx.bot) {
        const all = await players.getAllActivePlayers();
        const text =
          `🔥 ЗОЛОТОЙ ЧАС!\n\n` +
          `Доход всех заводов и научных центров временно x${multiplier} на ближайшие ${calc.formatDuration(
            minutes * 60 * 1000
          )}! Успейте настроить заводы, пока действует буст.`;
        for (const p of all) {
          await ctx.bot.notifyUser(p.vk_id, text).catch(() => {});
        }
      }
      return;
    }

    case 'курсферма': {
      // Формат: !админ курсферма [мин] [макс] — задать коридор курса нанокоина ("ферма").
      // Раз в час курс случайно скачет на одну из двух границ коридора (см. game/farm.js:
      // updateExchangeRate), а не плавно блуждает — это и делает эффект "то мин, то макс".
      const farm = require('../game/farm');
      const min = parseFloat(rest[0]);
      const max = parseFloat(rest[1]);
      if (!(min > 0) || !(max > 0) || !(max > min)) {
        await ctx.send(
          '⛔ Формат: !админ курсферма [мин] [макс], например !админ курсферма 20 50 (макс должен быть больше мин, оба > 0).'
        );
        return;
      }
      const result = await farm.setRateBounds(min, max);
      await ctx.send(
        `✅ Коридор курса нанокоина обновлён: ${result.min}–${result.max} вирт за 1₿.\n` +
          `Курс сразу пересчитан: ${result.rate} вирт за 1₿ (дальше раз в час будет случайно скакать между ${result.min} и ${result.max}).`
      );
      return;
    }

    case 'аукционстиль': {
      // Админ выставляет НОВЫЙ стиль (создаётся прямо здесь из вложения) на аукцион с торгами —
      // в отличие от "витрины" (фикс-цена), тут игроки соревнуются ставками.
      // Формат: !админ аукционстиль [фото|видео] [нач.цена] [шаг] [часы] (с вложением К ЭТОМУ сообщению)
      const kindArg = (rest[0] || '').toLowerCase();
      const kind = kindArg === 'фото' ? 'photo' : kindArg === 'видео' ? 'video' : null;
      if (!kind) {
        await ctx.send('⛔ Формат: !админ аукционстиль [фото|видео] [нач.цена] [шаг] [часы] (с вложенным фото/видео)');
        return;
      }

      const photo = (ctx.attachments || []).find((a) => a.type === 'photo');
      const video = (ctx.attachments || []).find((a) => a.type === 'video');
      const attachment = kind === 'photo' ? photo : video;
      if (!attachment) {
        await ctx.send(`⛔ Прикрепите ${kind === 'photo' ? 'фото' : 'видео'} к этому же сообщению.`);
        return;
      }

      const startPrice = parseInt(rest[1], 10);
      const minStep = parseInt(rest[2], 10);
      const durationHours = parseFloat(rest[3]);

      const result = await auction.createStyleLot(
        ctx.senderId,
        kind,
        attachment.toString(),
        startPrice,
        minStep,
        durationHours
      );

      if (!result.ok) {
        if (result.reason === 'invalid_duration') {
          await ctx.send(`⛔ Максимальная длительность аукциона — ${result.max}ч.`);
        } else {
          await ctx.send('⛔ Формат: !админ аукционстиль [фото|видео] [нач.цена] [шаг] [часы] (с вложением)');
        }
        return;
      }

      await ctx.send(
        `✅ Лот-стиль создан (аукцион №${result.auction.id}, стиль #${result.style.id}). ` +
          `Старт: ${calc.formatNumber(startPrice)} вирт, шаг: ${calc.formatNumber(minStep)}, длительность: ${durationHours}ч.\n` +
          `Игроки увидят его в общем списке: аукцион`
      );
      if (ctx.bot) {
        const all = await players.getAllActivePlayers();
        const text = `🎨 На аукцион выставлен эксклюзивный ${kind === 'photo' ? 'фото' : 'видео'}-стиль! Ставки: аукцион`;
        for (const p of all) {
          await ctx.bot.notifyUser(p.vk_id, text).catch(() => {});
        }
      }
      return;
    }

    case 'акция': {
      // Ежедневное окно предложения (FOMO) — общая флеш-акция на всех игроков, не привязана
      // к конкретному игроку. Формат: !админ акция [товар] [скидка%] [минут] / !админ акция снять
      // (маршрутизируется без резолва @упоминания — см. handlers/dispatcher.js).
      if ((rest[0] || '').toLowerCase() === 'снять') {
        await donateBuffs.clearFlashOffer();
        await ctx.send('✅ Флеш-акция снята.');
        return;
      }
      if (rest.length < 3) {
        await ctx.send('⛔ Формат: !админ акция [товар] [скидка%] [минут] или !админ акция снять');
        return;
      }
      const minutes = parseFloat(rest[rest.length - 1]);
      const discountPercent = parseFloat(rest[rest.length - 2]);
      const itemLabel = rest.slice(0, -2).join(' ');
      if (!itemLabel || !(discountPercent > 0) || !(minutes > 0)) {
        await ctx.send('⛔ Формат: !админ акция [товар] [скидка%] [минут] или !админ акция снять');
        return;
      }
      const offer = await donateBuffs.setFlashOffer(itemLabel, discountPercent, minutes);
      await ctx.send(
        `✅ Флеш-акция запущена: «${itemLabel}» со скидкой ${discountPercent}% до ${msg.formatDateTimeMsk(
          offer.expiresAt
        )}. Игроки увидят её в "донат"/"акция".`
      );
      if (ctx.bot) {
        const all = await players.getAllActivePlayers();
        const text = `🔥 ФЛЕШ-АКЦИЯ! «${itemLabel}» со скидкой ${discountPercent}% — успей за ${calc.formatDuration(
          minutes * 60 * 1000
        )}! Подробности: акция`;
        for (const p of all) {
          await ctx.bot.notifyUser(p.vk_id, text).catch(() => {});
        }
      }
      return;
    }

    case 'лайки': {
      // Управление системой штрафа за нелайкнутые посты сообщества (см. game/postLikes.js).
      // Формат: !админ лайки [вкл|выкл|статус|интервал [пресет]]
      // (маршрутизируется без резолва @упоминания — см. handlers/dispatcher.js).
      const action = (rest[0] || '').toLowerCase();

      if (action === 'вкл' || action === 'включить') {
        await postLikes.setSystemEnabled(true);
        await ctx.send('✅ Система штрафа за нелайкнутые посты включена.');
        return;
      }

      if (action === 'выкл' || action === 'выключить') {
        await postLikes.setSystemEnabled(false);
        await ctx.send('✅ Система штрафа за нелайкнутые посты выключена, штраф снят со всех игроков.');
        return;
      }

      if (action === 'статус') {
        const enabled = await postLikes.isSystemEnabled();
        const windowMs = await postLikes.getWindowMs();
        const windowLabel = windowMs ? calc.formatDuration(windowMs) : 'без ограничения (все посты)';
        await ctx.send(
          `ℹ️ Система лайков: ${enabled ? 'включена ✅' : 'выключена ⛔'}.\n` +
            `Учитываемый интервал постов: ${windowLabel}.`
        );
        return;
      }

      if (action === 'интервал') {
        const presetKey = (rest[1] || '').toLowerCase();
        const presets = postLikes.POST_LIKE_WINDOW_PRESETS;
        if (!Object.prototype.hasOwnProperty.call(presets, presetKey)) {
          await ctx.send(
            `⛔ Формат: !админ лайки интервал [${Object.keys(presets).join('|')}]`
          );
          return;
        }
        const ms = await postLikes.setWindowPreset(presetKey);
        const windowLabel = ms ? calc.formatDuration(ms) : 'без ограничения (все посты)';
        await ctx.send(`✅ Интервал учёта постов для штрафа за лайки установлен: ${windowLabel}.`);
        return;
      }

      await ctx.send(
        '⛔ Формат: !админ лайки [вкл|выкл|статус|интервал [5ч|день|3дня|5дней|30дней|60дней|все]]'
      );
      return;
    }

    default: {
      await ctx.send('⛔ Неизвестная админ-команда. !админ помощь — список команд.');
    }
  }
}

module.exports = { handleAdmin, isAdmin };
