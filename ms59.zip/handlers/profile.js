'use strict';

const players = require('../db/players');
const production = require('../db/production');
const clansDb = require('../db/clans');
const calc = require('../game/calc');
const msg = require('../utils/messages');
const C = require('../game/constants');
const images = require('../game/commandImages');

const NAME_REGEX = /^[a-zA-Zа-яА-ЯёЁ0-9 ]{2,30}$/;

async function handleStart(ctx) {
  const vkId = ctx.senderId;
  let player = await players.getPlayer(vkId);

  if (!player) {
    player = await players.createPlayerStub(vkId);
    await ctx.send(
      images.withImage('start', {
        message:
          `🏛️ Добро пожаловать, Командир!\n` +
          `Ваш народ ждёт великих свершений. Дайте название вашему государству (городу/империи):\n` +
          `- От 2 до 30 символов\n` +
          `- Только буквы, цифры и пробелы`,
      })
    );
    return;
  }

  if (player.registration_step === 'awaiting_name') {
    await ctx.send('✅ Вы уже начали регистрацию. Напишите название вашего государства сообщением.');
    return;
  }

  await ctx.send(
    images.withImage('start', `👋 С возвращением, «${player.state_name}»! Введите !помощь для списка команд.`)
  );
}

async function handleNameInput(ctx) {
  const vkId = ctx.senderId;
  const player = await players.getPlayer(vkId);
  if (!player || player.registration_step !== 'awaiting_name') return false;

  const name = ctx.text.trim();

  if (!NAME_REGEX.test(name)) {
    await ctx.send(
      '⛔ Название должно быть от 2 до 30 символов и содержать только буквы, цифры и пробелы. Попробуйте снова.'
    );
    return true;
  }

  const existing = await players.getPlayerByName(name);
  if (existing) {
    await ctx.send('⛔ Это название уже занято. Придумайте другое.');
    return true;
  }

  const updated = await players.finalizeRegistration(vkId, name);

  await ctx.send(
    `✅ Отлично! Государство «${updated.state_name}» основано!\n` +
      `📍 Ваши координаты на карте: (${updated.x}, ${updated.y})\n` +
      `🎁 Вам выдано ${C.START_BALANCE} вирт и ${C.STARTER_FREE_FACTORIES} заводов в подарок!\n` +
      `🚀 Пока заводов меньше ${C.NEWBIE_BOOST_FACTORY_THRESHOLD} — у вас повышенный доход, чтобы легче догнать остальных (это НЕ защита от атак — см. !помощь → «Бой»).\n` +
      `\n📚 КРАТКАЯ ИНСТРУКЦИЯ:\n` +
      `🏭 !построить — построить завод (стоимость зависит от количества)\n` +
      `🏪 !магазин — купить оружие и ПВО\n` +
      `⚔️ !атака @юзер [оружие] [количество] — атаковать игрока\n` +
      `🏭 !произвести [оружие] [количество] [заводов] — производить оружие\n` +
      `👷 !работа — мини-игра на жетоны (можно 40 раз в день)\n` +
      `💰 !профиль — посмотреть свою статистику\n` +
      `👥 !клан создать [название] — создать клан\n\n` +
      `Удачи в бою, Командир!`
  );
  return true;
}

async function handleProfile(ctx, targetId) {
  const vkId = targetId || ctx.senderId;
  const player = await players.getPlayer(vkId);

  if (!player || player.registration_step !== 'done') {
    await ctx.send(targetId ? '⛔ Этот игрок ещё не зарегистрирован.' : '⛔ Вы ещё не зарегистрированы. Напишите !старт');
    return;
  }

  const factoriesInProd = await production.getFactoriesInUse(vkId);
  const income = calc.incomePerHour(player, factoriesInProd);
  const factoryRank = await players.getFactoryRank(vkId);

  let clanName = null;
  let clanVaultContribution = 0;
  if (player.clan_id) {
    const clan = await clansDb.getClanById(player.clan_id);
    clanName = clan ? clan.name : null;
    clanVaultContribution = Math.round(income * C.CLAN_VAULT_INCOME_RATE);
  }

  const text = msg.profileMessage(player, income, clanName, factoryRank, clanVaultContribution);

  // Кастомное фото/видео профиля, выданное админом (см. !админ фото / !админ видео).
  // Если заданы оба — показываем фото (приоритетнее видео).
  const profileAttachment = player.profile_photo || player.profile_video || null;

  if (profileAttachment) {
    await ctx.send({ message: text, attachment: profileAttachment });
  } else {
    await ctx.send(text);
  }
}

async function handleRename(ctx, newName) {
  const vkId = ctx.senderId;
  const player = await players.getPlayer(vkId);
  if (!player || player.registration_step !== 'done') {
    await ctx.send('⛔ Вы ещё не зарегистрированы. Напишите !старт');
    return;
  }

  if (!newName || !NAME_REGEX.test(newName)) {
    await ctx.send('⛔ Название должно быть от 2 до 30 символов (буквы, цифры, пробелы).');
    return;
  }

  if (Number(player.balance) < C.RENAME_COST) {
    await ctx.send(`⛔ Недостаточно вирт. Нужно ${C.RENAME_COST}, у вас ${calc.formatNumber(player.balance)}.`);
    return;
  }

  const existing = await players.getPlayerByName(newName);
  if (existing) {
    await ctx.send('⛔ Это название уже занято.');
    return;
  }

  await players.updateBalance(vkId, -C.RENAME_COST);
  await players.renamePlayer(vkId, newName);
  await ctx.send(images.withImage('rename', `✅ Государство переименовано в «${newName}»!`));
}

module.exports = { handleStart, handleNameInput, handleProfile, handleRename, NAME_REGEX };
