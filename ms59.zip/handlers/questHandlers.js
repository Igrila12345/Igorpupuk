'use strict';

const players = require('../db/players');
const quests = require('../game/quests');
const career = require('../game/career');
const calc = require('../game/calc');
const images = require('../game/commandImages');

async function requireRegistered(ctx) {
  const player = await players.getPlayer(ctx.senderId);
  if (!player || player.registration_step !== 'done') {
    await ctx.send('⛔ Вы ещё не зарегистрированы. Напишите !старт');
    return null;
  }
  return player;
}

async function handleQuests(ctx) {
  const player = await requireRegistered(ctx);
  if (!player) return;

  const list = await quests.getTodayQuests(ctx.senderId);

  const lines = list.map((q, i) => {
    const mark = q.completed ? '✅' : `${q.progress}/${q.target}`;
    return `${i + 1}. ${q.desc}\n   ${mark} — награда: +${q.reward} вирт, +${q.xp} очков карьеры`;
  });

  const doneCount = list.filter((q) => q.completed).length;

  await ctx.send(
    images.withImage(
      'quests',
      `📋 ЗАДАНИЯ НА СЕГОДНЯ (${doneCount}/${list.length} выполнено)\n➖➖➖➖➖➖➖➖➖➖\n` +
        lines.join('\n\n') +
        `\n\n♻️ Обновятся в 00:00 по МСК.`
    )
  );
}

async function handleCareer(ctx) {
  const player = await requireRegistered(ctx);
  if (!player) return;

  const info = await career.getInfo(ctx.senderId);

  let progressLine;
  if (!info.next) {
    progressLine = '🏆 Максимальное звание достигнуто!';
  } else {
    const need = info.next.xpRequired - info.xp;
    progressLine =
      `📈 До звания «${info.next.title}»: ещё ${calc.formatNumber(need)} очков карьеры ` +
      `(${calc.formatNumber(info.xp)}/${calc.formatNumber(info.next.xpRequired)}), награда: +${calc.formatNumber(
        info.next.reward
      )} вирт.`;
  }

  await ctx.send(
    images.withImage(
      'career',
      `🎖️ КАРЬЕРА\n➖➖➖➖➖➖➖➖➖➖\n` +
        `Звание: ${info.title} (${info.level}/${info.maxLevel})\n` +
        `Очков карьеры: ${calc.formatNumber(info.xp)}\n` +
        `${progressLine}\n\n` +
        `Очки даются за выполнение ежедневных заданий (!задания).`
    )
  );
}

module.exports = { handleQuests, handleCareer };
