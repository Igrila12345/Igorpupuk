'use strict';

const players = require('../db/players');
const superRobot = require('../game/superRobot');
const calc = require('../game/calc');
const C = require('../game/constants');
const msg = require('../utils/messages');
const events = require('../game/events');
const images = require('../game/commandImages');

async function requireRegistered(ctx) {
  const player = await players.getPlayer(ctx.senderId);
  if (!player || player.registration_step !== 'done') {
    await ctx.send('⛔ Вы ещё не зарегистрированы. Напишите старт');
    return null;
  }
  return player;
}

function statusBlock(player) {
  const level = player.super_robot_level || 0;
  let text;
  if (level <= 0) {
    text = `🤖 Суперробот ещё не построен (0/${C.SUPER_ROBOT_MAX_LEVEL}).\n`;
    text += `📈 Постройка (до ур. 1): ${calc.formatNumber(superRobot.upgradeCost(0))} вирт — суперробот прокачать`;
    return text;
  }

  text = `🤖 ${superRobot.levelName(level)} (уровень ${level}/${C.SUPER_ROBOT_MAX_LEVEL})\n`;
  text += `💀 Сносит за атаку: ${superRobot.factoriesPerHit(level)} ${msg.pluralFactories(
    superRobot.factoriesPerHit(level)
  )}\n`;
  text += `⏳ Кулдаун атаки: ${calc.formatDuration(C.SUPER_ROBOT_ATTACK_COOLDOWN_MS)}\n`;
  if (level < C.SUPER_ROBOT_MAX_LEVEL) {
    text += `📈 Прокачка до ур. ${level + 1} «${superRobot.levelName(level + 1)}»: ${calc.formatNumber(
      superRobot.upgradeCost(level)
    )} вирт — суперробот прокачать`;
  } else {
    text += `🏆 Максимальный уровень достигнут!`;
  }
  return text;
}

// "суперробот" — статус (постройка/уровень/сила/кулдаун), без побочных эффектов
async function handleStatus(ctx) {
  const player = await requireRegistered(ctx);
  if (!player) return;

  let text = statusBlock(player) + '\n\n';

  const level = player.super_robot_level || 0;
  if (level > 0) {
    const left = superRobot.msLeft(player.super_robot_last_attack_at, C.SUPER_ROBOT_ATTACK_COOLDOWN_MS);
    text +=
      left > 0
        ? `⏳ Атака доступна через: ${calc.formatDuration(left)}\n\n`
        : `✅ Атака доступна прямо сейчас!\n\n`;
  }

  text +=
    `ℹ️ Суперробот качается ВИРТАМИ (не жетонами) и качать его тяжело — цена растёт быстро.\n` +
    `⚔️ Атака: суперробот атака @юзер — летит как оружие и напрямую сносит заводы противнику.\n` +
    `🛡️ Перехватить его на подлёте может только топовое ПВО (С-400 Триумф) — если получится, защитник получает крупную награду виртами, а сам робот не теряется.\n` +
    `📋 Все уровни: суперроботы`;

  await ctx.send(images.withImage('superRobotMenu', text.trim()));
}

async function handleUpgrade(ctx) {
  const player = await requireRegistered(ctx);
  if (!player) return;

  const result = await superRobot.upgradeSuperRobot(ctx.senderId);
  if (!result.ok) {
    if (result.reason === 'max_level') {
      await ctx.send(`⛔ У суперробота уже максимальный уровень (${C.SUPER_ROBOT_MAX_LEVEL}).`);
    } else if (result.reason === 'not_enough_balance') {
      await ctx.send(
        `⛔ Недостаточно вирт. Нужно ${calc.formatNumber(result.cost)}, не хватает ${calc.formatNumber(
          result.missing
        )}.`
      );
    } else {
      await ctx.send('⛔ Не удалось прокачать суперробота.');
    }
    return;
  }

  await ctx.send(
    images.withImage(
      'superRobotUpgrade',
      `✅ Суперробот прокачан до уровня ${result.newLevel} — «${superRobot.levelName(result.newLevel)}»! ` +
        `Стоимость: ${calc.formatNumber(result.cost)} вирт.\n` +
        `Сила атаки теперь: ${superRobot.factoriesPerHit(result.newLevel)} ${msg.pluralFactories(
          superRobot.factoriesPerHit(result.newLevel)
        )} за удар.`
    )
  );
}

async function handleAttack(ctx, targetId, peerId) {
  const vkId = ctx.senderId;
  const player = await requireRegistered(ctx);
  if (!player) return;

  if (!targetId) {
    await ctx.send('⛔ Укажите цель: суперробот атака @юзер');
    return;
  }

  const result = await superRobot.launchAttack(vkId, targetId, peerId);

  if (!result.ok) {
    const reasons = {
      self_attack: '⛔ Нельзя атаковать самого себя.',
      not_registered: '⛔ Цель не зарегистрирована в игре.',
      not_built: '⛔ Суперробот ещё не построен. Прокачайте его: суперробот прокачать',
      attacker_too_small: `⛔ Атаковать можно только имея от ${C.MIN_FACTORIES_TO_ATTACK} заводов. Сначала развейте экономику.`,
      defender_too_small: `⛔ Нельзя атаковать игрока с менее чем ${C.MIN_FACTORIES_TO_BE_ATTACKED} заводами.`,
    };
    if (result.reason === 'cooldown') {
      await ctx.send(`⏳ Суперробот ещё не восстановился. Осталось: ${calc.formatDuration(result.msLeft)}.`);
      return;
    }
    await ctx.send(reasons[result.reason] || '⛔ Атака невозможна.');
    return;
  }

  const attackerLink = msg.mentionLink(result.attackerId, result.attackerName);
  const defenderLink = msg.mentionLink(result.defenderId, result.defenderName);
  const name = superRobot.levelName(result.level);

  const drop = await events.awardDrop(vkId);

  await ctx.send(
    images.withImage(
      'superRobotAttack',
      `🤖 ГОСУДАРСТВО «${attackerLink}» ОТПРАВИЛО СУПЕРРОБОТА:\n` +
        `${name} (уровень ${result.level})\n` +
        `Цель: ${defenderLink}\n` +
        `Расстояние: ${Math.round(result.distance)} км\n` +
        `Прилёт через: ${calc.formatDuration(result.flightMs)}\n\n` +
        `Эффект: 💀 сносит ${result.factoriesPerHit} ${msg.pluralFactories(result.factoriesPerHit)} за атаку\n` +
        `🛡️ Перехватить может только С-400 Триумф противника` +
        events.dropSuffix(drop)
    )
  );

  if (ctx.bot) {
    await ctx.bot
      .notifyUser(
        targetId,
        `⚠️ Государство «${attackerLink}» отправило суперробота (ур. ${result.level}) по вашему городу! Прилёт через ${calc.formatDuration(
          result.flightMs
        )}. Единственная защита — С-400 Триумф.`
      )
      .catch(() => {});

    if (peerId) {
      await ctx.bot
        .sendToChat(
          peerId,
          `🤖 «${attackerLink}» отправил(а) суперробота (ур. ${result.level}) по «${defenderLink}». Прилёт через ${calc.formatDuration(
            result.flightMs
          )}.`
        )
        .catch(() => {});
    }
  }
}

// "суперроботы" — полная таблица всех 50 уровней
async function handleLevelsList(ctx) {
  const rows = superRobot.buildLevelsTable();
  const half = Math.ceil(rows.length / 2);
  const chunks = [rows.slice(0, half), rows.slice(half)];

  for (let i = 0; i < chunks.length; i++) {
    const fromLevel = chunks[i][0].level;
    const toLevel = chunks[i][chunks[i].length - 1].level;
    let text = `🤖 ВСЕ УРОВНИ СУПЕРРОБОТА (${fromLevel}-${toLevel} из ${rows.length})\n\n`;

    for (const row of chunks[i]) {
      text += `${row.level}. «${row.name}»\n`;
      text += `   🪙 Цена прокачки до этого уровня: ${calc.formatNumber(row.costToReach)} вирт\n`;
      text += `   💀 Сносит за атаку: ${row.factoriesPerHit} ${msg.pluralFactories(row.factoriesPerHit)}\n`;
    }

    if (i === chunks.length - 1) {
      text += `\nℹ️ Качается виртами (не жетонами) и намеренно дорого — это долгосрочная боевая инвестиция.`;
    }

    await ctx.send(text.trim());
  }
}

module.exports = {
  handleStatus,
  handleUpgrade,
  handleAttack,
  handleLevelsList,
};
