'use strict';

const players = require('../db/players');
const warehouse = require('../game/warehouse');
const calc = require('../game/calc');
const C = require('../game/constants');
const msg = require('../utils/messages');
const images = require('../game/commandImages');

async function handleShow(ctx) {
  const vkId = ctx.senderId;
  const player = await players.getPlayer(vkId);
  if (!player || player.registration_step !== 'done') {
    await ctx.send('⛔ Вы ещё не зарегистрированы. Напишите старт');
    return;
  }

  const boxes = Array.from({ length: C.WAREHOUSE_BOX_COUNT }, (_, i) => i + 1).join(' | ');
  const casesLeft = Math.max(0, C.EXCHANGE_CASE_MAX_PER_DAY - (player.exchange_case_count_today || 0));
  const factoriesLeft = Math.max(0, C.EXCHANGE_FACTORY_MAX_PER_DAY - (player.exchange_factory_count_today || 0));

  let text =
    `📦 ВОЕННЫЙ СКЛАД — кейс (цена: ${C.WAREHOUSE_COST_TOKENS} жетонов)\n` +
    `+---+---+---+---+---+\n| ${boxes} |\n+---+---+---+---+---+\n` +
    `🪙 Ваши жетоны: ${player.tokens || 0}\n` +
    `📊 Осталось сегодня: кейсов ${casesLeft}/${C.EXCHANGE_CASE_MAX_PER_DAY}, обменов на завод ${factoriesLeft}/${C.EXCHANGE_FACTORY_MAX_PER_DAY}\n\n` +
    `${msg.warehouseRewardsMessage()}\n\n` +
    `Введите номер коробки: выбрать [номер]\n` +
    `Либо обменяйте жетоны напрямую на завод: обменять (${C.EXCHANGE_FACTORY_COST_TOKENS} жетонов = 1 завод)`;

  if (calc.isVipActive(player)) {
    const scienceLeft = Math.max(
      0,
      C.EXCHANGE_SCIENCE_MAX_PER_DAY - (player.exchange_science_count_today || 0)
    );
    text += `\n👑 VIP: обменять науку (${C.EXCHANGE_SCIENCE_COST_TOKENS} жетонов = 1 научный центр, осталось сегодня: ${scienceLeft}/${C.EXCHANGE_SCIENCE_MAX_PER_DAY})`;
  }

  await ctx.send(images.withImage('case', text));
}

// Показывает только содержимое кейса и шансы, без открытия (команда "кейс шансы")
async function handleRewardsInfo(ctx) {
  await ctx.send(msg.warehouseRewardsMessage());
}

const REWARD_LABELS = {
  virts: (qty) => `💰 ${calc.formatNumber(qty)} вирт`,
  factory: () => `🏭 Бесплатный завод (+1)`,
};

async function handleSelect(ctx, boxArg) {
  const vkId = ctx.senderId;
  const player = await players.getPlayer(vkId);
  if (!player || player.registration_step !== 'done') {
    await ctx.send('⛔ Вы ещё не зарегистрированы. Напишите старт');
    return;
  }

  const boxNumber = parseInt(boxArg, 10);
  const result = await warehouse.openBox(vkId, boxNumber);

  if (!result.ok) {
    if (result.reason === 'invalid_box') {
      await ctx.send(`⛔ Выберите номер коробки от 1 до ${C.WAREHOUSE_BOX_COUNT}: выбрать [номер]`);
    } else if (result.reason === 'daily_limit') {
      await ctx.send(`⛔ Дневной лимит открытий кейса исчерпан (${result.limit}/день). Возвращайтесь завтра.`);
    } else if (result.reason === 'not_enough_tokens') {
      await ctx.send(`⛔ Недостаточно жетонов. Не хватает ${result.missing}. Заработать: работа`);
    } else {
      await ctx.send('⛔ Не удалось открыть коробку.');
    }
    return;
  }

  const { reward, qty, attemptsLeft } = result;
  let rewardText;
  if (REWARD_LABELS[reward.type]) {
    rewardText = REWARD_LABELS[reward.type](qty);
  } else {
    rewardText = `${reward.key} x${qty}`;
  }

  await ctx.send(
    `📦 Коробка №${boxNumber} открыта!\n🎁 Вы получили: ${rewardText}\n📊 Осталось кейсов сегодня: ${attemptsLeft}/${C.EXCHANGE_CASE_MAX_PER_DAY}`
  );
}

// Прямой обмен жетонов на завод без рандома
async function handleExchangeFactory(ctx) {
  const vkId = ctx.senderId;
  const player = await players.getPlayer(vkId);
  if (!player || player.registration_step !== 'done') {
    await ctx.send('⛔ Вы ещё не зарегистрированы. Напишите старт');
    return;
  }

  const result = await warehouse.exchangeForFactory(vkId);

  if (!result.ok) {
    if (result.reason === 'daily_limit') {
      await ctx.send(`⛔ Дневной лимит обмена на заводы исчерпан (${result.limit}/день). Возвращайтесь завтра.`);
    } else if (result.reason === 'not_enough_tokens') {
      await ctx.send(
        `⛔ Недостаточно жетонов. Нужно ${C.EXCHANGE_FACTORY_COST_TOKENS}, не хватает ${result.missing}. Заработать: работа`
      );
    } else {
      await ctx.send('⛔ Не удалось обменять жетоны.');
    }
    return;
  }

  await ctx.send(
    `✅ Обмен выполнен! Списано ${C.EXCHANGE_FACTORY_COST_TOKENS} жетонов, получен 🏭 1 завод.\n` +
      `Осталось жетонов: ${result.remainingTokens}\n` +
      `📊 Осталось обменов на завод сегодня: ${result.attemptsLeft}/${C.EXCHANGE_FACTORY_MAX_PER_DAY}`
  );
}

// Прямой обмен жетонов на научный центр — только для VIP
async function handleExchangeScience(ctx) {
  const vkId = ctx.senderId;
  const player = await players.getPlayer(vkId);
  if (!player || player.registration_step !== 'done') {
    await ctx.send('⛔ Вы ещё не зарегистрированы. Напишите старт');
    return;
  }

  const result = await warehouse.exchangeForScience(vkId);

  if (!result.ok) {
    if (result.reason === 'vip_required') {
      await ctx.send(`⛔ Обмен жетонов на научный центр доступен только с VIP-статусом. Прайс: донат`);
    } else if (result.reason === 'daily_limit') {
      await ctx.send(`⛔ Дневной лимит обмена на науку исчерпан (${result.limit} раз в день). Заходите завтра.`);
    } else if (result.reason === 'limit_reached') {
      await ctx.send(`⛔ Достигнут лимит научных центров (${result.limit}). Расширьте: наука расширить`);
    } else if (result.reason === 'not_enough_tokens') {
      await ctx.send(
        `⛔ Недостаточно жетонов. Нужно ${C.EXCHANGE_SCIENCE_COST_TOKENS}, не хватает ${result.missing}. Заработать: работа`
      );
    } else {
      await ctx.send('⛔ Не удалось обменять жетоны.');
    }
    return;
  }

  await ctx.send(
    `✅ Обмен выполнен! Списано ${C.EXCHANGE_SCIENCE_COST_TOKENS} жетонов, получен 🔬 1 научный центр.\n` +
      `Осталось жетонов: ${result.remainingTokens}\n` +
      `Осталось обменов сегодня: ${result.attemptsLeft}/${C.EXCHANGE_SCIENCE_MAX_PER_DAY}`
  );
}

module.exports = { handleShow, handleSelect, handleExchangeFactory, handleExchangeScience, handleRewardsInfo };
