'use strict';

const { Keyboard } = require('vk-io');
const players = require('../db/players');
const clansDb = require('../db/clans');
const clanGame = require('../game/clan');
const production = require('../db/production');
const calcGame = require('../game/calc');
const farm = require('../game/farm');
const msg = require('../utils/messages');
const images = require('../game/commandImages');

async function handleTopFactories(ctx) {
  const list = await players.getTopByFactories(10);
  const viewer = await players.getPlayer(ctx.senderId);
  const viewerCoords = viewer && viewer.registration_step === 'done' ? { x: viewer.x, y: viewer.y } : null;
  await ctx.send(msg.topFactoriesMessage(list, viewerCoords));
}

async function handleTopBalance(ctx) {
  const list = await players.getTopByBalance(10);
  await ctx.send(msg.topBalanceMessage(list));
}

async function handleTopClans(ctx) {
  const list = await clanGame.getTopClansByIncome(10);
  await ctx.send(msg.topClansMessage(list));
}

async function handleTopRobot(ctx) {
  const list = await players.getTopByRobotLevel(10);
  await ctx.send(msg.topRobotMessage(list));
}

async function handleTopSuperRobot(ctx) {
  const list = await players.getTopBySuperRobotLevel(10);
  await ctx.send(msg.topSuperRobotMessage(list));
}

// Общий топ по суммарному доходу в час (заводы + научные центры + бонусы) — считаем на лету
// для всех активных игроков, как и в почасовом тике (game/economy.js: hourlyTick), затем берём топ-10.
async function handleTopIncome(ctx) {
  const all = await players.getAllActivePlayers();
  const withIncome = [];
  for (const player of all) {
    if (player.factories <= 0 && (player.science_centers || 0) <= 0) continue;
    const factoriesInProd = await production.getFactoriesInUse(player.vk_id);
    const income = calcGame.incomePerHour(player, factoriesInProd);
    if (income > 0) withIncome.push({ player, income });
  }
  withIncome.sort((a, b) => b.income - a.income);
  const top = withIncome.slice(0, 10);
  await ctx.send(msg.topIncomeMessage(top));
}

async function handleTopFarmLevel(ctx) {
  const list = await players.getTopByFarmLevel(10);
  await ctx.send(msg.topFarmLevelMessage(list));
}

async function handleTopFarmIncome(ctx) {
  const list = await players.getTopByFarmLevel(10); // доход монотонно растёт с уровнем — порядок тот же
  const rate = await farm.getExchangeRate();
  await ctx.send(msg.topFarmIncomeMessage(list, rate));
}

function buildHelpKeyboard() {
  const rows = [];
  const order = msg.HELP_SECTION_ORDER;
  for (let i = 0; i < order.length; i += 2) {
    const row = order.slice(i, i + 2).map((key) =>
      Keyboard.textButton({
        label: msg.HELP_SECTIONS[key].label,
        payload: { cmd: 'help_section', section: key },
        color: Keyboard.PRIMARY_COLOR,
      })
    );
    rows.push(row);
  }
  return Keyboard.keyboard(rows).inline();
}

async function handleHelp(ctx) {
  await ctx.send(
    images.withImage('help', {
      message: msg.HELP_INTRO,
      keyboard: buildHelpKeyboard(),
    })
  );
}

async function handleHelpSection(ctx, sectionKey) {
  const section = msg.HELP_SECTIONS[sectionKey];
  if (!section) {
    // Устаревшая/битая кнопка — просто показываем меню заново
    await handleHelp(ctx);
    return;
  }
  await ctx.send({
    message: section.text,
    keyboard: buildHelpKeyboard(),
  });
}

module.exports = {
  handleTopFactories,
  handleTopBalance,
  handleTopClans,
  handleTopRobot,
  handleTopSuperRobot,
  handleTopIncome,
  handleTopFarmLevel,
  handleTopFarmIncome,
  handleHelp,
  handleHelpSection,
};
