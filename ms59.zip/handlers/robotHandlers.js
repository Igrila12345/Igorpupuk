'use strict';

const players = require('../db/players');
const robot = require('../game/robot');
const calc = require('../game/calc');
const C = require('../game/constants');
const msg = require('../utils/messages');
const events = require('../game/events');
const images = require('../game/commandImages');

async function requireRegistered(ctx) {
  const player = await players.getPlayer(ctx.senderId);
  if (!player || player.registration_step !== 'done') {
    await ctx.send('⛔ Вы ещё не зарегистрированы. Напишите старт');
    return null;
  }
  return player;
}

// Русское склонение "жетон/жетона/жетонов"
function pluralTokens(n) {
  const mod10 = n % 10;
  const mod100 = n % 100;
  if (mod10 === 1 && mod100 !== 11) return 'жетон';
  if ([2, 3, 4].includes(mod10) && ![12, 13, 14].includes(mod100)) return 'жетона';
  return 'жетонов';
}

function statusBlock(player) {
  const level = player.robot_level || 1;
  let text = `🤖 ${robot.levelName(level)} (уровень ${level}/${C.ROBOT_MAX_LEVEL})\n`;
  const range = robot.incomeRange(level);
  text += `💰 Мгновенный сбор («робот»): ${calc.formatNumber(range.min)}–${calc.formatNumber(
    range.max
  )} вирт (случайно), раз в час\n`;
  text += `🪙 Отправка («отправить»): ${robot.tokensPerSend(level)} ${pluralTokens(robot.tokensPerSend(level))}, раз в час\n`;
  if (robot.canAttack(level)) {
    const power = robot.destroyPower(level);
    text += `⚔️ Боевая атака («робот атака @юзер»): сносит ${power} ${msg.pluralFactories(power)}, кулдаун ${calc.formatDuration(
      C.ROBOT_ATTACK_COOLDOWN_MS
    )}\n`;
  } else {
    text += `⚔️ Боевая атака откроется на уровне ${C.ROBOT_FACTORY_DESTROY_UNLOCK_LEVEL} (1 завод, дальше больше — до ${C.ROBOT_FACTORY_DESTROY_MAX} на уровне ${C.ROBOT_FACTORY_DESTROY_UNLOCK_LEVEL + (C.ROBOT_FACTORY_DESTROY_MAX - 1) * C.ROBOT_FACTORY_DESTROY_LEVELS_PER_STEP})\n`;
  }
  if (level < C.ROBOT_MAX_LEVEL) {
    text += `📈 Прокачка до ур. ${level + 1} «${robot.levelName(level + 1)}»: ${calc.formatNumber(
      robot.upgradeCost(level)
    )} вирт — робот прокачать`;
  } else {
    text += `🏆 Максимальный уровень достигнут!`;
  }
  return text;
}

// "робот" — мгновенно приносит доход виртами, если кулдаун прошёл; иначе показывает статус.
async function handleFarm(ctx) {
  const player = await requireRegistered(ctx);
  if (!player) return;

  const result = await robot.farmVirts(ctx.senderId);
  if (!result.ok) {
    if (result.reason === 'cooldown') {
      await ctx.send(
        images.withImage(
          'robot',
          `${statusBlock(player)}\n\n⏳ Робот уже приносил доход недавно. Следующий сбор через ${calc.formatDuration(
            result.msLeft
          )}.`
        )
      );
    } else {
      await ctx.send('⛔ Не удалось получить доход с робота.');
    }
    return;
  }

  await ctx.send(
    images.withImage(
      'robot',
      `🤖 ${robot.levelName(result.level)} мгновенно принёс ${calc.formatNumber(result.amount)} вирт!\n` +
        `⏳ Следующий сбор доступен через ${calc.formatDuration(result.cooldownMs)}.\n` +
        `Статистика: мой робот`
    )
  );
}

async function handleUpgrade(ctx) {
  const player = await requireRegistered(ctx);
  if (!player) return;

  const result = await robot.upgradeRobot(ctx.senderId);
  if (!result.ok) {
    if (result.reason === 'max_level') {
      await ctx.send(`⛔ У робота уже максимальный уровень (${C.ROBOT_MAX_LEVEL}).`);
    } else if (result.reason === 'not_enough_money') {
      await ctx.send(
        `⛔ Недостаточно вирт. Нужно ${calc.formatNumber(result.cost)}, не хватает ${calc.formatNumber(
          result.missing
        )}.`
      );
    } else {
      await ctx.send('⛔ Не удалось прокачать робота.');
    }
    return;
  }

  const newRange = robot.incomeRange(result.newLevel);
  await ctx.send(
    images.withImage(
      'robotUpgrade',
      `✅ Робот прокачан до уровня ${result.newLevel} — «${robot.levelName(result.newLevel)}»! ` +
        `Стоимость: ${calc.formatNumber(result.cost)} вирт.\n` +
        `Доход за сбор теперь: ${calc.formatNumber(newRange.min)}–${calc.formatNumber(
          newRange.max
        )} вирт (случайно), жетонов за отправку: ${robot.tokensPerSend(result.newLevel)}.`
    )
  );
}

// "робот атака @юзер" — боевая способность прокачанного питомца (с уровня
// ROBOT_FACTORY_DESTROY_UNLOCK_LEVEL): летит как оружие, сила растёт с уровнем (см. robot.destroyPower()).
async function handleAttack(ctx, targetId, peerId) {
  const vkId = ctx.senderId;
  const player = await requireRegistered(ctx);
  if (!player) return;

  if (!targetId) {
    await ctx.send('⛔ Укажите цель: робот атака @юзер');
    return;
  }

  const result = await robot.launchAttack(vkId, targetId, peerId);

  if (!result.ok) {
    const reasons = {
      self_attack: '⛔ Нельзя атаковать самого себя.',
      not_registered: '⛔ Цель не зарегистрирована в игре.',
      attacker_too_small: `⛔ Атаковать можно только имея от ${C.MIN_FACTORIES_TO_ATTACK} заводов. Сначала развейте экономику.`,
      defender_too_small: `⛔ Нельзя атаковать игрока с менее чем ${C.MIN_FACTORIES_TO_BE_ATTACKED} заводами.`,
    };
    if (result.reason === 'level_too_low') {
      await ctx.send(`⛔ Боевая атака откроется на уровне робота ${result.required}. Качайте: робот прокачать`);
      return;
    }
    if (result.reason === 'cooldown') {
      await ctx.send(`⏳ Робот ещё не восстановился после атаки. Осталось: ${calc.formatDuration(result.msLeft)}.`);
      return;
    }
    await ctx.send(reasons[result.reason] || '⛔ Атака невозможна.');
    return;
  }

  const attackerLink = msg.mentionLink(result.attackerId, result.attackerName);
  const defenderLink = msg.mentionLink(result.defenderId, result.defenderName);
  const name = robot.levelName(result.level);

  const drop = await events.awardDrop(vkId);

  await ctx.send(
    images.withImage(
      'robotAttack',
      `🤖 РОБОТ-ПИТОМЕЦ «${attackerLink}» ОТПРАВЛЕН В АТАКУ:\n` +
        `${name} (уровень ${result.level})\n` +
        `Цель: ${defenderLink}\n` +
        `Расстояние: ${Math.round(result.distance)} км\n` +
        `Прилёт через: ${calc.formatDuration(result.flightMs)}\n\n` +
        `Эффект: 💀 сносит ${result.power} ${msg.pluralFactories(result.power)}, если прорвётся\n` +
        `🛡️ Перехватить может только С-400 Триумф противника` +
        events.dropSuffix(drop)
    )
  );

  if (ctx.bot) {
    await ctx.bot
      .notifyUser(
        targetId,
        `⚠️ Игрок «${attackerLink}» отправил робота-питомца (ур. ${result.level}) по вашему городу! Прилёт через ${calc.formatDuration(
          result.flightMs
        )}. Единственная защита — С-400 Триумф.`
      )
      .catch(() => {});

    if (peerId) {
      await ctx.bot
        .sendToChat(
          peerId,
          `🤖 «${attackerLink}» отправил(а) робота-питомца (ур. ${result.level}) по «${defenderLink}». Прилёт через ${calc.formatDuration(
            result.flightMs
          )}.`
        )
        .catch(() => {});
    }
  }
}

// "отправить" — мгновенно приносит жетоны, раз в час
async function handleSend(ctx) {
  const player = await requireRegistered(ctx);
  if (!player) return;

  const result = await robot.sendForTokens(ctx.senderId);
  if (!result.ok) {
    if (result.reason === 'cooldown') {
      await ctx.send(
        `⏳ Робот уже отправлялся недавно. Следующая отправка через ${calc.formatDuration(result.msLeft)}.`
      );
    } else {
      await ctx.send('⛔ Не удалось отправить робота.');
    }
    return;
  }

  await ctx.send(
    `📦 Робот вернулся с ${result.amount} ${pluralTokens(result.amount)}! ` +
      `Следующая отправка через ${calc.formatDuration(result.cooldownMs)}.`
  );
}

// "мой робот" — только статистика, без побочных эффектов (не расходует кулдауны)
async function handleMyStats(ctx) {
  const player = await requireRegistered(ctx);
  if (!player) return;

  const farmCooldownMs = robot.effectiveCooldownMs(player, C.ROBOT_FARM_COOLDOWN_MS);
  const sendCooldownMs = robot.effectiveCooldownMs(player, C.ROBOT_SEND_COOLDOWN_MS);
  const farmLeft = robot.msLeft(player.robot_last_farm_at, farmCooldownMs);
  const sendLeft = robot.msLeft(player.robot_last_send_at, sendCooldownMs);

  let text = statusBlock(player) + '\n\n';
  if (calc.isVipActive(player)) {
    text += `👑 VIP активен до ${msg.formatDateTimeMsk(player.vip_until)} — доход +${Math.round(
      C.VIP_INCOME_BONUS * 100
    )}%, кулдауны робота короче на ${Math.round((1 - C.VIP_ROBOT_COOLDOWN_MULT) * 100)}%.\n\n`;
  }
  text +=
    farmLeft > 0
      ? `⏳ Сбор вирт («робот»): через ${calc.formatDuration(farmLeft)}\n`
      : `✅ Сбор вирт («робот») доступен прямо сейчас!\n`;
  text +=
    sendLeft > 0
      ? `⏳ Отправка за жетонами («отправить»): через ${calc.formatDuration(sendLeft)}`
      : `✅ Отправка за жетонами («отправить») доступна прямо сейчас!`;

  await ctx.send(images.withImage('robot', text.trim()));
}

// "роботы" — таблица уровней робота. Уровней теперь 999, поэтому вместо построчного вывода
// ВСЕХ уровней (что дало бы ~тысячу строк) показываем: подробно уровни 1-50 (как раньше),
// затем выборочно каждый 50-й уровень до конца плюс сам максимум — этого достаточно, чтобы
// увидеть кривую роста цены/дохода на дальних уровнях, не заваливая чат текстом.
async function handleLevelsList(ctx) {
  const rows = robot.buildLevelsTable();
  const detailed = rows.slice(0, 50);
  const sampled = [];
  for (let level = 100; level < C.ROBOT_MAX_LEVEL; level += 50) {
    sampled.push(rows[level - 1]);
  }
  sampled.push(rows[rows.length - 1]);

  const chunks = [detailed.slice(0, 25), detailed.slice(25, 50), sampled];

  function renderRow(row) {
    const costLabel = row.costToReach ? `${calc.formatNumber(row.costToReach)} вирт` : 'старт (уровень 1)';
    const attackLabel = row.destroyPower > 0 ? `${row.destroyPower} ${msg.pluralFactories(row.destroyPower)}` : '—';
    let text = `${row.level}. «${row.name}»\n`;
    text += `   💵 Цена прокачки до этого уровня: ${costLabel}\n`;
    text += `   💰 Доход за сбор: ${calc.formatNumber(row.incomeRange.min)}–${calc.formatNumber(
      row.incomeRange.max
    )} вирт | 🪙 Жетонов: ${row.tokensPerSend} | ⚔️ Атака: ${attackLabel}\n`;
    return text;
  }

  for (let i = 0; i < chunks.length; i++) {
    const chunk = chunks[i];
    if (!chunk.length) continue;
    const label = i < 2 ? `${chunk[0].level}-${chunk[chunk.length - 1].level} из ${C.ROBOT_MAX_LEVEL}` : `выборочно 100-${C.ROBOT_MAX_LEVEL} из ${C.ROBOT_MAX_LEVEL}, шаг 50`;
    let text = `🤖 ВСЕ УРОВНИ РОБОТА (${label})\n\n`;
    for (const row of chunk) {
      text += renderRow(row);
    }

    if (i === chunks.length - 1) {
      text += `\n⚔️ С уровня ${C.ROBOT_FACTORY_DESTROY_UNLOCK_LEVEL} доступна боевая атака: робот атака @юзер — сносит от 1 до ${C.ROBOT_FACTORY_DESTROY_MAX} заводов (растёт каждые ${C.ROBOT_FACTORY_DESTROY_LEVELS_PER_STEP} уровней), но всегда меньше, чем суперробот на максимуме.`;
    }

    await ctx.send(text.trim());
  }
}

module.exports = {
  handleFarm,
  handleUpgrade,
  handleAttack,
  handleSend,
  handleMyStats,
  handleLevelsList,
};
