'use strict';

const { Keyboard } = require('vk-io');
const players = require('../db/players');
const farm = require('../game/farm');
const calc = require('../game/calc');
const C = require('../game/constants');
const msg = require('../utils/messages');
const images = require('../game/commandImages');

async function requireRegistered(ctx) {
  const player = await players.getPlayer(ctx.senderId);
  if (!player || player.registration_step !== 'done') {
    await ctx.send('⛔ Вы ещё не зарегистрированы. Напишите старт');
    return null;
  }
  return player;
}

// Русское склонение "нанокоин/нанокоина/нанокоинов"
function pluralCoins(n) {
  const mod10 = n % 10;
  const mod100 = n % 100;
  if (mod10 === 1 && mod100 !== 11) return 'нанокоин';
  if ([2, 3, 4].includes(mod10) && ![12, 13, 14].includes(mod100)) return 'нанокоина';
  return 'нанокоинов';
}

function formatCoins(n) {
  return `${calc.formatNumber(n)}${C.FARM_COIN_ABBR}`;
}

function formatAutonomy(ms) {
  if (ms <= 0) return '0ч';
  const totalSeconds = Math.floor(ms / 1000);
  const hours = Math.floor(totalSeconds / 3600);
  const minutes = Math.floor((totalSeconds % 3600) / 60);
  const seconds = totalSeconds % 60;
  if (hours <= 0 && minutes <= 0) return `${seconds}сек.`;
  if (hours <= 0) return `${minutes}мин. ${seconds}сек.`;
  return `${hours}ч. ${minutes}мин. ${seconds}сек.`;
}

// Клавиатура под карточкой фермы — повторяет раскладку кнопок из клиента:
// [Запустить/Остановить] [Модернизировать]
// [Снять ₿]              [Продать ₿]
// [Обновить]              [Что это?]
// [🏠]
function buildFarmKeyboard(state) {
  const toggleButton = state.enabled
    ? Keyboard.textButton({ label: '⏸ Остановить', payload: { cmd: 'farm_disable' }, color: Keyboard.NEGATIVE_COLOR })
    : Keyboard.textButton({ label: '▶️ Запустить', payload: { cmd: 'farm_enable' }, color: Keyboard.POSITIVE_COLOR });

  return Keyboard.keyboard([
    [
      toggleButton,
      Keyboard.textButton({
        label: '⚙️ Модернизировать',
        payload: { cmd: 'farm_upgrade' },
        color: Keyboard.PRIMARY_COLOR,
      }),
    ],
    [
      Keyboard.textButton({ label: `💰 Снять ${C.FARM_COIN_ABBR}`, payload: { cmd: 'farm_withdraw' }, color: Keyboard.SECONDARY_COLOR }),
      Keyboard.textButton({ label: `💱 Продать ${C.FARM_COIN_ABBR}`, payload: { cmd: 'farm_sell' }, color: Keyboard.SECONDARY_COLOR }),
    ],
    [
      Keyboard.textButton({ label: '🔄 Обновить', payload: { cmd: 'farm_status' }, color: Keyboard.SECONDARY_COLOR }),
      Keyboard.textButton({ label: '🆘 Что это?', payload: { cmd: 'farm_info' }, color: Keyboard.SECONDARY_COLOR }),
    ],
    [Keyboard.textButton({ label: '🏠', payload: { cmd: 'farm_home' }, color: Keyboard.SECONDARY_COLOR })],
  ]).inline();
}

function buildFarmCard(player, state) {
  if (!state.built) {
    return {
      text:
        `⛏️ Майнинг-ферма ещё не построена.\n` +
        `💵 Постройка: ${calc.formatNumber(farm.upgradeCost(0))} вирт`,
      keyboard: Keyboard.keyboard([
        [Keyboard.textButton({ label: '⚙️ Построить', payload: { cmd: 'farm_upgrade' }, color: Keyboard.POSITIVE_COLOR })],
        [Keyboard.textButton({ label: '🏠', payload: { cmd: 'farm_home' }, color: Keyboard.SECONDARY_COLOR })],
      ]).inline(),
    };
  }

  const lines = [];
  lines.push('⛏️ Ферма');
  lines.push('');
  lines.push(`⚔️ Уровень: ${state.level}/${C.FARM_MAX_LEVEL}`);
  lines.push(`↔️ Статус: ${state.enabled ? 'Включена' : 'Выключена'}`);
  lines.push(`⚡ Мощность ${calc.formatNumber(state.rate)}mhs`);
  lines.push(`⛏️ Добыча ${calc.formatNumber(state.rate)}${C.FARM_COIN_ABBR}/час${calc.isFarmBoostActive(player) ? ` (🔥 ускорена x${C.DONATE_FARM_BOOST_MULTIPLIER} до ${msg.formatDateTimeMsk(player.farm_boost_until)})` : ''}`);
  lines.push(`🔢 Баланс: ${formatCoins(state.balance)}`);
  lines.push(`🕐 Автономность: ${formatAutonomy(state.autonomyMsLeft)}`);

  const coins = Number(player.farm_coins) || 0;
  lines.push('');
  lines.push(`👛 Снято на кошелёк: ${calc.formatNumber(coins)} ${pluralCoins(coins)}`);

  if (state.level < C.FARM_MAX_LEVEL) {
    lines.push(`📈 Прокачка до ур. ${state.level + 1}: ${calc.formatNumber(farm.upgradeCost(state.level))} вирт`);
  } else {
    lines.push('🏆 Максимальный уровень достигнут!');
  }

  return { text: lines.join('\n'), keyboard: buildFarmKeyboard(state) };
}

async function sendFarmCard(ctx, player, state) {
  const card = buildFarmCard(player, state);
  await ctx.send(images.withImage('farm', { message: card.text, keyboard: card.keyboard }));
}

async function handleStatus(ctx) {
  const player = await requireRegistered(ctx);
  if (!player) return;
  const result = await farm.getStatus(ctx.senderId);
  await sendFarmCard(ctx, player, result.state);
}

async function handleUpgrade(ctx) {
  const player = await requireRegistered(ctx);
  if (!player) return;

  const result = await farm.buildOrUpgrade(ctx.senderId);
  if (!result.ok) {
    if (result.reason === 'max_level') {
      await ctx.send(`⛔ У фермы уже максимальный уровень (${C.FARM_MAX_LEVEL}).`);
    } else if (result.reason === 'not_enough_money') {
      await ctx.send(
        `⛔ Недостаточно вирт. Нужно ${calc.formatNumber(result.cost)}, не хватает ${calc.formatNumber(
          result.missing
        )}.`
      );
    } else {
      await ctx.send('⛔ Не удалось прокачать ферму.');
    }
    return;
  }

  const rate = farm.ratePerHour(result.newLevel);
  if (result.wasBuilt) {
    await ctx.send(
      `✅ Майнинг-ферма построена за ${calc.formatNumber(result.cost)} вирт!\n` +
        `⚙️ Добыча: ${calc.formatNumber(rate)}${C.FARM_COIN_ABBR}/час, автономность ${C.FARM_AUTONOMY_HOURS} ч.`
    );
  } else {
    await ctx.send(
      `✅ Ферма прокачана до уровня ${result.newLevel}/${C.FARM_MAX_LEVEL}! Стоимость: ${calc.formatNumber(
        result.cost
      )} вирт.\n` + `⚙️ Добыча теперь: ${calc.formatNumber(rate)}${C.FARM_COIN_ABBR}/час.`
    );
  }

  const fresh = await players.getPlayer(ctx.senderId);
  const state = await farm.settleFarm(ctx.senderId, fresh);
  await sendFarmCard(ctx, fresh, state);
}

async function handleEnable(ctx) {
  const player = await requireRegistered(ctx);
  if (!player) return;

  const result = await farm.enableFarm(ctx.senderId);
  if (!result.ok) {
    if (result.reason === 'not_built') {
      await ctx.send('⛔ Ферма ещё не построена. Постройка: ферма прокачать');
      return;
    } else if (result.reason === 'already_on') {
      // просто покажем актуальный статус
    } else if (result.reason === 'full') {
      await ctx.send(
        `⛔ Баланс фермы уже полный (${formatCoins(result.balance)}). Сначала снимите: Снять ${C.FARM_COIN_ABBR}`
      );
      return;
    } else {
      await ctx.send('⛔ Не удалось включить ферму.');
      return;
    }
  }

  const fresh = await players.getPlayer(ctx.senderId);
  const state = await farm.settleFarm(ctx.senderId, fresh);
  await sendFarmCard(ctx, fresh, state);
}

async function handleDisable(ctx) {
  const player = await requireRegistered(ctx);
  if (!player) return;

  const result = await farm.disableFarm(ctx.senderId);
  if (!result.ok && result.reason === 'not_built') {
    await ctx.send('⛔ Ферма ещё не построена. Постройка: ферма прокачать');
    return;
  }

  const fresh = await players.getPlayer(ctx.senderId);
  const state = await farm.settleFarm(ctx.senderId, fresh);
  await sendFarmCard(ctx, fresh, state);
}

async function handleWithdraw(ctx) {
  const player = await requireRegistered(ctx);
  if (!player) return;

  const result = await farm.withdraw(ctx.senderId);
  if (!result.ok) {
    if (result.reason === 'not_built') {
      await ctx.send('⛔ Ферма ещё не построена. Постройка: ферма прокачать');
    } else if (result.reason === 'nothing_to_withdraw') {
      await ctx.send('⛔ Снимать пока нечего — баланс фермы пуст.');
    } else {
      await ctx.send('⛔ Не удалось снять ₿.');
    }
    return;
  }

  await ctx.send(`✅ Вы сняли ${formatCoins(result.amount)}`);

  const fresh = await players.getPlayer(ctx.senderId);
  const state = await farm.settleFarm(ctx.senderId, fresh);
  await sendFarmCard(ctx, fresh, state);
}

async function handleSellPrompt(ctx) {
  const player = await requireRegistered(ctx);
  if (!player) return;

  const rate = await farm.getExchangeRate();
  const coins = Number(player.farm_coins) || 0;

  await ctx.send(
    `📈 Курс продажи: ${calc.formatNumber(rate)} вирт/1${C.FARM_COIN_ABBR}\n` +
      `👛 Ваш баланс: ${formatCoins(coins)}\n` +
      `🆘 Введите команду: ферма продать [число|всё]\n` +
      `💡 Мин. сумма: 1${C.FARM_COIN_ABBR}`
  );
}

async function handleSell(ctx, rawAmount) {
  const player = await requireRegistered(ctx);
  if (!player) return;

  if (!rawAmount) {
    await handleSellPrompt(ctx);
    return;
  }

  const normalized = rawAmount.toLowerCase();
  const amount = normalized === 'всё' || normalized === 'все' ? 'all' : parseInt(rawAmount, 10);

  if (amount !== 'all' && (!Number.isFinite(amount) || amount <= 0)) {
    await ctx.send('⛔ Формат: ферма продать [число|всё]');
    return;
  }

  const result = await farm.sellCoins(ctx.senderId, amount);
  if (!result.ok) {
    if (result.reason === 'nothing_to_sell') {
      await ctx.send('⛔ У вас нет нанокоинов на продажу.');
    } else if (result.reason === 'not_enough_coins') {
      await ctx.send(`⛔ У вас только ${calc.formatNumber(result.have)} нанокоинов.`);
    } else {
      await ctx.send('⛔ Не удалось продать нанокоины.');
    }
    return;
  }

  await ctx.send(
    `💱 Продано ${calc.formatNumber(result.sold)} ${pluralCoins(result.sold)} по курсу ${calc.formatNumber(
      result.rate
    )} вирт — получено ${calc.formatNumber(result.virts)} вирт.`
  );
}

async function handleInfo(ctx) {
  const player = await requireRegistered(ctx);
  if (!player) return;

  await ctx.send(
    `🆘 Майнинг-ферма\n\n` +
      `Ферма добывает отдельную валюту — ${C.FARM_COIN_NAME}ы (${C.FARM_COIN_ABBR}) — непрерывно, пока включена.\n` +
      `⚡ Мощность растёт с уровнем прокачки — чем выше уровень, тем больше ${C.FARM_COIN_ABBR}/час.\n` +
      `🕐 Автономность — сколько часов ферма копит ${C.FARM_COIN_ABBR} без вашего участия (сейчас ${C.FARM_AUTONOMY_HOURS} ч). ` +
      `Как только автономность обнуляется, ферма выключается и баланс перестаёт расти.\n` +
      `💰 «Снять ${C.FARM_COIN_ABBR}» переносит накопленное на личный кошелёк и одновременно перезапускает автономность.\n` +
      `💱 «Продать ${C.FARM_COIN_ABBR}» обменивает кошелёк на вирты по плавающему курсу (меняется раз в час).`
  );
}

module.exports = {
  handleStatus,
  handleUpgrade,
  handleEnable,
  handleDisable,
  handleWithdraw,
  handleSellPrompt,
  handleSell,
  handleInfo,
};
