'use strict';

const players = require('../db/players');
const factoryLimit = require('../game/factoryLimit');
const calc = require('../game/calc');
const C = require('../game/constants');
const images = require('../game/commandImages');

async function handleStatus(ctx) {
  const player = await players.getPlayer(ctx.senderId);
  if (!player || player.registration_step !== 'done') {
    await ctx.send('⛔ Вы ещё не зарегистрированы. Напишите старт');
    return;
  }

  const level = player.factory_limit_level || 0;
  const currentLimit = calc.currentFactoryLimit(level);
  const nextRow = C.FACTORY_LIMIT_LEVELS.find((l) => l.level === level + 1);

  let text = `🏭 ЛИМИТ ЗАВОДОВ\nТекущий лимит: ${currentLimit}\nЗаводов у вас: ${player.factories}`;

  if (nextRow) {
    text += `\n\n📈 Расширить до ${nextRow.limit}: ${calc.formatNumber(nextRow.cost)} вирт — лимит расширить`;
  } else {
    text += `\n\n🏆 Максимальный лимит достигнут (1000)!`;
  }

  await ctx.send(images.withImage('limit', text));
}

async function handleExpand(ctx) {
  const player = await players.getPlayer(ctx.senderId);
  if (!player || player.registration_step !== 'done') {
    await ctx.send('⛔ Вы ещё не зарегистрированы. Напишите старт');
    return;
  }

  const result = await factoryLimit.expand(ctx.senderId);
  if (!result.ok) {
    if (result.reason === 'max_level') {
      await ctx.send('⛔ Уже максимальный лимит заводов (1000).');
    } else if (result.reason === 'not_enough_money') {
      await ctx.send(
        `⛔ Недостаточно вирт. Нужно ${calc.formatNumber(result.cost)}, не хватает ${calc.formatNumber(
          result.missing
        )}.`
      );
    } else {
      await ctx.send('⛔ Не удалось расширить лимит.');
    }
    return;
  }

  await ctx.send(`✅ Лимит заводов расширен до ${result.newLimit}! Потрачено: ${calc.formatNumber(result.cost)} вирт.`);
}

module.exports = { handleStatus, handleExpand };
