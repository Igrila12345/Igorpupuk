'use strict';

const players = require('../db/players');
const science = require('../game/science');
const calc = require('../game/calc');
const C = require('../game/constants');
const events = require('../game/events');
const images = require('../game/commandImages');

async function requireRegistered(ctx) {
  const player = await players.getPlayer(ctx.senderId);
  if (!player || player.registration_step !== 'done') {
    await ctx.send('⛔ Вы ещё не зарегистрированы. Напишите старт');
    return null;
  }
  return player;
}

async function handleStatus(ctx) {
  const player = await requireRegistered(ctx);
  if (!player) return;

  const limit = calc.currentScienceLimit(player.science_limit_level);
  const nextRow = C.SCIENCE_LIMIT_LEVELS.find((l) => l.level === (player.science_limit_level || 1) + 1);
  const nextCost = calc.scienceBuildCost(player.science_centers || 0);

  let text =
    `🔬 НАУЧНЫЕ ЦЕНТРЫ\n` +
    `Построено: ${player.science_centers || 0}/${limit}\n` +
    `Доход с центра: ${C.SCIENCE_INCOME_PER_HOUR} вирт/час\n` +
    `Постройка следующего: ${C.SCIENCE_BUILD_FACTORY_COST} заводов + ${calc.formatNumber(nextCost)} вирт — наука построить\n` +
    `(цена растёт на ${calc.formatNumber(C.SCIENCE_BUILD_COST_STEP_AMOUNT)} вирт каждые ${C.SCIENCE_BUILD_COST_STEP_SIZE} построенных центров)`;

  if (nextRow) {
    text += `\n\n📈 Расширить лимит до ${nextRow.limit}: ${calc.formatNumber(nextRow.cost)} вирт — наука расширить`;
  } else {
    text += `\n\n🏆 Максимальный уровень лимита достигнут!`;
  }

  const scienceLeftToExchange = Math.max(
    0,
    (player.science_centers || 0) - C.NEWBIE_PROTECTION_SCIENCE_CENTERS
  );
  const exchangeLeftToday = C.SCIENCE_TO_FACTORY_MAX_PER_DAY - (player.exchange_science_to_factory_count_today || 0);
  const factoriesPerCenter = Math.max(1, Math.floor(C.SCIENCE_BUILD_FACTORY_COST * C.SCIENCE_TO_FACTORY_RATE));
  text += `\n\n🔁 Обменять центр(ы) обратно на заводы: наука обменять [количество]\n` +
    `Курс: 1 центр = ${factoriesPerCenter} завода (вирты за постройку не возвращаются)\n` +
    `Доступно к обмену: ${scienceLeftToExchange} (защищено: ${C.NEWBIE_PROTECTION_SCIENCE_CENTERS}) | Осталось обменов сегодня: ${Math.max(0, exchangeLeftToday)}/${C.SCIENCE_TO_FACTORY_MAX_PER_DAY}`;

  await ctx.send(images.withImage('science', text));
}

async function handleBuild(ctx) {
  const player = await requireRegistered(ctx);
  if (!player) return;

  const result = await science.buildCenter(ctx.senderId);
  if (!result.ok) {
    if (result.reason === 'limit_reached') {
      await ctx.send(`⛔ Достигнут лимит научных центров (${result.limit}). Расширьте: наука расширить`);
    } else if (result.reason === 'factory_threshold') {
      await ctx.send(`⛔ Для обмена на науку нужно иметь на балансе не менее ${result.need} заводов (сейчас: ${result.have}).`);
    } else if (result.reason === 'not_enough_factories') {
      await ctx.send(`⛔ Нужно ${result.need} обычных заводов (есть: ${result.have}).`);
    } else if (result.reason === 'not_enough_money') {
      await ctx.send(
        `⛔ Недостаточно вирт. Нужно ${calc.formatNumber(result.cost)}, не хватает ${calc.formatNumber(result.missing)}.`
      );
    } else {
      await ctx.send('⛔ Не удалось построить научный центр.');
    }
    return;
  }

  const drop = await events.awardDrop(ctx.senderId);
  await ctx.send(
    `🔬 НАУЧНЫЙ ЦЕНТР ПОСТРОЕН!\n${C.SCIENCE_BUILD_FACTORY_COST} заводов и ${calc.formatNumber(
      result.cost
    )} вирт было списано.\nНовый доход: +${C.SCIENCE_INCOME_PER_HOUR} вирт/час.${events.dropSuffix(drop)}`
  );
}

async function handleExpand(ctx) {
  const player = await requireRegistered(ctx);
  if (!player) return;

  const result = await science.expandLimit(ctx.senderId);
  if (!result.ok) {
    if (result.reason === 'max_level') {
      await ctx.send('⛔ Уже максимальный уровень лимита научных центров.');
    } else if (result.reason === 'not_enough_money') {
      await ctx.send(
        `⛔ Недостаточно вирт. Нужно ${calc.formatNumber(result.cost)}, не хватает ${calc.formatNumber(
          result.missing
        )}.`
      );
    } else {
      await ctx.send('⛔ Не удалось расширить лимит.');
    }
    return;
  }

  await ctx.send(`✅ Лимит научных центров расширен до ${result.newLimit}! Потрачено: ${calc.formatNumber(result.cost)} вирт.`);
}

async function handleExchangeToFactories(ctx, countArg) {
  const player = await requireRegistered(ctx);
  if (!player) return;

  const count = parseInt(countArg, 10);
  if (!Number.isInteger(count) || count <= 0) {
    await ctx.send('⛔ Формат: наука обменять [количество] — например: наука обменять 1');
    return;
  }

  const result = await science.exchangeToFactories(ctx.senderId, count);
  if (!result.ok) {
    if (result.reason === 'daily_limit') {
      await ctx.send(`⛔ Дневной лимит обмена науки на заводы исчерпан (${result.limit}/день). Попробуйте завтра.`);
    } else if (result.reason === 'exceeds_daily_limit') {
      await ctx.send(
        `⛔ Сегодня можно обменять ещё максимум ${result.remainingToday} центр(ов) (лимит ${C.SCIENCE_TO_FACTORY_MAX_PER_DAY}/день).`
      );
    } else if (result.reason === 'not_enough_science') {
      await ctx.send(
        `⛔ Недостаточно научных центров сверх защиты новичков. Есть: ${result.have}, порог защиты: ${result.protectedFloor}, максимум к обмену сейчас: ${result.maxExchangeable}.`
      );
    } else {
      await ctx.send('⛔ Не удалось обменять науку на заводы.');
    }
    return;
  }

  await ctx.send(
    `✅ Обменяно ${result.centersSpent} науч. центр(ов) на ${result.factoriesGained} завод(ов) (курс: 1 центр = ${result.factoriesPerCenter} завода, вирты за постройку центра не возвращаются).\n` +
      `Осталось обменов сегодня: ${result.remainingToday}/${C.SCIENCE_TO_FACTORY_MAX_PER_DAY}.`
  );
}

module.exports = { handleStatus, handleBuild, handleExpand, handleExchangeToFactories };
