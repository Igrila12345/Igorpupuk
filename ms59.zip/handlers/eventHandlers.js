'use strict';

const players = require('../db/players');
const events = require('../game/events');
const calc = require('../game/calc');
const C = require('../game/constants');

async function requireRegistered(ctx) {
  const player = await players.getPlayer(ctx.senderId);
  if (!player || player.registration_step !== 'done') {
    await ctx.send('⛔ Вы ещё не зарегистрированы. Напишите !старт');
    return null;
  }
  return player;
}

// "!ивент" — статус: текущий сезон (если есть), ваш баланс ивент-валюты, открыт ли магазин.
async function handleStatus(ctx) {
  const player = await requireRegistered(ctx);
  if (!player) return;

  const season = await events.getActiveSeason();
  const shopOpen = await events.isShopOpen();
  const balance = player.event_currency || 0;

  let text = `🎉 СЕЗОННЫЙ ИВЕНТ\n\n`;

  if (season) {
    text +=
      `${season.emoji} Сейчас идёт: ${season.name}\n` +
      `За постройку заводов, научных центров, сбор бонуса и атаки на игроков вам будет случайно ` +
      `выпадать ${season.emoji} (1–3 за действие).\n\n`;
  } else {
    text += `😴 Сейчас ни один сезонный ивент не запущен. Валюта за действия не капает.\n\n`;
  }

  text += `💰 Ваш баланс ивент-валюты: ${calc.formatNumber(balance)}\n`;
  text += shopOpen
    ? `🛒 Ивент-магазин ОТКРЫТ: ивент магазин — список товаров, ивент купить [товар] [кол-во] — покупка.`
    : `🔒 Ивент-магазин сейчас закрыт администратором.`;

  await ctx.send(text);
}

// "!ивент магазин" — список товаров и цен.
async function handleShop(ctx) {
  const player = await requireRegistered(ctx);
  if (!player) return;

  const shopOpen = await events.isShopOpen();
  const balance = player.event_currency || 0;

  let text = `🛒 ИВЕНТ-МАГАЗИН\n\nВаш баланс: ${calc.formatNumber(balance)} валюты\n\n`;
  events.SHOP_ITEMS.forEach((item) => {
    text += `${item.title} — ${calc.formatNumber(item.price)} валюты\n`;
  });
  text += `\nКупить: ивент купить [завод|наука|вип] [количество]`;

  if (!shopOpen) {
    text += `\n\n🔒 Магазин сейчас ЗАКРЫТ администратором — купить пока нельзя, но можно копить валюту.`;
  }

  await ctx.send(text);
}

// "!ивент купить [товар] [количество]"
async function handlePurchase(ctx, itemArg, qtyArg) {
  const player = await requireRegistered(ctx);
  if (!player) return;

  if (!itemArg) {
    await ctx.send('⛔ Формат: ивент купить [завод|наука|вип] [количество]');
    return;
  }

  let quantity = 1;
  if (qtyArg !== undefined && qtyArg !== null && String(qtyArg).trim() !== '') {
    const parsed = parseInt(qtyArg, 10);
    if (!Number.isInteger(parsed) || parsed < 1) {
      await ctx.send('⛔ Некорректное количество.');
      return;
    }
    quantity = parsed;
  }

  const result = await events.purchase(ctx.senderId, itemArg, quantity);

  if (!result.ok) {
    const reasons = {
      shop_closed: '🔒 Ивент-магазин сейчас закрыт администратором.',
      unknown_item: '⛔ Неизвестный товар. Доступно: завод, наука, вип. См. список: ивент магазин',
      not_registered: '⛔ Вы ещё не зарегистрированы. Напишите !старт',
    };
    if (result.reason === 'not_enough_currency') {
      await ctx.send(
        `⛔ Недостаточно ивент-валюты. Нужно ${calc.formatNumber(result.need)}, у вас ${calc.formatNumber(
          result.have
        )}.`
      );
      return;
    }
    if (result.reason === 'factory_limit') {
      await ctx.send(`⛔ Достигнут максимум заводов (${result.max}). Расширьте лимит: лимит расширить`);
      return;
    }
    if (result.reason === 'science_limit') {
      await ctx.send(`⛔ Достигнут лимит научных центров (${result.max}). Расширьте: наука расширить`);
      return;
    }
    await ctx.send(reasons[result.reason] || '⛔ Не удалось совершить покупку.');
    return;
  }

  let text = `✅ Куплено: ${result.item.title} x${result.qty} за ${calc.formatNumber(result.totalPrice)} валюты.`;
  if (result.item.key === 'vip') {
    const msg = require('../utils/messages');
    text += `\n👑 VIP активен до ${msg.formatDateTimeMsk(result.vipUntil)}.`;
  }
  await ctx.send(text);
}

module.exports = { handleStatus, handleShop, handlePurchase };
