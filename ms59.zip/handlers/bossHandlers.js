'use strict';

const { Keyboard } = require('vk-io');
const players = require('../db/players');
const boss = require('../game/boss');
const quests = require('../game/quests');
const calc = require('../game/calc');
const C = require('../game/constants');
const msg = require('../utils/messages');
const images = require('../game/commandImages');

function missText(penalties) {
  const parts = [];
  if (penalties.science > 0) parts.push(`науки: -${penalties.science}`);
  if (penalties.factory > 0) parts.push(`заводов: -${penalties.factory}`);
  if (!parts.length) return '';
  return ` (списано у вас: ${parts.join(', ')})`;
}

// Кнопка "Правила босса" под сообщением статуса — открывает раздел помощи "boss"
// (полное описание механики: цена ракеты, шанс попадания, награда, штраф, финальные бонусы).
function bossHelpKeyboard() {
  return Keyboard.keyboard([
    [
      Keyboard.textButton({
        label: '📖 Правила босса',
        payload: { cmd: 'help_section', section: 'boss' },
        color: Keyboard.PRIMARY_COLOR,
      }),
    ],
  ]).inline();
}

async function handleBossStatus(ctx) {
  const vkId = ctx.senderId;
  const player = await players.getPlayer(vkId);
  if (!player || player.registration_step !== 'done') {
    await ctx.send('⛔ Вы ещё не зарегистрированы. Напишите старт');
    return;
  }

  const state = await boss.getState();
  if (!state || !state.active) {
    await ctx.send(
      images.withImage('boss', {
        message:
          `👹 МИРОВОЙ БОСС\n\n` +
          `Сейчас босс не активен. Ждите объявления от администрации — как только босс появится, ` +
          `здесь можно будет покупать ракеты «${C.BOSS_ROCKET_NAME}» и бить по нему всем сервером.`,
        keyboard: bossHelpKeyboard(),
      })
    );
    return;
  }

  const myEntry = (state.participants && state.participants[String(vkId)]) || { hits: 0, misses: 0, fired: 0, earned: 0 };
  const top = boss.topParticipants(state, 5);
  const topLines = top.length
    ? top
        .map((p, i) => `${i + 1}. ${msg.mentionLink(p.vkId, `игрок ${p.vkId}`)} — ${p.hits} попаданий (${p.fired} ракет)`)
        .join('\n')
    : 'пока никто не стрелял';

  const dailyUsed = player.boss_launch_day && String(player.boss_launch_day).slice(0, 10) === todayStr()
    ? player.boss_launch_count_today || 0
    : 0;
  const dailyLeft = Math.max(0, C.BOSS_MAX_ROCKETS_PER_DAY - dailyUsed);

  await ctx.send(
    images.withImage('boss', {
      message:
        `👹 МИРОВОЙ БОСС — АКТИВЕН\n\n` +
        `🚀 Ракета «${C.BOSS_ROCKET_NAME}»: ${C.BOSS_ROCKET_PRICE} вирт/шт\n` +
        `🎯 Шанс попадания: ${Math.round(C.BOSS_HIT_CHANCE * 100)}%\n` +
        `💰 Награда за попадание: ${C.BOSS_HIT_REWARD_MIN}-${C.BOSS_HIT_REWARD_MAX} вирт (рандом)\n` +
        `⚠️ При промахе босс может забрать у вас 1 завод или 1 научный центр\n` +
        `📅 Лимит: ${C.BOSS_MAX_ROCKETS_PER_DAY} ракет/день (у вас осталось: ${dailyLeft})\n\n` +
        `Ваш вклад: ${myEntry.hits} попаданий из ${myEntry.fired} ракет, заработано ${calc.formatNumber(myEntry.earned)} вирт\n\n` +
        `🏆 ТОП по попаданиям:\n${topLines}\n\n` +
        `Выстрелить: босс [кол-во ракет], например «босс 10»`,
      keyboard: bossHelpKeyboard(),
    })
  );
}

function todayStr() {
  const parts = new Intl.DateTimeFormat('en-CA', { timeZone: 'Europe/Moscow' }).formatToParts(new Date());
  const map = {};
  for (const p of parts) map[p.type] = p.value;
  return `${map.year}-${map.month}-${map.day}`;
}

async function handleBossFire(ctx, countArg) {
  const vkId = ctx.senderId;
  const player = await players.getPlayer(vkId);
  if (!player || player.registration_step !== 'done') {
    await ctx.send('⛔ Вы ещё не зарегистрированы. Напишите старт');
    return;
  }

  const count = parseInt(countArg, 10);
  if (!Number.isInteger(count) || count <= 0) {
    await handleBossStatus(ctx);
    return;
  }

  const result = await boss.launchRockets(vkId, count);

  if (!result.ok) {
    if (result.reason === 'no_boss') {
      await ctx.send('👹 Сейчас босс не активен — стрелять не по кому.');
    } else if (result.reason === 'daily_limit') {
      await ctx.send(`⛔ На сегодня лимит ракет по боссу исчерпан (${result.dailyLimitToday}/день).`);
    } else if (result.reason === 'insufficient_balance') {
      await ctx.send(`⛔ Недостаточно вирт. Цена одной ракеты «${C.BOSS_ROCKET_NAME}»: ${C.BOSS_ROCKET_PRICE}.`);
    } else {
      await ctx.send('⛔ Не удалось выстрелить.');
    }
    return;
  }

  const cappedNote = result.capped
    ? ` (запрошено ${result.requestedCount}, выпущено ${result.fired} — упёрлись в лимит/баланс)`
    : '';

  const questNotices = await quests.trackProgress(vkId, 'boss', result.fired);

  await ctx.send(
    images.withImage('bossNumber', {
      message:
        `🚀 Выпущено ${result.fired} ракет «${C.BOSS_ROCKET_NAME}»${cappedNote}, потрачено ${calc.formatNumber(result.cost)} вирт.\n\n` +
        `🎯 Попаданий: ${result.hits}${result.doubled ? ' (бафф x2 активен!)' : ''}\n` +
        `💨 Промахов: ${result.misses}${missText(result.penalties)}\n` +
        `💰 Заработано: ${calc.formatNumber(result.earned)} вирт\n` +
        `📅 Осталось ракет сегодня: ${result.dailyLeft}` +
        (questNotices.length ? `\n\n${questNotices.join('\n')}` : ''),
      keyboard: bossHelpKeyboard(),
    })
  );
}

module.exports = { handleBossStatus, handleBossFire };
