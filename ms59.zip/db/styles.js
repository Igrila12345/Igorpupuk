'use strict';

const { query } = require('./pool');

async function createStyle(ownerVkId, kind, attachment, forced = false) {
  const res = await query(
    'INSERT INTO player_styles (owner_vk_id, kind, attachment, forced) VALUES ($1, $2, $3, $4) RETURNING *',
    [ownerVkId, kind, attachment, forced]
  );
  return res.rows[0];
}

async function getStyleById(id) {
  const res = await query('SELECT * FROM player_styles WHERE id = $1', [id]);
  return res.rows[0] || null;
}

async function getStylesByOwner(ownerVkId) {
  const res = await query('SELECT * FROM player_styles WHERE owner_vk_id = $1 ORDER BY id ASC', [ownerVkId]);
  return res.rows;
}

async function setStyleOwner(id, ownerVkId) {
  await query('UPDATE player_styles SET owner_vk_id = $2 WHERE id = $1', [id, ownerVkId]);
}

async function setStyleForced(id, forced) {
  await query('UPDATE player_styles SET forced = $2 WHERE id = $1', [id, forced]);
}

async function deleteStyle(id) {
  await query('DELETE FROM player_styles WHERE id = $1', [id]);
}

// ===================== ВИТРИНА (МАРКЕТПЛЕЙС) =====================

async function createListing(styleId, sellerVkId, price) {
  const res = await query(
    'INSERT INTO style_listings (style_id, seller_vk_id, price) VALUES ($1, $2, $3) RETURNING *',
    [styleId, sellerVkId, price]
  );
  return res.rows[0];
}

async function getListingById(id) {
  const res = await query(
    `SELECT l.*, s.kind, s.attachment, s.forced
     FROM style_listings l
     JOIN player_styles s ON s.id = l.style_id
     WHERE l.id = $1`,
    [id]
  );
  return res.rows[0] || null;
}

async function getAllListings(limit = 30) {
  const res = await query(
    `SELECT l.*, s.kind, s.attachment
     FROM style_listings l
     JOIN player_styles s ON s.id = l.style_id
     ORDER BY l.listed_at DESC
     LIMIT $1`,
    [limit]
  );
  return res.rows;
}

async function getListingByStyleId(styleId) {
  const res = await query('SELECT * FROM style_listings WHERE style_id = $1', [styleId]);
  return res.rows[0] || null;
}

async function deleteListing(id) {
  await query('DELETE FROM style_listings WHERE id = $1', [id]);
}

module.exports = {
  createStyle,
  getStyleById,
  getStylesByOwner,
  setStyleOwner,
  setStyleForced,
  deleteStyle,
  createListing,
  getListingById,
  getAllListings,
  getListingByStyleId,
  deleteListing,
};
