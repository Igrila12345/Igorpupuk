'use strict';

const { query } = require('./pool');

// Сколько игрок уже произвёл/получил в этой категории в ТЕКУЩЕМ часовом окне.
// Окно = календарный час (date_trunc('hour', NOW())). Если сохранённая запись относится
// к прошлому часу, она считается устаревшей и трактуется как 0 (реальный сброс
// произойдёт при следующей записи через addUsage — см. ниже).
async function getUsage(playerId, category) {
  const res = await query(
    `SELECT quantity FROM hourly_production_limits
     WHERE player_id = $1 AND category = $2 AND hour_bucket = date_trunc('hour', NOW())`,
    [playerId, category]
  );
  return res.rows[0] ? Number(res.rows[0].quantity) : 0;
}

// Добавляет amount к счётчику текущего часа. Если запись относится к прошлому часу
// (или её ещё нет) — счётчик стартует заново с amount, а не суммируется со старым значением.
async function addUsage(playerId, category, amount) {
  await query(
    `INSERT INTO hourly_production_limits (player_id, category, hour_bucket, quantity)
     VALUES ($1, $2, date_trunc('hour', NOW()), $3)
     ON CONFLICT (player_id, category) DO UPDATE SET
       quantity = CASE
         WHEN hourly_production_limits.hour_bucket = date_trunc('hour', NOW())
         THEN hourly_production_limits.quantity + EXCLUDED.quantity
         ELSE EXCLUDED.quantity
       END,
       hour_bucket = date_trunc('hour', NOW())`,
    [playerId, category, amount]
  );
}

module.exports = { getUsage, addUsage };
