'use strict';

const { query } = require('./pool');

async function createAttack(attackerId, defenderId, weapon, quantity, distanceKm, arrivalAt, peerId) {
  const res = await query(
    `INSERT INTO attacks_in_flight (attacker_id, defender_id, weapon, quantity, distance_km, arrival_at, peer_id)
     VALUES ($1, $2, $3, $4, $5, $6, $7) RETURNING *`,
    [attackerId, defenderId, weapon, quantity, distanceKm, arrivalAt, peerId || null]
  );
  return res.rows[0];
}

async function getDueAttacks() {
  const res = await query(
    `SELECT * FROM attacks_in_flight WHERE resolved = FALSE AND arrival_at <= NOW()`
  );
  return res.rows;
}

async function getAllPendingAttacks() {
  const res = await query(`SELECT * FROM attacks_in_flight WHERE resolved = FALSE`);
  return res.rows;
}

async function markAttackResolved(id) {
  await query('UPDATE attacks_in_flight SET resolved = TRUE WHERE id = $1', [id]);
}

async function setCooldown(attackerId, defenderId) {
  await query(
    `INSERT INTO attack_cooldowns (attacker_id, defender_id, last_attack_at)
     VALUES ($1, $2, NOW())
     ON CONFLICT (attacker_id, defender_id) DO UPDATE SET last_attack_at = NOW()`,
    [attackerId, defenderId]
  );
}

async function getCooldown(attackerId, defenderId) {
  const res = await query(
    'SELECT last_attack_at FROM attack_cooldowns WHERE attacker_id = $1 AND defender_id = $2',
    [attackerId, defenderId]
  );
  return res.rows[0] ? res.rows[0].last_attack_at : null;
}

module.exports = {
  createAttack,
  getDueAttacks,
  getAllPendingAttacks,
  markAttackResolved,
  setCooldown,
  getCooldown,
};
