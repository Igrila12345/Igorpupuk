'use strict';

const C = require('./constants');

function distanceKm(x1, y1, x2, y2) {
  return Math.sqrt((x1 - x2) ** 2 + (y1 - y2) ** 2);
}

function nextFactoryPrice(currentCount) {
  return Math.round(C.FACTORY_BASE_PRICE * Math.pow(C.FACTORY_PRICE_GROWTH, currentCount));
}

// Активные (не заблокированные) заводы = всего заводов - сумма заблокированных - заводы в производстве (учитывается отдельно вызывающим кодом)
function sumBlocked(blockedFactories) {
  if (!blockedFactories || !Array.isArray(blockedFactories)) return 0;
  const now = Date.now();
  return blockedFactories
    .filter((b) => new Date(b.unblock_at).getTime() > now)
    .reduce((sum, b) => sum + b.count, 0);
}

function isVipActive(player) {
  return !!(player && player.vip_until && new Date(player.vip_until) > new Date());
}

function isMinerActive(player) {
  return !!(player && player.miner_until && new Date(player.miner_until) > new Date());
}

// Майнер, выданный командой "!админ майнер @юзер навсегда", ставит miner_until на
// MINER_FOREVER_YEARS лет вперёд — считаем такой майнер "вечным" для отображения (вместо
// конкретной далёкой даты показываем игроку просто "навсегда").
function isMinerForever(player) {
  if (!isMinerActive(player)) return false;
  const yearsLeft = (new Date(player.miner_until).getTime() - Date.now()) / (365.25 * 24 * 60 * 60 * 1000);
  return yearsLeft > C.MINER_FOREVER_DISPLAY_THRESHOLD_YEARS;
}

// ===================== РАСХОДУЕМЫЕ ДОНАТ-БАФФЫ (см. game/donateBuffs.js, game/constants.js) =====================

function isIncomeBoostActive(player) {
  return !!(player && player.income_boost_until && new Date(player.income_boost_until) > new Date());
}

// Щит: защита заводов от НЕядерного оружия (см. game/combat.js, game/robot.js, game/superRobot.js —
// ядерное оружие (nuke_strike) щит намеренно НЕ проверяет и наносит урон как обычно).
function isShieldActive(player) {
  return !!(player && player.shield_until && new Date(player.shield_until) > new Date());
}

function isWorkDoubleActive(player) {
  return !!(player && player.work_double_until && new Date(player.work_double_until) > new Date());
}

function isFarmBoostActive(player) {
  return !!(player && player.farm_boost_until && new Date(player.farm_boost_until) > new Date());
}

// Донат-бафф x2 к награде за попадание по мировому боссу (см. game/boss.js, DONATE_BOSS_DOUBLE_*)
function isBossDoubleActive(player) {
  return !!(player && player.boss_double_until && new Date(player.boss_double_until) > new Date());
}

function incomePerHour(player, factoriesInProduction = 0) {
  const blocked = sumBlocked(player.blocked_factories);
  const normalFactories = player.factories - player.gold_mine_count;
  const goldFactories = player.gold_mine_count;
  // Считаем усреднённо: доход пропорционален доле активных заводов
  const totalActive = Math.max(player.factories - blocked - factoriesInProduction, 0);
  const activeRatio = player.factories > 0 ? totalActive / player.factories : 0;
  let income =
    normalFactories * C.FACTORY_INCOME_PER_HOUR * activeRatio +
    goldFactories * C.FACTORY_INCOME_PER_HOUR * C.GOLD_MINE_MULTIPLIER * activeRatio;

  // Научные центры — не подвержены блокировке/производству, доход стабильный
  const scienceCenters = player.science_centers || 0;
  income += scienceCenters * C.SCIENCE_INCOME_PER_HOUR;

  const radiationActive = player.radiation_until && new Date(player.radiation_until) > new Date();
  if (radiationActive) income *= 1 - C.RADIATION_INCOME_PENALTY;

  // Бонус для новых/маленьких игроков (catch-up): полный +NEWBIE_BOOST_INCOME_BONUS начиная
  // с 1 завода, линейно убывает до 0 на пороге NEWBIE_BOOST_FACTORY_THRESHOLD и выше. Не помогает
  // игрокам, которые уже прошли порог — только выравнивает разрыв в самом начале игры.
  if (player.factories < C.NEWBIE_BOOST_FACTORY_THRESHOLD) {
    const progress = Math.max(0, player.factories - 1) / (C.NEWBIE_BOOST_FACTORY_THRESHOLD - 1);
    const boost = C.NEWBIE_BOOST_INCOME_BONUS * (1 - progress);
    income *= 1 + boost;
  }

  // VIP: +25% к пассивному доходу
  if (isVipActive(player)) income *= 1 + C.VIP_INCOME_BONUS;

  // Донат-бафф "буст дохода" (x1.5 или x2 на ограниченное время) — множитель хранится
  // персонально в income_boost_mult, т.к. цена/множитель отличаются (см. !админ доход).
  if (isIncomeBoostActive(player) && player.income_boost_mult) {
    income *= Number(player.income_boost_mult);
  }

  if (player.factories <= 0 && scienceCenters <= 0) return 0;
  return Math.round(income);
}

// Штраф на трофеи при атаке значительно более слабого игрока (по числу заводов) — чтобы топы
// не farm-или мелких игроков как основной источник дохода. Если у защитника меньше
// WEAK_TARGET_RATIO_THRESHOLD от заводов атакующего — трофеи снижаются пропорционально
// разрыву, вплоть до WEAK_TARGET_MIN_LOOT_MULTIPLIER на совсем беззащитных новичках.
// Если защитник сопоставим или сильнее атакующего — множитель всегда 1 (штрафа нет).
function weakTargetLootMultiplier(attacker, defender) {
  const attackerFactories = Math.max(attacker.factories || 0, 1);
  const defenderFactories = Math.max(defender.factories || 0, 0);
  const ratio = defenderFactories / attackerFactories;

  if (ratio >= C.WEAK_TARGET_RATIO_THRESHOLD) return 1;

  const scaled = ratio / C.WEAK_TARGET_RATIO_THRESHOLD; // 0..1
  return C.WEAK_TARGET_MIN_LOOT_MULTIPLIER + (1 - C.WEAK_TARGET_MIN_LOOT_MULTIPLIER) * scaled;
}

function formatNumber(n) {
  return Math.round(n).toLocaleString('ru-RU');
}

function formatDuration(ms) {
  if (ms <= 0) return '0 сек';
  // Меньше минуты — показываем секунды, а не округлённые "0 мин" (это вводило в заблуждение:
  // бот писал "ждите" и тут же "осталось 0 мин", будто ждать не нужно).
  if (ms < 60000) {
    const totalSeconds = Math.max(1, Math.round(ms / 1000));
    return `${totalSeconds} сек`;
  }
  const totalMinutes = Math.round(ms / 60000);
  const hours = Math.floor(totalMinutes / 60);
  const minutes = totalMinutes % 60;
  const parts = [];
  if (hours > 0) parts.push(`${hours} ч`);
  if (minutes > 0 || hours === 0) parts.push(`${minutes} мин`);
  return parts.join(' ');
}

function formatHours(hoursFloat) {
  if (Number.isInteger(hoursFloat)) return `${hoursFloat} ч`;
  return `${hoursFloat} ч`;
}

function randomInt(min, max) {
  return Math.floor(Math.random() * (max - min + 1)) + min;
}

function pickRandom(arr, count) {
  const copy = [...arr];
  const result = [];
  while (copy.length && result.length < count) {
    const idx = Math.floor(Math.random() * copy.length);
    result.push(copy.splice(idx, 1)[0]);
  }
  return result;
}

// Возвращает наивысший достигнутый скилл-тир по количеству заводов (или null, если ни один не достигнут)
function getSkillTier(factories) {
  let best = null;
  for (const tier of C.SKILL_TIERS) {
    if (factories >= tier.factories) best = tier;
  }
  return best;
}

// Текущий лимит заводов игрока с учётом купленных расширений
function currentFactoryLimit(factoryLimitLevel) {
  const level = factoryLimitLevel || 0;
  const row = C.FACTORY_LIMIT_LEVELS.find((l) => l.level === level) || C.FACTORY_LIMIT_LEVELS[0];
  return row.limit;
}

// Текущий лимит научных центров игрока с учётом купленных расширений
function currentScienceLimit(scienceLimitLevel) {
  const level = scienceLimitLevel || 1;
  const row = C.SCIENCE_LIMIT_LEVELS.find((l) => l.level === level) || C.SCIENCE_LIMIT_LEVELS[0];
  return row.limit;
}

// Цена постройки СЛЕДУЮЩЕГО научного центра с учётом уже построенных (builtCount).
// Растёт ступенчато: каждые SCIENCE_BUILD_COST_STEP_SIZE построенных центров цена
// подскакивает на SCIENCE_BUILD_COST_STEP_AMOUNT. Например, при базе 500/шаге 5/приросте 300:
// центры 1-5 -> 500, центры 6-10 -> 800, центры 11-15 -> 1100, и т.д.
function scienceBuildCost(builtCount) {
  const step = Math.floor((builtCount || 0) / C.SCIENCE_BUILD_COST_STEP_SIZE);
  return C.SCIENCE_BUILD_VIRT_COST + step * C.SCIENCE_BUILD_COST_STEP_AMOUNT;
}

module.exports = {
  distanceKm,
  nextFactoryPrice,
  sumBlocked,
  isVipActive,
  isMinerActive,
  isMinerForever,
  isIncomeBoostActive,
  isShieldActive,
  isWorkDoubleActive,
  isFarmBoostActive,
  isBossDoubleActive,
  incomePerHour,
  weakTargetLootMultiplier,
  formatNumber,
  formatDuration,
  formatHours,
  randomInt,
  pickRandom,
  getSkillTier,
  currentFactoryLimit,
  currentScienceLimit,
  scienceBuildCost,
};
