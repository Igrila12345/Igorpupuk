'use strict';

const C = require('./constants');
const players = require('../db/players');

// Разные варианты текста-обёртки для одного и того же исхода — чтобы дозор не выглядел
// как один и тот же копипаст-текст при частом использовании (КД короткий, 15 минут).
const FLAVOR = {
  virts: [
    'Патруль нашёл на границе брошенный склад с виртами.',
    'Разведгруппа обменяла трофеи у местных на вирты.',
    'Пограничники приняли пошлину с проезжавшего каравана.',
  ],
  tokens: [
    'Патруль помог рабочим на объекте — те отсыпали жетонов.',
    'На обходе нашли ящик с жетонами склада.',
    'Дозор обменял найденный хлам на жетоны на складе.',
  ],
  virts_tokens: [
    'Удачный обход: и вирты, и жетоны нашлись в одном тайнике.',
    'Патруль перехватил мелкий контрабандный груз — вирты и жетоны в трофеях.',
  ],
  jackpot: [
    'Дозор наткнулся на тайник времён прошлой войны! Крупная добыча.',
    'Патрулю повезло — нашли забытый склад снабжения, забитый под завязку.',
  ],
  nothing: [
    'Тихий обход — ничего интересного не нашли.',
    'Патруль прошёл по границе, но трофеев не было.',
    'На этот раз дозор вернулся ни с чем.',
  ],
};

function pickFlavor(type) {
  const arr = FLAVOR[type];
  return arr[Math.floor(Math.random() * arr.length)];
}

function randInt(min, max) {
  return Math.floor(Math.random() * (max - min + 1)) + min;
}

// Выбор исхода по весам из C.PATROL_OUTCOMES (веса не обязаны быть нормализованы к 1 —
// берём сумму весов и катим случайное число в этом диапазоне).
function rollOutcome() {
  const totalWeight = C.PATROL_OUTCOMES.reduce((sum, o) => sum + o.weight, 0);
  let roll = Math.random() * totalWeight;
  for (const outcome of C.PATROL_OUTCOMES) {
    if (roll < outcome.weight) return outcome;
    roll -= outcome.weight;
  }
  return C.PATROL_OUTCOMES[C.PATROL_OUTCOMES.length - 1];
}

function msLeft(lastAt, cooldownMs) {
  if (!lastAt) return 0;
  const left = cooldownMs - (Date.now() - new Date(lastAt).getTime());
  return left > 0 ? left : 0;
}

async function runPatrol(vkId) {
  const player = await players.getPlayer(vkId);
  if (!player) return { ok: false, reason: 'not_registered' };

  const left = msLeft(player.patrol_last_at, C.PATROL_COOLDOWN_MS);
  if (left > 0) {
    return { ok: false, reason: 'cooldown', msLeft: left };
  }

  const outcome = rollOutcome();
  let virts = 0;
  let tokens = 0;

  if (outcome.type === 'virts') {
    virts = randInt(outcome.virtsMin, outcome.virtsMax);
  } else if (outcome.type === 'tokens') {
    tokens = outcome.tokens;
  } else if (outcome.type === 'virts_tokens') {
    virts = randInt(outcome.virtsMin, outcome.virtsMax);
    tokens = outcome.tokens;
  } else if (outcome.type === 'jackpot') {
    virts = randInt(outcome.virtsMin, outcome.virtsMax);
    tokens = outcome.tokens;
  }
  // outcome.type === 'nothing' — virts и tokens остаются 0

  if (virts > 0) await players.updateBalance(vkId, virts);
  if (tokens > 0) await players.addTokens(vkId, tokens);
  await players.setPatrolLastAt(vkId, new Date());

  return {
    ok: true,
    type: outcome.type,
    virts,
    tokens,
    flavorText: pickFlavor(outcome.type),
    cooldownMs: C.PATROL_COOLDOWN_MS,
  };
}

module.exports = { runPatrol };
