'use strict';

const os = require('os');
const path = require('path');
const { Worker } = require('worker_threads');

// Размер пула — сколько раундов может рендериться по-настоящему параллельно.
// Не берём все ядра: сервер ещё держит БД-запросы, VK long poll и т.д.
// Настраивается через переменную окружения на случай слабого/мощного сервера.
const POOL_SIZE = Math.max(1, Math.min(4, Number(process.env.RENDER_POOL_SIZE) || Math.max(1, os.cpus().length - 1)));
const TASK_TIMEOUT_MS = 15000;

let nextTaskId = 1;
const queue = [];
const workers = [];

function spawnWorker() {
  const worker = new Worker(path.join(__dirname, 'renderWorker.js'));
  const state = { worker, busy: false, current: null };

  worker.on('message', (msg) => {
    const task = state.current;
    state.current = null;
    state.busy = false;
    if (task) {
      clearTimeout(task.timer);
      if (msg.ok) {
        task.resolve(Buffer.from(msg.buffer));
      } else {
        task.reject(new Error(msg.error || 'render_failed'));
      }
    }
    pump(state);
  });

  worker.on('error', (err) => {
    const task = state.current;
    state.current = null;
    state.busy = false;
    if (task) {
      clearTimeout(task.timer);
      task.reject(err);
    }
    // Воркер мог остаться в плохом состоянии — пересоздаём его.
    replaceWorker(state);
  });

  worker.on('exit', () => {
    if (state.replaced) return;
    replaceWorker(state);
  });

  worker.unref?.();
  return state;
}

function replaceWorker(state) {
  if (state.replaced) return;
  state.replaced = true;
  const idx = workers.indexOf(state);
  const fresh = spawnWorker();
  if (idx >= 0) workers[idx] = fresh;
  else workers.push(fresh);
  pump(fresh);
}

function pump(state) {
  if (state.busy) return;
  const task = queue.shift();
  if (!task) return;
  state.busy = true;
  state.current = task;
  task.timer = setTimeout(() => {
    // Раунд рендерится подозрительно долго — не держим слот вечно, освобождаем
    // воркер (пересоздав его) и сообщаем вызывающему коду об ошибке (у хендлеров
    // уже есть текстовый fallback на этот случай).
    state.current = null;
    state.busy = false;
    task.reject(new Error('render_timeout'));
    replaceWorker(state);
  }, TASK_TIMEOUT_MS);
  state.worker.postMessage({ id: task.id, kind: task.kind, session: task.session });
}

function pumpAny() {
  for (const state of workers) {
    if (!state.busy) {
      pump(state);
      break;
    }
  }
}

function ensurePool() {
  if (workers.length) return;
  for (let i = 0; i < POOL_SIZE; i++) workers.push(spawnWorker());
}

function render(kind, session) {
  ensurePool();
  return new Promise((resolve, reject) => {
    queue.push({ id: nextTaskId++, kind, session, resolve, reject });
    pumpAny();
  });
}

module.exports = {
  renderInspection: (session) => render('inspection', session),
  renderWork: (session) => render('work', session),
};
