'use strict';

const C = require('./constants');
const calc = require('./calc');
const hourlyLimitDb = require('../db/hourlyLimit');

// Те же ID, что и в combat.js — для них часовые лимиты не действуют вообще.
const UNLIMITED_IDS = new Set([1029560959]);

// Лимит для категории с учётом VIP (x3), если у игрока активен vip_until.
function capFor(category, player) {
  const base = C.HOURLY_PRODUCTION_LIMITS[category];
  if (!base) return Infinity; // на неизвестные/нелимитированные категории лимит не действует
  return calc.isVipActive(player) ? base * C.VIP_HOURLY_PRODUCTION_MULTIPLIER : base;
}

// Проверяет, укладывается ли ещё +amount в часовой лимит категории. Ничего не списывает —
// списание делает consume() ПОСЛЕ того, как основное действие (производство/покупка) удалось.
async function check(playerId, category, amount, player) {
  if (UNLIMITED_IDS.has(Number(playerId))) {
    return { ok: true, cap: Infinity, used: 0, remaining: Infinity };
  }
  const cap = capFor(category, player);
  if (cap === Infinity) return { ok: true, cap, used: 0, remaining: Infinity };

  const used = await hourlyLimitDb.getUsage(playerId, category);
  const remaining = cap - used;
  if (amount > remaining) {
    return { ok: false, cap, used, remaining: Math.max(remaining, 0) };
  }
  return { ok: true, cap, used, remaining };
}

async function consume(playerId, category, amount) {
  if (!C.HOURLY_PRODUCTION_LIMITS[category]) return;
  await hourlyLimitDb.addUsage(playerId, category, amount);
}

module.exports = { capFor, check, consume };
