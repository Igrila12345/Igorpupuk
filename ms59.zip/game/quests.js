'use strict';

// Ежедневные задания. Пул и параметры — в game/constants.js: QUEST_POOL, QUESTS_PER_DAY.
// Прогресс копится в players.quests_data (JSONB), пересобирается раз в сутки (МСК).

const C = require('./constants');
const players = require('../db/players');
const career = require('./career');
const gameDate = require('./gameDate');

function shuffle(arr) {
  const a = arr.slice();
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

function pickDailyQuests() {
  const picked = shuffle(C.QUEST_POOL).slice(0, C.QUESTS_PER_DAY);
  return picked.map((q) => ({
    id: q.id,
    type: q.type,
    target: q.target,
    reward: q.reward,
    xp: q.xp,
    desc: q.desc,
    progress: 0,
    completed: false,
  }));
}

// Гарантирует, что у игрока есть актуальный набор заданий на сегодня (МСК). Возвращает
// { quests, isNew } — isNew=true, если набор был только что пересобран.
async function ensureTodayQuests(player) {
  const today = gameDate.todayStr();
  const currentDay = player.quests_day ? String(player.quests_day).slice(0, 10) : null;

  if (currentDay === today && Array.isArray(player.quests_data) && player.quests_data.length) {
    return { quests: player.quests_data, isNew: false };
  }

  const quests = pickDailyQuests();
  await players.setQuestsData(player.vk_id, quests, today);
  return { quests, isNew: true };
}

async function getTodayQuests(vkId) {
  const player = await players.getPlayer(vkId);
  if (!player) return null;
  const { quests } = await ensureTodayQuests(player);
  return quests;
}

// Вызывается из игровой логики после успешного действия (работа/атака/дозор/инспекция/
// босс/постройка завода/кража/взнос в сейф клана). amount — на сколько продвинуть
// прогресс (обычно 1, но для клан-взноса — фактическая сумма вирт).
// Возвращает массив готовых текстовых уведомлений о выполненных заданиях (и, если
// применимо, о повышении звания) — вызывающий код просто добавляет их к своему ответу.
async function trackProgress(vkId, type, amount = 1) {
  const player = await players.getPlayer(vkId);
  if (!player || player.registration_step !== 'done') return [];

  const { quests } = await ensureTodayQuests(player);

  const messages = [];
  let changed = false;

  for (const q of quests) {
    if (q.completed || q.type !== type) continue;

    q.progress = Math.min(q.target, q.progress + amount);
    changed = true;

    if (q.progress >= q.target) {
      q.completed = true;
      await players.updateBalance(vkId, q.reward);
      const careerResult = await career.addXp(vkId, q.xp);

      let text = `🎯 Задание выполнено: «${q.desc}» — +${q.reward} вирт, +${q.xp} очков карьеры!`;
      if (careerResult && careerResult.rankUpText) {
        text += `\n${careerResult.rankUpText}`;
      }
      messages.push(text);
    }

    break; // одно действие продвигает только одно (первое подходящее незавершённое) задание
  }

  if (changed) {
    await players.setQuestsData(vkId, quests, gameDate.todayStr());
  }

  return messages;
}

module.exports = { getTodayQuests, trackProgress };
