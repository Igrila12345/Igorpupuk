'use strict';

const C = require('./constants');
const calc = require('./calc');
const players = require('../db/players');
const clansDb = require('../db/clans');
const production = require('../db/production');

async function createClan(vkId, name) {
  if (name.length < C.CLAN_NAME_MIN || name.length > C.CLAN_NAME_MAX) {
    return { ok: false, reason: 'invalid_name_length' };
  }
  const player = await players.getPlayer(vkId);
  if (!player) return { ok: false, reason: 'not_registered' };
  if (player.clan_id) return { ok: false, reason: 'already_in_clan' };

  const existing = await clansDb.getClanByName(name);
  if (existing) return { ok: false, reason: 'name_taken' };

  if (C.CLAN_CREATE_COST > 0) {
    await players.updateBalance(vkId, -C.CLAN_CREATE_COST);
  }
  const clan = await clansDb.createClan(name, vkId);
  await players.setClan(vkId, clan.id, 'leader');

  return { ok: true, clan };
}

async function invite(leaderId, targetId) {
  const leader = await players.getPlayer(leaderId);
  if (!leader || !leader.clan_id || leader.clan_role !== 'leader') {
    return { ok: false, reason: 'not_leader' };
  }
  const target = await players.getPlayer(targetId);
  if (!target) return { ok: false, reason: 'target_not_registered' };
  if (target.clan_id) return { ok: false, reason: 'target_already_in_clan' };

  await clansDb.createInvite(leader.clan_id, targetId);
  return { ok: true, clanId: leader.clan_id };
}

async function join(playerId, clanName) {
  const player = await players.getPlayer(playerId);
  if (!player) return { ok: false, reason: 'not_registered' };
  if (player.clan_id) return { ok: false, reason: 'already_in_clan' };

  const clan = await clansDb.getClanByName(clanName);
  if (!clan) return { ok: false, reason: 'clan_not_found' };

  const invited = await clansDb.hasInvite(clan.id, playerId);
  if (!invited) return { ok: false, reason: 'no_invite' };

  await players.setClan(playerId, clan.id, 'member');
  await clansDb.removeInvite(clan.id, playerId);

  return { ok: true, clan };
}

async function kick(leaderId, targetId) {
  const leader = await players.getPlayer(leaderId);
  if (!leader || !leader.clan_id || leader.clan_role !== 'leader') {
    return { ok: false, reason: 'not_leader' };
  }
  const target = await players.getPlayer(targetId);
  if (!target || target.clan_id !== leader.clan_id) {
    return { ok: false, reason: 'not_member' };
  }
  if (targetId === leaderId) return { ok: false, reason: 'cannot_kick_self' };

  await players.setClan(targetId, null, null);
  return { ok: true };
}

async function leave(playerId) {
  const player = await players.getPlayer(playerId);
  if (!player || !player.clan_id) return { ok: false, reason: 'not_in_clan' };

  if (player.clan_role !== 'leader') {
    await players.setClan(playerId, null, null);
    return { ok: true };
  }

  // Глава уходит: клан должен остаться цел, поэтому передаём главенство.
  const members = await clansDb.getClanMembers(player.clan_id);
  const successor = members.find((m) => m.vk_id !== playerId && m.clan_role === 'deputy')
    || members.find((m) => m.vk_id !== playerId);

  if (!successor) {
    // Глава — единственный участник клана: покинуть некому, клан пришлось бы оставить без главы.
    return { ok: false, reason: 'leader_last_member' };
  }

  await players.setClan(successor.vk_id, player.clan_id, 'leader');
  await clansDb.setLeader(player.clan_id, successor.vk_id);
  await players.setClan(playerId, null, null);

  return { ok: true, transferredTo: successor.vk_id, transferredToName: successor.state_name };
}

// Роспуск клана главой. Требует точного повтора названия клана как подтверждения
// (иначе случайное "клан удалить" сотрёт клан без предупреждения) и пустого сейфа
// (иначе накопленные всеми участниками деньги молча сгорят — их нужно сначала снять).
async function disbandClan(leaderId, confirmName) {
  const leader = await players.getPlayer(leaderId);
  if (!leader || !leader.clan_id || leader.clan_role !== 'leader') {
    return { ok: false, reason: 'not_leader' };
  }

  const clan = await clansDb.getClanById(leader.clan_id);
  if (!clan) return { ok: false, reason: 'not_leader' };

  if (!confirmName || confirmName.trim().toLowerCase() !== clan.name.toLowerCase()) {
    return { ok: false, reason: 'confirm_required', clanName: clan.name };
  }

  if (Number(clan.vault) > 0) {
    return { ok: false, reason: 'vault_not_empty', vault: Number(clan.vault) };
  }

  const members = await clansDb.getClanMembers(clan.id);

  await clansDb.clearMembersClan(clan.id);
  await clansDb.deleteClan(clan.id);

  return {
    ok: true,
    clanName: clan.name,
    notifyMemberIds: members.map((m) => m.vk_id).filter((id) => id !== leaderId),
  };
}

// ===================== ЗАМЫ КЛАНА =====================
// Глава может назначить участника замом — замы, как и глава, могут снимать
// средства из сейфа клана (см. withdrawVault ниже).

async function promoteDeputy(leaderId, targetId) {
  const leader = await players.getPlayer(leaderId);
  if (!leader || !leader.clan_id || leader.clan_role !== 'leader') {
    return { ok: false, reason: 'not_leader' };
  }
  const target = await players.getPlayer(targetId);
  if (!target || target.clan_id !== leader.clan_id) {
    return { ok: false, reason: 'not_member' };
  }
  if (targetId === leaderId) return { ok: false, reason: 'cannot_target_self' };
  if (target.clan_role === 'deputy') return { ok: false, reason: 'already_deputy' };

  await players.setClan(targetId, leader.clan_id, 'deputy');
  return { ok: true, clanId: leader.clan_id };
}

async function demoteDeputy(leaderId, targetId) {
  const leader = await players.getPlayer(leaderId);
  if (!leader || !leader.clan_id || leader.clan_role !== 'leader') {
    return { ok: false, reason: 'not_leader' };
  }
  const target = await players.getPlayer(targetId);
  if (!target || target.clan_id !== leader.clan_id) {
    return { ok: false, reason: 'not_member' };
  }
  if (target.clan_role !== 'deputy') return { ok: false, reason: 'not_deputy' };

  await players.setClan(targetId, leader.clan_id, 'member');
  return { ok: true, clanId: leader.clan_id };
}

async function useBonus(leaderId, bonusKey) {
  const bonus = C.CLAN_BONUSES[bonusKey.toLowerCase()];
  if (!bonus) return { ok: false, reason: 'unknown_bonus' };

  const leader = await players.getPlayer(leaderId);
  if (!leader || !leader.clan_id || leader.clan_role !== 'leader') {
    return { ok: false, reason: 'not_leader' };
  }

  const clan = await clansDb.getClanById(leader.clan_id);
  // ВАЖНО: колонки в БД называются латиницей (bonus.dbColumn — forsazh/eshelon/industry),
  // а не кириллицей (bonus.key). Раньше здесь ошибочно использовался bonus.key, из-за чего
  // строился несуществующий кириллический столбец: список кулдауна тут всегда читался как
  // undefined (кулдаун никогда не срабатывал), а сохранение бонуса ниже падало с ошибкой БД
  // УЖЕ ПОСЛЕ списания денег из сейфа — деньги терялись, а бонус не активировался.
  const cooldownField = `bonus_${bonus.dbColumn}_cooldown`;
  if (clan[cooldownField] && new Date(clan[cooldownField]) > new Date()) {
    return { ok: false, reason: 'cooldown', until: clan[cooldownField] };
  }

  const info = await getClanVaultInfo(clan.id);
  const cost = Math.round(info.effectiveMaxVault * bonus.costRateOfMaxVault);

  if (Number(clan.vault) < cost) {
    return { ok: false, reason: 'not_enough_vault', cost, have: Number(clan.vault) };
  }

  await clansDb.spendVault(clan.id, cost);
  const until = new Date(Date.now() + bonus.durationHours * 60 * 60 * 1000);
  const cooldownUntil = new Date(Date.now() + bonus.cooldownHours * 60 * 60 * 1000);

  try {
    await clansDb.setBonusActive(clan.id, bonus.dbColumn, until, cooldownUntil);
  } catch (err) {
    // Деньги уже списаны — если активация бонуса всё же не удалась (неожиданная ошибка БД
    // и т.п.), возвращаем средства в сейф клана, чтобы никто не терял деньги впустую.
    await clansDb.refundVault(clan.id, cost).catch(() => {});
    throw err;
  }

  return { ok: true, bonus, cost, until };
}

// ===================== СЕЙФ КЛАНА: УРОВЕНЬ И ВМЕСТИМОСТЬ =====================

// Единая формула бонуса к вместимости сейфа по уровню — двухступенчатая (см. constants.js:
// CLAN_VAULT_TIER1_MAX_LEVEL/CLAN_VAULT_LEVEL_CAPACITY_BONUS/_TIER2). Возвращает ДОЛЮ (0.01 = 1%),
// не проценты — умножать на 100 для отображения. Единственное место, где считается этот бонус —
// используется и в getClanVaultInfo() ниже, и в handlers/clanHandlers.js для отображения, чтобы
// не дублировать формулу и не получить рассинхрон при следующем изменении ставок.
function clanVaultCapacityBonus(level) {
  const tier1 = Math.min(level, C.CLAN_VAULT_TIER1_MAX_LEVEL) * C.CLAN_VAULT_LEVEL_CAPACITY_BONUS;
  const tier2 = Math.max(0, level - C.CLAN_VAULT_TIER1_MAX_LEVEL) * C.CLAN_VAULT_LEVEL_CAPACITY_BONUS_TIER2;
  return tier1 + tier2;
}

// Собирает всю информацию по сейфу клана в одном месте: сколько собрано за всё время,
// текущий уровень (0-CLAN_VAULT_MAX_LEVEL), базовую и итоговую (с учётом бонуса уровня) вместимость.
async function getClanVaultInfo(clanId) {
  const clan = await clansDb.getClanById(clanId);
  if (!clan) return null;

  const clanFactories = await clansDb.getClanFactoriesSum(clanId);
  const baseMaxVault = clanFactories * C.CLAN_VAULT_PER_FACTORY;
  const totalCollected = Number(clan.vault_total_collected || 0);
  const level = clansDb.levelFromTotal(totalCollected);
  const capacityBonus = clanVaultCapacityBonus(level);
  const effectiveMaxVault = Math.round(baseMaxVault * (1 + capacityBonus));
  const nextLevelTotal =
    level >= C.CLAN_VAULT_MAX_LEVEL ? null : clansDb.totalRequiredForLevel(level + 1);

  return {
    clan,
    clanFactories,
    baseMaxVault,
    effectiveMaxVault,
    totalCollected,
    level,
    capacityBonus,
    nextLevelTotal,
  };
}

// Топ кланов по суммарному доходу в час всех участников (та же формула, что и в личном
// профиле/почасовом начислении: учитывает VIP, науку, золотые жилы, радиацию и вычитает
// заблокированные/занятые производством заводы) — совпадает с тем, что реально капает
// в карман игрокам и в сейф клана, а не просто с количеством заводов.
async function getTopClansByIncome(limit = 10) {
  const clans = await clansDb.getAllClans();
  const results = [];

  for (const clan of clans) {
    const members = await clansDb.getClanMembers(clan.id);
    let totalIncome = 0;
    let totalFactories = 0;

    for (const member of members) {
      totalFactories += member.factories || 0;
      if (member.factories <= 0 && (member.science_centers || 0) <= 0) continue;
      const factoriesInProd = await production.getFactoriesInUse(member.vk_id);
      totalIncome += calc.incomePerHour(member, factoriesInProd);
    }

    results.push({
      id: clan.id,
      name: clan.name,
      vault: clan.vault,
      leader_id: clan.leader_id,
      total_income: totalIncome,
      total_factories: totalFactories,
    });
  }

  results.sort((a, b) => b.total_income - a.total_income);
  return results.slice(0, limit);
}

// Любой участник клана может пополнить сейф из своего баланса.
async function depositVault(playerId, rawAmount) {
  const player = await players.getPlayer(playerId);
  if (!player) return { ok: false, reason: 'not_registered' };
  if (!player.clan_id) return { ok: false, reason: 'not_in_clan' };

  const amount = Math.floor(Number(rawAmount));
  if (!Number.isFinite(amount) || amount <= 0) {
    return { ok: false, reason: 'invalid_amount' };
  }

  const info = await getClanVaultInfo(player.clan_id);
  const available = Math.max(0, info.effectiveMaxVault - Number(info.clan.vault));
  if (available <= 0) {
    return { ok: false, reason: 'vault_full' };
  }

  const toDeposit = Math.min(amount, available);
  if (Number(player.balance) < toDeposit) {
    return { ok: false, reason: 'not_enough_money', have: Number(player.balance), need: toDeposit };
  }

  await players.updateBalance(playerId, -toDeposit);
  const res = await clansDb.addVault(player.clan_id, toDeposit, info.effectiveMaxVault);
  const { level, leveledUp } = await clansDb.syncVaultLevel(player.clan_id, res.totalCollected);

  return {
    ok: true,
    deposited: toDeposit,
    capped: toDeposit < amount,
    vault: res.vault,
    maxVault: info.effectiveMaxVault,
    level,
    leveledUp,
    clanName: info.clan.name,
  };
}

// Глава клана и назначенные им замы могут снимать средства из сейфа себе на баланс.
async function withdrawVault(leaderId, rawAmount) {
  const leader = await players.getPlayer(leaderId);
  if (!leader || !leader.clan_id || (leader.clan_role !== 'leader' && leader.clan_role !== 'deputy')) {
    return { ok: false, reason: 'not_leader' };
  }

  const amount = Math.floor(Number(rawAmount));
  if (!Number.isFinite(amount) || amount <= 0) {
    return { ok: false, reason: 'invalid_amount' };
  }

  const clan = await clansDb.getClanById(leader.clan_id);
  if (Number(clan.vault) < amount) {
    return { ok: false, reason: 'not_enough_vault', have: Number(clan.vault) };
  }

  const newVault = await clansDb.withdrawVault(leader.clan_id, amount);
  if (newVault === null) {
    return { ok: false, reason: 'not_enough_vault', have: Number(clan.vault) };
  }
  await players.updateBalance(leaderId, amount);
  await clansDb.logVaultWithdraw(leader.clan_id, leaderId, amount);

  return { ok: true, amount, vault: newVault, clanName: clan.name };
}

// Лог последних снятий из сейфа — доступен главе и заму (см. handlers/clanHandlers.js: handleVaultLogs()).
async function getVaultLogs(playerId, limit) {
  const player = await players.getPlayer(playerId);
  if (!player || !player.clan_id || (player.clan_role !== 'leader' && player.clan_role !== 'deputy')) {
    return { ok: false, reason: 'not_leader' };
  }
  const clan = await clansDb.getClanById(player.clan_id);
  const logs = await clansDb.getVaultLogs(player.clan_id, limit);
  return { ok: true, logs, clanName: clan.name };
}

module.exports = {
  createClan,
  invite,
  join,
  kick,
  leave,
  disbandClan,
  promoteDeputy,
  demoteDeputy,
  useBonus,
  getClanVaultInfo,
  clanVaultCapacityBonus,
  getTopClansByIncome,
  depositVault,
  withdrawVault,
  getVaultLogs,
};
