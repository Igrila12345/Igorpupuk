'use strict';

const C = require('./constants');
const calc = require('./calc');

// Минимальный отрыв (в штуках значков) верной коробки от всех остальных.
// Без этого игра превращалась в угадайку "8 или 9?", которую по фото/тексту
// на телефоне реально не различить — отсюда и жалобы "мини-игра не понятная".
const MIN_GAP = 4;

function generateCounts() {
  for (;;) {
    const counts = [];
    while (counts.length < C.WORK_BOX_COUNT) {
      const n = calc.randomInt(C.WORK_BOX_MIN_ICONS, C.WORK_BOX_MAX_ICONS);
      // Не допускаем повторов, иначе у раунда не будет единственно верного ответа
      if (!counts.includes(n)) counts.push(n);
    }

    const sorted = [...counts].sort((a, b) => b - a);
    if (sorted[0] - sorted[1] >= MIN_GAP) return counts;
    // Иначе отрыв слишком маленький — перегенерируем набор чисел
  }
}

// Расставляет иконки не полностью случайно, а по "дрожащей" сетке — так при одинаковом
// количестве точки распределены равномерно по всей коробке, и разница в плотности видна
// с первого взгляда, а не тонет в случайных кластерах.
function scatterIcons(count) {
  const cols = Math.ceil(Math.sqrt(count));
  const rows = Math.ceil(count / cols);
  const cellW = 1 / cols;
  const cellH = 1 / rows;

  const cells = [];
  for (let r = 0; r < rows; r++) {
    for (let c = 0; c < cols; c++) {
      cells.push({ r, c });
    }
  }
  // Перемешиваем ячейки, чтобы "лишние" (при count не кратном cols*rows) выпадали случайно
  for (let i = cells.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [cells[i], cells[j]] = [cells[j], cells[i]];
  }

  const icons = [];
  for (let i = 0; i < count; i++) {
    const { r, c } = cells[i];
    const jitterX = (Math.random() - 0.5) * 0.5 * cellW;
    const jitterY = (Math.random() - 0.5) * 0.5 * cellH;
    const x = Math.min(1, Math.max(0, c * cellW + cellW / 2 + jitterX));
    const y = Math.min(1, Math.max(0, r * cellH + cellH / 2 + jitterY));
    icons.push({ x, y });
  }
  return icons;
}

// Генерирует один раунд мини-игры "работа": WORK_BOX_COUNT коробок одинакового
// размера, в каждой — разное число "заводов" (иконок). Так как физический размер
// коробок одинаков, плотность прямо пропорциональна количеству иконок — коробка
// с наибольшим количеством и есть верный ответ, и её отрыв от остальных всегда
// заметен (см. MIN_GAP).
function generateRound() {
  const counts = generateCounts();

  const boxes = counts.map((count) => ({ count, icons: scatterIcons(count) }));

  // Перемешиваем порядок коробок, чтобы верная позиция каждый раунд была новой
  for (let i = boxes.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [boxes[i], boxes[j]] = [boxes[j], boxes[i]];
  }

  let correctIndex = 0;
  for (let i = 1; i < boxes.length; i++) {
    if (boxes[i].count > boxes[correctIndex].count) correctIndex = i;
  }

  return { boxes, correctIndex };
}

module.exports = { generateRound };
