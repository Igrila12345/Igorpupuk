'use strict';

const C = require('./constants');
const calc = require('./calc');

// Генерирует один раунд "инспекции": от INSPECTION_GRID_MIN до INSPECTION_GRID_MAX
// одинаковых значков-заводов (число меняется от раунда к раунду), один из которых
// "аномальный" (в рендере — развёрнут на 45°). Игрок должен найти его и нажать
// номер соответствующей ячейки.
function generateRound() {
  const size = calc.randomInt(C.INSPECTION_GRID_MIN, C.INSPECTION_GRID_MAX);
  const anomalyIndex = Math.floor(Math.random() * size);
  return { size, anomalyIndex };
}

module.exports = { generateRound };
