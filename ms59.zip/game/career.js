'use strict';

// Карьера (звания) — очки копятся навсегда, начисляются за выполненные ежедневные
// задания (см. game/quests.js). При достижении нового звания — разовая награда виртами.

const C = require('./constants');
const players = require('../db/players');

function rankByXp(xp) {
  let current = C.CAREER_RANKS[0];
  for (const r of C.CAREER_RANKS) {
    if (xp >= r.xpRequired) current = r;
    else break;
  }
  return current;
}

function nextRank(currentLevel) {
  return C.CAREER_RANKS.find((r) => r.level === currentLevel + 1) || null;
}

// Начисляет очки карьеры и, если пересечён один или несколько порогов званий,
// выдаёт суммарную награду за все пройденные звания разом и возвращает текст об этом.
async function addXp(vkId, amount) {
  const res = await players.addCareerXp(vkId, amount);
  if (!res) return null;

  const newRank = rankByXp(res.xp);
  if (newRank.level <= res.rank) {
    return { xp: res.xp, rankUpText: null };
  }

  const passedRanks = C.CAREER_RANKS.filter((r) => r.level > res.rank && r.level <= newRank.level);
  const totalReward = passedRanks.reduce((sum, r) => sum + r.reward, 0);

  if (totalReward > 0) {
    await players.updateBalance(vkId, totalReward);
  }
  await players.setCareerRank(vkId, newRank.level);

  return {
    xp: res.xp,
    rankUpText: `🎖️ Новое звание: «${newRank.title}»! Награда: +${totalReward} вирт.`,
  };
}

async function getInfo(vkId) {
  const player = await players.getPlayer(vkId);
  if (!player) return null;

  const xp = Number(player.career_xp) || 0;
  const current = rankByXp(xp);
  const next = nextRank(current.level);

  return {
    title: current.title,
    level: current.level,
    xp,
    maxLevel: C.CAREER_RANKS.length,
    next: next ? { title: next.title, xpRequired: next.xpRequired, reward: next.reward } : null,
  };
}

module.exports = { addXp, getInfo, rankByXp };
