'use strict';

const C = require('./constants');
const players = require('../db/players');
const productionDb = require('../db/production');
const hourlyLimit = require('./hourlyLimit');

// Активных заводов (свободных от блокировки и от других производств)
async function getFreeFactories(vkId) {
  const player = await players.getPlayer(vkId);
  if (!player) return 0;
  const now = Date.now();
  const blocked = (player.blocked_factories || []).filter(
    (b) => new Date(b.unblock_at).getTime() > now
  ).reduce((s, b) => s + b.count, 0);
  const inProduction = await productionDb.getFactoriesInUse(vkId);
  return Math.max(player.factories - blocked - inProduction, 0);
}

async function startProduction(vkId, weaponKey, quantity, factoriesToUse) {
  const weapon = C.WEAPONS[weaponKey];
  if (!weapon) return { ok: false, reason: 'unknown_weapon' };
  if (weapon.notProducible) return { ok: false, reason: 'not_producible' };
  if (quantity <= 0 || factoriesToUse <= 0) return { ok: false, reason: 'invalid_amount' };

  const player = await players.getPlayer(vkId);
  if (!player) return { ok: false, reason: 'not_registered' };

  const freeFactories = await getFreeFactories(vkId);
  if (factoriesToUse > freeFactories) {
    return { ok: false, reason: 'not_enough_free_factories', freeFactories };
  }

  const totalCost = weapon.productionCost * quantity;
  if (Number(player.balance) < totalCost) {
    return { ok: false, reason: 'not_enough_money', totalCost, missing: totalCost - Number(player.balance) };
  }

  // Часовой лимит производства по категории оружия (БПЛА/ракеты/ядерное) — см. game/hourlyLimit.js.
  // У VIP лимит в 3 раза выше (C.VIP_HOURLY_PRODUCTION_MULTIPLIER).
  const limitCheck = await hourlyLimit.check(vkId, weapon.category, quantity, player);
  if (!limitCheck.ok) {
    return {
      ok: false,
      reason: 'hourly_limit_exceeded',
      category: weapon.category,
      cap: limitCheck.cap,
      used: limitCheck.used,
      remaining: limitCheck.remaining,
    };
  }

  // Время производства: базовое время (для 1 шт на 1 заводе) * quantity / factoriesToUse
  let baseMinutes = weapon.productionMinutes * quantity;
  let totalMinutes = baseMinutes / factoriesToUse;

  let massBonusApplied = false;
  if (factoriesToUse >= C.MASS_PRODUCTION_FACTORY_THRESHOLD) {
    totalMinutes *= 1 - C.MASS_PRODUCTION_TIME_BONUS;
    massBonusApplied = true;
  }

  // Общее ускорение производства в 3 раза (см. C.PRODUCTION_SPEED_MULTIPLIER)
  totalMinutes /= C.PRODUCTION_SPEED_MULTIPLIER;

  const readyAt = new Date(Date.now() + totalMinutes * 60 * 1000);

  await players.updateBalance(vkId, -totalCost);
  const record = await productionDb.createProduction(
    vkId,
    weaponKey,
    quantity,
    factoriesToUse,
    readyAt
  );

  await hourlyLimit.consume(vkId, weapon.category, quantity);

  return {
    ok: true,
    record,
    totalCost,
    totalMinutes,
    massBonusApplied,
    incomeLostPerHour: factoriesToUse * C.FACTORY_INCOME_PER_HOUR,
  };
}

async function collectWeapon(vkId, weaponKey, quantityRequested) {
  const ready = await productionDb.getReadyUncollected(vkId, weaponKey);
  if (!ready.length) return { ok: false, reason: 'nothing_ready' };

  let remaining = quantityRequested;
  let collected = 0;
  const collectedRecordIds = [];

  for (const record of ready) {
    if (remaining <= 0) break;
    // Каждая запись производства выдаётся целиком (упрощение: забираем целыми партиями)
    collectedRecordIds.push(record.id);
    collected += record.quantity;
    remaining -= record.quantity;
  }

  if (collected === 0) return { ok: false, reason: 'nothing_ready' };

  for (const id of collectedRecordIds) {
    await productionDb.markCollected(id);
  }
  await players.addToArsenal(vkId, weaponKey, collected);

  return { ok: true, collected };
}

module.exports = {
  getFreeFactories,
  startProduction,
  collectWeapon,
};
