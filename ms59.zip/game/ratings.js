'use strict';

const C = require('./constants');
const players = require('../db/players');
const clansDb = require('../db/clans');
const clanGame = require('./clan');

async function distributeDailyRewards(bot) {
  const topPlayers = await players.getTopByFactories(3);
  for (let i = 0; i < topPlayers.length; i++) {
    const reward = C.DAILY_FACTORY_REWARDS[i];
    if (!reward) break;
    const p = topPlayers[i];
    await players.updateBalance(p.vk_id, reward.virts);
    await players.addToArsenal(p.vk_id, reward.weapon, reward.qty);
    if (bot) {
      await bot
        .notifyUser(
          p.vk_id,
          `🏆 Ежедневная награда за ${reward.place} место в топе заводов!\n💰 +${reward.virts} вирт\n⚔️ +${reward.qty} шт. «${reward.weapon}»`
        )
        .catch(() => {});
    }
  }

  const topClans = await clanGame.getTopClansByIncome(3);
  for (let i = 0; i < topClans.length; i++) {
    const reward = C.DAILY_CLAN_REWARDS[i];
    if (!reward) break;
    const clan = topClans[i];
    const clanFactories = Number(clan.total_factories);
    const maxVault = clanFactories * C.CLAN_VAULT_PER_FACTORY;
    await clansDb.addVault(clan.id, reward.virts, maxVault);

    if (bot) {
      const members = await clansDb.getClanMembers(clan.id);
      for (const m of members) {
        await bot
          .notifyUser(
            m.vk_id,
            `🏆 Ваш клан «${clan.name}» занял ${reward.place} место в топе кланов!\n💰 В сейф клана зачислено +${reward.virts} вирт.`
          )
          .catch(() => {});
      }
    }
  }
}

module.exports = { distributeDailyRewards };
