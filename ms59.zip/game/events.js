'use strict';

const C = require('./constants');
const calc = require('./calc');
const players = require('../db/players');
const gameMeta = require('../db/shop'); // getMeta/setMeta живут в db/shop.js (общая таблица game_meta)

const META_ACTIVE_EVENT = 'active_event';
const META_SHOP_OPEN = 'event_shop_open';

// ===================== АКТИВНЫЙ СЕЗОН =====================

// Возвращает объект сезона из C.EVENT_SEASONS или null, если ивент выключен.
async function getActiveSeason() {
  const key = await gameMeta.getMeta(META_ACTIVE_EVENT);
  return key && C.EVENT_SEASONS[key] ? C.EVENT_SEASONS[key] : null;
}

// key — один из ключей C.EVENT_SEASONS ('winter'/'spring'/'summer'/'autumn') либо null,
// чтобы выключить ивент (валюта за действия капать перестаёт, но уже накопленная остаётся).
async function setActiveSeason(key) {
  if (key === null) {
    await gameMeta.setMeta(META_ACTIVE_EVENT, '');
    return null;
  }
  if (!C.EVENT_SEASONS[key]) return null;
  await gameMeta.setMeta(META_ACTIVE_EVENT, key);
  return C.EVENT_SEASONS[key];
}

function findSeasonKey(arg) {
  const lower = (arg || '').toLowerCase();
  const aliases = {
    зима: 'winter',
    зиму: 'winter',
    winter: 'winter',
    весна: 'spring',
    весну: 'spring',
    spring: 'spring',
    лето: 'summer',
    summer: 'summer',
    осень: 'autumn',
    autumn: 'autumn',
  };
  return aliases[lower] || null;
}

// ===================== НАЧИСЛЕНИЕ ВАЛЮТЫ ЗА ДЕЙСТВИЯ =====================

// Вызывается из хендлеров после УСПЕШНОГО игрового действия (постройка завода, постройка
// научного центра, сбор ежедневного бонуса, атака другого игрока). Если сезон не активен —
// ничего не делает и возвращает null. Иначе начисляет случайное количество валюты сезона
// (C.EVENT_DROP_MIN..C.EVENT_DROP_MAX) и возвращает {season, amount} для уведомления игрока.
async function awardDrop(vkId) {
  const season = await getActiveSeason();
  if (!season) return null;

  const amount = calc.randomInt(C.EVENT_DROP_MIN, C.EVENT_DROP_MAX);
  await players.addEventCurrency(vkId, amount);
  return { season, amount };
}

// Короткая приписка к сообщению об успешном действии, например: "\n☀️ +2 (Лето)".
// Ничего не возвращает (пустую строку), если ивент не активен — вызывающему коду не нужно
// самому проверять активность ивента на каждом месте вызова.
function dropSuffix(drop) {
  if (!drop) return '';
  return `\n${drop.season.emoji} +${drop.amount} (${drop.season.name})`;
}

// ===================== ИВЕНТ-МАГАЗИН =====================

async function isShopOpen() {
  const v = await gameMeta.getMeta(META_SHOP_OPEN);
  return v === '1';
}

async function setShopOpen(open) {
  await gameMeta.setMeta(META_SHOP_OPEN, open ? '1' : '0');
}

const SHOP_ITEMS = [
  { key: 'factory', title: '🏭 Завод', price: C.EVENT_SHOP_PRICE_FACTORY },
  { key: 'science', title: '🔬 Научный центр', price: C.EVENT_SHOP_PRICE_SCIENCE },
  { key: 'vip', title: `👑 VIP на ${C.EVENT_SHOP_PRICE_VIP_DAYS} дней`, price: C.EVENT_SHOP_PRICE_VIP },
];

function findShopItem(arg) {
  const lower = (arg || '').toLowerCase();
  const aliases = {
    завод: 'factory',
    заводы: 'factory',
    завода: 'factory',
    factory: 'factory',
    наука: 'science',
    науку: 'science',
    science: 'science',
    вип: 'vip',
    vip: 'vip',
  };
  const key = aliases[lower];
  return SHOP_ITEMS.find((i) => i.key === key) || null;
}

// Покупка предмета за ивент-валюту. Требует, чтобы магазин был открыт админом
// (см. setShopOpen / !админ ивентмагазин). quantity — сколько штук купить за раз.
async function purchase(vkId, itemArg, quantity = 1) {
  const shopOpen = await isShopOpen();
  if (!shopOpen) return { ok: false, reason: 'shop_closed' };

  const item = findShopItem(itemArg);
  if (!item) return { ok: false, reason: 'unknown_item' };

  const qty = Math.max(1, Math.floor(quantity) || 1);
  const totalPrice = item.price * qty;

  const player = await players.getPlayer(vkId);
  if (!player || player.registration_step !== 'done') return { ok: false, reason: 'not_registered' };

  if ((player.event_currency || 0) < totalPrice) {
    return { ok: false, reason: 'not_enough_currency', have: player.event_currency || 0, need: totalPrice };
  }

  if (item.key === 'factory') {
    const maxFactories = calc.currentFactoryLimit(player.factory_limit_level);
    if (player.factories + qty > maxFactories) {
      return { ok: false, reason: 'factory_limit', max: maxFactories, have: player.factories };
    }
  }

  if (item.key === 'science') {
    const limit = calc.currentScienceLimit(player.science_limit_level);
    if ((player.science_centers || 0) + qty > limit) {
      return { ok: false, reason: 'science_limit', max: limit, have: player.science_centers || 0 };
    }
  }

  await players.addEventCurrency(vkId, -totalPrice);

  if (item.key === 'factory') {
    await players.addFactories(vkId, qty, false);
  } else if (item.key === 'science') {
    await players.addScienceCenters(vkId, qty);
  } else if (item.key === 'vip') {
    const now = new Date();
    const currentUntil = player.vip_until && new Date(player.vip_until) > now ? new Date(player.vip_until) : now;
    const newUntil = new Date(currentUntil.getTime() + qty * C.EVENT_SHOP_PRICE_VIP_DAYS * 24 * 60 * 60 * 1000);
    await players.setVipUntil(vkId, newUntil);
    return { ok: true, item, qty, totalPrice, vipUntil: newUntil };
  }

  return { ok: true, item, qty, totalPrice };
}

module.exports = {
  getActiveSeason,
  setActiveSeason,
  findSeasonKey,
  awardDrop,
  dropSuffix,
  isShopOpen,
  setShopOpen,
  SHOP_ITEMS,
  findShopItem,
  purchase,
};
