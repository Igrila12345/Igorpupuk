'use strict';

const C = require('./constants');
const calc = require('./calc');
const shopDb = require('../db/shop');
const players = require('../db/players');
const hourlyLimit = require('./hourlyLimit');

function randomChoiceUnique(arr, count) {
  return calc.pickRandom(arr, count);
}

async function refreshShop() {
  const state = await shopDb.getShopState();

  // Если магазин заблокирован после покупки ядерки — не обновляем
  if (state.locked_until && new Date(state.locked_until) > new Date()) {
    return state;
  }

  const items = [];

  const weaponTypesCount = calc.randomInt(C.SHOP_WEAPON_TYPES_MIN, C.SHOP_WEAPON_TYPES_MAX);
  const weaponKeys = randomChoiceUnique(C.NON_NUKE_WEAPON_KEYS, weaponTypesCount);
  for (const key of weaponKeys) {
    items.push({
      key,
      type: 'weapon',
      qty: calc.randomInt(C.SHOP_ITEM_QTY_MIN, C.SHOP_ITEM_QTY_MAX),
      price: C.WEAPONS[key].price,
    });
  }

  const adTypesCount = calc.randomInt(C.SHOP_AD_TYPES_MIN, C.SHOP_AD_TYPES_MAX);
  const adKeys = randomChoiceUnique(Object.keys(C.AIR_DEFENSE), adTypesCount);
  for (const key of adKeys) {
    items.push({
      key,
      type: 'air_defense',
      qty: calc.randomInt(C.SHOP_ITEM_QTY_MIN, C.SHOP_ITEM_QTY_MAX),
      price: C.AIR_DEFENSE[key].price,
    });
  }

  if (Math.random() < C.SHOP_NUKE_CHANCE) {
    const nukeKey = C.NUKE_KEYS[Math.floor(Math.random() * C.NUKE_KEYS.length)];
    items.push({
      key: nukeKey,
      type: 'weapon',
      qty: 1,
      price: C.WEAPONS[nukeKey].price,
    });
  }

  await shopDb.setShopState(items, null);
  return { items, refreshed_at: new Date(), locked_until: null };
}

// Порядок отображения товаров в магазине: оружие (кроме ядерного), затем ПВО, затем ядерное.
// Используется и для показа номеров, и для покупки по номеру (!купить 3 2).
function orderedShopItems(items) {
  const weapons = items.filter((i) => i.type === 'weapon' && C.WEAPONS[i.key].category !== 'nuke');
  const ad = items.filter((i) => i.type === 'air_defense');
  const nukes = items.filter((i) => i.type === 'weapon' && C.WEAPONS[i.key].category === 'nuke');
  return [...weapons, ...ad, ...nukes];
}

async function buyItem(vkId, itemKeyOrIndex, quantity) {
  const state = await shopDb.getShopState();

  if (state.locked_until && new Date(state.locked_until) > new Date()) {
    return { ok: false, reason: 'shop_locked', until: state.locked_until };
  }

  const items = state.items || [];

  let itemKey = itemKeyOrIndex;
  if (/^\d+$/.test(String(itemKeyOrIndex).trim())) {
    const ordered = orderedShopItems(items);
    const pos = parseInt(itemKeyOrIndex, 10) - 1;
    if (!ordered[pos]) return { ok: false, reason: 'not_in_shop' };
    itemKey = ordered[pos].key;
  }

  const itemIndex = items.findIndex((i) => i.key.toLowerCase() === String(itemKey).toLowerCase());
  if (itemIndex === -1) return { ok: false, reason: 'not_in_shop' };

  const item = items[itemIndex];
  if (item.qty < quantity) return { ok: false, reason: 'not_enough_stock', available: item.qty };

  const player = await players.getPlayer(vkId);
  if (!player) return { ok: false, reason: 'not_registered' };

  const totalCost = item.price * quantity;
  if (Number(player.balance) < totalCost) {
    return { ok: false, reason: 'not_enough_money', missing: totalCost - Number(player.balance) };
  }

  // Часовой лимит на приток ПВО (покупка в магазине) — см. game/hourlyLimit.js.
  // На обычное оружие (type === 'weapon') лимит здесь не действует: оно и так
  // ограничено крошечным случайным ассортиментом магазина; факторное производство
  // лимитируется отдельно в game/production.js.
  if (item.type === 'air_defense') {
    const limitCheck = await hourlyLimit.check(vkId, 'air_defense', quantity, player);
    if (!limitCheck.ok) {
      return {
        ok: false,
        reason: 'hourly_limit_exceeded',
        category: 'air_defense',
        cap: limitCheck.cap,
        used: limitCheck.used,
        remaining: limitCheck.remaining,
      };
    }
  }

  await players.updateBalance(vkId, -totalCost);

  if (item.type === 'weapon') {
    await players.addToArsenal(vkId, item.key, quantity);
  } else {
    await players.addToAirDefense(vkId, item.key, quantity);
    await hourlyLimit.consume(vkId, 'air_defense', quantity);
  }

  item.qty -= quantity;
  const isNuke = C.WEAPONS[item.key] && C.WEAPONS[item.key].category === 'nuke';

  let lockedUntil = state.locked_until;
  if (isNuke) {
    lockedUntil = new Date(Date.now() + C.SHOP_LOCKOUT_AFTER_NUKE_MIN * 60 * 1000);
  }

  const newItems = item.qty > 0 ? items : items.filter((_, idx) => idx !== itemIndex);
  await shopDb.setShopState(newItems, lockedUntil);

  return { ok: true, totalCost, item, isNuke };
}

module.exports = { refreshShop, buyItem, orderedShopItems };
