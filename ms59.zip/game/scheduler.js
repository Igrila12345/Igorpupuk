'use strict';

const cron = require('node-cron');
const economy = require('./economy');
const miner = require('./miner');
const farm = require('./farm');
const shop = require('./shop');
const ratings = require('./ratings');
const attackResolver = require('./attackResolver');
const auction = require('./auction');
const shopDb = require('../db/shop');
const C = require('./constants');

function startScheduler(bot) {
  // Каждую минуту: проверяем прилетевшие атаки, готовые производства не требуют тика (забираются вручную),
  // разблокировки заводов по времени, снятие радиации.
  cron.schedule('* * * * *', async () => {
    try {
      await attackResolver.resolvePendingAttacks(bot);
      await economy.processFactoryUnblocks();
      await economy.processRadiationExpiry();
      await auction.resolveExpiredAuctions(bot);
    } catch (err) {
      console.error('[Scheduler] Ошибка в минутном тике:', err);
    }
  });

  // Каждый час: доход, налоги, курс нанокоина майнинг-фермы (сама добыча теперь считается
  // "на лету" в реальном времени в game/farm.js, почасовой тик ей не требуется)
  cron.schedule('0 * * * *', async () => {
    try {
      await economy.hourlyTick(bot);
      await miner.hourlyMinerTick();
      await farm.updateExchangeRate();
    } catch (err) {
      console.error('[Scheduler] Ошибка в часовом тике (доход/налоги):', err);
    }
  });

  // Каждые 5 минут: обновление магазина
  cron.schedule('*/5 * * * *', async () => {
    try {
      await shop.refreshShop();
    } catch (err) {
      console.error('[Scheduler] Ошибка обновления магазина:', err);
    }
  });

  // Ежедневно в 00:00 по МСК (сервер должен быть настроен на TZ=Europe/Moscow либо укажем явно)
  cron.schedule(
    '0 0 * * *',
    async () => {
      try {
        await ratings.distributeDailyRewards(bot);
      } catch (err) {
        console.error('[Scheduler] Ошибка выдачи ежедневных наград:', err);
      }
    },
    { timezone: 'Europe/Moscow' }
  );

  console.log('[Scheduler] Все фоновые задачи запущены.');
}

// Восстановление состояния при старте: если магазин пуст, генерируем сразу
async function bootstrapState() {
  const state = await shopDb.getShopState();
  if (!state.items || state.items.length === 0) {
    await shop.refreshShop();
  }
}

module.exports = { startScheduler, bootstrapState };
