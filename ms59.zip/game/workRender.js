'use strict';

const Jimp = require('jimp');
const C = require('./constants');
const R = require('./renderUtils');

const BOX_W = 220;
const BOX_H = 160;
const GAP = 30;
const MARGIN_SIDE = 30;
const HEADER_HEIGHT = 74;
const PADDING_TOP = 26;
const MARGIN_BOTTOM = 26;
const BORDER = 3;
const CORNER_RADIUS = 14;
const ICON_SIZE = 16;
const ICON_PADDING = 14; // отступ от края коробки, чтобы иконки не вылезали за рамку

const MARGIN_TOP = HEADER_HEIGHT + PADDING_TOP;

let factoryIconPromise = null;

async function buildFactoryIcon() {
  const icon = new Jimp(ICON_SIZE, ICON_SIZE, R.PALETTE.icon);
  for (let x = 0; x < ICON_SIZE; x++) {
    for (let y = 0; y < ICON_SIZE; y++) {
      if (x === 0 || y === 0 || x === ICON_SIZE - 1 || y === ICON_SIZE - 1) {
        icon.setPixelColor(R.PALETTE.iconBorder, x, y);
      }
    }
  }
  return icon;
}

function getFactoryIcon() {
  if (!factoryIconPromise) factoryIconPromise = buildFactoryIcon();
  return factoryIconPromise;
}

// session: { round, boxes: [{count, icons:[{x,y}]}], correctIndex }
async function renderRound(session) {
  const boxCount = session.boxes.length;
  const width = MARGIN_SIDE * 2 + boxCount * BOX_W + (boxCount - 1) * GAP;
  const height = MARGIN_TOP + BOX_H + MARGIN_BOTTOM;

  const [image, { fontTitle, fontBadge }, factoryIcon] = await Promise.all([
    R.buildBackground(width, height),
    R.getFonts(),
    getFactoryIcon(),
  ]);

  // Заголовок в своей полосе — сетка коробок начинается строго под ней, без наложения
  // (это и убирает артефакт в правом верхнем углу, который раньше давала подпись
  // номера коробки, залезающая под область заголовка).
  R.drawHeader(image, width, HEADER_HEIGHT, `👷 РАБОТА \u2014 раунд ${session.round}/${C.WORK_ROUNDS}`, fontTitle);

  for (let i = 0; i < boxCount; i++) {
    const box = session.boxes[i];
    const boxX = MARGIN_SIDE + i * (BOX_W + GAP);
    const boxY = MARGIN_TOP;

    R.drawCardWithShadow(image, boxX, boxY, BOX_W, BOX_H, R.PALETTE.cell, CORNER_RADIUS);
    R.drawFrame(image, boxX, boxY, BOX_W, BOX_H, BORDER, R.PALETTE.cellBorder);

    const usableW = BOX_W - ICON_PADDING * 2 - ICON_SIZE;
    const usableH = BOX_H - ICON_PADDING * 2 - ICON_SIZE;

    for (const icon of box.icons) {
      const ix = boxX + ICON_PADDING + Math.round(icon.x * usableW);
      const iy = boxY + ICON_PADDING + Math.round(icon.y * usableH);
      image.composite(factoryIcon, ix, iy);
    }

    await R.drawBadge(image, boxX - 6, boxY - 6, i + 1, fontBadge);
  }

  return image.getBufferAsync(Jimp.MIME_PNG);
}

module.exports = { renderRound };
