#!/usr/bin/env bash
# Простой запасной вариант "держателя" бота без pm2: если процесс упадёт (любой код выхода,
# кроме явной ручной остановки через Ctrl+C/SIGTERM), скрипт перезапустит его через паузу.
# Использовать, если на сервере нельзя/не хочется ставить pm2:
#   chmod +x scripts/run-forever.sh
#   nohup ./scripts/run-forever.sh > logs/run-forever.log 2>&1 &
#
# Для полноценной эксплуатации всё же рекомендуется pm2 (ecosystem.config.js) или systemd —
# они умеют автозапуск после перезагрузки сервера, этот скрипт — нет.

cd "$(dirname "$0")/.."
mkdir -p logs

RESTART_DELAY=5

while true; do
  echo "[run-forever] $(date -Iseconds) Запуск бота..."
  node index.js
  EXIT_CODE=$?
  echo "[run-forever] $(date -Iseconds) Бот завершился с кодом ${EXIT_CODE}. Перезапуск через ${RESTART_DELAY}с..."
  sleep "$RESTART_DELAY"
done
