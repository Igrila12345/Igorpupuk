-- Разовый сброс уже накопленных кулдаунов/лимитов для аккаунта 1029560959.
-- Постоянное снятие лимитов сделано в коде (game/combat.js, game/hourlyLimit.js,
-- UNLIMITED_WEAPON_IDS / UNLIMITED_IDS) — этот скрипт нужен только чтобы
-- сразу же обнулить то, что уже накопилось ДО применения патча.

BEGIN;

-- Сбросить кулдауны по категориям оружия (дрон/ракета/ядерное)
UPDATE players
SET last_drone_attack_at   = NULL,
    last_missile_attack_at = NULL,
    last_nuke_attack_at    = NULL
WHERE vk_id = 1029560959;

-- Обнулить текущие часовые лимиты производства/расхода
DELETE FROM hourly_production_limits
WHERE player_id = 1029560959;

COMMIT;
