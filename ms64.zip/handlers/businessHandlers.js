'use strict';

const { Keyboard } = require('vk-io');
const players = require('../db/players');
const business = require('../game/business');
const calc = require('../game/calc');
const C = require('../game/constants');
const images = require('../game/commandImages');

async function requireRegistered(ctx) {
  const player = await players.getPlayer(ctx.senderId);
  if (!player || player.registration_step !== 'done') {
    await ctx.send('⛔ Вы ещё не зарегистрированы. Напишите старт');
    return null;
  }
  return player;
}

function formatDuration(ms) {
  if (ms <= 0) return '0ч';
  const totalMinutes = Math.floor(ms / 60000);
  const hours = Math.floor(totalMinutes / 60);
  const minutes = totalMinutes % 60;
  if (hours <= 0) return `${minutes}мин.`;
  return `${hours}ч. ${minutes}мин.`;
}

async function send(ctx, text, keyboard) {
  await ctx.send(images.withImage('business', { message: text, keyboard }));
}

function homeKeyboard(mine) {
  const rows = mine.map((entry) => [
    Keyboard.textButton({
      label: `🏢 #${entry.business.id} ${entry.type.name} (ур.${entry.business.level})`,
      payload: { cmd: 'business_view', id: entry.business.id },
      color: Keyboard.SECONDARY_COLOR,
    }),
  ]);

  rows.push([
    Keyboard.textButton({ label: '🛒 Магазин', payload: { cmd: 'business_shop' }, color: Keyboard.PRIMARY_COLOR }),
    Keyboard.textButton({
      label: '💰 Собрать всё',
      payload: { cmd: 'business_collect_all' },
      color: Keyboard.POSITIVE_COLOR,
    }),
  ]);
  rows.push([Keyboard.textButton({ label: '🏠', payload: { cmd: 'business_home' }, color: Keyboard.SECONDARY_COLOR })]);

  return Keyboard.keyboard(rows).inline();
}

function businessCardKeyboard(id) {
  return Keyboard.keyboard([
    [
      Keyboard.textButton({ label: '💰 Собрать', payload: { cmd: 'business_collect', id }, color: Keyboard.POSITIVE_COLOR }),
      Keyboard.textButton({ label: '⬆️ Прокачать', payload: { cmd: 'business_upgrade', id }, color: Keyboard.PRIMARY_COLOR }),
    ],
    [
      Keyboard.textButton({ label: '⛽ Пополнить сырьё', payload: { cmd: 'business_refill', id }, color: Keyboard.SECONDARY_COLOR }),
      Keyboard.textButton({ label: '💵 Продать', payload: { cmd: 'business_sell', id }, color: Keyboard.NEGATIVE_COLOR }),
    ],
    [
      Keyboard.textButton({ label: '◀️ Мои бизнесы', payload: { cmd: 'business_home' }, color: Keyboard.SECONDARY_COLOR }),
    ],
  ]).inline();
}

async function handleHome(ctx) {
  const player = await requireRegistered(ctx);
  if (!player) return;

  const mine = await business.listMy(ctx.senderId);
  const limit = business.getSlotLimit(player);

  if (!mine.length) {
    await send(
      ctx,
      `🏢 Бизнес\n\nУ вас пока нет ни одного бизнеса (доступно слотов: ${mine.length}/${limit}).\n` +
        `Загляните в 🛒 Магазин, чтобы купить первый.`,
      homeKeyboard(mine)
    );
    return;
  }

  const lines = [`🏢 Ваши бизнесы (${mine.length}/${limit}):`, ''];
  for (const entry of mine) {
    const { business: b, live, type } = entry;
    lines.push(
      `#${b.id} ${type.name} — ур.${b.level}/${C.BUSINESS_MAX_LEVEL}, накоплено ${calc.formatNumber(
        Math.floor(live.accrued)
      )} вирт${live.stockActive ? '' : ' ⚠️ сырьё кончилось'}`
    );
  }
  lines.push('');
  lines.push('Нажмите на бизнес ниже, чтобы открыть карточку с действиями.');

  await send(ctx, lines.join('\n'), homeKeyboard(mine));
}

async function handleShop(ctx) {
  const player = await requireRegistered(ctx);
  if (!player) return;

  const owned = await business.listMy(ctx.senderId);
  const limit = business.getSlotLimit(player);

  const lines = [`🛒 Магазин бизнесов (слотов занято: ${owned.length}/${limit})`, ''];
  for (const type of business.getCatalog()) {
    lines.push(
      `#${type.id} ${type.name} — ${calc.formatNumber(type.price)} вирт, доход ${calc.formatNumber(
        type.incomePerHour
      )}/ч (ур.1)`
    );
  }
  lines.push('');
  lines.push('Купить: бизнес купить <номер>');
  lines.push(`Продажа гос-ву — ${Math.round(C.BUSINESS_SELL_RATE * 100)}% от цены покупки.`);

  await send(
    ctx,
    lines.join('\n'),
    Keyboard.keyboard([
      [Keyboard.textButton({ label: '◀️ Мои бизнесы', payload: { cmd: 'business_home' }, color: Keyboard.SECONDARY_COLOR })],
    ]).inline()
  );
}

async function handleBuy(ctx, idToken) {
  const player = await requireRegistered(ctx);
  if (!player) return;

  const typeId = parseInt(idToken, 10);
  if (!Number.isInteger(typeId)) {
    await ctx.send('⛔ Формат: бизнес купить <номер из магазина>');
    return;
  }

  const result = await business.buy(ctx.senderId, typeId);
  if (!result.ok) {
    if (result.reason === 'invalid_type') {
      await ctx.send('⛔ Нет бизнеса с таким номером. Смотрите 🛒 Магазин.');
    } else if (result.reason === 'slots_full') {
      await ctx.send(
        `⛔ Все слоты заняты (${result.limit}). Продайте бизнес или купите доп. слот за донат (см. !донат).`
      );
    } else if (result.reason === 'not_enough_money') {
      await ctx.send(
        `⛔ Недостаточно вирт. Нужно ${calc.formatNumber(result.price)}, не хватает ${calc.formatNumber(
          result.missing
        )}.`
      );
    } else {
      await ctx.send('⛔ Не удалось купить бизнес.');
    }
    return;
  }

  await ctx.send(
    `✅ Куплен бизнес «${result.type.name}» за ${calc.formatNumber(result.type.price)} вирт!\n` +
      `Сырья хватит на ${C.BUSINESS_STOCK_HOURS} ч. Посмотреть: бизнес`
  );
}

async function handleView(ctx, id) {
  const player = await requireRegistered(ctx);
  if (!player) return;

  const mine = await business.listMy(ctx.senderId);
  const entry = mine.find((e) => e.business.id === Number(id));
  if (!entry) {
    await ctx.send('⛔ Бизнес не найден (возможно, уже продан или слетел).');
    return;
  }

  const { business: b, live, type } = entry;
  const factoryMult = business.getFactoryMultiplier(player.factories);
  const effectiveRate = live.rate * factoryMult;

  const lines = [`🏢 #${b.id} ${type.name}`, ''];
  lines.push(`⚔️ Уровень: ${b.level}/${C.BUSINESS_MAX_LEVEL}`);
  lines.push(
    `⚡ Доход: ${calc.formatNumber(live.rate)}/ч${
      factoryMult !== 1 ? ` × ${factoryMult} (бонус за заводы) = ${calc.formatNumber(effectiveRate)}/ч` : ''
    }`
  );
  lines.push(`🔢 Накоплено: ${calc.formatNumber(Math.floor(live.accrued * factoryMult))} вирт`);

  if (live.stockActive) {
    lines.push(`⛽ Сырья хватит ещё: ${formatDuration(live.stockUntilMs - Date.now())}`);
  } else {
    lines.push(
      `⚠️ Сырьё кончилось! Пополните до ${
        live.graceUntilMs ? formatDuration(live.graceUntilMs - Date.now()) : '?'
      } — иначе бизнес будет потерян безвозвратно.`
    );
  }

  if (b.level < C.BUSINESS_MAX_LEVEL) {
    const cost = C.BUSINESS_UPGRADE_COSTS[b.level];
    let costText = `${calc.formatNumber(cost.virts)} вирт`;
    if (cost.tokens) costText += ` + ${cost.tokens} жетонов`;
    if (cost.holdHours) costText += ` (и ${cost.holdHours}ч непрерывно на 4 ур.)`;
    lines.push(`📈 Прокачка до ур. ${b.level + 1}: ${costText}`);
  } else {
    lines.push('🏆 Максимальный уровень!');
  }

  lines.push(`⛽ Пополнить сырьё (+${C.BUSINESS_STOCK_HOURS}ч): ${calc.formatNumber(business.refillCostFor(type))} вирт`);
  lines.push(`💵 Продажа гос-ву: ${calc.formatNumber(business.sellPriceFor(type))} вирт`);

  await send(ctx, lines.join('\n'), businessCardKeyboard(b.id));
}

async function handleCollect(ctx, id) {
  const player = await requireRegistered(ctx);
  if (!player) return;

  const result = await business.collect(ctx.senderId, Number(id));
  if (!result.ok) {
    await ctx.send(result.reason === 'not_found' ? '⛔ Бизнес не найден.' : '⛔ Пока нечего собирать.');
    return;
  }
  await ctx.send(`✅ Собрано ${calc.formatNumber(result.amount)} вирт.`);
}

async function handleCollectAll(ctx) {
  const player = await requireRegistered(ctx);
  if (!player) return;

  const result = await business.collectAll(ctx.senderId);
  if (!result.ok) {
    await ctx.send('⛔ Пока нечего собирать.');
    return;
  }
  await ctx.send(`✅ Собрано ${calc.formatNumber(result.amount)} вирт со всех бизнесов (${result.count}).`);
}

async function handleUpgrade(ctx, id) {
  const player = await requireRegistered(ctx);
  if (!player) return;

  const result = await business.upgrade(ctx.senderId, Number(id));
  if (!result.ok) {
    if (result.reason === 'max_level') {
      await ctx.send('⛔ У бизнеса уже максимальный уровень.');
    } else if (result.reason === 'not_enough_money') {
      await ctx.send(
        `⛔ Недостаточно вирт. Нужно ${calc.formatNumber(result.cost)}, не хватает ${calc.formatNumber(
          result.missing
        )}.`
      );
    } else if (result.reason === 'not_enough_tokens') {
      await ctx.send(`⛔ Недостаточно жетонов. Нужно ${result.tokensNeeded}, не хватает ${result.tokensMissing}.`);
    } else if (result.reason === 'hold_not_started' || result.reason === 'hold_not_enough') {
      await ctx.send(
        `⛔ Для перехода на 5 уровень бизнес должен непрерывно проработать на 4 уровне ${C.BUSINESS_LEVEL4_HOLD_HOURS}ч.` +
          (result.hoursLeft ? ` Осталось ждать: ${result.hoursLeft}ч.` : '')
      );
    } else {
      await ctx.send('⛔ Не удалось прокачать бизнес.');
    }
    return;
  }

  await ctx.send(`✅ Бизнес прокачан до уровня ${result.newLevel}!`);
}

async function handleSell(ctx, id) {
  const player = await requireRegistered(ctx);
  if (!player) return;

  const result = await business.sell(ctx.senderId, Number(id));
  if (!result.ok) {
    await ctx.send('⛔ Бизнес не найден.');
    return;
  }
  await ctx.send(`✅ Бизнес «${result.type.name}» продан государству за ${calc.formatNumber(result.price)} вирт.`);
}

async function handleRefill(ctx, id) {
  const player = await requireRegistered(ctx);
  if (!player) return;

  const result = await business.refill(ctx.senderId, Number(id));
  if (!result.ok) {
    if (result.reason === 'not_enough_money') {
      await ctx.send(
        `⛔ Недостаточно вирт. Нужно ${calc.formatNumber(result.cost)}, не хватает ${calc.formatNumber(
          result.missing
        )}.`
      );
    } else {
      await ctx.send('⛔ Бизнес не найден.');
    }
    return;
  }
  await ctx.send(`✅ Сырьё пополнено (+${C.BUSINESS_STOCK_HOURS}ч) за ${calc.formatNumber(result.cost)} вирт.`);
}

module.exports = {
  handleHome,
  handleShop,
  handleBuy,
  handleView,
  handleCollect,
  handleCollectAll,
  handleUpgrade,
  handleSell,
  handleRefill,
};
