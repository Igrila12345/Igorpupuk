'use strict';

const C = require('./constants');
const calc = require('./calc');
const players = require('../db/players');
const atomStationBuilds = require('../db/atomStationBuilds');
const asyncLock = require('./asyncLock');

// Постройка АЭС (можно сразу несколько штук одной командой, максимум см.
// C.ATOM_STATION_BUILD_MAX_PER_COMMAND / _VIP). Обёрнуто в withLock по vkId — тот же
// принцип, что и у game/economy.js: buildFactoryLocked, чтобы параллельные вызовы не могли
// обойти часовой лимит построек.
async function build(vkId, count = 1) {
  return asyncLock.withLock(`build-atom-station:${vkId}`, () => buildLocked(vkId, count));
}

async function buildLocked(vkId, count = 1) {
  const player0 = await players.getPlayer(vkId);
  if (!player0) return { ok: false, reason: 'not_registered' };

  const maxPerCommand = calc.isVipActive(player0)
    ? C.ATOM_STATION_BUILD_MAX_PER_COMMAND_VIP
    : C.ATOM_STATION_BUILD_MAX_PER_COMMAND;
  const requested = Math.max(1, Math.min(Math.floor(count) || 1, maxPerCommand));

  let built = 0;
  let totalSpent = 0;
  let lastReason = null;
  let lastExtra = null;

  for (let i = 0; i < requested; i++) {
    const player = await players.getPlayer(vkId);
    const maxStations = calc.currentAtomStationLimit(player.atom_station_limit_level);
    if ((player.atom_stations || 0) >= maxStations) {
      lastReason = 'max_reached';
      lastExtra = { max: maxStations };
      break;
    }

    const buildLimit = calc.isVipActive(player)
      ? C.ATOM_STATION_BUILD_LIMIT_PER_HOUR * C.VIP_ATOM_STATION_BUILD_LIMIT_MULTIPLIER
      : C.ATOM_STATION_BUILD_LIMIT_PER_HOUR;
    const recentBuilds = await atomStationBuilds.countRecentBuilds(vkId, 60 * 60 * 1000);
    if (recentBuilds >= buildLimit) {
      lastReason = 'build_limit';
      lastExtra = { limit: buildLimit };
      break;
    }

    // Цена АЭС фиксированная — не растёт от количества уже построенных (в отличие от
    // заводов, см. calc.nextFactoryPrice).
    const price = C.ATOM_STATION_PRICE;
    if (Number(player.balance) < price) {
      lastReason = 'not_enough_money';
      lastExtra = { price, missing: price - Number(player.balance) };
      break;
    }

    await players.updateBalance(vkId, -price);
    await players.addAtomStations(vkId, 1);
    await atomStationBuilds.logBuild(vkId);

    built += 1;
    totalSpent += price;
  }

  if (built === 0) {
    return { ok: false, reason: lastReason || 'unknown', ...lastExtra };
  }

  return {
    ok: true,
    built,
    requested,
    totalSpent,
    stoppedEarly: built < requested ? lastReason : null,
  };
}

// Расширение максимального числа АЭС (не путать с часовым лимитом построек выше) —
// тот же принцип, что и game/factoryLimit.js: expand / game/science.js: expandLimit.
async function expandLimit(vkId) {
  const player = await players.getPlayer(vkId);
  if (!player) return { ok: false, reason: 'not_registered' };

  const currentLevel = player.atom_station_limit_level || 1;
  const nextRow = C.ATOM_STATION_LIMIT_LEVELS.find((l) => l.level === currentLevel + 1);
  if (!nextRow) {
    return { ok: false, reason: 'max_level' };
  }

  if (Number(player.balance) < nextRow.cost) {
    return { ok: false, reason: 'not_enough_money', cost: nextRow.cost, missing: nextRow.cost - Number(player.balance) };
  }

  await players.updateBalance(vkId, -nextRow.cost);
  await players.setAtomStationLimitLevel(vkId, nextRow.level);

  return { ok: true, newLevel: nextRow.level, newLimit: nextRow.limit, cost: nextRow.cost };
}

module.exports = { build, expandLimit };
