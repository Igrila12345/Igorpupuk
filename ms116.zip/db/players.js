'use strict';

const { query } = require('./pool');
const C = require('../game/constants');

async function getPlayer(vkId) {
  const res = await query('SELECT * FROM players WHERE vk_id = $1', [vkId]);
  return res.rows[0] || null;
}

async function getPlayersByIds(vkIds) {
  const ids = [...new Set((vkIds || []).filter(Boolean))];
  if (!ids.length) return {};
  const res = await query('SELECT * FROM players WHERE vk_id = ANY($1)', [ids]);
  const map = {};
  for (const row of res.rows) map[row.vk_id] = row;
  return map;
}

async function getPlayerByName(stateName) {
  const res = await query(
    'SELECT * FROM players WHERE LOWER(state_name) = LOWER($1)',
    [stateName]
  );
  return res.rows[0] || null;
}

async function createPlayerStub(vkId) {
  const res = await query(
    `INSERT INTO players (vk_id, balance, registration_step)
     VALUES ($1, $2, 'awaiting_name')
     ON CONFLICT (vk_id) DO NOTHING
     RETURNING *`,
    [vkId, C.START_BALANCE]
  );
  if (res.rows[0]) return res.rows[0];
  return getPlayer(vkId);
}

function randCoord() {
  return Math.floor(Math.random() * (C.MAP_MAX - C.MAP_MIN + 1)) + C.MAP_MIN;
}

async function finalizeRegistration(vkId, stateName) {
  const x = randCoord();
  const y = randCoord();
  const res = await query(
    `UPDATE players
     SET state_name = $2, x = $3, y = $4, registration_step = 'done', last_seen = NOW(),
         factories = factories + $5
     WHERE vk_id = $1
     RETURNING *`,
    [vkId, stateName, x, y, C.STARTER_FREE_FACTORIES]
  );
  return res.rows[0];
}

async function touchLastSeen(vkId) {
  await query('UPDATE players SET last_seen = NOW() WHERE vk_id = $1', [vkId]);
}

async function updateBalance(vkId, delta) {
  const res = await query(
    'UPDATE players SET balance = balance + $2 WHERE vk_id = $1 RETURNING balance',
    [vkId, delta]
  );
  return res.rows[0] ? Number(res.rows[0].balance) : null;
}

async function setBalance(vkId, value) {
  await query('UPDATE players SET balance = $2 WHERE vk_id = $1', [vkId, value]);
}

async function renamePlayer(vkId, newName) {
  await query('UPDATE players SET state_name = $2 WHERE vk_id = $1', [vkId, newName]);
}

async function addFactories(vkId, count, isGoldMine) {
  const res = await query(
    `UPDATE players
     SET factories = factories + $2,
         gold_mine_count = gold_mine_count + $3
     WHERE vk_id = $1
     RETURNING *`,
    [vkId, count, isGoldMine ? 1 : 0]
  );
  return res.rows[0];
}

async function setArsenal(vkId, arsenal) {
  await query('UPDATE players SET arsenal = $2::jsonb WHERE vk_id = $1', [
    vkId,
    JSON.stringify(arsenal),
  ]);
}

async function setAirDefense(vkId, airDefense) {
  await query('UPDATE players SET air_defense = $2::jsonb WHERE vk_id = $1', [
    vkId,
    JSON.stringify(airDefense),
  ]);
}

// ===================== "ПРОЧНОСТЬ" ПВО (накопительный урон, по аналогии с factory_damage) =====================

async function setAirDefenseDamage(vkId, airDefenseDamage) {
  await query('UPDATE players SET air_defense_damage = $2::jsonb WHERE vk_id = $1', [
    vkId,
    JSON.stringify(airDefenseDamage),
  ]);
}

async function addToArsenal(vkId, weaponKey, qty) {
  const player = await getPlayer(vkId);
  const arsenal = player.arsenal || {};
  arsenal[weaponKey] = (arsenal[weaponKey] || 0) + qty;
  await setArsenal(vkId, arsenal);
  return arsenal;
}

async function addToAirDefense(vkId, adKey, qty) {
  const player = await getPlayer(vkId);
  const ad = player.air_defense || {};
  ad[adKey] = (ad[adKey] || 0) + qty;
  await setAirDefense(vkId, ad);
  return ad;
}

async function setBlockedFactories(vkId, blockedList) {
  await query('UPDATE players SET blocked_factories = $2::jsonb WHERE vk_id = $1', [
    vkId,
    JSON.stringify(blockedList),
  ]);
}

async function setRadiationUntil(vkId, until) {
  await query('UPDATE players SET radiation_until = $2 WHERE vk_id = $1', [vkId, until]);
}

async function setClan(vkId, clanId, role) {
  await query('UPDATE players SET clan_id = $2, clan_role = $3 WHERE vk_id = $1', [
    vkId,
    clanId,
    role,
  ]);
}

// Место игрока в общем рейтинге по заводам (та же сортировка, что и в getTopByFactories:
// по количеству заводов убыв., при равенстве — по балансу убыв.)
async function getFactoryRank(vkId) {
  const res = await query(
    `SELECT rank FROM (
       SELECT vk_id, ROW_NUMBER() OVER (ORDER BY factories DESC, balance DESC) AS rank
       FROM players WHERE registration_step = 'done'
     ) ranked WHERE vk_id = $1`,
    [vkId]
  );
  return res.rows[0] ? Number(res.rows[0].rank) : null;
}

// Место игрока в общем рейтинге по виртам (та же сортировка, что и в getTopByBalance:
// по балансу убыв.). Используется кражей — теперь она нацелена на топ по виртам,
// а не по заводам (заводы неприкосновенны для кражи, см. game/steal.js).
async function getBalanceRank(vkId) {
  const res = await query(
    `SELECT rank FROM (
       SELECT vk_id, ROW_NUMBER() OVER (ORDER BY balance DESC) AS rank
       FROM players WHERE registration_step = 'done'
     ) ranked WHERE vk_id = $1`,
    [vkId]
  );
  return res.rows[0] ? Number(res.rows[0].rank) : null;
}

async function getTopByFactories(limit = 10) {
  const res = await query(
    `SELECT * FROM players WHERE registration_step = 'done' ORDER BY factories DESC, balance DESC LIMIT $1`,
    [limit]
  );
  return res.rows;
}

async function getTopByBalance(limit = 10) {
  const res = await query(
    `SELECT * FROM players WHERE registration_step = 'done' ORDER BY balance DESC LIMIT $1`,
    [limit]
  );
  return res.rows;
}

async function getAllActivePlayers() {
  const res = await query(`SELECT * FROM players WHERE registration_step = 'done'`);
  return res.rows;
}

// Облегчённая версия для гонки заводов (game/factoryRace.js): нужны только заводы + клан
// каждого игрока — и для снимка на старте цикла, и для подсчёта прироста на финише/в статусе.
// Полный SELECT * (как в getAllActivePlayers) тут не нужен и просто тратит память на JSONB-поля.
async function getFactoriesSnapshot() {
  const res = await query(
    `SELECT vk_id, state_name, factories, clan_id FROM players WHERE registration_step = 'done'`
  );
  return res.rows;
}

// Облегчённая версия для минутного тика economy.processFactoryUnblocks: у подавляющего
// большинства игроков blocked_factories пустой массив, а полный SELECT * тянет также
// тяжёлые JSONB-поля (arsenal, air_defense и т.д.) по КАЖДОМУ игроку КАЖДУЮ минуту без
// необходимости. Здесь берём только 2 нужные колонки и сразу фильтруем на стороне БД —
// логика и результат processFactoryUnblocks не меняются, меняется только объём читаемых
// и передаваемых данных.
async function getPlayersWithBlockedFactories() {
  const res = await query(
    `SELECT vk_id, blocked_factories FROM players
     WHERE registration_step = 'done' AND blocked_factories <> '[]'::jsonb`
  );
  return res.rows;
}

// ===================== АДМИН: СПИСОК ВСЕХ ИГРОКОВ (постранично) =====================

async function getPlayersCount() {
  const res = await query(`SELECT COUNT(*)::int AS count FROM players WHERE registration_step = 'done'`);
  return res.rows[0] ? res.rows[0].count : 0;
}

async function getPlayersPage(offset, limit) {
  const res = await query(
    `SELECT * FROM players WHERE registration_step = 'done' ORDER BY last_seen DESC LIMIT $1 OFFSET $2`,
    [limit, offset]
  );
  return res.rows;
}

async function destroyOneFactory(vkId) {
  const player = await getPlayer(vkId);
  if (!player || player.factories <= 0) return null;
  // Восстановление заводов отключено: снесённый завод пропадает навсегда,
  // игрока это стимулирует достраивать новые заводы вместо ожидания.
  await query(
    'UPDATE players SET factories = factories - 1, destroyed_factories = destroyed_factories + 1 WHERE vk_id = $1',
    [vkId]
  );
  return true;
}

// ===================== ХП ЗАВОДОВ (накопительный урон) =====================

async function setFactoryDamage(vkId, value) {
  await query('UPDATE players SET factory_damage = $2 WHERE vk_id = $1', [vkId, value]);
}

async function addFactoryDamage(vkId, delta) {
  const res = await query(
    'UPDATE players SET factory_damage = factory_damage + $2 WHERE vk_id = $1 RETURNING factory_damage',
    [vkId, delta]
  );
  return res.rows[0] ? res.rows[0].factory_damage : null;
}

// ===================== ЕЖЕДНЕВНЫЙ БОНУС =====================

async function setLastDailyBonus(vkId, when) {
  await query('UPDATE players SET last_daily_bonus = $2 WHERE vk_id = $1', [vkId, when]);
}

// ===================== СТАТИСТИКА =====================

// Возвращает НОВОЕ суммарное значение enemy_factories_destroyed (через RETURNING) — используется
// для уведомления игрока "снесено всего: N" сразу после атаки, без отдельного getPlayer().
async function incrementEnemyFactoriesDestroyed(vkId, count) {
  if (!count) return null;
  const res = await query(
    'UPDATE players SET enemy_factories_destroyed = enemy_factories_destroyed + $2 WHERE vk_id = $1 RETURNING enemy_factories_destroyed',
    [vkId, count]
  );
  return res.rows[0] ? res.rows[0].enemy_factories_destroyed : null;
}

// ===================== РОБОТ =====================

async function setRobotLevel(vkId, level) {
  await query('UPDATE players SET robot_level = $2 WHERE vk_id = $1', [vkId, level]);
}

async function setRobotLastFarm(vkId, when) {
  await query('UPDATE players SET robot_last_farm_at = $2 WHERE vk_id = $1', [vkId, when]);
}

async function setRobotLastAttack(vkId, when) {
  await query('UPDATE players SET robot_last_attack_at = $2 WHERE vk_id = $1', [vkId, when]);
}

async function setRobotLastSend(vkId, when) {
  await query('UPDATE players SET robot_last_send_at = $2 WHERE vk_id = $1', [vkId, when]);
}

async function getTopByRobotLevel(limit = 10) {
  const res = await query(
    `SELECT * FROM players WHERE registration_step = 'done' ORDER BY robot_level DESC, balance DESC LIMIT $1`,
    [limit]
  );
  return res.rows;
}

// ===================== VIP =====================

async function setVipUntil(vkId, until) {
  await query('UPDATE players SET vip_until = $2 WHERE vk_id = $1', [vkId, until]);
}

// ===================== ЗАЩИТА ОТ КРАЖИ (отдельная подписка, не VIP) =====================

async function setStealProtectionUntil(vkId, until) {
  await query('UPDATE players SET steal_protection_until = $2 WHERE vk_id = $1', [vkId, until]);
}

// Ставит НЕОБРАТИМЫЙ флаг «бонус новичка отработан» (см. game/calc.js: isNewbieBoostActive).
// Условие `newbie_boost_ended = FALSE` в WHERE делает вызов идемпотентным: повторные вызовы
// для уже помеченного игрока не трогают строку.
async function markNewbieBoostEnded(vkId) {
  await query('UPDATE players SET newbie_boost_ended = TRUE WHERE vk_id = $1 AND newbie_boost_ended = FALSE', [vkId]);
}

// ===================== ПРОКАЧКА ЗАВОДОВ (общий множитель дохода) =====================

// Атомарный инкремент с условием "текущий уровень ровно expectedLevel" — защита от гонки:
// если между чтением игрока в game/economy.js и этим запросом уровень уже успел вырасти
// (двойной клик/два одновременных запроса), запрос вернёт 0 строк и вызывающий код поймёт,
// что нужно перечитать игрока и попробовать снова, а не тихо продать два уровня по цене одного.
async function incrementFactoryUpgradeLevel(vkId, expectedLevel) {
  const res = await query(
    'UPDATE players SET factory_upgrade_level = factory_upgrade_level + 1 WHERE vk_id = $1 AND factory_upgrade_level = $2 RETURNING factory_upgrade_level',
    [vkId, expectedLevel]
  );
  return res.rows[0] ? res.rows[0].factory_upgrade_level : null;
}

// ===================== КАЗИНО — АДМИНСКИЙ БУСТ ШАНСА =====================

// percent: 50 или 60 — принудительный шанс выигрыша (3 одинаковых) на каждый спин слотов
// для конкретного игрока; null — снять буст, шансы обычные (см. game/casino.js: rollReels).
async function setCasinoWinBoost(vkId, percent) {
  await query('UPDATE players SET casino_win_boost_percent = $2 WHERE vk_id = $1', [vkId, percent]);
}

// ===================== МАЙНЕР (донат) =====================

async function setMinerUntil(vkId, until) {
  await query('UPDATE players SET miner_until = $2 WHERE vk_id = $1', [vkId, until]);
}

// Прокачка майнера (0-15) — только жетоны/час, см. game/miner.js: tokensForLevel
async function setMinerLevel(vkId, level) {
  await query('UPDATE players SET miner_level = $2 WHERE vk_id = $1', [vkId, level]);
}

// УСТАРЕЛО: старый однослотовый донат-бизнес. Множественные донат-бизнесы теперь живут в
// отдельной таблице (см. db/donateBusiness.js) — эта функция больше нигде не вызывается,
// оставлена только как пример для ручной миграции старых данных (см. db/schema.sql).
async function setDonateBusiness(vkId, typeId, until, weeklyAt) {
  await query(
    'UPDATE players SET donate_business_id = $2, donate_business_until = $3, donate_business_weekly_at = $4 WHERE vk_id = $1',
    [vkId, typeId, until, weeklyAt]
  );
}

// Доп. слоты под ДОНАТ-бизнесы сверх бесплатного (см. !админ донатбизнесслот, game/donateBusiness.js)
async function addDonateBusinessExtraSlots(vkId, delta) {
  const res = await query(
    'UPDATE players SET donate_business_extra_slots = GREATEST(donate_business_extra_slots + $2, 0) WHERE vk_id = $1 RETURNING donate_business_extra_slots',
    [vkId, delta]
  );
  return res.rows[0] ? res.rows[0].donate_business_extra_slots : null;
}

// ===================== РАСХОДУЕМЫЕ ДОНАТ-БАФФЫ (см. game/donateBuffs.js) =====================

async function setIncomeBoost(vkId, until, mult) {
  await query('UPDATE players SET income_boost_until = $2, income_boost_mult = $3 WHERE vk_id = $1', [
    vkId,
    until,
    mult,
  ]);
}

async function setShieldUntil(vkId, until) {
  await query('UPDATE players SET shield_until = $2 WHERE vk_id = $1', [vkId, until]);
}

async function setWorkDoubleUntil(vkId, until) {
  await query('UPDATE players SET work_double_until = $2 WHERE vk_id = $1', [vkId, until]);
}

async function setFarmBoostUntil(vkId, until) {
  await query('UPDATE players SET farm_boost_until = $2 WHERE vk_id = $1', [vkId, until]);
}

// ⚡ Турбоферма — донат-подписка x${FARM_PRO_MULTIPLIER} к добыче фермы (см. game/farm.js)
async function setFarmProUntil(vkId, until) {
  await query('UPDATE players SET farm_pro_until = $2 WHERE vk_id = $1', [vkId, until]);
}

// ===================== НОВЫЕ ВРЕМЕННЫЕ ДОНАТ-ТОВАРЫ (см. game/donateBuffs.js) =====================

async function setEmojiTag(vkId, emoji, until) {
  await query('UPDATE players SET emoji_tag = $2, emoji_tag_until = $3 WHERE vk_id = $1', [vkId, emoji, until]);
}

async function setScienceBoostUntil(vkId, until) {
  await query('UPDATE players SET science_boost_until = $2 WHERE vk_id = $1', [vkId, until]);
}

async function setStealBoostUntil(vkId, until) {
  await query('UPDATE players SET steal_boost_until = $2 WHERE vk_id = $1', [vkId, until]);
}

async function setPatrolBoostUntil(vkId, until) {
  await query('UPDATE players SET patrol_boost_until = $2 WHERE vk_id = $1', [vkId, until]);
}

async function setInspectionBoostUntil(vkId, until) {
  await query('UPDATE players SET inspection_boost_until = $2 WHERE vk_id = $1', [vkId, until]);
}

async function setDonateStreak(vkId, streak, dayStr) {
  await query('UPDATE players SET donate_streak = $2, donate_streak_date = $3 WHERE vk_id = $1', [
    vkId,
    streak,
    dayStr,
  ]);
}

// ===================== КАСТОМНЫЕ ФОТО/ВИДЕО ПРОФИЛЯ (выдаёт админ) =====================

// value — VK attachment-строка ("photo-123456_789") или null, чтобы снять.
async function setProfilePhoto(vkId, value) {
  await query('UPDATE players SET profile_photo = $2 WHERE vk_id = $1', [vkId, value]);
}

async function setProfileVideo(vkId, value) {
  await query('UPDATE players SET profile_video = $2 WHERE vk_id = $1', [vkId, value]);
}

// ===================== АКТИВНЫЙ СТИЛЬ (см. game/styles.js) =====================

async function setActiveStyle(vkId, styleId, photoValue, videoValue) {
  await query(
    'UPDATE players SET active_style_id = $2, profile_photo = $3, profile_video = $4 WHERE vk_id = $1',
    [vkId, styleId, photoValue, videoValue]
  );
}

async function setStyleLocked(vkId, locked) {
  await query('UPDATE players SET style_locked = $2 WHERE vk_id = $1', [vkId, locked]);
}

// ===================== ДОЗОР =====================

async function setPatrolLastAt(vkId, date) {
  // Заодно увеличиваем patrol_count_total — суммарный счётчик для навыка "Дозор" (см.
  // game/skills.js), который в отличие от дневных лимитов НИКОГДА не обнуляется.
  const res = await query(
    'UPDATE players SET patrol_last_at = $2, patrol_count_total = patrol_count_total + 1 WHERE vk_id = $1 RETURNING patrol_count_total',
    [vkId, date]
  );
  return res.rows[0] ? res.rows[0].patrol_count_total : null;
}

// Просто сброс КД (например, донат-предмет resetPatrolCooldown в game/donateBuffs.js) —
// БЕЗ увеличения patrol_count_total, т.к. это не сыгранный обход, а разблокировка попытки.
async function resetPatrolLastAt(vkId) {
  await query('UPDATE players SET patrol_last_at = NULL WHERE vk_id = $1', [vkId]);
}

// ===================== СУПЕРРОБОТ =====================

async function setSuperRobotLevel(vkId, level) {
  await query('UPDATE players SET super_robot_level = $2 WHERE vk_id = $1', [vkId, level]);
}

async function setSuperRobotLastAttack(vkId, when) {
  await query('UPDATE players SET super_robot_last_attack_at = $2 WHERE vk_id = $1', [vkId, when]);
}

async function getTopBySuperRobotLevel(limit = 10) {
  const res = await query(
    `SELECT * FROM players WHERE registration_step = 'done' AND super_robot_level > 0
     ORDER BY super_robot_level DESC, balance DESC LIMIT $1`,
    [limit]
  );
  return res.rows;
}

// ===================== МАЙНИНГ-ФЕРМА =====================

async function setFarmLevel(vkId, level) {
  await query('UPDATE players SET farm_level = $2 WHERE vk_id = $1', [vkId, level]);
}

// Прокачка фермы за жетоны (см. game/constants.js: FARM_TOKEN_BOOST_*, game/farm.js:
// upgradeWithTokens) — отдельный счётчик от farm_level (тот качается за вирты).
async function setFarmTokenLevel(vkId, level) {
  await query('UPDATE players SET farm_token_level = $2 WHERE vk_id = $1', [vkId, level]);
}

async function addFarmCoins(vkId, delta) {
  await query('UPDATE players SET farm_coins = GREATEST(farm_coins + $2, 0) WHERE vk_id = $1', [vkId, delta]);
}

// Снимок текущего состояния непрерывной добычи (см. game/farm.js: computeLiveState/settleFarm).
// enabled — идёт ли добыча сейчас; balance — замороженный баланс на ферме на момент записи;
// sinceAt = null означает "не считаем", иначе момент начала текущего отрезка добычи.
async function setFarmState(vkId, { enabled, balance, sinceAt }) {
  await query('UPDATE players SET farm_enabled = $2, farm_balance = $3, farm_since_at = $4 WHERE vk_id = $1', [
    vkId,
    enabled,
    Math.max(0, Math.round(balance)),
    sinceAt,
  ]);
}

async function getTopByFarmLevel(limit = 10) {
  const res = await query(
    `SELECT * FROM players WHERE registration_step = 'done' AND farm_level > 0
     ORDER BY farm_level DESC, farm_coins DESC LIMIT $1`,
    [limit]
  );
  return res.rows;
}

async function getTopByScienceCenters(limit = 10) {
  const res = await query(
    `SELECT * FROM players WHERE registration_step = 'done' AND science_centers > 0
     ORDER BY science_centers DESC, balance DESC LIMIT $1`,
    [limit]
  );
  return res.rows;
}

// ===================== РАБОТА И ЖЕТОНЫ =====================

// ===================== ИВЕНТ-ВАЛЮТА (сезонные ивенты, см. game/events.js) =====================

async function addEventCurrency(vkId, delta) {
  const res = await query(
    'UPDATE players SET event_currency = GREATEST(event_currency + $2, 0) WHERE vk_id = $1 RETURNING event_currency',
    [vkId, delta]
  );
  return res.rows[0] ? res.rows[0].event_currency : null;
}

// Доп. слоты под бизнесы сверх бесплатных (выдаются вручную админом после доната, см. !админ бизнесслот)
async function addBusinessExtraSlots(vkId, delta) {
  const res = await query(
    'UPDATE players SET business_extra_slots = GREATEST(business_extra_slots + $2, 0) WHERE vk_id = $1 RETURNING business_extra_slots',
    [vkId, delta]
  );
  return res.rows[0] ? res.rows[0].business_extra_slots : null;
}

async function addTokens(vkId, delta) {
  const res = await query(
    'UPDATE players SET tokens = tokens + $2 WHERE vk_id = $1 RETURNING tokens',
    [vkId, delta]
  );
  return res.rows[0] ? res.rows[0].tokens : null;
}

async function incrementWorkCount(vkId, dayStr) {
  await query(
    `UPDATE players SET work_count_today = work_count_today + 1, last_work_time = NOW(), work_day = $2 WHERE vk_id = $1`,
    [vkId, dayStr]
  );
}

async function resetWorkDay(vkId, dayStr) {
  await query(
    'UPDATE players SET work_count_today = 0, work_bonus_attempts_today = 0, work_day = $2 WHERE vk_id = $1',
    [vkId, dayStr]
  );
}

// Доп. попытки "работы" сверх обычного дневного лимита (донат-ускоритель, см.
// DONATE_WORK_EXTRA_* в game/constants.js). Прибавляются к тому, что уже есть сегодня —
// сгорают вместе с обычным лимитом при смене дня (см. resetWorkDay выше).
async function addWorkBonusAttempts(vkId, amount) {
  const res = await query(
    'UPDATE players SET work_bonus_attempts_today = work_bonus_attempts_today + $2 WHERE vk_id = $1 RETURNING work_bonus_attempts_today',
    [vkId, amount]
  );
  return res.rows[0] ? res.rows[0].work_bonus_attempts_today : null;
}

// Текущая сессия мини-игры "работа" (раунд, коробки, дедлайн). NULL — сессии нет.
async function setWorkSession(vkId, session) {
  await query('UPDATE players SET work_session = $2::jsonb WHERE vk_id = $1', [
    vkId,
    session ? JSON.stringify(session) : null,
  ]);
}

// ===================== ИНСПЕКЦИЯ (вторая мини-игра, см. game/inspection.js) =====================
// Отдельный от "работы" дневной счётчик/кулдаун/сессия — обе активности накапливаются
// и тратятся независимо друг от друга.

async function incrementInspectionCount(vkId, dayStr) {
  await query(
    `UPDATE players SET inspection_count_today = inspection_count_today + 1, last_inspection_time = NOW(), inspection_day = $2 WHERE vk_id = $1`,
    [vkId, dayStr]
  );
}

async function resetInspectionDay(vkId, dayStr) {
  await query('UPDATE players SET inspection_count_today = 0, inspection_day = $2 WHERE vk_id = $1', [
    vkId,
    dayStr,
  ]);
}

// Текущая сессия мини-игры "инспекция" (раунд, сетка ячеек, индекс аномалии, дедлайн). NULL — сессии нет.
async function setInspectionSession(vkId, session) {
  await query('UPDATE players SET inspection_session = $2::jsonb WHERE vk_id = $1', [
    vkId,
    session ? JSON.stringify(session) : null,
  ]);
}

// ===================== МИРОВОЙ БОСС (личный дневной лимит ракет, см. game/boss.js) =====================

async function incrementBossLaunchCount(vkId, amount, dayStr) {
  await query(
    `UPDATE players SET boss_launch_count_today = boss_launch_count_today + $2, last_boss_launch_time = NOW(), boss_launch_day = $3 WHERE vk_id = $1`,
    [vkId, amount, dayStr]
  );
}

async function resetBossLaunchDay(vkId, dayStr) {
  await query('UPDATE players SET boss_launch_count_today = 0, boss_launch_day = $2 WHERE vk_id = $1', [
    vkId,
    dayStr,
  ]);
}

async function setBossDoubleUntil(vkId, until) {
  await query('UPDATE players SET boss_double_until = $2 WHERE vk_id = $1', [vkId, until]);
}

// ===================== КРАЖА У ТОП-5 (см. game/steal.js) =====================

async function incrementStealCount(vkId, dayStr) {
  // steal_count_total — суммарный счётчик для навыка "Кража" (см. game/skills.js),
  // в отличие от steal_count_today НИКОГДА не обнуляется дневным сбросом.
  const res = await query(
    `UPDATE players SET steal_count_today = steal_count_today + 1, steal_count_total = steal_count_total + 1,
            last_steal_at = NOW(), steal_day = $2
     WHERE vk_id = $1 RETURNING steal_count_today, steal_count_total`,
    [vkId, dayStr]
  );
  return res.rows[0] ? res.rows[0] : null;
}

async function resetStealDay(vkId, dayStr) {
  await query('UPDATE players SET steal_count_today = 0, steal_day = $2 WHERE vk_id = $1', [
    vkId,
    dayStr,
  ]);
}

// Мгновенно снимает кулдаун кражи (last_steal_at обнуляется — game/steal.js:
// msLeft(attacker.last_steal_at, ...) считает 0, если last_steal_at пуст). Используется
// ТОЛЬКО скрытой админ-командой "!админ кражакд" (см. handlers/adminHandlers.js) — не
// затрагивает дневной лимит (STEAL_DAILY_LIMIT), только 2-минутный кулдаун между попытками.
async function resetStealCooldown(vkId) {
  await query('UPDATE players SET last_steal_at = NULL WHERE vk_id = $1', [vkId]);
}

// ===================== ЕЖЕДНЕВНЫЕ ЗАДАНИЯ И КАРЬЕРА (см. game/quests.js, game/career.js) =====================

async function setQuestsData(vkId, questsArray, dayStr) {
  await query('UPDATE players SET quests_data = $2, quests_day = $3 WHERE vk_id = $1', [
    vkId,
    JSON.stringify(questsArray),
    dayStr,
  ]);
}

async function addCareerXp(vkId, amount) {
  const res = await query(
    'UPDATE players SET career_xp = career_xp + $2 WHERE vk_id = $1 RETURNING career_xp, career_rank',
    [vkId, amount]
  );
  if (!res.rows[0]) return null;
  return { xp: Number(res.rows[0].career_xp), rank: Number(res.rows[0].career_rank) };
}

async function setCareerRank(vkId, rank) {
  await query('UPDATE players SET career_rank = $2 WHERE vk_id = $1', [vkId, rank]);
}

// ===================== ДНЕВНЫЕ ЛИМИТЫ ОБМЕНА ЖЕТОНОВ =====================

async function incrementExchangeFactoryCount(vkId, dayStr) {
  await query(
    `UPDATE players SET exchange_factory_count_today = exchange_factory_count_today + 1, exchange_factory_day = $2 WHERE vk_id = $1`,
    [vkId, dayStr]
  );
}

async function incrementExchangeFactoryCountBy(vkId, dayStr, amount) {
  await query(
    `UPDATE players SET exchange_factory_count_today = exchange_factory_count_today + $3, exchange_factory_day = $2 WHERE vk_id = $1`,
    [vkId, dayStr, amount]
  );
}

async function resetExchangeFactoryDay(vkId, dayStr) {
  await query('UPDATE players SET exchange_factory_count_today = 0, exchange_factory_day = $2 WHERE vk_id = $1', [
    vkId,
    dayStr,
  ]);
}

async function incrementExchangeCaseCount(vkId, dayStr) {
  await query(
    `UPDATE players SET exchange_case_count_today = exchange_case_count_today + 1, exchange_case_day = $2 WHERE vk_id = $1`,
    [vkId, dayStr]
  );
}

async function resetExchangeCaseDay(vkId, dayStr) {
  await query('UPDATE players SET exchange_case_count_today = 0, exchange_case_day = $2 WHERE vk_id = $1', [
    vkId,
    dayStr,
  ]);
}

async function incrementExchangeScienceCount(vkId, dayStr) {
  await query(
    `UPDATE players SET exchange_science_count_today = exchange_science_count_today + 1, exchange_science_day = $2 WHERE vk_id = $1`,
    [vkId, dayStr]
  );
}

// Массовый аналог incrementExchangeScienceCount — для "обменять науку всё"/"обменять науку N"
// (см. game/warehouse.js: exchangeForScienceBulk), тот же приём, что и у
// incrementExchangeFactoryCountBy выше (одно обновление на всю пачку, а не N по одному).
async function incrementExchangeScienceCountBy(vkId, dayStr, amount) {
  await query(
    `UPDATE players SET exchange_science_count_today = exchange_science_count_today + $3, exchange_science_day = $2 WHERE vk_id = $1`,
    [vkId, dayStr, amount]
  );
}

async function resetExchangeScienceDay(vkId, dayStr) {
  await query('UPDATE players SET exchange_science_count_today = 0, exchange_science_day = $2 WHERE vk_id = $1', [
    vkId,
    dayStr,
  ]);
}

async function incrementExchangeScienceToFactoryCount(vkId, dayStr) {
  await query(
    `UPDATE players SET exchange_science_to_factory_count_today = exchange_science_to_factory_count_today + 1, exchange_science_to_factory_day = $2 WHERE vk_id = $1`,
    [vkId, dayStr]
  );
}

async function resetExchangeScienceToFactoryDay(vkId, dayStr) {
  await query(
    'UPDATE players SET exchange_science_to_factory_count_today = 0, exchange_science_to_factory_day = $2 WHERE vk_id = $1',
    [vkId, dayStr]
  );
}

// ===================== НАУЧНЫЕ ЦЕНТРЫ =====================

async function addScienceCenters(vkId, count) {
  await query('UPDATE players SET science_centers = science_centers + $2 WHERE vk_id = $1', [
    vkId,
    count,
  ]);
}

// Списывает count научных центров у игрока. Боевого оружия, сносящего чужую науку, в игре
// больше нет — единственный, кто теперь вызывает эту функцию, это сам игрок через обмен
// науки на заводы (game/science.js: exchangeToFactories). GREATEST(...,0) на случай гонки/
// несостыковки — центры никогда не уходят в минус.
async function decrementScienceCenters(vkId, count) {
  await query('UPDATE players SET science_centers = GREATEST(science_centers - $2, 0) WHERE vk_id = $1', [
    vkId,
    count,
  ]);
}

async function setScienceLimitLevel(vkId, level) {
  await query('UPDATE players SET science_limit_level = $2 WHERE vk_id = $1', [vkId, level]);
}

// ===================== ЛИМИТ ЗАВОДОВ =====================

async function setFactoryLimitLevel(vkId, level) {
  await query('UPDATE players SET factory_limit_level = $2 WHERE vk_id = $1', [vkId, level]);
}

// ===================== АТОМНЫЕ СТАНЦИИ (АЭС) =====================
// В отличие от заводов — намеренно нет decrementAtomStations: АЭС нельзя снести боевыми
// действиями (game/combat.js / game/attackResolver.js их не трогают) и нет обмена обратно,
// поэтому у игрока нет легального способа уменьшить это число.

async function addAtomStations(vkId, count) {
  await query('UPDATE players SET atom_stations = atom_stations + $2 WHERE vk_id = $1', [
    vkId,
    count,
  ]);
}

async function setAtomStationLimitLevel(vkId, level) {
  await query('UPDATE players SET atom_station_limit_level = $2 WHERE vk_id = $1', [vkId, level]);
}

async function decrementFactories(vkId, count) {
  await query('UPDATE players SET factories = GREATEST(factories - $2, 0) WHERE vk_id = $1', [
    vkId,
    count,
  ]);
}

// ===================== КУЛДАУНЫ ЗАПУСКА ОРУЖИЯ ПО КАТЕГОРИЯМ =====================

const CATEGORY_COOLDOWN_COLUMN = {
  drone: 'last_drone_attack_at',
  missile: 'last_missile_attack_at',
  nuke: 'last_nuke_attack_at',
};

async function touchCategoryAttack(vkId, category) {
  const column = CATEGORY_COOLDOWN_COLUMN[category];
  if (!column) return; // у диверсантов (saboteur) отдельного кулдауна нет
  await query(`UPDATE players SET ${column} = NOW() WHERE vk_id = $1`, [vkId]);
}

// ===================== АДМИН: ОБНУЛЕНИЕ ИГРОКА =====================
// Сбрасывает игровой прогресс (баланс, заводы, оружие, жетоны, лимиты, робота и т.п.)
// к стартовым значениям. Профиль (название государства, координаты) и членство
// в клане НЕ трогаем — это не "удаление" аккаунта, а обнуление прогресса.
async function resetPlayerProgress(vkId) {
  await query(
    `UPDATE players SET
       balance = 100,
       factories = 0,
       gold_mines = '{}',
       gold_mine_count = 0,
       destroyed_factories = 0,
       arsenal = '{}'::jsonb,
       air_defense = '{}'::jsonb,
       air_defense_damage = '{}'::jsonb,
       blocked_factories = '[]'::jsonb,
       radiation_until = NULL,
       factory_damage = 0,
       enemy_factories_destroyed = 0,
       tokens = 0,
       work_count_today = 0,
       work_session = NULL,
       inspection_count_today = 0,
       inspection_session = NULL,
       boss_launch_count_today = 0,
       boss_double_until = NULL,
       exchange_factory_count_today = 0,
       exchange_case_count_today = 0,
       exchange_science_count_today = 0,
       science_centers = 0,
       science_limit_level = 1,
       factory_limit_level = 0,
       atom_stations = 0,
       atom_station_limit_level = 1,
       robot_level = 1,
       robot_last_farm_at = NULL,
       robot_last_send_at = NULL,
       robot_last_attack_at = NULL,
       super_robot_level = 0,
       super_robot_last_attack_at = NULL,
       patrol_last_at = NULL,
       income_boost_until = NULL,
       income_boost_mult = NULL,
       shield_until = NULL,
       work_double_until = NULL,
       farm_boost_until = NULL,
       emoji_tag = NULL,
       emoji_tag_until = NULL,
       science_boost_until = NULL,
       steal_boost_until = NULL,
       patrol_boost_until = NULL,
       inspection_boost_until = NULL,
       work_bonus_attempts_today = 0,
       donate_streak = 0,
       donate_streak_date = NULL
     WHERE vk_id = $1`,
    [vkId]
  );
}

async function resetAllPlayersProgress() {
  const res = await query(
    `UPDATE players SET
       balance = 100,
       factories = 0,
       gold_mines = '{}',
       gold_mine_count = 0,
       destroyed_factories = 0,
       arsenal = '{}'::jsonb,
       air_defense = '{}'::jsonb,
       air_defense_damage = '{}'::jsonb,
       blocked_factories = '[]'::jsonb,
       radiation_until = NULL,
       factory_damage = 0,
       enemy_factories_destroyed = 0,
       tokens = 0,
       work_count_today = 0,
       work_session = NULL,
       inspection_count_today = 0,
       inspection_session = NULL,
       boss_launch_count_today = 0,
       boss_double_until = NULL,
       exchange_factory_count_today = 0,
       exchange_case_count_today = 0,
       exchange_science_count_today = 0,
       science_centers = 0,
       science_limit_level = 1,
       factory_limit_level = 0,
       atom_stations = 0,
       atom_station_limit_level = 1,
       robot_level = 1,
       robot_last_farm_at = NULL,
       robot_last_send_at = NULL,
       robot_last_attack_at = NULL,
       super_robot_level = 0,
       super_robot_last_attack_at = NULL,
       patrol_last_at = NULL,
       income_boost_until = NULL,
       income_boost_mult = NULL,
       shield_until = NULL,
       work_double_until = NULL,
       farm_boost_until = NULL,
       emoji_tag = NULL,
       emoji_tag_until = NULL,
       science_boost_until = NULL,
       steal_boost_until = NULL,
       patrol_boost_until = NULL,
       inspection_boost_until = NULL,
       work_bonus_attempts_today = 0,
       donate_streak = 0,
       donate_streak_date = NULL`
  );
  return res.rowCount;
}

module.exports = {
  getPlayer,
  getPlayersByIds,
  getPlayerByName,
  createPlayerStub,
  finalizeRegistration,
  touchLastSeen,
  updateBalance,
  setBalance,
  renamePlayer,
  addFactories,
  setArsenal,
  setAirDefense,
  setAirDefenseDamage,
  addToArsenal,
  addToAirDefense,
  setBlockedFactories,
  getPlayersWithBlockedFactories,
  setRadiationUntil,
  setClan,
  getTopByFactories,
  getFactoryRank,
  getBalanceRank,
  getTopByBalance,
  getTopByRobotLevel,
  getAllActivePlayers,
  getPlayersCount,
  getPlayersPage,
  destroyOneFactory,
  setFactoryDamage,
  addFactoryDamage,
  setLastDailyBonus,
  incrementEnemyFactoriesDestroyed,
  setRobotLevel,
  setRobotLastFarm,
  setRobotLastAttack,
  setRobotLastSend,
  setVipUntil,
  setStealProtectionUntil,
  markNewbieBoostEnded,
  incrementFactoryUpgradeLevel,
  setCasinoWinBoost,
  setMinerUntil,
  setDonateBusiness,
  setIncomeBoost,
  setShieldUntil,
  setWorkDoubleUntil,
  setFarmBoostUntil,
  setFarmProUntil,
  setMinerLevel,
  setEmojiTag,
  setScienceBoostUntil,
  setStealBoostUntil,
  setPatrolBoostUntil,
  setInspectionBoostUntil,
  setDonateStreak,
  addWorkBonusAttempts,
  setProfilePhoto,
  setProfileVideo,
  setActiveStyle,
  setStyleLocked,
  setPatrolLastAt,
  resetPatrolLastAt,
  setSuperRobotLevel,
  setSuperRobotLastAttack,
  getTopBySuperRobotLevel,

  setFarmLevel,
  setFarmTokenLevel,
  addFarmCoins,
  setFarmState,
  getTopByFarmLevel,
  getTopByScienceCenters,
  addTokens,
  addBusinessExtraSlots,
  addDonateBusinessExtraSlots,
  addEventCurrency,
  incrementWorkCount,
  resetWorkDay,
  incrementInspectionCount,
  resetInspectionDay,
  setInspectionSession,
  incrementBossLaunchCount,
  resetBossLaunchDay,
  setBossDoubleUntil,
  incrementStealCount,
  resetStealDay,
  resetStealCooldown,
  setQuestsData,
  addCareerXp,
  setCareerRank,
  incrementExchangeFactoryCount,
  incrementExchangeFactoryCountBy,
  resetExchangeFactoryDay,
  incrementExchangeCaseCount,
  resetExchangeCaseDay,
  incrementExchangeScienceCount,
  incrementExchangeScienceCountBy,
  resetExchangeScienceDay,
  incrementExchangeScienceToFactoryCount,
  resetExchangeScienceToFactoryDay,
  setWorkSession,
  addScienceCenters,
  decrementScienceCenters,
  setScienceLimitLevel,
  setFactoryLimitLevel,
  addAtomStations,
  setAtomStationLimitLevel,
  decrementFactories,
  touchCategoryAttack,
  resetPlayerProgress,
  resetAllPlayersProgress,
};
