'use strict';

const players = require('../db/players');
const atomStation = require('../game/atomStation');
const calc = require('../game/calc');
const C = require('../game/constants');
const events = require('../game/events');

async function requireRegistered(ctx) {
  const player = await players.getPlayer(ctx.senderId);
  if (!player || player.registration_step !== 'done') {
    await ctx.send('⛔ Вы ещё не зарегистрированы. Напишите старт');
    return null;
  }
  return player;
}

async function handleStatus(ctx) {
  const player = await requireRegistered(ctx);
  if (!player) return;

  const limit = calc.currentAtomStationLimit(player.atom_station_limit_level);
  const nextRow = C.ATOM_STATION_LIMIT_LEVELS.find(
    (l) => l.level === (player.atom_station_limit_level || 1) + 1
  );
  const maxPerCommand = calc.isVipActive(player)
    ? C.ATOM_STATION_BUILD_MAX_PER_COMMAND_VIP
    : C.ATOM_STATION_BUILD_MAX_PER_COMMAND;
  const buildLimitPerHour = calc.isVipActive(player)
    ? C.ATOM_STATION_BUILD_LIMIT_PER_HOUR * C.VIP_ATOM_STATION_BUILD_LIMIT_MULTIPLIER
    : C.ATOM_STATION_BUILD_LIMIT_PER_HOUR;

  let text =
    `☢️ АТОМНЫЕ СТАНЦИИ (АЭС)\n` +
    `Построено: ${player.atom_stations || 0}/${limit}\n` +
    `Доход со станции: ${C.ATOM_STATION_INCOME_PER_HOUR} вирт/час (нельзя снести)\n` +
    `Цена за штуку: ${calc.formatNumber(C.ATOM_STATION_PRICE)} вирт\n` +
    `Лимит построек: ${buildLimitPerHour} в час, максимум ${maxPerCommand} за одну команду\n\n` +
    `Постройка: аэс купить [количество]`;

  if (nextRow) {
    text += `\n📈 Расширить лимит до ${nextRow.limit}: ${calc.formatNumber(nextRow.cost)} вирт — аэс расширить`;
  } else {
    text += `\n🏆 Максимальный уровень лимита достигнут!`;
  }

  await ctx.send(text);
}

async function handleBuild(ctx, qtyArg) {
  const player = await requireRegistered(ctx);
  if (!player) return;

  const maxPerCommand = calc.isVipActive(player)
    ? C.ATOM_STATION_BUILD_MAX_PER_COMMAND_VIP
    : C.ATOM_STATION_BUILD_MAX_PER_COMMAND;

  let quantity = 1;
  if (qtyArg !== undefined && qtyArg !== null && String(qtyArg).trim() !== '') {
    const parsed = parseInt(qtyArg, 10);
    if (!Number.isInteger(parsed) || parsed < 1) {
      await ctx.send(`⛔ Некорректное количество. Формат: аэс купить [количество, максимум ${maxPerCommand}]`);
      return;
    }
    quantity = parsed;
  }
  if (quantity > maxPerCommand) {
    await ctx.send(
      `⛔ За один раз можно построить не более ${maxPerCommand} АЭС${
        calc.isVipActive(player) ? '' : ` (с VIP — до ${C.ATOM_STATION_BUILD_MAX_PER_COMMAND_VIP})`
      }.`
    );
    return;
  }

  const result = await atomStation.build(ctx.senderId, quantity);

  if (!result.ok) {
    if (result.reason === 'max_reached') {
      await ctx.send(`⛔ У вас уже максимум АЭС (${result.max}). Расширьте лимит: аэс расширить`);
    } else if (result.reason === 'build_limit') {
      await ctx.send(`⛔ Лимит постройки АЭС: не более ${result.limit} в час. Попробуйте позже.`);
    } else if (result.reason === 'not_enough_money') {
      await ctx.send(
        `⛔ Недостаточно вирт. Цена АЭС: ${calc.formatNumber(result.price)}, не хватает ${calc.formatNumber(
          result.missing
        )}.`
      );
    } else {
      await ctx.send('⛔ Не удалось построить АЭС.');
    }
    return;
  }

  let text = `☢️ Построено АЭС: ${result.built} за ${calc.formatNumber(result.totalSpent)} вирт! Доход +${calc.formatNumber(
    result.built * C.ATOM_STATION_INCOME_PER_HOUR
  )} вирт/час.`;
  if (result.stoppedEarly) {
    const stopReasons = {
      max_reached: 'достигнут максимум АЭС',
      build_limit: `лимит ${C.ATOM_STATION_BUILD_LIMIT_PER_HOUR} построек в час`,
      not_enough_money: 'закончились вирты',
    };
    text += `\n⚠️ Построено меньше запрошенного (${result.requested}): ${stopReasons[result.stoppedEarly] || 'лимит'}.`;
  }

  const drop = await events.awardDrop(ctx.senderId);
  text += events.dropSuffix(drop);

  await ctx.send(text);
}

async function handleExpand(ctx) {
  const player = await requireRegistered(ctx);
  if (!player) return;

  const result = await atomStation.expandLimit(ctx.senderId);
  if (!result.ok) {
    if (result.reason === 'max_level') {
      await ctx.send('⛔ Уже максимальный уровень лимита АЭС.');
    } else if (result.reason === 'not_enough_money') {
      await ctx.send(
        `⛔ Недостаточно вирт. Нужно ${calc.formatNumber(result.cost)}, не хватает ${calc.formatNumber(
          result.missing
        )}.`
      );
    } else {
      await ctx.send('⛔ Не удалось расширить лимит.');
    }
    return;
  }

  await ctx.send(`✅ Лимит АЭС расширен до ${result.newLimit}! Потрачено: ${calc.formatNumber(result.cost)} вирт.`);
}

module.exports = { handleStatus, handleBuild, handleExpand };
