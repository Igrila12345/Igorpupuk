'use strict';

const { query } = require('./pool');

// Добавляет посты в отслеживание (ON CONFLICT DO NOTHING — published_at не обновляется задним
// числом, чтобы не сдвигать уже идущий грейс-период, если VK вдруг вернёт тот же пост дважды).
async function upsertPosts(ownerId, posts) {
  if (!posts || !posts.length) return;
  const postIds = posts.map((p) => p.postId);
  const publishedAts = posts.map((p) => p.publishedAt);
  await query(
    `INSERT INTO community_posts (owner_id, post_id, published_at)
     SELECT $1, unnest($2::bigint[]), unnest($3::timestamptz[])
     ON CONFLICT (owner_id, post_id) DO NOTHING`,
    [ownerId, postIds, publishedAts]
  );
}

// Посты, которые ещё нужно опрашивать через likes.getList: старше грейс-периода И хотя бы у
// одного активного игрока по ним ещё нет лайка. Как только все активные игроки лайкнули —
// пост перестаёт сюда попадать (лишний трафик к VK API не тратится).
async function getPendingPosts(ownerId, gracePeriodMs, limit) {
  const res = await query(
    `SELECT cp.post_id, cp.published_at
     FROM community_posts cp
     WHERE cp.owner_id = $1
       AND cp.published_at <= NOW() - ($2 || ' milliseconds')::interval
       AND EXISTS (
         SELECT 1 FROM players p
         WHERE p.registration_step = 'done'
           AND NOT EXISTS (
             SELECT 1 FROM post_likes pl
             WHERE pl.owner_id = $1 AND pl.post_id = cp.post_id AND pl.vk_id = p.vk_id
           )
       )
     ORDER BY cp.published_at DESC
     LIMIT $3`,
    [ownerId, gracePeriodMs, limit]
  );
  return res.rows;
}

// Массово записывает лайки поста (ON CONFLICT DO NOTHING — идемпотентно, можно смело
// перезаписывать полный список при каждом опросе).
async function bulkInsertLikes(ownerId, postId, vkIds) {
  if (!vkIds || !vkIds.length) return;
  await query(
    `INSERT INTO post_likes (owner_id, post_id, vk_id)
     SELECT $1, $2, unnest($3::bigint[])
     ON CONFLICT (owner_id, post_id, vk_id) DO NOTHING`,
    [ownerId, postId, vkIds]
  );
}

// Пересчитывает like_penalty_active для ВСЕХ активных игроков одним запросом: true, если
// существует хотя бы 1 пост старше грейс-периода (и не старше windowMs, если задан — это
// настраиваемый админом интервал "за какой период учитывать посты", см. !админ лайки интервал),
// который игрок не лайкнул. windowMs = null означает "без ограничения" (учитываем все посты).
async function recomputePenalties(ownerId, gracePeriodMs, windowMs) {
  await query(
    `UPDATE players p
     SET like_penalty_active = EXISTS (
       SELECT 1 FROM community_posts cp
       WHERE cp.owner_id = $1
         AND cp.published_at <= NOW() - ($2 || ' milliseconds')::interval
         AND ($3::bigint IS NULL OR cp.published_at >= NOW() - ($3 || ' milliseconds')::interval)
         AND NOT EXISTS (
           SELECT 1 FROM post_likes pl
           WHERE pl.owner_id = $1 AND pl.post_id = cp.post_id AND pl.vk_id = p.vk_id
         )
     )
     WHERE p.registration_step = 'done'`,
    [ownerId, gracePeriodMs, windowMs || null]
  );
}

// Список непролайканных игроком постов (старше грейс-периода, в пределах windowMs если задан)
// — для команды "!лайки".
async function getUnlikedPostsForPlayer(ownerId, vkId, gracePeriodMs, windowMs) {
  const res = await query(
    `SELECT cp.post_id, cp.published_at
     FROM community_posts cp
     WHERE cp.owner_id = $1
       AND cp.published_at <= NOW() - ($2 || ' milliseconds')::interval
       AND ($4::bigint IS NULL OR cp.published_at >= NOW() - ($4 || ' milliseconds')::interval)
       AND NOT EXISTS (
         SELECT 1 FROM post_likes pl
         WHERE pl.owner_id = $1 AND pl.post_id = cp.post_id AND pl.vk_id = $3
       )
     ORDER BY cp.published_at DESC`,
    [ownerId, gracePeriodMs, vkId, windowMs || null]
  );
  return res.rows;
}

// Снимает штраф со всех игроков разом — вызывается при "!админ лайки выкл", чтобы штраф не
// "висел" на игроках до следующего пересчёта (система при выключении вообще не тикает).
async function clearAllPenalties() {
  await query(`UPDATE players SET like_penalty_active = false WHERE like_penalty_active = true`);
}

module.exports = {
  upsertPosts,
  getPendingPosts,
  bulkInsertLikes,
  recomputePenalties,
  getUnlikedPostsForPlayer,
  clearAllPenalties,
};
