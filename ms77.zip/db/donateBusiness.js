'use strict';

// CRUD для таблицы donate_businesses (см. db/schema.sql) — множественные донат-бизнесы на
// игрока, по аналогии с db/business.js (player_businesses) для обычных вирт-бизнесов.

const { query } = require('./pool');

async function listByPlayer(playerId) {
  const res = await query(
    `SELECT * FROM donate_businesses WHERE player_id = $1 ORDER BY id ASC`,
    [playerId]
  );
  return res.rows;
}

async function listActiveByPlayer(playerId) {
  const res = await query(
    `SELECT * FROM donate_businesses WHERE player_id = $1 AND until > NOW() ORDER BY id ASC`,
    [playerId]
  );
  return res.rows;
}

async function countActiveByPlayer(playerId) {
  const res = await query(
    `SELECT COUNT(*)::int AS count FROM donate_businesses WHERE player_id = $1 AND until > NOW()`,
    [playerId]
  );
  return res.rows[0].count;
}

async function getById(id) {
  const res = await query(`SELECT * FROM donate_businesses WHERE id = $1`, [id]);
  return res.rows[0] || null;
}

// Возвращает запись по id, только если она принадлежит playerId (защита от чужих id в командах)
async function getOwned(playerId, id) {
  const res = await query(
    `SELECT * FROM donate_businesses WHERE id = $1 AND player_id = $2`,
    [id, playerId]
  );
  return res.rows[0] || null;
}

async function create(playerId, tierId, until, level = 1) {
  const res = await query(
    `INSERT INTO donate_businesses (player_id, tier_id, level, until, weekly_at)
     VALUES ($1, $2, $3, $4, NOW()) RETURNING *`,
    [playerId, tierId, level, until]
  );
  return res.rows[0];
}

async function updateTierAndUntil(id, tierId, until) {
  const res = await query(
    `UPDATE donate_businesses SET tier_id = $2, until = $3 WHERE id = $1 RETURNING *`,
    [id, tierId, until]
  );
  return res.rows[0];
}

async function updateLevel(id, level) {
  const res = await query(
    `UPDATE donate_businesses SET level = $2 WHERE id = $1 RETURNING *`,
    [id, level]
  );
  return res.rows[0];
}

async function updateWeeklyAt(id, weeklyAt) {
  await query(`UPDATE donate_businesses SET weekly_at = $2 WHERE id = $1`, [id, weeklyAt]);
}

async function remove(id) {
  await query(`DELETE FROM donate_businesses WHERE id = $1`, [id]);
}

async function removeAllForPlayer(playerId) {
  await query(`DELETE FROM donate_businesses WHERE player_id = $1`, [playerId]);
}

// Все ещё действующие записи (для часового/суточного тика в game/donateBusiness.js,
// вызывается из game/scheduler.js) — без привязки к "активным за последнее время" игрокам,
// как раньше через players.getAllActivePlayers(): сама таблица уже маленькая и отфильтрована
// по until > NOW().
async function listAllActive() {
  const res = await query(`SELECT * FROM donate_businesses WHERE until > NOW()`);
  return res.rows;
}

// Все записи, включая истёкшие (нужно суточному тику, чтобы снять истёкшие и уведомить игрока)
async function listAllExpired() {
  const res = await query(`SELECT * FROM donate_businesses WHERE until <= NOW()`);
  return res.rows;
}

module.exports = {
  listByPlayer,
  listActiveByPlayer,
  countActiveByPlayer,
  getById,
  getOwned,
  create,
  updateTierAndUntil,
  updateLevel,
  updateWeeklyAt,
  remove,
  removeAllForPlayer,
  listAllActive,
  listAllExpired,
};
