'use strict';

const players = require('../db/players');
const postLikes = require('../game/postLikes');
const C = require('../game/constants');

async function handleLikes(ctx) {
  const vkId = ctx.senderId;
  const player = await players.getPlayer(vkId);
  if (!player || player.registration_step !== 'done') {
    await ctx.send('⛔ Вы ещё не зарегистрированы. Напишите !старт');
    return;
  }

  if (!postLikes.getGroupOwnerId()) {
    await ctx.send('⛔ Эта функция сейчас недоступна (не настроена на стороне сообщества).');
    return;
  }

  const unliked = await postLikes.getUnlikedPostsForPlayer(vkId);

  if (!unliked.length) {
    await ctx.send('✅ Вы лайкнули все посты сообщества. Штраф к доходу не действует.');
    return;
  }

  const penaltyPercent = Math.round(C.POST_LIKE_INCOME_PENALTY * 100);
  const lines = unliked
    .slice(0, 15)
    .map((p, i) => `${i + 1}. ${p.url}`)
    .join('\n');
  const more = unliked.length > 15 ? `\n… и ещё ${unliked.length - 15} пост(ов)` : '';

  await ctx.send(
    `⚠️ Доход снижен на ${penaltyPercent}%, пока не лайкнуты посты сообщества:\n` +
      `${lines}${more}\n\n` +
      `Лайкните их — при следующей проверке (в течение нескольких минут) доход вернётся к обычному.`
  );
}

module.exports = { handleLikes };
