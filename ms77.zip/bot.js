'use strict';

const { VK } = require('vk-io');
const shopDb = require('./db/shop');

// VK режет одно сообщение по 4096 символам (messages.send падает с ошибкой, если
// длиннее) — например, у "!админ помощь2" текст был 4313 символов, из-за чего
// messages.send кидал исключение, а пользователь видел только общее
// "Произошла ошибка при выполнении команды". Разбиваем длинный текст на несколько
// сообщений вместо того, чтобы просто падать.
const VK_MESSAGE_LIMIT = 4096;

function splitLongText(text, limit = VK_MESSAGE_LIMIT) {
  if (text.length <= limit) return [text];
  const chunks = [];
  let rest = text;
  while (rest.length > limit) {
    // Стараемся резать по границе строки/пробела, чтобы не разрывать слово или строку
    // посередине; если в пределах лимита нет удобного места — режем жёстко по лимиту.
    let cut = rest.lastIndexOf('\n', limit);
    if (cut < limit * 0.5) cut = rest.lastIndexOf(' ', limit);
    if (cut < limit * 0.5) cut = limit;
    chunks.push(rest.slice(0, cut).trimEnd());
    rest = rest.slice(cut).trimStart();
  }
  if (rest) chunks.push(rest);
  return chunks;
}

// Оборачивает context.send так, чтобы слишком длинный текст автоматически уходил
// несколькими сообщениями подряд, а не падал с ошибкой VK API. Трогаем только
// простые текстовые вызовы (ctx.send('строка') или ctx.send('строка', {...})) —
// вызовы с attachment/keyboard (объектная форма) не трогаем, чтобы не сломать
// прикреплённые фото/клавиатуры: там просто аккуратно обрежем текст.
function patchContextSend(context) {
  const originalSend = context.send.bind(context);
  context.send = async (textOrParams, params) => {
    if (typeof textOrParams === 'string') {
      const chunks = splitLongText(textOrParams);
      if (chunks.length === 1) return originalSend(textOrParams, params);
      let last;
      for (const chunk of chunks) {
        last = await originalSend(chunk, params);
      }
      return last;
    }
    if (textOrParams && typeof textOrParams === 'object' && typeof textOrParams.message === 'string') {
      if (textOrParams.message.length <= VK_MESSAGE_LIMIT) return originalSend(textOrParams, params);
      // Есть attachment/keyboard — разбивать рискованно (прикрепление уедет не туда),
      // поэтому просто аккуратно обрезаем текст, чтобы сообщение вообще ушло.
      const truncated = textOrParams.message.slice(0, VK_MESSAGE_LIMIT - 20).trimEnd() + '…';
      return originalSend({ ...textOrParams, message: truncated }, params);
    }
    return originalSend(textOrParams, params);
  };
}

class Bot {
  constructor(token) {
    this.vk = new VK({ token, apiLimit: 20 });
  }

  async notifyUser(vkId, text) {
    try {
      await this.vk.api.messages.send({
        user_id: vkId,
        message: text,
        random_id: Math.floor(Math.random() * 1e9),
      });
    } catch (err) {
      // Пользователь мог заблокировать сообщения сообщества — не критично
      console.error(`[Bot] Не удалось отправить сообщение ${vkId}:`, err.message);
    }
  }

  async sendToChat(peerId, text) {
    try {
      await this.vk.api.messages.send({
        peer_id: peerId,
        message: text,
        random_id: Math.floor(Math.random() * 1e9),
      });
    } catch (err) {
      console.error(`[Bot] Не удалось отправить сообщение в беседу ${peerId}:`, err.message);
    }
  }

  async registerChatIfNeeded(ctx) {
    // Если сообщение пришло из беседы (peer_id > 2e9), запоминаем её для глобальных логов
    if (ctx.peerId && ctx.peerId > 2000000000) {
      await shopDb.addBroadcastChat(ctx.peerId).catch(() => {});
    }
  }

  onMessage(handler) {
    this.vk.updates.on('message_new', async (context, next) => {
      try {
        context.bot = this;
        patchContextSend(context);
        await this.registerChatIfNeeded(context);
        await handler(context);
      } catch (err) {
        console.error('[Bot] Ошибка обработки сообщения:', err);
        try {
          await context.send('⛔ Произошла внутренняя ошибка. Попробуйте ещё раз позже.');
        } catch (_) {
          /* ignore */
        }
      }
      return next();
    });
  }

  async start() {
    await this.startWithRetry();
    console.log('[Bot] VK Long Poll запущен.');
  }

  // Если Long Poll обрывается (сеть, VK отдал 5xx и т.п.), не даём процессу просто затихнуть —
  // пробуем поднять соединение заново с нарастающей паузой, вместо падения всего бота.
  async startWithRetry(attempt = 1) {
    try {
      await this.vk.updates.start();
    } catch (err) {
      const delayMs = Math.min(60000, 3000 * attempt);
      console.error(
        `[Bot] Long Poll упал (попытка ${attempt}). Переподключение через ${delayMs / 1000} с.`,
        err.message
      );
      await new Promise((resolve) => setTimeout(resolve, delayMs));
      await this.startWithRetry(attempt + 1);
    }
  }
}

module.exports = Bot;
