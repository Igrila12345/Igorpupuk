'use strict';

// ===================== ГОНКА ЗАВОДОВ =====================
// Еженедельный ивент (см. C.FACTORY_RACE_* в game/constants.js): в начале цикла снимается
// "снимок" количества заводов у всех игроков и кланов, через FACTORY_RACE_CYCLE_DAYS дней
// бот сравнивает текущее количество со снимком — кто нарастил больше всех В ПРОЦЕНТАХ от
// стартового значения, тот и в топе (топ-3 отдельно среди игроков и отдельно среди кланов).
//
// Снесённые атакой заводы автоматически уменьшают итоговый прирост — никакой отдельной
// логики на этот счёт не нужно, т.к. считаем именно (текущее значение - снимок), а не сумму
// покупок за неделю.
//
// Устроено по образцу game/zoneWar.js: состояние хранится в game_meta (db/shop.js),
// maybeResolveCycle(bot) вызывается из ежедневного тика планировщика и сама решает, прошла
// ли неделя — если да, подводит итоги, награждает и тут же открывает новый цикл.

const C = require('./constants');
const calc = require('./calc');
const players = require('../db/players');
const clansDb = require('../db/clans');
const gameMeta = require('../db/shop');

const META_ENABLED = 'factory_race_enabled';
const META_STARTED_AT = 'factory_race_started_at';
const META_SNAPSHOT_PLAYERS = 'factory_race_snapshot_players';
const META_SNAPSHOT_CLANS = 'factory_race_snapshot_clans';
const META_REWARDS_PLAYER = 'factory_race_rewards_player';
const META_REWARDS_CLAN = 'factory_race_rewards_clan';

// ===================== ВКЛ/ВЫКЛ И ЦИКЛ =====================

async function isEnabled() {
  const v = await gameMeta.getMeta(META_ENABLED);
  return v === '1';
}

async function takeSnapshot() {
  const playerRows = await players.getFactoriesSnapshot();
  const playerSnapshot = {};
  for (const p of playerRows) playerSnapshot[p.vk_id] = Number(p.factories) || 0;

  const clanRows = await clansDb.getClansFactoriesSnapshot();
  const clanSnapshot = {};
  for (const c of clanRows) clanSnapshot[c.id] = Number(c.total_factories) || 0;

  await gameMeta.setMeta(META_SNAPSHOT_PLAYERS, JSON.stringify(playerSnapshot));
  await gameMeta.setMeta(META_SNAPSHOT_CLANS, JSON.stringify(clanSnapshot));
  await gameMeta.setMeta(META_STARTED_AT, new Date().toISOString());
}

// Включает гонку. Если снимка ещё нет (первый запуск) — сразу снимает его, стартуя цикл.
async function setEnabled(on) {
  await gameMeta.setMeta(META_ENABLED, on ? '1' : '0');
  if (on) {
    const started = await gameMeta.getMeta(META_STARTED_AT);
    if (!started) await takeSnapshot();
  }
}

// Принудительно начинает НОВЫЙ цикл прямо сейчас (используется админ-командой "старт" и
// автоматически после подведения итогов истёкшего цикла).
async function startNewCycle() {
  await takeSnapshot();
}

async function getCycleInfo() {
  const startedRaw = await gameMeta.getMeta(META_STARTED_AT);
  const startedAt = startedRaw ? new Date(startedRaw) : new Date();
  const endsAt = new Date(startedAt.getTime() + C.FACTORY_RACE_CYCLE_DAYS * 24 * 60 * 60 * 1000);
  return { startedAt, endsAt };
}

async function getSnapshots() {
  const rawPlayers = await gameMeta.getMeta(META_SNAPSHOT_PLAYERS);
  const rawClans = await gameMeta.getMeta(META_SNAPSHOT_CLANS);
  return {
    players: rawPlayers ? JSON.parse(rawPlayers) : {},
    clans: rawClans ? JSON.parse(rawClans) : {},
  };
}

// ===================== ПОДСЧЁТ ПРИРОСТА / РЕЙТИНГ =====================

// snapshot: {id: заводов_на_старте}, currentRows: [{id, factories, name}], minGrowth: порог
// чистого прироста в штуках. Возвращает отсортированный по проценту роста массив
// {id, name, start, current, growth, percent} — только тех, кто прошёл порог minGrowth.
function rankByGrowth(snapshot, currentRows, minGrowth) {
  const ranked = [];
  for (const row of currentRows) {
    const start = snapshot[row.id] || 0;
    const growth = row.factories - start;
    if (growth < minGrowth) continue;
    const percent = growth / Math.max(start, 1);
    ranked.push({ id: row.id, name: row.name, start, current: row.factories, growth, percent });
  }
  ranked.sort((a, b) => b.percent - a.percent || b.growth - a.growth);
  return ranked;
}

// Живой рейтинг во время активного цикла — используется командой статуса ("!гонка"),
// награды тут ещё не выдаются, это просто предпросмотр текущей расстановки.
async function getLivePlayerRanking(limit = 5) {
  const { players: snapshot } = await getSnapshots();
  const rows = await players.getFactoriesSnapshot();
  const currentRows = rows.map((r) => ({ id: r.vk_id, name: r.state_name, factories: Number(r.factories) || 0 }));
  return rankByGrowth(snapshot, currentRows, C.FACTORY_RACE_MIN_GROWTH_PLAYER).slice(0, limit);
}

async function getLiveClanRanking(limit = 5) {
  const { clans: snapshot } = await getSnapshots();
  const rows = await clansDb.getClansFactoriesSnapshot();
  const currentRows = rows.map((r) => ({ id: r.id, name: r.name, factories: Number(r.total_factories) || 0 }));
  return rankByGrowth(snapshot, currentRows, C.FACTORY_RACE_MIN_GROWTH_CLAN).slice(0, limit);
}

// Личный прогресс одного игрока (для "!гонка") — вне зависимости от того, попадает ли он в топ.
async function getPlayerProgress(vkId) {
  const { players: snapshot } = await getSnapshots();
  const player = await players.getPlayer(vkId);
  if (!player) return null;
  const start = snapshot[vkId] || 0;
  const current = Number(player.factories) || 0;
  return { start, current, growth: current - start };
}

// ===================== НАГРАДЫ (админ-конфигурируемые, по образцу game/dailyRewards.js) =====================

async function getRewardsConfig(scope) {
  const key = scope === 'clan' ? META_REWARDS_CLAN : META_REWARDS_PLAYER;
  const fallback = scope === 'clan' ? C.FACTORY_RACE_DEFAULT_REWARDS_CLAN : C.FACTORY_RACE_DEFAULT_REWARDS_PLAYER;
  const raw = await gameMeta.getMeta(key);
  if (!raw) return fallback.map((r) => ({ ...r }));
  try {
    const parsed = JSON.parse(raw);
    if (!Array.isArray(parsed) || !parsed.length) return fallback.map((r) => ({ ...r }));
    return [1, 2, 3].map((place) => parsed.find((r) => r.place === place) || fallback.find((r) => r.place === place));
  } catch {
    return fallback.map((r) => ({ ...r }));
  }
}

async function setPrize(scope, place, virts) {
  if (scope !== 'player' && scope !== 'clan') return { ok: false, reason: 'bad_scope' };
  if (![1, 2, 3].includes(place)) return { ok: false, reason: 'bad_place' };
  virts = Math.max(0, Math.floor(virts) || 0);

  const key = scope === 'clan' ? META_REWARDS_CLAN : META_REWARDS_PLAYER;
  const current = await getRewardsConfig(scope);
  const updated = current.map((r) => (r.place === place ? { place, virts } : r));
  await gameMeta.setMeta(key, JSON.stringify(updated));
  return { ok: true, prize: { place, virts } };
}

async function resetRewards(scope) {
  const key = scope === 'clan' ? META_REWARDS_CLAN : META_REWARDS_PLAYER;
  await gameMeta.setMeta(key, '');
  return getRewardsConfig(scope);
}

// ===================== ПОДВЕДЕНИЕ ИТОГОВ ЦИКЛА =====================

// force=true — админ-команда "финиш" подводит итоги немедленно, не дожидаясь конца недели.
async function resolveCycle(bot, force = false) {
  if (!force) {
    const { endsAt } = await getCycleInfo();
    if (new Date() < endsAt) return { resolved: false };
  }

  const playerRewards = await getRewardsConfig('player');
  const clanRewards = await getRewardsConfig('clan');

  const playerTop = await getLivePlayerRanking(3);
  const clanTop = await getLiveClanRanking(3);

  for (let i = 0; i < playerTop.length; i++) {
    const reward = playerRewards[i];
    if (!reward || reward.virts <= 0) continue;
    const winner = playerTop[i];
    await players.updateBalance(winner.id, reward.virts);
    if (bot) {
      await bot
        .notifyUser(
          winner.id,
          `🏁 ГОНКА ЗАВОДОВ ЗАВЕРШЕНА!\n🏆 Вы заняли ${reward.place} место среди игроков по приросту заводов за неделю (+${winner.growth} завод., ${Math.round(
            winner.percent * 100
          )}% роста)!\n💰 Награда: +${calc.formatNumber(reward.virts)} вирт.`
        )
        .catch(() => {});
    }
  }

  for (let i = 0; i < clanTop.length; i++) {
    const reward = clanRewards[i];
    if (!reward || reward.virts <= 0) continue;
    const winner = clanTop[i];
    const clan = await clansDb.getClanById(winner.id);
    if (!clan) continue;
    const maxVault = winner.current * C.CLAN_VAULT_PER_FACTORY;
    await clansDb.addVault(winner.id, reward.virts, maxVault);
    if (bot) {
      const members = await clansDb.getClanMembers(winner.id);
      for (const m of members) {
        await bot
          .notifyUser(
            m.vk_id,
            `🏁 ГОНКА ЗАВОДОВ ЗАВЕРШЕНА!\n🏆 Ваш клан «${clan.name}» занял ${reward.place} место по приросту заводов за неделю (+${winner.growth} завод., ${Math.round(
              winner.percent * 100
            )}% роста)!\n💰 В сейф клана зачислено +${calc.formatNumber(reward.virts)} вирт.`
          )
          .catch(() => {});
      }
    }
  }

  // Сразу открываем новый цикл — новый снимок берётся от ТЕКУЩЕГО состояния (уже после
  // начисления наград, но награды не меняют количество заводов, так что это не влияет на честность).
  await startNewCycle();

  return { resolved: true, playerTop, clanTop };
}

async function maybeResolveCycle(bot) {
  if (!(await isEnabled())) return { resolved: false };
  return resolveCycle(bot, false);
}

module.exports = {
  isEnabled,
  setEnabled,
  startNewCycle,
  getCycleInfo,
  getLivePlayerRanking,
  getLiveClanRanking,
  getPlayerProgress,
  getRewardsConfig,
  setPrize,
  resetRewards,
  resolveCycle,
  maybeResolveCycle,
};
