'use strict';

// Кража у топ-5 игроков (по виртам/балансу — тот же рейтинг, что и в "!топ виртов").
// Специально сбалансирована, чтобы не сносить топеров: см. комментарий к константам
// STEAL_* в game/constants.js.

const C = require('./constants');
const players = require('../db/players');
const gameDate = require('./gameDate');
const calc = require('./calc');

function msLeft(lastAt, cooldownMs) {
  if (!lastAt) return 0;
  const left = cooldownMs - (Date.now() - new Date(lastAt).getTime());
  return left > 0 ? left : 0;
}

function clamp(value, min, max) {
  return Math.max(min, Math.min(max, value));
}

// Случайно применяет бонусный дроп (наука или заводы) с жертвы на вора.
// Если у жертвы не хватает выбранного ресурса — пробуем второй вариант.
// Если и его нет — бонус пропускается (возвращаем null).
async function tryBonusDrop(attackerVkId, target) {
  // Кража больше не может красть заводы — только науку (см. правку: заводы неприкосновенны).
  if ((target.science_centers || 0) >= C.STEAL_BONUS_SCIENCE) {
    // Не выдаём науку ворюге сверх его личного лимита (иначе можно было получить
    // научные центры сверх лимита кражей, как это было возможно через аукцион).
    const attacker = await players.getPlayer(attackerVkId);
    const limit = calc.currentScienceLimit(attacker ? attacker.science_limit_level : 1);
    const room = limit - (attacker ? attacker.science_centers || 0 : 0);
    if (room <= 0) return null;

    await players.decrementScienceCenters(target.vk_id, C.STEAL_BONUS_SCIENCE);
    await players.addScienceCenters(attackerVkId, C.STEAL_BONUS_SCIENCE);
    return { type: 'science', amount: C.STEAL_BONUS_SCIENCE };
  }
  return null;
}

async function attemptSteal(attackerVkId, targetVkId) {
  if (String(attackerVkId) === String(targetVkId)) {
    return { ok: false, reason: 'self' };
  }

  const attacker = await players.getPlayer(attackerVkId);
  if (!attacker || attacker.registration_step !== 'done') {
    return { ok: false, reason: 'not_registered' };
  }

  const target = await players.getPlayer(targetVkId);
  if (!target || target.registration_step !== 'done') {
    return { ok: false, reason: 'target_not_registered' };
  }

  const rank = await players.getBalanceRank(targetVkId);
  if (!rank || rank > C.STEAL_TOP_N) {
    return { ok: false, reason: 'not_top', topN: C.STEAL_TOP_N };
  }

  const today = gameDate.todayStr();
  let dayCount = attacker.steal_count_today || 0;
  if (attacker.steal_day && String(attacker.steal_day).slice(0, 10) !== today) {
    // Раньше сброс дня учитывался только в локальной переменной dayCount (для проверки
    // лимита ниже), но никогда не писался в БД — resetStealDay существовал, но нигде не
    // вызывался. incrementStealCount() ниже всегда делает steal_count_today + 1 к СТАРОМУ
    // значению из БД, поэтому счётчик не обнулялся по факту никогда: на второй день лимит
    // "не обновлялся", т.к. накопленное вчера продолжало расти. Обнуляем в БД сразу здесь,
    // как это уже делает game/inspection.js: ensureDayReset().
    await players.resetStealDay(attackerVkId, today);
    dayCount = 0;
  }

  const left = msLeft(attacker.last_steal_at, C.STEAL_COOLDOWN_MS);
  if (left > 0) {
    return { ok: false, reason: 'cooldown', msLeft: left };
  }

  if (dayCount >= C.STEAL_DAILY_LIMIT) {
    return { ok: false, reason: 'daily_limit', limit: C.STEAL_DAILY_LIMIT };
  }

  const targetBalance = Number(target.balance) || 0;
  const rawAmount = targetBalance * C.STEAL_PERCENT_OF_BALANCE;
  const stolen = Math.min(
    targetBalance,
    Math.round(clamp(rawAmount, C.STEAL_MIN_AMOUNT, C.STEAL_MAX_AMOUNT))
  );

  if (stolen <= 0) {
    return { ok: false, reason: 'target_broke' };
  }

  // 🍀 Донат-бафф: x2 доля атакующего от украденного, пока активен steal_boost_until (см.
  // game/donateBuffs.js: grantStealBoost, DONATE_STEAL_BOOST_* в constants.js). Сумма, снятая
  // с жертвы (stolen), от этого баффа НЕ меняется — увеличивается только доля вора.
  const stealBoosted = calc.isStealBoostActive(attacker);
  const shareMult = stealBoosted ? C.DONATE_STEAL_BOOST_MULTIPLIER : 1;
  const attackerGain = Math.round(stolen * C.STEAL_ATTACKER_SHARE * shareMult);

  await players.updateBalance(targetVkId, -stolen);
  if (attackerGain > 0) {
    await players.updateBalance(attackerVkId, attackerGain);
  }

  const newCount = await players.incrementStealCount(attackerVkId, today);

  let bonus = null;
  if (newCount % C.STEAL_BONUS_EVERY === 0) {
    const freshTarget = await players.getPlayer(targetVkId);
    bonus = await tryBonusDrop(attackerVkId, freshTarget);
  }

  return {
    ok: true,
    stolen,
    attackerGain,
    bonus,
    stealsToday: newCount,
    dailyLimit: C.STEAL_DAILY_LIMIT,
    targetId: target.vk_id,
    targetName: target.state_name,
    attackerId: attacker.vk_id,
    attackerName: attacker.state_name,
    stealBoosted,
  };
}

module.exports = { attemptSteal };
