'use strict';

// ===================== НАСТРАИВАЕМЫЕ ЕЖЕДНЕВНЫЕ ПРИЗЫ =====================
//
// Раньше призы за топ-3 (топ заводов) были зашиты намертво в C.DAILY_FACTORY_REWARDS —
// поменять их мог только разработчик правкой кода. Этот модуль хранит призы в game_meta
// (JSON), чтобы админ мог менять их командой в игре: вирты + ЛЮБОЕ оружие из C.WEAPONS +
// количество, на каждое из 3 мест отдельно. Если конфиг не задан — используются дефолтные
// значения из C.DAILY_FACTORY_REWARDS, так что ничего не ломается на старых серверах.

const C = require('./constants');
const gameMeta = require('../db/shop');

const META_KEY = 'daily_factory_rewards_config';

// Возвращает массив вида [{place, virts, weapon, qty}, ...] длиной до 3.
// weapon может быть null — тогда за это место выдаются только вирты, без оружия.
async function getConfig() {
  const raw = await gameMeta.getMeta(META_KEY);
  if (!raw) return defaultConfig();
  try {
    const parsed = JSON.parse(raw);
    if (!Array.isArray(parsed) || !parsed.length) return defaultConfig();
    return [1, 2, 3].map((place) => {
      const found = parsed.find((r) => r.place === place);
      const fallback = C.DAILY_FACTORY_REWARDS.find((r) => r.place === place) || {
        place,
        virts: 0,
        weapon: null,
        qty: 0,
      };
      return found || fallback;
    });
  } catch {
    return defaultConfig();
  }
}

function defaultConfig() {
  return C.DAILY_FACTORY_REWARDS.map((r) => ({ ...r }));
}

// place: 1|2|3, virts: число >= 0, weaponKey: ключ из C.WEAPONS либо null (только вирты), qty: число >= 0
async function setPrize(place, virts, weaponKey, qty) {
  if (![1, 2, 3].includes(place)) return { ok: false, reason: 'bad_place' };
  virts = Math.max(0, Math.floor(virts) || 0);
  qty = Math.max(0, Math.floor(qty) || 0);

  let weapon = null;
  if (weaponKey) {
    const match = Object.keys(C.WEAPONS).find((k) => k.toLowerCase() === String(weaponKey).toLowerCase());
    if (!match) return { ok: false, reason: 'unknown_weapon' };
    weapon = match;
  }
  if (weapon && qty <= 0) qty = 1; // если указали оружие, но забыли кол-во — по умолчанию 1

  const current = await getConfig();
  const updated = current.map((r) => (r.place === place ? { place, virts, weapon, qty: weapon ? qty : 0 } : r));
  await gameMeta.setMeta(META_KEY, JSON.stringify(updated));
  return { ok: true, prize: { place, virts, weapon, qty: weapon ? qty : 0 } };
}

async function resetToDefault() {
  await gameMeta.setMeta(META_KEY, '');
  return defaultConfig();
}

function findWeaponKey(arg) {
  if (!arg) return null;
  const match = Object.keys(C.WEAPONS).find((k) => k.toLowerCase() === String(arg).toLowerCase());
  return match || null;
}

module.exports = {
  getConfig,
  setPrize,
  resetToDefault,
  findWeaponKey,
};
