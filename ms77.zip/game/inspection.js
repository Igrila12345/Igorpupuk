'use strict';

const C = require('./constants');
const calc = require('./calc');
const players = require('../db/players');
const inspectionGame = require('./inspectionGame');
const gameDate = require('./gameDate');

// "Инспекция" — вторая, полностью самостоятельная мини-игра наравне с "работой":
// свой дневной лимит, свой кулдаун, своя сессия — не делит попытки с "работой".
// Награда — ВИРТЫ (в "работе" — жетоны), чтобы это была отдельная ветка дохода,
// а не то же самое другими словами. Механика сложнее: нужно найти "аномальный"
// (развёрнутый) значок в сетке, а не просто прикинуть, где значков больше.

function dailyLimit() {
  return C.INSPECTION_MAX_PER_DAY;
}

async function ensureDayReset(player) {
  const today = gameDate.todayStr();
  const storedDay = player.inspection_day ? String(player.inspection_day).slice(0, 10) : null;
  if (storedDay !== today) {
    await players.resetInspectionDay(player.vk_id, today);
    player.inspection_count_today = 0;
    player.inspection_day = today;
  }
  return player;
}

// Выбирает случайный тип награды за пройденную инспекцию (вирты/заводы/наука) согласно
// весам C.INSPECTION_REWARDS (см. constants.js) — та же схема, что и в game/warehouse.js.
function rollReward() {
  const roll = Math.random() * 100;
  let cumulative = 0;
  for (const reward of C.INSPECTION_REWARDS) {
    cumulative += reward.chance;
    if (roll < cumulative) return reward;
  }
  return C.INSPECTION_REWARDS[0];
}

function buildSession(round, roundNumber) {
  return {
    round: roundNumber,
    size: round.size,
    anomalyIndex: round.anomalyIndex,
    expiresAt: new Date(Date.now() + C.INSPECTION_ROUND_TIMEOUT_MS).toISOString(),
  };
}

async function startInspection(vkId) {
  let player = await players.getPlayer(vkId);
  if (!player) return { ok: false, reason: 'not_registered' };

  player = await ensureDayReset(player);

  if (player.inspection_session) {
    const session = player.inspection_session;
    const expired = session.expiresAt && new Date(session.expiresAt) < new Date();
    if (!expired) {
      const attemptsLeft = Math.max(0, dailyLimit() - (player.inspection_count_today || 0));
      return { ok: true, resumed: true, session, attemptsLeft, dailyLimitToday: dailyLimit() };
    }
    await players.setInspectionSession(vkId, null);
  }

  if ((player.inspection_count_today || 0) >= dailyLimit()) {
    return { ok: false, reason: 'daily_limit', attemptsLeft: 0, dailyLimitToday: dailyLimit() };
  }

  if (player.last_inspection_time) {
    const elapsed = Date.now() - new Date(player.last_inspection_time).getTime();
    if (elapsed < C.INSPECTION_COOLDOWN_MS) {
      return { ok: false, reason: 'cooldown', remainingMs: C.INSPECTION_COOLDOWN_MS - elapsed };
    }
  }

  const round = inspectionGame.generateRound();
  const session = buildSession(round, 1);

  await players.incrementInspectionCount(vkId, gameDate.todayStr());
  await players.setInspectionSession(vkId, session);

  const attemptsLeft = dailyLimit() - ((player.inspection_count_today || 0) + 1);

  return { ok: true, resumed: false, session, attemptsLeft, dailyLimitToday: dailyLimit() };
}

async function pickCell(vkId, cellIndex, expectedRound) {
  const player = await players.getPlayer(vkId);
  if (!player) return { ok: false, reason: 'not_registered' };

  const attemptsLeft = Math.max(0, dailyLimit() - (player.inspection_count_today || 0));
  const dailyLimitToday = dailyLimit();

  const session = player.inspection_session;
  if (!session || Number(session.round) !== Number(expectedRound)) {
    return { ok: false, reason: 'no_session' };
  }

  if (session.expiresAt && new Date(session.expiresAt) < new Date()) {
    await players.setInspectionSession(vkId, null);
    return { ok: false, reason: 'timeout', attemptsLeft, dailyLimitToday };
  }

  if (!Number.isInteger(cellIndex) || cellIndex < 0 || cellIndex >= session.size) {
    return { ok: false, reason: 'invalid_cell' };
  }

  if (cellIndex !== session.anomalyIndex) {
    await players.setInspectionSession(vkId, null);
    return { ok: false, reason: 'wrong', attemptsLeft, dailyLimitToday };
  }

  if (session.round >= C.INSPECTION_ROUNDS) {
    await players.setInspectionSession(vkId, null);

    // VIP удваивает награду за инспекцию (см. C.VIP_WORK_INSPECTION_BONUS_MULTIPLIER).
    // 🔍 Донат-бафф x2 (см. DONATE_INSPECTION_BOOST_*) СТАКУЕТСЯ с VIP — множители перемножаются.
    const vip = calc.isVipActive(player);
    const inspectionBoosted = calc.isInspectionBoostActive(player);
    const mult =
      (vip ? C.VIP_WORK_INSPECTION_BONUS_MULTIPLIER : 1) *
      (inspectionBoosted ? C.DONATE_INSPECTION_BOOST_MULTIPLIER : 1);

    let reward = rollReward();
    let rewardType = reward.type;
    let qty = reward.min === reward.max ? reward.min : calc.randomInt(reward.min, reward.max);

    // Наука — редкая и ограниченная награда: нельзя выдать сверх личного лимита научных
    // центров игрока (тот же принцип, что и в game/steal.js: tryBonusDrop). Если места нет —
    // подменяем награду на вирты, чтобы попытка не пропадала впустую.
    if (rewardType === 'science') {
      const limit = calc.currentScienceLimit(player.science_limit_level);
      const room = limit - (player.science_centers || 0);
      if (room <= 0) {
        rewardType = 'virts';
        qty = calc.randomInt(C.INSPECTION_VIRTS_MIN, C.INSPECTION_VIRTS_MAX);
      } else {
        qty = Math.min(qty, room);
      }
    }

    qty *= mult;

    let virts = 0;
    let factories = 0;
    let science = 0;
    let totalBalance = player.balance || 0;
    let totalFactories = player.factories || 0;
    let totalScience = player.science_centers || 0;

    if (rewardType === 'virts') {
      virts = qty;
      totalBalance = await players.updateBalance(vkId, qty);
    } else if (rewardType === 'factory') {
      factories = qty;
      const updated = await players.addFactories(vkId, qty, false);
      totalFactories = updated ? updated.factories : totalFactories + qty;
    } else if (rewardType === 'science') {
      science = qty;
      await players.addScienceCenters(vkId, qty);
      totalScience += qty;
    }

    return {
      ok: true,
      status: 'completed',
      rewardType,
      qty,
      virts,
      factories,
      science,
      vip,
      inspectionBoosted,
      totalBalance,
      totalFactories,
      totalScience,
      attemptsLeft,
      dailyLimitToday,
    };
  }

  const round = inspectionGame.generateRound();
  const nextSession = buildSession(round, session.round + 1);
  await players.setInspectionSession(vkId, nextSession);

  return { ok: true, status: 'next_round', session: nextSession, attemptsLeft, dailyLimitToday };
}

async function getStatus(vkId) {
  let player = await players.getPlayer(vkId);
  if (!player) return { ok: false, reason: 'not_registered' };

  player = await ensureDayReset(player);

  const attemptsUsed = player.inspection_count_today || 0;
  const dailyLimitToday = dailyLimit();
  const attemptsLeft = Math.max(0, dailyLimitToday - attemptsUsed);

  let activeRound = null;
  if (player.inspection_session) {
    const session = player.inspection_session;
    const expired = session.expiresAt && new Date(session.expiresAt) < new Date();
    if (!expired) activeRound = session.round;
  }

  return { ok: true, attemptsUsed, attemptsLeft, dailyLimitToday, activeRound, balance: player.balance || 0 };
}

module.exports = { startInspection, pickCell, getStatus };
