'use strict';

const { parentPort } = require('worker_threads');

const renderers = {
  inspection: require('./inspectionRender'),
  work: require('./workRender'),
  zoneMap: require('./zoneMapRender'),
};

parentPort.on('message', async (msg) => {
  const { id, kind, session } = msg;
  try {
    const renderer = renderers[kind];
    if (!renderer) throw new Error(`Unknown render kind: ${kind}`);
    const buffer =
      kind === 'zoneMap' ? await renderer.renderMap(session.zones, session.cycleInfo) : await renderer.renderRound(session);
    // Buffer передаётся как ArrayBuffer с transfer — без копирования между потоками.
    const ab = buffer.buffer.slice(buffer.byteOffset, buffer.byteOffset + buffer.byteLength);
    parentPort.postMessage({ id, ok: true, buffer: ab }, [ab]);
  } catch (err) {
    parentPort.postMessage({ id, ok: false, error: err && err.message ? err.message : String(err) });
  }
});
