'use strict';

require('dotenv').config();

const { initSchema } = require('./db/pool');
const Bot = require('./bot');
const { dispatch } = require('./handlers/dispatcher');
const scheduler = require('./game/scheduler');

// Ошибки, вылетевшие мимо всех try/catch (например, из cron-задачи или из глубины vk-io),
// не должны положить процесс молча. Логируем максимум деталей и завершаемся управляемо —
// внешний супервизор (pm2 / run-forever.sh / systemd) сразу поднимет процесс заново.
// Продолжать работу после uncaughtException небезопасно (состояние может быть повреждено),
// поэтому это не "проглатывание" ошибки, а контролируемый быстрый рестарт вместо зависания.
process.on('unhandledRejection', (reason) => {
  console.error('[Fatal] Необработанный Promise-reject:', reason);
});

process.on('uncaughtException', (err) => {
  console.error('[Fatal] Необработанное исключение:', err);
  process.exit(1);
});

function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

// Повторяем попытку подключения к БД при старте вместо мгновенного падения —
// полезно, если Postgres поднимается позже бота (например, оба в докере/на одном сервере).
async function initSchemaWithRetry(maxAttempts = 10) {
  let attempt = 0;
  for (;;) {
    attempt += 1;
    try {
      await initSchema();
      return;
    } catch (err) {
      if (attempt >= maxAttempts) throw err;
      const delayMs = Math.min(30000, 2000 * attempt);
      console.error(
        `[Init] Не удалось подключиться к БД (попытка ${attempt}/${maxAttempts}). Повтор через ${delayMs / 1000} с.`,
        err.message
      );
      await sleep(delayMs);
    }
  }
}

async function main() {
  if (!process.env.VK_TOKEN) {
    throw new Error('Не задан VK_TOKEN в переменных окружения (.env)');
  }
  if (!process.env.DATABASE_URL) {
    throw new Error('Не задан DATABASE_URL в переменных окружения (.env)');
  }
  if (!process.env.VK_GROUP_ID) {
    // Не бросаем исключение — бот вполне может работать и без этого (штраф за нелайкнутые
    // посты просто выключится сам, см. game/postLikes.js: getGroupOwnerId), но предупреждаем,
    // т.к. по умолчанию README ожидает, что переменная задана.
    console.error(
      '[Init] Не задан VK_GROUP_ID в переменных окружения (.env) — штраф за нелайкнутые посты сообщества работать не будет.'
    );
  }

  console.log('[Init] Инициализация базы данных...');
  await initSchemaWithRetry();

  console.log('[Init] Восстановление состояния (магазин и т.д.)...');
  await scheduler.bootstrapState();

  const bot = new Bot(process.env.VK_TOKEN);
  bot.onMessage(dispatch);

  console.log('[Init] Первичная синхронизация лайков постов сообщества...');
  await scheduler.bootstrapPostLikes(bot);

  scheduler.startScheduler(bot);

  await bot.start();
  console.log('[Init] Бот запущен и готов к работе.');
}

main().catch((err) => {
  console.error('[Fatal] Не удалось запустить бота:', err);
  process.exit(1);
});
