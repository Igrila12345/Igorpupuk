'use strict';

const Jimp = require('jimp');
const C = require('./constants');
const R = require('./renderUtils');
const calc = require('./calc');

// Символы рисуются простыми геометрическими фигурами (не эмодзи!) — растровый шрифт
// проекта (assets/fonts) содержит только латиницу/кириллицу и отфильтрованный набор
// символов, цветные эмодзи-глифы (🍒🍋🔔⭐💎7️⃣) он не отрисует (см. renderUtils.js:
// sanitizeText). Тот же приём, что и с иконкой завода в workRender.js — просто кружок/
// фигура нужного цвета вместо картинки.
const REEL_W = 170;
const REEL_H = 170;
const REEL_GAP = 24;
const MARGIN_SIDE = 30;
const HEADER_HEIGHT = 74;
const PADDING_TOP = 26;
const FOOTER_HEIGHT = 64;
const BORDER = 3;
const CORNER_RADIUS = 16;
const SYMBOL_SIZE = 96;

const MARGIN_TOP = HEADER_HEIGHT + PADDING_TOP;

const symbolIconCache = new Map();

// Рисует символ как фигуру size x size с прозрачным фоном (кешируется по ключу символа —
// фигур всего 6, дешевле нарисовать один раз и переиспользовать, как factoryIcon в
// workRender.js).
function buildSymbolIcon(sym, size) {
  const icon = new Jimp(size, size, 0x00000000);
  const cx = size / 2;
  const cy = size / 2;

  switch (sym.key) {
    case 'cherry': {
      // два кружка рядом — стилизованная "вишня"
      const r = size * 0.22;
      drawCircle(icon, cx - r * 0.9, cy + r * 0.5, r, sym.color);
      drawCircle(icon, cx + r * 0.9, cy + r * 0.5, r, sym.color);
      break;
    }
    case 'lemon': {
      drawEllipse(icon, cx, cy, size * 0.34, size * 0.24, sym.color);
      break;
    }
    case 'bell': {
      drawCircle(icon, cx, cy - size * 0.05, size * 0.32, sym.color);
      drawRect(icon, cx - size * 0.22, cy + size * 0.18, size * 0.44, size * 0.1, sym.color);
      break;
    }
    case 'star': {
      drawStar(icon, cx, cy, size * 0.4, size * 0.17, sym.color);
      break;
    }
    case 'diamond': {
      drawDiamond(icon, cx, cy, size * 0.36, sym.color);
      break;
    }
    case 'seven': {
      drawRect(icon, cx - size * 0.3, cy - size * 0.34, size * 0.6, size * 0.14, sym.color);
      drawRect(icon, cx + size * 0.02, cy - size * 0.34, size * 0.16, size * 0.68, sym.color);
      break;
    }
    default:
      drawCircle(icon, cx, cy, size * 0.3, sym.color);
  }
  return icon;
}

function setPx(icon, x, y, color) {
  const w = icon.bitmap.width;
  const h = icon.bitmap.height;
  const ix = Math.round(x);
  const iy = Math.round(y);
  if (ix < 0 || iy < 0 || ix >= w || iy >= h) return;
  icon.setPixelColor(color, ix, iy);
}

function drawCircle(icon, cx, cy, r, color) {
  const r2 = r * r;
  for (let y = Math.floor(cy - r); y <= Math.ceil(cy + r); y++) {
    for (let x = Math.floor(cx - r); x <= Math.ceil(cx + r); x++) {
      const dx = x - cx;
      const dy = y - cy;
      if (dx * dx + dy * dy <= r2) setPx(icon, x, y, color);
    }
  }
}

function drawEllipse(icon, cx, cy, rx, ry, color) {
  for (let y = Math.floor(cy - ry); y <= Math.ceil(cy + ry); y++) {
    for (let x = Math.floor(cx - rx); x <= Math.ceil(cx + rx); x++) {
      const dx = (x - cx) / rx;
      const dy = (y - cy) / ry;
      if (dx * dx + dy * dy <= 1) setPx(icon, x, y, color);
    }
  }
}

function drawRect(icon, x0, y0, w, h, color) {
  for (let y = Math.floor(y0); y <= Math.ceil(y0 + h); y++) {
    for (let x = Math.floor(x0); x <= Math.ceil(x0 + w); x++) {
      setPx(icon, x, y, color);
    }
  }
}

function drawDiamond(icon, cx, cy, r, color) {
  for (let y = Math.floor(cy - r); y <= Math.ceil(cy + r); y++) {
    for (let x = Math.floor(cx - r); x <= Math.ceil(cx + r); x++) {
      const dx = Math.abs(x - cx) / r;
      const dy = Math.abs(y - cy) / r;
      if (dx + dy <= 1) setPx(icon, x, y, color);
    }
  }
}

function drawStar(icon, cx, cy, outerR, innerR, color) {
  const points = [];
  for (let i = 0; i < 10; i++) {
    const r = i % 2 === 0 ? outerR : innerR;
    const angle = (Math.PI / 5) * i - Math.PI / 2;
    points.push({ x: cx + r * Math.cos(angle), y: cy + r * Math.sin(angle) });
  }
  // Простая заливка звезды через "четно-нечетное" правило по всем пикселям bbox —
  // фигура маленькая (≤~100px), так что это дёшево и не требует полноценного полигон-фила.
  const minX = Math.floor(cx - outerR);
  const maxX = Math.ceil(cx + outerR);
  const minY = Math.floor(cy - outerR);
  const maxY = Math.ceil(cy + outerR);
  for (let y = minY; y <= maxY; y++) {
    for (let x = minX; x <= maxX; x++) {
      if (pointInPolygon(x + 0.5, y + 0.5, points)) setPx(icon, x, y, color);
    }
  }
}

function pointInPolygon(x, y, points) {
  let inside = false;
  for (let i = 0, j = points.length - 1; i < points.length; j = i++) {
    const xi = points[i].x;
    const yi = points[i].y;
    const xj = points[j].x;
    const yj = points[j].y;
    const intersect = yi > y !== yj > y && x < ((xj - xi) * (y - yi)) / (yj - yi) + xi;
    if (intersect) inside = !inside;
  }
  return inside;
}

function getSymbolIcon(sym) {
  if (!symbolIconCache.has(sym.key)) {
    symbolIconCache.set(sym.key, buildSymbolIcon(sym, SYMBOL_SIZE));
  }
  return symbolIconCache.get(sym.key);
}

// session: { bet, win, matchType, reels: [symbol, symbol, symbol], balance }
async function renderSpin(session) {
  const width = MARGIN_SIDE * 2 + REEL_W * 3 + REEL_GAP * 2;
  const height = MARGIN_TOP + REEL_H + FOOTER_HEIGHT;

  const [image, { fontTitle, fontLabel }] = await Promise.all([R.buildBackground(width, height), R.getFonts()]);

  R.drawHeader(image, width, HEADER_HEIGHT, '🎰 КАЗИНО — СЛОТЫ', fontTitle);

  for (let i = 0; i < 3; i++) {
    const x = MARGIN_SIDE + i * (REEL_W + REEL_GAP);
    const y = MARGIN_TOP;
    const won = session.matchType !== 'none';
    const cellColor = won ? 0x2c3a2eff : R.PALETTE.cell;
    const borderColor = won ? 0x66bb6aff : R.PALETTE.cellBorder;

    R.drawCardWithShadow(image, x, y, REEL_W, REEL_H, cellColor, CORNER_RADIUS);
    R.drawFrame(image, x, y, REEL_W, REEL_H, BORDER, borderColor);

    const icon = getSymbolIcon(session.reels[i]);
    const ix = x + Math.round((REEL_W - SYMBOL_SIZE) / 2);
    const iy = y + Math.round((REEL_H - SYMBOL_SIZE) / 2);
    image.composite(icon, ix, iy);
  }

  const footerY = MARGIN_TOP + REEL_H + 12;
  const resultLine =
    session.win > 0
      ? `✅ Выигрыш: +${calc.formatNumber(session.win)} вирт (ставка ${calc.formatNumber(session.bet)})`
      : `❌ Проигрыш: -${calc.formatNumber(session.bet)} вирт`;
  R.printBoxed(image, fontLabel, MARGIN_SIDE, footerY, width - MARGIN_SIDE * 2, 28, resultLine, Jimp.HORIZONTAL_ALIGN_CENTER);
  R.printBoxed(
    image,
    fontLabel,
    MARGIN_SIDE,
    footerY + 28,
    width - MARGIN_SIDE * 2,
    24,
    `Баланс: ${calc.formatNumber(session.balance)} вирт`,
    Jimp.HORIZONTAL_ALIGN_CENTER
  );

  return image.getBufferAsync(Jimp.MIME_PNG);
}

module.exports = { renderSpin };
