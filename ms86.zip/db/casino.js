'use strict';

const { query } = require('./pool');

// Пишем каждую прокрутку слотов отдельной строкой — это и лог для дебага/анти-фрода,
// и источник данных для топа (см. getTopWinners).
async function insertSpin(vkId, bet, win, reels) {
  const net = win - bet;
  await query(
    'INSERT INTO casino_spins (vk_id, bet, win, net, reels) VALUES ($1, $2, $3, $4, $5)',
    [vkId, bet, win, net, reels]
  );
}

// day/week/month — календарные периоды по МСК (как и остальные дневные сбросы в игре, см.
// game/gameDate.js), а не скользящее окно "последние 24ч" — так "топ за день" ведёт себя
// предсказуемо и обнуляется ровно в полночь МСК, а не "плывёт" ежесекундно.
// date_trunc(unit, now() AT TIME ZONE 'Europe/Moscow') AT TIME ZONE 'Europe/Moscow' —
// стандартный приём: сначала переводим "сейчас" в наивное московское время, обрезаем его
// до границы периода, затем интерпретируем обратно как московское время и получаем
// корректный timestamptz границы периода в UTC.
const PERIOD_UNITS = { day: 'day', week: 'week', month: 'month' };

// Топ по суммарным ВЫИГРЫШАМ (не по чистому балансу с казино!). Это осознанный выбор по
// ТЗ: если игрок выиграл 1000, а затем проиграл 500 — в топе должно остаться 1000, а не
// 500 и тем более не -500. SUM(win) по определению может только расти во времени (win >= 0
// в каждой строке), проигрыши на неё не влияют вообще — ровно то поведение, которое нужно.
async function getTopWinners(period, limit = 10) {
  if (period === 'all') {
    const res = await query(
      `SELECT cs.vk_id, p.state_name, SUM(cs.win)::BIGINT AS total_win
       FROM casino_spins cs
       JOIN players p ON p.vk_id = cs.vk_id
       WHERE cs.win > 0
       GROUP BY cs.vk_id, p.state_name
       ORDER BY total_win DESC
       LIMIT $1`,
      [limit]
    );
    return res.rows;
  }

  const unit = PERIOD_UNITS[period];
  if (!unit) throw new Error(`Unknown casino top period: ${period}`);

  const res = await query(
    `SELECT cs.vk_id, p.state_name, SUM(cs.win)::BIGINT AS total_win
     FROM casino_spins cs
     JOIN players p ON p.vk_id = cs.vk_id
     WHERE cs.win > 0
       AND cs.created_at >= (date_trunc($1, now() AT TIME ZONE 'Europe/Moscow') AT TIME ZONE 'Europe/Moscow')
     GROUP BY cs.vk_id, p.state_name
     ORDER BY total_win DESC
     LIMIT $2`,
    [unit, limit]
  );
  return res.rows;
}

// Личная статистика игрока по казино (для "!казино" без аргументов) — сколько всего
// прокруток, сколько поставлено/выиграно всего и сегодня, чистый итог (для честности
// показываем и его, хотя в топе он не участвует).
async function getPlayerStats(vkId) {
  const totalRes = await query(
    `SELECT COUNT(*)::INT AS spins,
            COALESCE(SUM(bet), 0)::BIGINT AS total_bet,
            COALESCE(SUM(win), 0)::BIGINT AS total_win,
            COALESCE(SUM(net), 0)::BIGINT AS total_net
     FROM casino_spins
     WHERE vk_id = $1`,
    [vkId]
  );
  const todayRes = await query(
    `SELECT COALESCE(SUM(win), 0)::BIGINT AS today_win,
            COALESCE(SUM(bet), 0)::BIGINT AS today_bet
     FROM casino_spins
     WHERE vk_id = $1
       AND created_at >= (date_trunc('day', now() AT TIME ZONE 'Europe/Moscow') AT TIME ZONE 'Europe/Moscow')`,
    [vkId]
  );
  return { ...totalRes.rows[0], ...todayRes.rows[0] };
}

// Топ-3 (и вообще топ-N) за ПРОШЕДШИЕ сутки по МСК — используется только для выдачи
// ежедневной награды казино в момент срабатывания крон-джобы 00:00 МСК (см.
// game/casino.js: distributeDailyRewards). В отличие от getTopWinners('day'), который в
// момент вызова РОВНО в 00:00 МСК посчитал бы уже наступивший (пустой) новый день, эта
// функция явно берёт окно [вчера 00:00 МСК; сегодня 00:00 МСК) — то есть ровно те сутки,
// за которые нужно наградить победителей.
async function getTopWinnersForPreviousDay(limit = 3) {
  const res = await query(
    `SELECT cs.vk_id, p.state_name, SUM(cs.win)::BIGINT AS total_win
     FROM casino_spins cs
     JOIN players p ON p.vk_id = cs.vk_id
     WHERE cs.win > 0
       AND cs.created_at >= (date_trunc('day', (now() AT TIME ZONE 'Europe/Moscow') - interval '1 day') AT TIME ZONE 'Europe/Moscow')
       AND cs.created_at < (date_trunc('day', now() AT TIME ZONE 'Europe/Moscow') AT TIME ZONE 'Europe/Moscow')
     GROUP BY cs.vk_id, p.state_name
     ORDER BY total_win DESC
     LIMIT $1`,
    [limit]
  );
  return res.rows;
}

module.exports = { insertSpin, getTopWinners, getPlayerStats, getTopWinnersForPreviousDay };
