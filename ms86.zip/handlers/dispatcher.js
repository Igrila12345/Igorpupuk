'use strict';

const parse = require('../utils/parse');
const profile = require('./profile');
const economyHandlers = require('./economyHandlers');
const productionHandlers = require('./productionHandlers');
const shopHandlers = require('./shopHandlers');
const combatHandlers = require('./combatHandlers');
const clanHandlers = require('./clanHandlers');
const ratingHandlers = require('./ratingHandlers');
const adminHandlers = require('./adminHandlers');
const robotHandlers = require('./robotHandlers');
const superRobotHandlers = require('./superRobotHandlers');
const minerHandlers = require('./minerHandlers');
const farmHandlers = require('./farmHandlers');
const businessHandlers = require('./businessHandlers');
const zoneHandlers = require('./zoneHandlers');
const raceHandlers = require('./raceHandlers');
const workHandlers = require('./workHandlers');
const inspectionHandlers = require('./inspectionHandlers');
const warehouseHandlers = require('./warehouseHandlers');
const scienceHandlers = require('./scienceHandlers');
const limitHandlers = require('./limitHandlers');
const auctionHandlers = require('./auctionHandlers');
const promoHandlers = require('./promoHandlers');
const donateHandlers = require('./donateHandlers');
const patrolHandlers = require('./patrolHandlers');
const eventHandlers = require('./eventHandlers');
const bossHandlers = require('./bossHandlers');
const styleHandlers = require('./styleHandlers');
const stealHandlers = require('./stealHandlers');
const questHandlers = require('./questHandlers');
const likeHandlers = require('./likeHandlers');
const casinoHandlers = require('./casinoHandlers');
const players = require('../db/players');
const C = require('../game/constants');
const images = require('../game/commandImages');

// Кулдаун между командами одного игрока (в памяти процесса)
const lastCommandAt = new Map();

function isOnCommandCooldown(vkId) {
  const now = Date.now();
  const last = lastCommandAt.get(vkId);
  if (last && now - last < C.COMMAND_COOLDOWN_MS) {
    return C.COMMAND_COOLDOWN_MS - (now - last);
  }
  lastCommandAt.set(vkId, now);
  return 0;
}

// Разрешаем вызывать команды и без "!" — по алиасам ключевых слов.
// В беседах (не ЛС) это особенно важно: реагируем только на точное совпадение
// первого слова с известной командой, остальной текст беседы игнорируем.
const COMMAND_ALIASES = {
  начать: 'старт',
  начало: 'старт',
  старт: 'старт',
  регистрация: 'старт',
  команды: 'помощь',
  помощь: 'помощь',
  справка: 'помощь',
  правила: 'помощь',
  питомец: 'робот',
  работать: 'работа',
  склады: 'склад',
  баланс: 'профиль',
  я: 'профиль',
  инвентарь: 'арсенал',
  атаковать: 'атака',
  переименовка: 'переименовать',
  донат: 'донат',
  прайс: 'донат',
  цены: 'донат',
  ценник: 'донат',
  оплата: 'донат',
  патруль: 'дозор',
  ивенты: 'ивент',
  событие: 'ивент',
  майнингферма: 'ферма',
  осмотр: 'инспекция',
  проверка: 'инспекция',
  осмотреть: 'инспекция',
  скины: 'стиль',
  магазинстилей: 'витрина',
  украсть: 'кража',
  ограбить: 'кража',
  квесты: 'задания',
  квест: 'задания',
  задание: 'задания',
  звание: 'карьера',
  звания: 'карьера',
  лайк: 'лайки',
  бизнесы: 'бизнес',
  бизнесс: 'бизнес',
};

// Некоторые алиасы — это ходовые русские слова, которые люди пишут в начале обычных фраз
// (например, "Я подумала, что ты нападаешь"). Если такой алиас сработает просто по первому
// слову сообщения, бот будет ложно реагировать на обычную переписку в беседе. Поэтому для них
// команда засчитывается, только если она написана САМОСТОЯТЕЛЬНО (всё сообщение — ровно это
// слово), либо явно с "!" (например "!я").
const AMBIGUOUS_WORD_ALIASES = new Set(['я']);

const KNOWN_COMMANDS = new Set([
  'старт',
  'профиль',
  'переименовать',
  'построить',
  'бонус',
  'перевод',
  'магазин',
  'купить',
  'арсенал',
  'атака',
  'разведка',
  'произвести',
  'производство',
  'забрать',
  'разблокировать',
  'топ',
  'помощь',
  'гайд',
  'админ',
  'клан',
  'робот',
  'роботы',
  'суперробот',
  'суперроботы',
  'майнер',
  'отправить',
  'мой',
  'работа',
  'склад',
  'выбрать',
  'наука',
  'лимит',
  'аукцион',
  'продать',
  'ставка',
  'отмена',
  'лоты',
  'промо',
  'обменять',
  'оружие',
  'вооружение',
  'донат',
  'дозор',
  'ивент',
  'ферма',
  'акция',
  'инспекция',
  'босс',
  'стиль',
  'витрина',
  'кража',
  'задания',
  'карьера',
  'лайки',
  'бизнес',
  'зоны',
  'гонка',
  'казино',
]);

function isPrivateMessage(ctx) {
  // В VK личные сообщения имеют peer_id, равный user_id (< 2e9), беседы >= 2e9
  return ctx.peerId && ctx.peerId < 2000000000;
}

// Резолвит часть ссылки ВК ("id123456" или короткое имя типа "durov") в числовой vk_id.
// Числовой id и "idNNN" разбираются без обращения к API. Короткое имя требует вызова
// VK API (utils.resolveScreenName) через бота, привязанного к текущему контексту.
async function resolveVkLinkPart(ctx, linkPart) {
  if (!linkPart) return null;

  const idMatch = linkPart.match(/^id(\d+)$/i);
  if (idMatch) return Number(idMatch[1]);
  if (/^\d+$/.test(linkPart)) return Number(linkPart);

  if (!ctx || !ctx.bot || !ctx.bot.vk) return null;
  try {
    const result = await ctx.bot.vk.api.utils.resolveScreenName({ screen_name: linkPart });
    if (result && result.type === 'user' && result.object_id) {
      return Number(result.object_id);
    }
  } catch (err) {
    console.error('[Dispatcher] Не удалось разрешить ссылку ВК:', err.message);
  }
  return null;
}

async function resolveMentionToId(ctx, text, tokens, index) {
  const token = tokens[index];
  if (token) {
    let id = parse.extractMentionId(token);
    if (id) return id;

    const linkPart = parse.extractVkLinkPart(token);
    if (linkPart) {
      const resolved = await resolveVkLinkPart(ctx, linkPart);
      if (resolved) return resolved;
    }
  }

  // Возможно, это упоминание с пробелом в имени [id123|Имя Фамилия] — ищем в исходном тексте
  let id = parse.findMentionInText(text);
  if (id) return id;

  // Или это просто ссылка на профиль ВК где-то в тексте сообщения
  const linkPart = parse.extractVkLinkPart(text);
  if (linkPart) {
    return await resolveVkLinkPart(ctx, linkPart);
  }

  return null;
}

async function dispatch(ctx) {
  // ===== ЗАЩИТА ОТ ВЫПОЛНЕНИЯ "СТАРЫХ"/ЧУЖИХ СООБЩЕНИЙ КАК КОМАНД =====
  // Раньше здесь была только проверка на service-события (ctx.action). Как показала практика,
  // этого недостаточно: при закреплении сообщения VK всё равно может прислать апдейт,
  // который дальше по цепочке доходит до текста старого сообщения (например, "Построить 5",
  // отправленного 13 минут назад другим игроком), и бот выполняет его как только что введённую
  // команду. Поэтому теперь двойная защита:
  //
  // 1) Если апдейт помечен как служебное действие (закреп/откреп/кик/приглашение/смена
  //    названия беседы и т.п.) — независимо от того, как именно это поле называется в
  //    конкретной версии библиотеки, — игнорируем его.
  const rawPayload = (ctx.state && ctx.state.payload) || ctx.payload || {};
  const looksLikeServiceEvent = !!ctx.action || !!rawPayload.action;
  if (looksLikeServiceEvent) {
    console.log(
      `[Dispatcher] Пропущено служебное событие (закреп/кик/и т.п.) от senderId=${ctx.senderId}, peer=${ctx.peerId}`
    );
    return;
  }

  // 2) Главная защита: сообщение обязано быть СВЕЖИМ. Если время самого сообщения
  //    (message.date на стороне VK) старше разумного порога — это не живой ввод команды
  //    прямо сейчас, чем бы он ни был вызван (закреп, пересылка, повторная доставка апдейта
  //    и т.п.), и его нельзя исполнять. Единственная категория апдейтов, у которых
  //    createdAt может отсутствовать, — это клики по инлайн-кнопкам без обычного текста;
  //    для них проверка ниже просто не сработает (age будет 0/NaN и пропустится).
  const createdAtSec = typeof ctx.createdAt === 'number' ? ctx.createdAt : null;
  if (createdAtSec) {
    const ageMs = Date.now() - createdAtSec * 1000;
    if (ageMs > C.MAX_COMMAND_MESSAGE_AGE_MS) {
      console.log(
        `[Dispatcher] Пропущено устаревшее сообщение (возраст ${Math.round(ageMs / 1000)} сек) от senderId=${ctx.senderId}, текст="${(ctx.text || '').slice(0, 50)}"`
      );
      return;
    }
  }

  // Клики по инлайн-кнопкам мини-игры "работа" приходят с payload и обрабатываются
  // отдельно от текстовых команд (и без общего кулдауна команд — раунды короткие).
  // Обёрнуто в try/catch по тому же принципу, что и блок текстовых команд ниже: без этого
  // любая ошибка в обработчике кнопки долетала бы до bot.js и показывала бы пользователю
  // голый "⛔ Произошла внутренняя ошибка", вместо штатного сообщения и логирования по команде.
  const payload = ctx.messagePayload;
  if (payload && typeof payload.cmd === 'string' && payload.cmd.length) {
    try {
      switch (payload.cmd) {
        case 'work_pick':
          return await workHandlers.handleWorkPick(ctx, payload.box, payload.round);
        case 'work_start':
          return await workHandlers.handleWork(ctx);
        case 'work_menu':
          return await workHandlers.handleWorkMenu(ctx);
        case 'inspection_pick':
          return await inspectionHandlers.handleInspectionPick(ctx, payload.cell, payload.round);
        case 'inspection_start':
          return await inspectionHandlers.handleInspection(ctx);
        case 'help_section':
          return await ratingHandlers.handleHelpSection(ctx, payload.section, payload.page);
        case 'help_page':
          return await ratingHandlers.handleHelpPage(ctx, payload.page);
        case 'exchange_factory':
          return await warehouseHandlers.handleExchangeFactory(ctx);
        case 'warehouse_show':
          return await warehouseHandlers.handleShow(ctx);
        case 'farm_status':
          return await farmHandlers.handleStatus(ctx);
        case 'farm_upgrade':
          return await farmHandlers.handleUpgrade(ctx);
        case 'farm_enable':
          return await farmHandlers.handleEnable(ctx);
        case 'farm_disable':
          return await farmHandlers.handleDisable(ctx);
        case 'farm_withdraw':
          return await farmHandlers.handleWithdraw(ctx);
        case 'farm_sell':
          return await farmHandlers.handleSellPrompt(ctx);
        case 'farm_info':
          return await farmHandlers.handleInfo(ctx);
        case 'farm_home':
          return await ratingHandlers.handleHelp(ctx);
        case 'business_home':
          return await businessHandlers.handleHome(ctx);
        case 'business_shop':
          return await businessHandlers.handleShop(ctx, payload.page);
        case 'business_buy':
          return await businessHandlers.handleBuy(ctx, payload.id, payload.page);
        case 'business_view':
          return await businessHandlers.handleView(ctx, payload.id);
        case 'business_collect':
          return await businessHandlers.handleCollect(ctx, payload.id);
        case 'business_collect_all':
          return await businessHandlers.handleCollectAll(ctx);
        case 'business_upgrade':
          return await businessHandlers.handleUpgrade(ctx, payload.id);
        case 'business_sell':
          return await businessHandlers.handleSell(ctx, payload.id);
        case 'business_sell_confirm':
          return await businessHandlers.handleSell(ctx, payload.id, true);
        case 'business_refill':
          return await businessHandlers.handleRefill(ctx, payload.id);
        case 'donate_page':
          return await donateHandlers.handleDonate(ctx, payload.topic);
        default:
          // Неизвестный cmd в payload — просто игнорируем (не обязательно наша кнопка),
          // проваливаемся дальше к обработке как обычного текстового сообщения.
          break;
      }
    } catch (err) {
      console.error(`[Dispatcher] Ошибка при обработке payload-кнопки "${payload.cmd}":`, err);
      await ctx.send('⛔ Произошла ошибка при выполнении команды. Попробуйте позже.');
      return;
    }
  }

  const text = (ctx.text || '').trim();
  if (!text) return;

  // Ввод названия государства при регистрации перехватываем только в ЛС,
  // чтобы обычные сообщения в беседе не ломали чужую регистрацию.
  if (isPrivateMessage(ctx)) {
    const handledName = await profile.handleNameInput(ctx);
    if (handledName) return;
  }

  const tokens = parse.splitArgs(text);

  // Быстрый алиас пополнения сейфа клана: "+сейф 111" — то же самое, что "клан сейф пополнить 111".
  // Проверяем до общего разбора команд, т.к. "+" — не "!", и "сейф" сам по себе не команда верхнего уровня.
  if (tokens[0] && tokens[0].toLowerCase() === '+сейф') {
    const remainingCooldownMs = isOnCommandCooldown(ctx.senderId);
    if (remainingCooldownMs > 0) {
      await ctx.send(`⏳ Не так быстро! Подождите ${(remainingCooldownMs / 1000).toFixed(1)} сек. между командами.`);
      return;
    }
    return await clanHandlers.handleDeposit(ctx, tokens[1]);
  }

  let rawCommand = tokens[0].toLowerCase();
  const startedWithBang = rawCommand.startsWith('!');
  if (startedWithBang) rawCommand = rawCommand.slice(1);

  const normalized = COMMAND_ALIASES[rawCommand] || rawCommand;

  // Слова-омонимы вроде "я" не должны запускать команду, если это просто первое слово обычной
  // фразы ("Я подумала...") — только если всё сообщение состоит из одного этого слова, или оно
  // явно вызвано через "!" (например "!я").
  if (!startedWithBang && AMBIGUOUS_WORD_ALIASES.has(rawCommand) && tokens.length > 1) {
    return;
  }

  // И в ЛС, и в беседах реагируем только на точное совпадение с известной командой —
  // так бот не отвечает на посторонние сообщения в общем чате.
  if (!KNOWN_COMMANDS.has(normalized)) return;

  const remainingCooldownMs = isOnCommandCooldown(ctx.senderId);
  if (remainingCooldownMs > 0) {
    await ctx.send(`⏳ Не так быстро! Подождите ${(remainingCooldownMs / 1000).toFixed(1)} сек. между командами.`);
    return;
  }

  const command = '!' + normalized;

  try {
    switch (command) {
      case '!старт':
        return await profile.handleStart(ctx);

      case '!профиль': {
        const targetId = await resolveMentionToId(ctx, text, tokens, 1);
        return await profile.handleProfile(ctx, targetId);
      }

      case '!переименовать': {
        const newName = tokens.slice(1).join(' ');
        return await profile.handleRename(ctx, newName);
      }

      case '!построить':
        return await economyHandlers.handleBuild(ctx, tokens[1]);

      case '!бонус':
        return await economyHandlers.handleDailyBonus(ctx);

      case '!перевод': {
        const targetId = await resolveMentionToId(ctx, text, tokens, 1);
        const rest = tokens.slice(2);
        const amountArg = rest[rest.length - 1];
        return await economyHandlers.handleTransfer(ctx, targetId, amountArg);
      }

      case '!магазин':
        return await shopHandlers.handleShop(ctx);

      case '!купить': {
        // Название товара может состоять из нескольких слов, количество — последний токен если число
        const rest = tokens.slice(1);
        let quantity = 1;
        let nameTokens = rest;
        const last = rest[rest.length - 1];
        if (last && /^\d+$/.test(last)) {
          quantity = parseInt(last, 10);
          nameTokens = rest.slice(0, -1);
        }
        const itemName = nameTokens.join(' ');
        return await shopHandlers.handleBuy(ctx, itemName, String(quantity));
      }

      case '!арсенал':
        return await shopHandlers.handleArsenal(ctx);

      case '!атака': {
        const targetId = await resolveMentionToId(ctx, text, tokens, 1);
        const rest = tokens.slice(2);
        if (rest.length < 2) {
          await ctx.send('⛔ Формат: !атака @юзер [оружие] [количество]');
          return;
        }
        const qty = rest[rest.length - 1];
        const weapon = rest.slice(0, -1).join(' ');
        return await combatHandlers.handleAttack(ctx, targetId, weapon, qty, ctx.peerId);
      }

      case '!разведка': {
        const targetId = await resolveMentionToId(ctx, text, tokens, 1);
        return await combatHandlers.handleRecon(ctx, targetId);
      }

      case '!кража': {
        const sub = (tokens[1] || '').toLowerCase();
        if (sub === 'статистика' || sub === 'навык') return await stealHandlers.handleStats(ctx);
        const targetId = await resolveMentionToId(ctx, text, tokens, 1);
        return await stealHandlers.handleSteal(ctx, targetId, ctx.peerId);
      }

      case '!задания':
        return await questHandlers.handleQuests(ctx);

      case '!карьера':
        return await questHandlers.handleCareer(ctx);

      case '!лайки':
        return await likeHandlers.handleLikes(ctx);

      case '!произвести': {
        const rest = tokens.slice(1);
        // формат: [оружие...] [количество] [заводов]
        if (rest.length < 3) {
          await ctx.send('⛔ Формат: !произвести [оружие] [количество] [заводов]');
          return;
        }
        const factoriesArg = rest[rest.length - 1];
        const qtyArg = rest[rest.length - 2];
        const weaponArg = rest.slice(0, -2).join(' ');
        return await productionHandlers.handleProduce(ctx, weaponArg, qtyArg, factoriesArg);
      }

      case '!производство':
        return await productionHandlers.handleProductionStatus(ctx);

      case '!забрать': {
        const rest = tokens.slice(1);
        if (rest.length < 2) {
          await ctx.send('⛔ Формат: !забрать [оружие] [количество]');
          return;
        }
        const qtyArg = rest[rest.length - 1];
        const weaponArg = rest.slice(0, -1).join(' ');
        return await productionHandlers.handleCollect(ctx, weaponArg, qtyArg);
      }

      case '!разблокировать': {
        return await economyHandlers.handleUnblock(ctx, tokens[1]);
      }

      case '!топ': {
        const sub = (tokens[1] || '').toLowerCase();
        if (sub === 'заводы') return await ratingHandlers.handleTopFactories(ctx);
        if (sub === 'вирты') return await ratingHandlers.handleTopBalance(ctx);
        if (sub === 'кланы') return await ratingHandlers.handleTopClans(ctx);
        if (sub === 'робот' || sub === 'роботы') return await ratingHandlers.handleTopRobot(ctx);
        if (sub === 'суперробот' || sub === 'суперроботы') return await ratingHandlers.handleTopSuperRobot(ctx);
        if (sub === 'доход') return await ratingHandlers.handleTopIncome(ctx);
        if (sub === 'ферма' || sub === 'фермы') return await ratingHandlers.handleTopFarmLevel(ctx);
        if (sub === 'фермадоход') return await ratingHandlers.handleTopFarmIncome(ctx);
        if (sub === 'наука' || sub === 'науки') return await ratingHandlers.handleTopScience(ctx);
        await ctx.send(
          images.withImage('tops', {
            message:
              '⛔ Формат: !топ заводы / !топ вирты / !топ кланы / !топ робот / !топ суперробот / ' +
              '!топ доход / !топ ферма / !топ фермадоход / !топ наука',
          })
        );
        return;
      }

      case '!помощь':
        return await ratingHandlers.handleHelp(ctx);

      case '!гайд':
        return await ratingHandlers.handleHelpSection(ctx, 'guide');

      case '!робот': {
        // "робот прокачать" — повысить уровень. "робот атака @юзер" — боевая атака (с уровня
        // ROBOT_FACTORY_DESTROY_UNLOCK_LEVEL). Любой другой вызов (включая просто "робот") —
        // мгновенная попытка собрать доход виртами (раз в час); если рано, покажет статус и кулдаун.
        const sub = (tokens[1] || '').toLowerCase();
        if (sub === 'прокачать') return await robotHandlers.handleUpgrade(ctx);
        if (sub === 'атака') {
          const targetId = await resolveMentionToId(ctx, text, tokens, 2);
          return await robotHandlers.handleAttack(ctx, targetId, ctx.peerId);
        }
        return await robotHandlers.handleFarm(ctx);
      }

      case '!роботы':
        return await robotHandlers.handleLevelsList(ctx);

      case '!отправить':
        return await robotHandlers.handleSend(ctx);

      case '!дозор': {
        const sub = (tokens[1] || '').toLowerCase();
        if (sub === 'статистика' || sub === 'навык') return await patrolHandlers.handleStats(ctx);
        return await patrolHandlers.handlePatrol(ctx);
      }

      case '!суперробот': {
        // "суперробот прокачать" — прокачать уровень за жетоны.
        // "суперробот атака @юзер" — атаковать другого игрока (снос заводов).
        // Просто "суперробот" — статус.
        const sub = (tokens[1] || '').toLowerCase();
        if (sub === 'прокачать') return await superRobotHandlers.handleUpgrade(ctx);
        if (sub === 'атака') {
          const targetId = await resolveMentionToId(ctx, text, tokens, 2);
          return await superRobotHandlers.handleAttack(ctx, targetId, ctx.peerId);
        }
        return await superRobotHandlers.handleStatus(ctx);
      }

      case '!суперроботы':
        return await superRobotHandlers.handleLevelsList(ctx);

      case '!майнер':
        return await minerHandlers.handleStatus(ctx);

      case '!босс': {
        // "босс" — статус ивента, "босс [кол-во]" — купить и выпустить N ракет "Орешник".
        const arg = tokens[1];
        if (arg && /^\d+$/.test(arg)) {
          return await bossHandlers.handleBossFire(ctx, arg);
        }
        return await bossHandlers.handleBossStatus(ctx);
      }

      case '!стиль': {
        // "стиль" — инвентарь, "стиль выбрать N" — экипировать, "стиль снять" — снять,
        // "стиль продать N цена" — выставить на витрину.
        const sub = (tokens[1] || '').toLowerCase();
        if (sub === 'выбрать') return await styleHandlers.handleEquip(ctx, tokens[2]);
        if (sub === 'снять') return await styleHandlers.handleUnequip(ctx);
        if (sub === 'продать') return await styleHandlers.handleSell(ctx, tokens[2], tokens[3]);
        return await styleHandlers.handleInventory(ctx);
      }

      case '!витрина': {
        // "витрина" — список лотов, "витрина купить N" — купить лот, "витрина снять N" — свой лот убрать.
        const sub = (tokens[1] || '').toLowerCase();
        if (sub === 'купить') return await styleHandlers.handleBuy(ctx, tokens[2]);
        if (sub === 'снять') return await styleHandlers.handleCancelListing(ctx, tokens[2]);
        return await styleHandlers.handleShowcase(ctx);
      }

      case '!ферма': {
        // "ферма прокачать" — построить/прокачать уровень, "ферма включить"/"ферма выключить" —
        // переключить непрерывную добычу, "ферма снять" — перенести накопленное на кошелёк,
        // "ферма продать [число|всё]" — продать нанокоины за вирты. Просто "ферма" — статус (с кнопками).
        const sub = (tokens[1] || '').toLowerCase();
        if (sub === 'прокачать') return await farmHandlers.handleUpgrade(ctx);
        if (sub === 'включить' || sub === 'старт' || sub === 'запустить') return await farmHandlers.handleEnable(ctx);
        if (sub === 'выключить' || sub === 'стоп' || sub === 'остановить') return await farmHandlers.handleDisable(ctx);
        if (sub === 'снять') return await farmHandlers.handleWithdraw(ctx);
        if (sub === 'продать') return await farmHandlers.handleSell(ctx, tokens[2]);
        return await farmHandlers.handleStatus(ctx);
      }

      case '!зоны': {
        const sub = (tokens[1] || '').toLowerCase();
        if (sub === 'история') return await zoneHandlers.handleHistory(ctx);
        return await zoneHandlers.handleStatus(ctx);
      }

      case '!гонка':
        return await raceHandlers.handleStatus(ctx);

      case '!бизнес': {
        // "бизнес" — список своих бизнесов, "бизнес магазин" — каталог из 25 видов,
        // "бизнес купить N" — купить по номеру из магазина, "бизнес N" — карточка своего
        // бизнеса по его id, "бизнес собрать [N]" — собрать доход (с одного или со всех),
        // "бизнес прокачать N" / "бизнес продать N" / "бизнес сырьё N" (или "пополнить N").
        const sub = (tokens[1] || '').toLowerCase();
        if (sub === 'магазин') return await businessHandlers.handleShop(ctx);
        if (sub === 'купить') return await businessHandlers.handleBuy(ctx, tokens[2]);
        if (sub === 'прокачать') return await businessHandlers.handleUpgrade(ctx, tokens[2]);
        if (sub === 'продать') return await businessHandlers.handleSell(ctx, tokens[2]);
        if (sub === 'сырьё' || sub === 'сырье' || sub === 'пополнить') {
          return await businessHandlers.handleRefill(ctx, tokens[2]);
        }
        if (sub === 'собрать') {
          return tokens[2] ? await businessHandlers.handleCollect(ctx, tokens[2]) : await businessHandlers.handleCollectAll(ctx);
        }
        if (/^\d+$/.test(sub)) return await businessHandlers.handleView(ctx, sub);
        return await businessHandlers.handleHome(ctx);
      }

      case '!донат': {
        const sub = (tokens[1] || '').toLowerCase();
        if (sub === 'бизнес') return await donateHandlers.handleBusinessStatus(ctx);
        return await donateHandlers.handleDonate(ctx);
      }

      case '!акция':
        return await donateHandlers.handleFlashOffer(ctx);

      case '!мой': {
        const sub = (tokens[1] || '').toLowerCase();
        if (sub === 'робот') return await robotHandlers.handleMyStats(ctx);
        await ctx.send('⛔ Формат: мой робот');
        return;
      }

      case '!админ': {
        const sub = (tokens[1] || '').toLowerCase();
        if (sub === 'помощь' || sub === 'помощь2' || sub === 'рассылка' || sub === 'игроки' || sub === 'ивент' || sub === 'ивентмагазин' || sub === 'ивентприз' || sub === 'приз' || sub === 'зонывойна' || sub === 'зонабонус' || sub === 'зонабуст' || sub === 'акция' || sub === 'босс' || sub === 'буст' || sub === 'лайки' || sub === 'гонказаводов') {
          const rest = tokens.slice(2);
          return await adminHandlers.handleAdmin(ctx, sub, null, rest);
        }
        if (sub === 'обнулить' && (tokens[2] || '').toLowerCase() === 'всех') {
          return await adminHandlers.handleAdmin(ctx, sub, 'всех', []);
        }
        if (sub === 'вернутьдоход' && (tokens[2] || '').toLowerCase() === 'всех') {
          return await adminHandlers.handleAdmin(ctx, sub, 'всех', []);
        }
        if (sub === 'кланфото' || sub === 'кланвидео' || sub === 'курсферма' || sub === 'ценазаводов') {
          // Цель — не игрок по упоминанию, а клан по названию / число (цена) / "сброс" — просто передаём rest как есть.
          const rest = tokens.slice(2);
          return await adminHandlers.handleAdmin(ctx, sub, null, rest);
        }
        const targetId = await resolveMentionToId(ctx, text, tokens, 2);
        const rest = tokens.slice(3);
        return await adminHandlers.handleAdmin(ctx, sub, targetId, rest);
      }

      case '!клан': {
        const sub = (tokens[1] || '').toLowerCase();
        const rest = tokens.slice(2);

        if (!sub) {
          return await clanHandlers.handleInfo(ctx);
        }
        if (sub === 'создать') {
          return await clanHandlers.handleCreate(ctx, rest.join(' '));
        }
        if (sub === 'пригласить') {
          const targetId = await resolveMentionToId(ctx, text, tokens, 2);
          return await clanHandlers.handleInvite(ctx, targetId);
        }
        if (sub === 'вступить') {
          return await clanHandlers.handleJoin(ctx, rest.join(' '));
        }
        if (sub === 'кик') {
          const targetId = await resolveMentionToId(ctx, text, tokens, 2);
          return await clanHandlers.handleKick(ctx, targetId);
        }
        if (sub === 'зам') {
          const targetId = await resolveMentionToId(ctx, text, tokens, 2);
          return await clanHandlers.handlePromoteDeputy(ctx, targetId);
        }
        if (sub === 'снять_зама' || sub === 'разжаловать') {
          const targetId = await resolveMentionToId(ctx, text, tokens, 2);
          return await clanHandlers.handleDemoteDeputy(ctx, targetId);
        }
        if (sub === 'бонус') {
          return await clanHandlers.handleBonus(ctx, rest.join(' '));
        }
        if (sub === 'сейф' || sub === 'казна') {
          const action = (rest[0] || '').toLowerCase();
          if (['пополнить', 'внести', 'закинуть', 'положить'].includes(action)) {
            return await clanHandlers.handleDeposit(ctx, rest[1]);
          }
          if (['забрать', 'снять', 'вывести'].includes(action)) {
            return await clanHandlers.handleWithdraw(ctx, rest[1]);
          }
          if (['логи', 'лог', 'история'].includes(action)) {
            return await clanHandlers.handleVaultLogs(ctx);
          }
          return await clanHandlers.handleVault(ctx);
        }
        if (sub === 'инфо') {
          return await clanHandlers.handleInfo(ctx);
        }
        if (sub === 'зона') {
          return await clanHandlers.handleZoneStake(ctx, rest[0], rest[1]);
        }
        if (sub === 'покинуть') {
          return await clanHandlers.handleLeave(ctx);
        }
        if (sub === 'удалить' || sub === 'распустить') {
          return await clanHandlers.handleDisband(ctx, rest.join(' '));
        }

        await ctx.send('⛔ Неизвестная команда клана. Введите !помощь для списка команд.');
        return;
      }

      case '!работа':
        return await workHandlers.handleWorkMenu(ctx);

      case '!казино': {
        const sub = (tokens[1] || '').toLowerCase();
        if (sub === 'слот' || sub === 'слоты') return await casinoHandlers.handleSlot(ctx, tokens[2]);
        if (sub === 'топ') return await casinoHandlers.handleTop(ctx, tokens[2]);
        return await casinoHandlers.handleStatus(ctx);
      }

      case '!инспекция':
        return await inspectionHandlers.handleInspectionMenu(ctx);

      case '!склад': {
        const sub = (tokens[1] || '').toLowerCase();
        if (sub === 'шансы') return await warehouseHandlers.handleRewardsInfo(ctx);
        return await warehouseHandlers.handleShow(ctx);
      }

      case '!выбрать':
        return await warehouseHandlers.handleSelect(ctx, tokens[1]);

      case '!наука': {
        const sub = (tokens[1] || '').toLowerCase();
        if (sub === 'построить') return await scienceHandlers.handleBuild(ctx);
        if (sub === 'расширить') return await scienceHandlers.handleExpand(ctx);
        if (sub === 'обменять') return await scienceHandlers.handleExchangeToFactories(ctx, tokens[2]);
        return await scienceHandlers.handleStatus(ctx);
      }

      case '!ивент': {
        const sub = (tokens[1] || '').toLowerCase();
        if (sub === 'магазин') return await eventHandlers.handleShop(ctx);
        if (sub === 'купить') {
          const itemArg = tokens[2];
          const qtyArg = tokens[3];
          return await eventHandlers.handlePurchase(ctx, itemArg, qtyArg);
        }
        return await eventHandlers.handleStatus(ctx);
      }

      case '!лимит': {
        const sub = (tokens[1] || '').toLowerCase();
        if (sub === 'расширить') return await limitHandlers.handleExpand(ctx);
        return await limitHandlers.handleStatus(ctx);
      }

      case '!аукцион': {
        if (tokens[1] && /^\d+$/.test(tokens[1])) {
          return await auctionHandlers.handleDetails(ctx, tokens[1]);
        }
        return await auctionHandlers.handleList(ctx);
      }

      case '!продать': {
        const [itemName, qty, start, step, hours] = tokens.slice(1);
        return await auctionHandlers.handleCreate(ctx, itemName, qty, start, step, hours);
      }

      case '!ставка':
        return await auctionHandlers.handleBid(ctx, tokens[1], tokens[2]);

      case '!отмена':
        return await auctionHandlers.handleCancel(ctx, tokens[1]);

      case '!лоты':
        return await auctionHandlers.handleMyLots(ctx);

      case '!обменять': {
        const sub = (tokens[1] || '').toLowerCase();
        if (sub === 'наука' || sub === 'науку') return await warehouseHandlers.handleExchangeScience(ctx);
        return await warehouseHandlers.handleExchangeFactory(ctx);
      }

      case '!оружие':
        return await shopHandlers.handleWeaponsInfo(ctx);

      case '!вооружение':
        return await shopHandlers.handleProductionGuide(ctx);

      case '!промо': {
        const sub = (tokens[1] || '').toLowerCase();
        if (sub === 'создать') {
          return await promoHandlers.handleCreate(ctx, tokens.slice(2));
        }
        if (sub === 'список') {
          return await promoHandlers.handleList(ctx);
        }
        if (sub === 'удалить') {
          return await promoHandlers.handleDelete(ctx, tokens[2]);
        }
        if (sub === 'vip') {
          // промо vip [код] [вкл|выкл] — правит флаг vip_only у уже созданного промокода
          // задним числом, без пересоздания (см. handlers/promoHandlers.js: handleSetVipOnly).
          return await promoHandlers.handleSetVipOnly(ctx, tokens[2], tokens[3]);
        }
        // !промо WAR2025 — активация игроком
        return await promoHandlers.handleRedeem(ctx, tokens[1]);
      }

      default: {
        // Проверяем, зарегистрирован ли игрок вообще, для более полезной подсказки
        const player = await players.getPlayer(ctx.senderId);
        if (!player) {
          await ctx.send('⛔ Неизвестная команда. Начните с команды !старт');
        } else {
          await ctx.send('⛔ Неизвестная команда. Введите !помощь для списка всех команд.');
        }
      }
    }
  } catch (err) {
    console.error(`[Dispatcher] Ошибка при обработке команды "${command}":`, err);
    await ctx.send('⛔ Произошла ошибка при выполнении команды. Попробуйте позже.');
  }
}

module.exports = { dispatch };
