'use strict';

const path = require('path');
const Jimp = require('jimp');

// Кастомные bitmap-шрифты (см. assets/fonts) — встроенные шрифты Jimp (FONT_SANS_*)
// содержат только латиницу, поэтому любой кириллический текст рендерился как "?????".
// Эти .fnt/.png сгенерированы из DejaVu Sans (полная поддержка кириллицы) и уже включают
// только те emoji/символы, для которых у DejaVu реально есть отрисованный глиптот —
// остальные коды при генерации отфильтрованы, чтобы не запекать в атлас "тофу"-квадраты.
const FONT_TITLE_PATH = path.join(__dirname, '..', 'assets', 'fonts', 'sans-32-white.fnt');
const FONT_LABEL_PATH = path.join(__dirname, '..', 'assets', 'fonts', 'sans-16-white.fnt');

// Множество символов, которые реально есть в обоих шрифтах выше (парсится из .fnt при
// старте). Используется в sanitizeText(), чтобы вырезать неподдерживаемые символы ДО
// печати — иначе Jimp пытается напечатать отсутствующий глиф и на его месте остаётся
// "дыра"/квадрат, что для пользователя выглядит так же плохо, как исходный баг с "?".
let supportedCharsCache = null;
function loadSupportedChars() {
  if (supportedCharsCache) return supportedCharsCache;
  const fs = require('fs');
  const set = new Set();
  for (const fontPath of [FONT_TITLE_PATH, FONT_LABEL_PATH]) {
    const text = fs.readFileSync(fontPath, 'utf8');
    const re = /^char id=(\d+)/gm;
    let m;
    while ((m = re.exec(text))) set.add(Number(m[1]));
  }
  supportedCharsCache = set;
  return set;
}

// Убирает из текста символы, которых нет в наших bitmap-шрифтах (например, цветные emoji,
// которые ни один растровый bitmap-шрифт всё равно не отрисует правильно), вместо того
// чтобы отдать их Jimp и получить "?"/пустой квадрат в лейауте.
function sanitizeText(text) {
  if (!text) return text;
  const supported = loadSupportedChars();
  let out = '';
  for (const ch of String(text)) {
    const cp = ch.codePointAt(0);
    if (supported.has(cp)) out += ch;
  }
  // Схлопываем пробелы, которые остались на месте вырезанных emoji.
  return out.replace(/[ \t]{2,}/g, ' ').trim();
}

// Палитра — общая для "работы" и "инспекции", чтобы оба рендера выглядели как единый
// визуальный стиль, а не как два разных экрана.
const PALETTE = {
  bgTop: 0x0f1420ff,
  bgBottom: 0x1a2233ff,
  header: 0x18202fff,
  headerAccent: 0x4fc3f7ff,
  cell: 0x232a36ff,
  cellShadow: 0x0a0d13aa,
  cellBorder: 0x4fc3f7ff,
  badgeBg: 0x0f1420ff,
  badgeBorder: 0x4fc3f7ff,
  icon: 0xffa726ff,
  iconBorder: 0x7a4a00ff,
  iconAnomalyGlow: 0xff5252ff,
};

let fontTitleCache = null;
let fontLabelCache = null;
let fontBadgeCache = null;

async function getFonts() {
  if (!fontTitleCache) fontTitleCache = await Jimp.loadFont(FONT_TITLE_PATH);
  if (!fontLabelCache) fontLabelCache = await Jimp.loadFont(FONT_LABEL_PATH);
  if (!fontBadgeCache) fontBadgeCache = await Jimp.loadFont(FONT_LABEL_PATH);
  return { fontTitle: fontTitleCache, fontLabel: fontLabelCache, fontBadge: fontBadgeCache };
}

// Вертикальный градиентный фон — считается один раз на размер и кешируется,
// т.к. размеры холста повторяются между раундами одного типа мини-игры.
const bgCache = new Map();
async function buildBackground(width, height) {
  const key = `${width}x${height}`;
  if (bgCache.has(key)) return bgCache.get(key).clone();

  const image = new Jimp(width, height, PALETTE.bgTop);
  const topRgba = Jimp.intToRGBA(PALETTE.bgTop);
  const bottomRgba = Jimp.intToRGBA(PALETTE.bgBottom);
  for (let y = 0; y < height; y++) {
    const t = y / Math.max(1, height - 1);
    const r = Math.round(topRgba.r + (bottomRgba.r - topRgba.r) * t);
    const g = Math.round(topRgba.g + (bottomRgba.g - topRgba.g) * t);
    const b = Math.round(topRgba.b + (bottomRgba.b - topRgba.b) * t);
    const color = Jimp.rgbaToInt(r, g, b, 255);
    for (let x = 0; x < width; x++) image.setPixelColor(color, x, y);
  }
  bgCache.set(key, image);
  return image.clone();
}

// Срезает углы прямоугольной области image[x,y,w,h] под радиус, делая пиксели
// за пределами скруглённого прямоугольника прозрачными. Работает только по углам
// (не по всей площади), поэтому дёшево даже при частом вызове.
function roundCorners(image, x, y, w, h, radius) {
  const r2 = radius * radius;
  const corners = [
    { cx: x + radius, cy: y + radius, x0: x, y0: y }, // top-left
    { cx: x + w - radius - 1, cy: y + radius, x0: x + w - radius, y0: y }, // top-right
    { cx: x + radius, cy: y + h - radius - 1, x0: x, y0: y + h - radius }, // bottom-left
    { cx: x + w - radius - 1, cy: y + h - radius - 1, x0: x + w - radius, y0: y + h - radius }, // bottom-right
  ];
  for (const { cx, cy, x0, y0 } of corners) {
    for (let py = y0; py < y0 + radius; py++) {
      for (let px = x0; px < x0 + radius; px++) {
        const dx = px - cx;
        const dy = py - cy;
        if (dx * dx + dy * dy > r2) {
          image.setPixelColor(0x00000000, px, py);
        }
      }
    }
  }
}

// Рамка (незалитый прямоугольник) заданной толщины — кешируется по (w,h,color,border),
// т.к. в обеих мини-играх все ячейки/коробки одного размера внутри одного рендера.
const frameCache = new Map();
function getFrameStrips(w, h, border, color) {
  const key = `${w}x${h}x${border}x${color}`;
  if (frameCache.has(key)) return frameCache.get(key);
  const strips = {
    top: new Jimp(w, border, color),
    bottom: new Jimp(w, border, color),
    left: new Jimp(border, h, color),
    right: new Jimp(border, h, color),
  };
  frameCache.set(key, strips);
  return strips;
}

function drawFrame(image, x, y, w, h, border, color) {
  const s = getFrameStrips(w, h, border, color);
  image.composite(s.top, x, y);
  image.composite(s.bottom, x, y + h - border);
  image.composite(s.left, x, y);
  image.composite(s.right, x + w - border, y);
}

// Мягкая "тень" под карточкой — смещённый затемнённый прямоугольник со скруглением.
const shadowCache = new Map();
function getShadow(w, h, radius) {
  const key = `${w}x${h}x${radius}`;
  if (shadowCache.has(key)) return shadowCache.get(key);
  const shadow = new Jimp(w, h, PALETTE.cellShadow);
  roundCorners(shadow, 0, 0, w, h, radius);
  shadowCache.set(key, shadow);
  return shadow;
}

function drawCardWithShadow(image, x, y, w, h, fillColor, radius) {
  const shadow = getShadow(w, h, radius);
  image.composite(shadow, x + 6, y + 8);
  const fillKey = `fill:${w}x${h}x${fillColor}`;
  let fill = frameCache.get(fillKey);
  if (!fill) {
    fill = new Jimp(w, h, fillColor);
    roundCorners(fill, 0, 0, w, h, radius);
    frameCache.set(fillKey, fill);
  }
  image.composite(fill, x, y);
}

// Круглый номерной бейдж в углу карточки — заменяет отдельную строку с цифрами
// над каждой ячейкой, чтобы не бороться за вертикальное место с заголовком.
const badgeCache = new Map();
async function drawBadge(image, x, y, number, fontBadge) {
  const size = 30;
  const cacheKey = `badge`;
  let base = badgeCache.get(cacheKey);
  if (!base) {
    base = new Jimp(size, size, PALETTE.badgeBg);
    roundCorners(base, 0, 0, size, size, 8);
    drawFrame(base, 0, 0, size, size, 2, PALETTE.badgeBorder);
    badgeCache.set(cacheKey, base);
  }
  image.composite(base.clone(), x, y);
  image.print(
    fontBadge,
    x,
    y,
    { text: sanitizeText(`${number}`), alignmentX: Jimp.HORIZONTAL_ALIGN_CENTER, alignmentY: Jimp.VERTICAL_ALIGN_MIDDLE },
    size,
    size
  );
}

function drawHeader(image, width, height, title, fontTitle) {
  const header = new Jimp(width, height, PALETTE.header);
  image.composite(header, 0, 0);
  const accent = new Jimp(width, 3, PALETTE.headerAccent);
  image.composite(accent, 0, height - 3);
  image.print(
    fontTitle,
    0,
    0,
    { text: sanitizeText(title), alignmentX: Jimp.HORIZONTAL_ALIGN_CENTER, alignmentY: Jimp.VERTICAL_ALIGN_MIDDLE },
    width,
    height - 3
  );
}

// Печатает текст в ОТДЕЛЬНЫЙ прозрачный холст размером ровно w x h и композитит его в
// (x, y) основного изображения. В отличие от прямого image.print(...) с maxWidth без
// maxHeight, это жёстко ограничивает область текста: если строка не влезла по ширине,
// Jimp переносит её на вторую строку, но т.к. холст-подложка имеет фиксированную высоту h,
// всё, что не поместилось по вертикали, просто обрезается — вместо того, чтобы "протечь"
// поверх соседней ячейки на основном изображении (это и был баг с наползающими подписями
// владельца/названия зоны на карте войны за зоны, см. game/zoneMapRender.js).
function printBoxed(image, font, x, y, w, h, text, alignmentX) {
  const box = new Jimp(w, h, 0x00000000);
  box.print(font, 0, 0, { text: sanitizeText(text), alignmentX: alignmentX || Jimp.HORIZONTAL_ALIGN_CENTER }, w);
  image.composite(box, x, y);
}

module.exports = {
  PALETTE,
  getFonts,
  buildBackground,
  roundCorners,
  drawFrame,
  drawCardWithShadow,
  drawBadge,
  drawHeader,
  printBoxed,
  sanitizeText,
};
