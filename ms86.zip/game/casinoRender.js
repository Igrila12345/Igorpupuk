'use strict';

const Jimp = require('jimp');
const GIFEncoder = require('gifencoder');
const C = require('./constants');
const R = require('./renderUtils');
const calc = require('./calc');

// ===================== АНИМАЦИЯ (гифка вместо статичной картинки) =====================
// Раньше renderSpin рисовал один статичный кадр с уже готовым результатом — по факту
// это была просто цифра без ощущения "казино". Теперь рендерим полноценную гифку:
// барабаны крутятся вразнобой и останавливаются один за другим слева направо (как в
// настоящих слотах), а итог показывается только на последних кадрах.
//
// Длительность гифки намеренно равна C.CASINO_SPIN_MS — game/casino.js держит игрока
// "занятым" (нельзя запустить вторую партию) ровно на этот же срок, синхронно с тем,
// сколько реально крутится анимация на экране.
const FRAME_DELAY_MS = 80; // ~12.5 кадра/сек — достаточно для ощущения вращения, гифка не разрастается
const LAST_FRAME_HOLD_MS = 1800; // последний кадр с итогом держим дольше остальных, чтобы результат успел прочитаться
// Моменты (в долях от общей длительности), когда останавливается каждый барабан —
// левый первым, правый последним, как в классических слотах.
const REEL_LOCK_FRACTIONS = [0.35, 0.6, 0.82];

// Символы рисуются простыми геометрическими фигурами (не эмодзи!) — растровый шрифт
// проекта (assets/fonts) содержит только латиницу/кириллицу и отфильтрованный набор
// символов, цветные эмодзи-глифы (🍒🍋🔔⭐💎7️⃣) он не отрисует (см. renderUtils.js:
// sanitizeText). Тот же приём, что и с иконкой завода в workRender.js — просто кружок/
// фигура нужного цвета вместо картинки.
const REEL_W = 170;
const REEL_H = 170;
const REEL_GAP = 24;
const MARGIN_SIDE = 30;
const HEADER_HEIGHT = 74;
const PADDING_TOP = 26;
const FOOTER_HEIGHT = 64;
const BORDER = 3;
const CORNER_RADIUS = 16;
const SYMBOL_SIZE = 96;

const MARGIN_TOP = HEADER_HEIGHT + PADDING_TOP;

const symbolIconCache = new Map();

// Рисует символ как фигуру size x size с прозрачным фоном (кешируется по ключу символа —
// фигур всего 6, дешевле нарисовать один раз и переиспользовать, как factoryIcon в
// workRender.js).
function buildSymbolIcon(sym, size) {
  const icon = new Jimp(size, size, 0x00000000);
  const cx = size / 2;
  const cy = size / 2;

  switch (sym.key) {
    case 'cherry': {
      // два кружка рядом — стилизованная "вишня"
      const r = size * 0.22;
      drawCircle(icon, cx - r * 0.9, cy + r * 0.5, r, sym.color);
      drawCircle(icon, cx + r * 0.9, cy + r * 0.5, r, sym.color);
      break;
    }
    case 'lemon': {
      drawEllipse(icon, cx, cy, size * 0.34, size * 0.24, sym.color);
      break;
    }
    case 'bell': {
      drawCircle(icon, cx, cy - size * 0.05, size * 0.32, sym.color);
      drawRect(icon, cx - size * 0.22, cy + size * 0.18, size * 0.44, size * 0.1, sym.color);
      break;
    }
    case 'star': {
      drawStar(icon, cx, cy, size * 0.4, size * 0.17, sym.color);
      break;
    }
    case 'diamond': {
      drawDiamond(icon, cx, cy, size * 0.36, sym.color);
      break;
    }
    case 'seven': {
      drawRect(icon, cx - size * 0.3, cy - size * 0.34, size * 0.6, size * 0.14, sym.color);
      drawRect(icon, cx + size * 0.02, cy - size * 0.34, size * 0.16, size * 0.68, sym.color);
      break;
    }
    default:
      drawCircle(icon, cx, cy, size * 0.3, sym.color);
  }
  return icon;
}

function setPx(icon, x, y, color) {
  const w = icon.bitmap.width;
  const h = icon.bitmap.height;
  const ix = Math.round(x);
  const iy = Math.round(y);
  if (ix < 0 || iy < 0 || ix >= w || iy >= h) return;
  icon.setPixelColor(color, ix, iy);
}

function drawCircle(icon, cx, cy, r, color) {
  const r2 = r * r;
  for (let y = Math.floor(cy - r); y <= Math.ceil(cy + r); y++) {
    for (let x = Math.floor(cx - r); x <= Math.ceil(cx + r); x++) {
      const dx = x - cx;
      const dy = y - cy;
      if (dx * dx + dy * dy <= r2) setPx(icon, x, y, color);
    }
  }
}

function drawEllipse(icon, cx, cy, rx, ry, color) {
  for (let y = Math.floor(cy - ry); y <= Math.ceil(cy + ry); y++) {
    for (let x = Math.floor(cx - rx); x <= Math.ceil(cx + rx); x++) {
      const dx = (x - cx) / rx;
      const dy = (y - cy) / ry;
      if (dx * dx + dy * dy <= 1) setPx(icon, x, y, color);
    }
  }
}

function drawRect(icon, x0, y0, w, h, color) {
  for (let y = Math.floor(y0); y <= Math.ceil(y0 + h); y++) {
    for (let x = Math.floor(x0); x <= Math.ceil(x0 + w); x++) {
      setPx(icon, x, y, color);
    }
  }
}

function drawDiamond(icon, cx, cy, r, color) {
  for (let y = Math.floor(cy - r); y <= Math.ceil(cy + r); y++) {
    for (let x = Math.floor(cx - r); x <= Math.ceil(cx + r); x++) {
      const dx = Math.abs(x - cx) / r;
      const dy = Math.abs(y - cy) / r;
      if (dx + dy <= 1) setPx(icon, x, y, color);
    }
  }
}

function drawStar(icon, cx, cy, outerR, innerR, color) {
  const points = [];
  for (let i = 0; i < 10; i++) {
    const r = i % 2 === 0 ? outerR : innerR;
    const angle = (Math.PI / 5) * i - Math.PI / 2;
    points.push({ x: cx + r * Math.cos(angle), y: cy + r * Math.sin(angle) });
  }
  // Простая заливка звезды через "четно-нечетное" правило по всем пикселям bbox —
  // фигура маленькая (≤~100px), так что это дёшево и не требует полноценного полигон-фила.
  const minX = Math.floor(cx - outerR);
  const maxX = Math.ceil(cx + outerR);
  const minY = Math.floor(cy - outerR);
  const maxY = Math.ceil(cy + outerR);
  for (let y = minY; y <= maxY; y++) {
    for (let x = minX; x <= maxX; x++) {
      if (pointInPolygon(x + 0.5, y + 0.5, points)) setPx(icon, x, y, color);
    }
  }
}

function pointInPolygon(x, y, points) {
  let inside = false;
  for (let i = 0, j = points.length - 1; i < points.length; j = i++) {
    const xi = points[i].x;
    const yi = points[i].y;
    const xj = points[j].x;
    const yj = points[j].y;
    const intersect = yi > y !== yj > y && x < ((xj - xi) * (y - yi)) / (yj - yi) + xi;
    if (intersect) inside = !inside;
  }
  return inside;
}

function getSymbolIcon(sym) {
  if (!symbolIconCache.has(sym.key)) {
    symbolIconCache.set(sym.key, buildSymbolIcon(sym, SYMBOL_SIZE));
  }
  return symbolIconCache.get(sym.key);
}

// Случайный символ для "вращающихся" (ещё не остановленных) барабанов — визуальный шум,
// никак не связанный с реальными весами исхода (тот уже посчитан в game/casino.js
// ДО рендера; рисуем только то, что игрок увидит на экране).
function randomSpinningSymbol() {
  const list = C.CASINO_SLOT_SYMBOLS;
  return list[Math.floor(Math.random() * list.length)];
}

// Рисует один кадр анимации поверх готового фона (background уже склонирован вызывающим
// кодом — здесь можно мутировать его напрямую).
function drawFrame(frame, width, fontTitle, fontLabel, reelSymbols, revealing, session) {
  R.drawHeader(frame, width, HEADER_HEIGHT, '🎰 КАЗИНО — СЛОТЫ', fontTitle);

  for (let i = 0; i < 3; i++) {
    const x = MARGIN_SIDE + i * (REEL_W + REEL_GAP);
    const y = MARGIN_TOP;
    // Подсвечиваем зелёным только когда все барабаны уже остановлены (revealing) и есть
    // выигрыш — до этого момента цвет ячеек нейтральный, даже если конкретный барабан
    // уже "встал" на свой финальный символ (чтобы не спойлерить исход раньше времени).
    // Выигрыш теперь только при полном совпадении всех трёх (game/casino.js:
    // resolveOutcome), так что тут либо все 3 ячейки зелёные, либо ни одной — частичного
    // выигрыша/подсветки 2 из 3 больше не бывает.
    const isWinningReel = revealing && session.matchType === 'three';
    const cellColor = isWinningReel ? 0x2c3a2eff : R.PALETTE.cell;
    const borderColor = isWinningReel ? 0x66bb6aff : R.PALETTE.cellBorder;

    R.drawCardWithShadow(frame, x, y, REEL_W, REEL_H, cellColor, CORNER_RADIUS);
    R.drawFrame(frame, x, y, REEL_W, REEL_H, BORDER, borderColor);

    const icon = getSymbolIcon(reelSymbols[i]);
    const ix = x + Math.round((REEL_W - SYMBOL_SIZE) / 2);
    const iy = y + Math.round((REEL_H - SYMBOL_SIZE) / 2);
    frame.composite(icon, ix, iy);
  }

  const footerY = MARGIN_TOP + REEL_H + 12;
  if (revealing) {
    const resultLine =
      session.win > 0
        ? `✅ Выигрыш: +${calc.formatNumber(session.win)} вирт (ставка ${calc.formatNumber(session.bet)})`
        : `❌ Проигрыш: -${calc.formatNumber(session.bet)} вирт`;
    R.printBoxed(frame, fontLabel, MARGIN_SIDE, footerY, width - MARGIN_SIDE * 2, 28, resultLine, Jimp.HORIZONTAL_ALIGN_CENTER);
    R.printBoxed(
      frame,
      fontLabel,
      MARGIN_SIDE,
      footerY + 28,
      width - MARGIN_SIDE * 2,
      24,
      `Баланс: ${calc.formatNumber(session.balance)} вирт`,
      Jimp.HORIZONTAL_ALIGN_CENTER
    );
  } else {
    R.printBoxed(
      frame,
      fontLabel,
      MARGIN_SIDE,
      footerY,
      width - MARGIN_SIDE * 2,
      28,
      '🎰 Крутим барабаны…',
      Jimp.HORIZONTAL_ALIGN_CENTER
    );
  }
}

// session: { bet, win, matchType, reels: [symbol, symbol, symbol], balance }
// Возвращает Buffer с анимированным GIF: барабаны крутятся и останавливаются по очереди
// слева направо, итог (выигрыш/проигрыш + баланс) появляется только на последних кадрах.
async function renderSpin(session) {
  const width = MARGIN_SIDE * 2 + REEL_W * 3 + REEL_GAP * 2;
  const height = MARGIN_TOP + REEL_H + FOOTER_HEIGHT;

  const [background, { fontTitle, fontLabel }] = await Promise.all([R.buildBackground(width, height), R.getFonts()]);

  const totalFrames = Math.max(20, Math.round(C.CASINO_SPIN_MS / FRAME_DELAY_MS));
  const lockAt = REEL_LOCK_FRACTIONS.map((frac) => Math.round(totalFrames * frac));

  const encoder = new GIFEncoder(width, height);
  encoder.start();
  encoder.setRepeat(-1); // проиграть один раз и остановиться на итоговом кадре, не зацикливать
  encoder.setQuality(12); // палитра чуть грубее ради размера файла — на плоских иконках почти незаметно
  encoder.setDelay(FRAME_DELAY_MS);

  for (let f = 0; f < totalFrames; f++) {
    const revealing = f >= lockAt[2];
    const reelSymbols = [
      f >= lockAt[0] ? session.reels[0] : randomSpinningSymbol(),
      f >= lockAt[1] ? session.reels[1] : randomSpinningSymbol(),
      f >= lockAt[2] ? session.reels[2] : randomSpinningSymbol(),
    ];

    const frame = background.clone();
    drawFrame(frame, width, fontTitle, fontLabel, reelSymbols, revealing, session);

    if (f === totalFrames - 1) encoder.setDelay(LAST_FRAME_HOLD_MS);
    encoder.addFrame(frame.bitmap.data);
  }

  encoder.finish();
  return encoder.out.getData();
}

module.exports = { renderSpin };
