'use strict';

const C = require('./constants');
const players = require('../db/players');
const shopDb = require('../db/shop'); // getMeta/setMeta — курс нанокоина живёт в общей таблице game_meta
const calc = require('./calc');

// ===================== Уровень / цена прокачки =====================

// currentLevel = 0 -> это цена ПОСТРОЙКИ фермы (первый уровень), дальше — обычная прокачка
function upgradeCost(currentLevel) {
  if (currentLevel <= 0) return C.FARM_BUILD_COST;
  const raw = C.FARM_UPGRADE_BASE_COST * Math.pow(C.FARM_UPGRADE_GROWTH, currentLevel - 1);
  return Math.round(raw / 10) * 10;
}

// ===================== Добыча в час =====================

// Фиксированная ставка ₿/час на данном уровне (среднее старого диапазона min/max) — ферма
// теперь копит непрерывно в реальном времени, а не случайными часовыми "тиками".
function ratePerHour(level) {
  if (level <= 0) return 0;
  const min = C.FARM_YIELD_BASE_MIN + C.FARM_YIELD_GROWTH_MIN * Math.sqrt(level);
  const max = C.FARM_YIELD_BASE_MAX + C.FARM_YIELD_GROWTH_MAX * Math.sqrt(level);
  return (min + max) / 2;
}

// Оставлено под старым именем для обратной совместимости (используется в топах/справке)
function avgYieldPerHour(level) {
  return ratePerHour(level);
}

// Ставка добычи с учётом ⚡ Турбофермы (донат-подписка, см. FARM_PRO_* в constants.js) —
// x${C.FARM_PRO_MULTIPLIER} к базовой ставке, пока активна farm_pro_until. Это отдельный,
// более "постоянный" множитель — временный бафф "ускорение фермы" (farm_boost_until)
// накладывается ПОВЕРХ него в computeLiveState (сегментами), а не вместо него.
function effectiveRatePerHour(level, player) {
  const base = ratePerHour(level);
  return calc.isFarmProActive(player) ? base * C.FARM_PRO_MULTIPLIER : base;
}

// Потолок накопления на самой ферме: ставка/час * часы автономности. Принимает player, чтобы
// учесть ⚡ Турбоферму — с ней потолок растёт пропорционально возросшей ставке.
function capFor(level, player) {
  return effectiveRatePerHour(level, player) * C.FARM_AUTONOMY_HOURS;
}

// ===================== Живое состояние фермы =====================
// Считаем баланс "на лету" по разнице времени с момента farm_since_at — никакого почасового
// планировщика для самой добычи больше не требуется (в отличие от старой циклической механики).
function computeLiveState(player, now = Date.now()) {
  const level = player.farm_level || 0;
  if (level <= 0) {
    return { level: 0, built: false, enabled: false, balance: 0, rate: 0, cap: 0, autonomyMsLeft: 0, full: false };
  }

  const rate = effectiveRatePerHour(level, player);
  const cap = capFor(level, player);
  let balance = Number(player.farm_balance) || 0;
  let enabled = !!player.farm_enabled;
  let autonomyMsLeft = 0;

  if (enabled) {
    const sinceMs = player.farm_since_at ? new Date(player.farm_since_at).getTime() : now;
    const elapsedMs = Math.max(now - sinceMs, 0);

    // Донат-бафф "ускорение фермы" (см. DONATE_FARM_BOOST_* в constants.js): считаем
    // накопленное по СЕГМЕНТАМ — часть интервала [sinceMs; now], попавшая под действие
    // farm_boost_until, идёт по ускоренной ставке, остальное — по обычной. Это нужно,
    // чтобы буст, купленный/истёкший ПОСЕРЕДИНЕ уже идущего отрезка добычи, считался
    // честно, а не задним числом на весь интервал или не задним числом вообще.
    const boostUntilMs =
      player.farm_boost_until && calc.isFarmBoostActive(player) ? new Date(player.farm_boost_until).getTime() : 0;
    let liveGain;
    if (boostUntilMs > sinceMs) {
      const boostEndMs = Math.min(boostUntilMs, now);
      const boostedHours = Math.max(boostEndMs - sinceMs, 0) / 3600000;
      const normalHours = Math.max(now - boostEndMs, 0) / 3600000;
      liveGain = rate * C.DONATE_FARM_BOOST_MULTIPLIER * boostedHours + rate * normalHours;
    } else {
      liveGain = rate * (elapsedMs / 3600000);
    }

    const live = balance + liveGain;

    if (live >= cap) {
      balance = cap;
      enabled = false;
      autonomyMsLeft = 0;
    } else {
      balance = live;
      autonomyMsLeft = Math.max(C.FARM_AUTONOMY_HOURS * 3600000 - elapsedMs, 0);
    }
  } else {
    balance = Math.min(balance, cap);
  }

  return { level, built: true, enabled, balance, rate, cap, autonomyMsLeft, full: balance >= cap && cap > 0 };
}

// Пересчитывает и, если ферма успела упереться в потолок (авто-пауза), сохраняет состояние в БД.
// Возвращает актуальный live-снимок. Вызывать в начале любого действия с фермой.
async function settleFarm(vkId, player) {
  const live = computeLiveState(player);
  if (live.built && !!player.farm_enabled && !live.enabled) {
    // Ферма сама встала на паузу, упершись в потолок автономности — фиксируем это в БД
    await players.setFarmState(vkId, { enabled: false, balance: live.balance, sinceAt: null });
  }
  return live;
}

// ===================== Постройка / прокачка =====================

async function buildOrUpgrade(vkId) {
  const player = await players.getPlayer(vkId);
  if (!player) return { ok: false, reason: 'not_registered' };

  const level = player.farm_level || 0;
  if (level >= C.FARM_MAX_LEVEL) return { ok: false, reason: 'max_level' };

  const cost = upgradeCost(level);
  const balance = Number(player.balance) || 0;
  if (balance < cost) {
    return { ok: false, reason: 'not_enough_money', cost, missing: cost - balance };
  }

  // Замораживаем текущую живую добычу под старую ставку до момента апгрейда
  const live = await settleFarm(vkId, player);

  await players.updateBalance(vkId, -cost);
  await players.setFarmLevel(vkId, level + 1);

  // Если ферма была включена — продолжаем добычу сразу под новую (более высокую) ставку
  if (live.built && live.enabled) {
    await players.setFarmState(vkId, { enabled: true, balance: live.balance, sinceAt: new Date() });
  } else {
    await players.setFarmState(vkId, { enabled: false, balance: live.balance, sinceAt: null });
  }

  return { ok: true, cost, newLevel: level + 1, wasBuilt: level === 0 };
}

// ===================== Включение / выключение добычи =====================

async function enableFarm(vkId) {
  const player = await players.getPlayer(vkId);
  if (!player) return { ok: false, reason: 'not_registered' };

  const level = player.farm_level || 0;
  if (level <= 0) return { ok: false, reason: 'not_built' };

  const live = await settleFarm(vkId, player);
  if (live.enabled) return { ok: false, reason: 'already_on' };
  if (live.full) return { ok: false, reason: 'full', balance: live.balance };

  await players.setFarmState(vkId, { enabled: true, balance: live.balance, sinceAt: new Date() });
  return { ok: true, level, rate: live.rate };
}

async function disableFarm(vkId) {
  const player = await players.getPlayer(vkId);
  if (!player) return { ok: false, reason: 'not_registered' };

  const level = player.farm_level || 0;
  if (level <= 0) return { ok: false, reason: 'not_built' };

  const live = computeLiveState(player);
  if (!live.enabled) return { ok: false, reason: 'already_off' };

  await players.setFarmState(vkId, { enabled: false, balance: live.balance, sinceAt: null });
  return { ok: true, balance: live.balance };
}

// ===================== Статус (только чтение) =====================

async function getStatus(vkId) {
  const player = await players.getPlayer(vkId);
  if (!player) return { ok: false, reason: 'not_registered' };
  return { ok: true, player, state: await settleFarm(vkId, player) };
}

// ===================== Снятие накопленного ₿ =====================
// Переносит текущий живой баланс фермы в личный кошелёк игрока (farm_coins, продаётся отдельно),
// обнуляет баланс на ферме и перезапускает автономность — заодно включает ферму, если была выключена.
async function withdraw(vkId) {
  const player = await players.getPlayer(vkId);
  if (!player) return { ok: false, reason: 'not_registered' };

  const level = player.farm_level || 0;
  if (level <= 0) return { ok: false, reason: 'not_built' };

  const live = computeLiveState(player);
  const amount = Math.floor(live.balance);
  if (amount <= 0) return { ok: false, reason: 'nothing_to_withdraw' };

  await players.addFarmCoins(vkId, amount);
  await players.setFarmState(vkId, { enabled: true, balance: 0, sinceAt: new Date() });

  return { ok: true, amount };
}

// ===================== Курс обмена нанокоина =====================

async function getExchangeRate() {
  const raw = await shopDb.getMeta(C.FARM_EXCHANGE_META_KEY);
  if (raw === null || raw === undefined) return C.FARM_EXCHANGE_RATE_START;
  const val = parseFloat(raw);
  return Number.isFinite(val) ? val : C.FARM_EXCHANGE_RATE_START;
}

// Границы коридора курса. По умолчанию — константы FARM_EXCHANGE_RATE_MIN/MAX, но админ
// может переопределить их командой !админ курсферма [мин] [макс] (см. handlers/adminHandlers.js) —
// тогда используются значения из game_meta.
async function getRateBounds() {
  const [rawMin, rawMax] = await Promise.all([
    shopDb.getMeta(C.FARM_EXCHANGE_RATE_MIN_META_KEY),
    shopDb.getMeta(C.FARM_EXCHANGE_RATE_MAX_META_KEY),
  ]);
  const parsedMin = parseFloat(rawMin);
  const parsedMax = parseFloat(rawMax);
  const min = rawMin !== null && rawMin !== undefined && Number.isFinite(parsedMin) ? parsedMin : C.FARM_EXCHANGE_RATE_MIN;
  const max = rawMax !== null && rawMax !== undefined && Number.isFinite(parsedMax) ? parsedMax : C.FARM_EXCHANGE_RATE_MAX;
  return { min, max };
}

// Админ задаёт новый коридор курса (см. !админ курсферма [мин] [макс]). Сразу же
// пересчитывает текущий курс в новых границах, чтобы изменение стало заметно сразу,
// а не только на следующем часовом тике планировщика.
async function setRateBounds(min, max) {
  await shopDb.setMeta(C.FARM_EXCHANGE_RATE_MIN_META_KEY, String(min));
  await shopDb.setMeta(C.FARM_EXCHANGE_RATE_MAX_META_KEY, String(max));
  const rate = await updateExchangeRate();
  return { min, max, rate };
}

// Курс раз в час (см. game/scheduler.js) резко скачет на одну из двух крайних точек
// коридора — либо на минимум, либо на максимум (50/50), а не плавно "блуждает" внутри
// диапазона. Коридор берётся из getRateBounds() (по умолчанию — константы, либо то, что
// задал админ). Не привязано к какой-либо реальной бирже, чисто игровой элемент.
async function updateExchangeRate() {
  const { min, max } = await getRateBounds();
  const next = Math.random() < 0.5 ? min : max;
  const rounded = Math.round(next * 100) / 100;
  await shopDb.setMeta(C.FARM_EXCHANGE_META_KEY, String(rounded));
  return rounded;
}

// ===================== Продажа нанокоинов =====================

// amount — число монет либо строка 'all' (продать всё)
async function sellCoins(vkId, amount) {
  const player = await players.getPlayer(vkId);
  if (!player) return { ok: false, reason: 'not_registered' };

  const have = Number(player.farm_coins) || 0;
  const requested = amount === 'all' ? have : Math.floor(amount);

  if (!Number.isFinite(requested) || requested <= 0) {
    return { ok: false, reason: 'invalid_amount' };
  }
  if (have <= 0) return { ok: false, reason: 'nothing_to_sell' };
  if (requested > have) return { ok: false, reason: 'not_enough_coins', have };

  const rate = await getExchangeRate();
  const virts = Math.round(requested * rate);

  await players.addFarmCoins(vkId, -requested);
  await players.updateBalance(vkId, virts);

  return { ok: true, sold: requested, virts, rate };
}

module.exports = {
  upgradeCost,
  ratePerHour,
  avgYieldPerHour,
  effectiveRatePerHour,
  capFor,
  computeLiveState,
  settleFarm,
  buildOrUpgrade,
  enableFarm,
  disableFarm,
  getStatus,
  withdraw,
  getExchangeRate,
  getRateBounds,
  setRateBounds,
  updateExchangeRate,
  sellCoins,
};
