'use strict';

const postLikesDb = require('../db/postLikes');
const C = require('./constants');

// owner_id для VK-методов — отрицательный ID сообщества. Берём из VK_GROUP_ID (.env), а не
// вычисляем откуда-то ещё, т.к. это единственное официальное сообщество, посты которого
// нужно лайкать (см. README: "Данные для подключения уже прописаны в .env").
function getGroupOwnerId() {
  const raw = process.env.VK_GROUP_ID;
  const groupId = Number(raw);
  if (!raw || !groupId || Number.isNaN(groupId)) return null;
  return -Math.abs(groupId);
}

// Подтягивает последние посты со стены сообщества (filter: 'owner' — только официальные
// посты от лица самого сообщества, а не чужие записи, если у группы включена открытая стена)
// и заносит новые в отслеживание. Работает независимо от события wall_post_new — так надёжнее:
// не зависит от того, включена ли галочка в настройках Long Poll и дошёл ли конкретный апдейт.
async function syncPosts(vk, ownerId) {
  const res = await vk.api.wall.get({
    owner_id: ownerId,
    count: 30,
    filter: 'owner',
  });
  const items = (res && res.items) || [];
  const posts = items
    .filter((post) => post && post.id && post.date)
    .map((post) => ({
      postId: post.id,
      publishedAt: new Date(post.date * 1000).toISOString(),
    }));
  await postLikesDb.upsertPosts(ownerId, posts);
}

// Опрашивает likes.getList для постов, которых ещё не все активные игроки лайкнули, и
// записывает актуальный список лайкнувших (постранично — VK отдаёт максимум 1000 за раз).
// Как только по посту лайкнули все активные игроки, getPendingPosts перестаёт его отдавать —
// повторных запросов к VK по "закрытым" постам больше не будет.
async function syncLikes(vk, ownerId) {
  const pending = await postLikesDb.getPendingPosts(
    ownerId,
    C.POST_LIKE_GRACE_PERIOD_MS,
    C.POST_LIKE_MAX_POSTS_PER_SYNC
  );

  for (const post of pending) {
    const likerIds = [];
    let offset = 0;
    const pageSize = 1000;
    for (;;) {
      const res = await vk.api.likes.getList({
        type: 'post',
        owner_id: ownerId,
        item_id: post.post_id,
        count: pageSize,
        offset,
      });
      // Разные версии VK API отдают список то в items, то в users — проверяем оба.
      const users = (res && res.items) || (res && res.users) || [];
      likerIds.push(...users);
      if (users.length < pageSize) break;
      offset += pageSize;
      if (offset > 50000) break; // защитный предел от бесконечного цикла
    }
    if (likerIds.length) {
      await postLikesDb.bulkInsertLikes(ownerId, post.post_id, likerIds);
    }
  }
}

// Полный цикл: подтягиваем новые посты → опрашиваем лайки по "хвостам" → пересчитываем
// штрафной флаг у всех активных игроков. Каждый шаг обёрнут в свой try/catch: сбой VK API на
// одном шаге (например, временная 502-ошибка при wall.get) не должен ронять весь цикл и
// мешать пересчитать штраф по уже накопленным данным.
async function syncAndRecompute(bot) {
  const ownerId = getGroupOwnerId();
  if (!ownerId) {
    console.error('[PostLikes] Не задан VK_GROUP_ID в .env — штраф за нелайкнутые посты выключен.');
    return;
  }
  if (!bot || !bot.vk) return;

  try {
    await syncPosts(bot.vk, ownerId);
  } catch (err) {
    console.error('[PostLikes] Не удалось опросить wall.get:', err.message);
  }

  try {
    await syncLikes(bot.vk, ownerId);
  } catch (err) {
    console.error('[PostLikes] Не удалось опросить likes.getList:', err.message);
  }

  try {
    await postLikesDb.recomputePenalties(ownerId, C.POST_LIKE_GRACE_PERIOD_MS);
  } catch (err) {
    console.error('[PostLikes] Не удалось пересчитать штрафы за лайки:', err.message);
  }
}

// Для команды "!лайки" — список непролайканных игроком постов с прямыми ссылками на них.
async function getUnlikedPostsForPlayer(vkId) {
  const ownerId = getGroupOwnerId();
  if (!ownerId) return [];
  const rows = await postLikesDb.getUnlikedPostsForPlayer(ownerId, vkId, C.POST_LIKE_GRACE_PERIOD_MS);
  const groupId = Math.abs(ownerId);
  return rows.map((row) => ({
    postId: row.post_id,
    publishedAt: row.published_at,
    url: `https://vk.com/wall-${groupId}_${row.post_id}`,
  }));
}

module.exports = {
  getGroupOwnerId,
  syncAndRecompute,
  getUnlikedPostsForPlayer,
};
