'use strict';

const C = require('./constants');
const players = require('../db/players');
const blackjackDb = require('../db/blackjack');
const asyncLock = require('./asyncLock');

// Активные раздачи — как spinningPlayers в game/casino.js, только тут партия живёт не
// 6 секунд гифки, а всё время, пока игрок не пришлёт "хит" или "стенд" (несколько
// сообщений подряд). Держим в памяти процесса: колода, открытые карты, ставка. Ничего
// из этого не нужно переживать перезапуск бота — если процесс упал посреди раздачи,
// ставка уже списана и об этом останется запись в БД (как обычный проигрыш), это
// приемлемо для мини-игры такого масштаба (тот же трейд-офф, что и у остальных
// коротких активностей в проекте).
const activeHands = new Map();

const SUITS = ['spades', 'hearts', 'diamonds', 'clubs'];
const RANKS = [
  { key: 'A', value: 11 },
  { key: '2', value: 2 },
  { key: '3', value: 3 },
  { key: '4', value: 4 },
  { key: '5', value: 5 },
  { key: '6', value: 6 },
  { key: '7', value: 7 },
  { key: '8', value: 8 },
  { key: '9', value: 9 },
  { key: '10', value: 10 },
  { key: 'J', value: 10 },
  { key: 'Q', value: 10 },
  { key: 'K', value: 10 },
];

function buildShuffledDeck() {
  const deck = [];
  for (const suit of SUITS) {
    for (const rank of RANKS) {
      deck.push({ suit, rank: rank.key, value: rank.value });
    }
  }
  // Fisher–Yates — обычная стандартная перетасовка, никакой скрытой логики тут нет.
  for (let i = deck.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [deck[i], deck[j]] = [deck[j], deck[i]];
  }
  return deck;
}

// Считает очки руки с учётом того, что "A" может стоить 11 или 1 — сначала все "A"
// считаются по 11, затем, пока сумма > 21 и есть хотя бы один "A", ещё не сниженный до 1,
// одна такая карта переоценивается в 1 (классическое правило блэкджека).
function handValue(cards) {
  let total = cards.reduce((sum, c) => sum + c.value, 0);
  let acesAsEleven = cards.filter((c) => c.rank === 'A').length;
  while (total > 21 && acesAsEleven > 0) {
    total -= 10;
    acesAsEleven--;
  }
  return total;
}

function isBlackjack(cards) {
  return cards.length === 2 && handValue(cards) === 21;
}

function isBusy(vkId) {
  return activeHands.has(vkId);
}

function getHand(vkId) {
  return activeHands.get(vkId) || null;
}

// Публичная точка входа для старта новой раздачи — проверки те же, что и у слотов
// (см. game/casino.js: spin): регистрация, формат ставки, границы, баланс. Списывает
// ставку сразу, раздаёт по 2 карты игроку и дилеру и сразу проверяет натуральный
// блэкджек (если он есть хотя бы у одной стороны, раздача завершается тут же — по
// правилам добирать карты после натурального блэкджека не нужно).
async function start(vkId, betRaw) {
  if (isBusy(vkId)) {
    return { ok: false, reason: 'already_playing' };
  }

  const player = await players.getPlayer(vkId);
  if (!player || player.registration_step !== 'done') {
    return { ok: false, reason: 'not_registered' };
  }

  const bet = Math.floor(Number(betRaw));
  if (!Number.isFinite(bet) || bet <= 0) {
    return { ok: false, reason: 'bad_bet' };
  }
  if (bet < C.BLACKJACK_MIN_BET) {
    return { ok: false, reason: 'bet_too_small' };
  }
  if (bet > C.BLACKJACK_MAX_BET) {
    return { ok: false, reason: 'bet_too_big' };
  }
  if (Number(player.balance) < bet) {
    return { ok: false, reason: 'not_enough_balance', balance: Number(player.balance) };
  }

  return asyncLock.withLock(`blackjack:${vkId}`, () => startLocked(vkId, bet));
}

async function startLocked(vkId, bet) {
  if (isBusy(vkId)) {
    // Повторный вызов для того же vkId, пока предыдущий startLocked ещё выполнялся
    // (та же защита от гонки, что и в game/casino.js: spinLocked).
    return { ok: false, reason: 'already_playing' };
  }

  const balanceAfterBet = await players.updateBalance(vkId, -bet);
  if (balanceAfterBet === null || balanceAfterBet < 0) {
    if (balanceAfterBet !== null) await players.updateBalance(vkId, bet);
    return { ok: false, reason: 'not_enough_balance' };
  }

  const deck = buildShuffledDeck();
  const playerCards = [deck.pop(), deck.pop()];
  const dealerCards = [deck.pop(), deck.pop()];

  const hand = {
    bet,
    deck,
    playerCards,
    dealerCards,
    finished: false,
    startedAt: Date.now(),
  };

  const playerBJ = isBlackjack(playerCards);
  const dealerBJ = isBlackjack(dealerCards);

  if (playerBJ || dealerBJ) {
    // Натуральный блэкджек у любой из сторон — раздача сразу закрыта, карты дилера
    // открыты полностью (в обычном ходе дилер прячет вторую карту до конца раздачи).
    const resolved = await finishHand(vkId, hand, true);
    return { ok: true, phase: 'finished', ...resolved };
  }

  activeHands.set(vkId, hand);
  scheduleTimeout(vkId);

  return {
    ok: true,
    phase: 'turn',
    bet,
    playerCards: playerCards.slice(),
    dealerCards: dealerCards.slice(),
    dealerHidden: true,
    playerTotal: handValue(playerCards),
    balance: balanceAfterBet,
  };
}

// Автосворачивание брошенной на середине раздачи — см. C.BLACKJACK_HAND_TIMEOUT_MS.
// Ставка НЕ возвращается (игрок сам не довёл партию до конца), карты дилера в записи в
// БД фиксируются как есть на момент таймаута — это просто лог, на баланс это никак уже
// не влияет.
function scheduleTimeout(vkId) {
  const hand = activeHands.get(vkId);
  if (!hand) return;
  hand.timeoutTimer = setTimeout(() => {
    const current = activeHands.get(vkId);
    if (!current || current.finished) return;
    finishHand(vkId, current, false, { forcedTimeout: true }).catch((err) => {
      console.error('[Blackjack] Ошибка при автозавершении по таймауту:', err);
    });
  }, C.BLACKJACK_HAND_TIMEOUT_MS);
  hand.timeoutTimer.unref?.();
}

function clearTimeoutFor(hand) {
  if (hand.timeoutTimer) {
    clearTimeout(hand.timeoutTimer);
    hand.timeoutTimer = null;
  }
}

// Берёт карту — доступно только пока раздача в фазе "ход игрока" (hand существует и не
// завершена). Если после добора перебор (>21), раздача сразу завершается поражением.
async function hit(vkId) {
  const hand = activeHands.get(vkId);
  if (!hand || hand.finished) {
    return { ok: false, reason: 'no_active_hand' };
  }
  return asyncLock.withLock(`blackjack:${vkId}`, () => hitLocked(vkId, hand));
}

async function hitLocked(vkId, hand) {
  if (hand.finished) return { ok: false, reason: 'no_active_hand' };

  hand.playerCards.push(hand.deck.pop());
  const total = handValue(hand.playerCards);

  if (total > 21) {
    const resolved = await finishHand(vkId, hand, true);
    return { ok: true, phase: 'finished', ...resolved };
  }

  return {
    ok: true,
    phase: 'turn',
    bet: hand.bet,
    playerCards: hand.playerCards.slice(),
    dealerCards: hand.dealerCards.slice(),
    dealerHidden: true,
    playerTotal: total,
  };
}

// Игрок останавливается — дилер доигрывает по стандартному правилу (берёт карты, пока
// очков меньше 17; на "мягких" 17 с тузом дилер тоже останавливается — упрощённая, но
// самая распространённая версия правила, без деления на "soft/hard 17").
async function stand(vkId) {
  const hand = activeHands.get(vkId);
  if (!hand || hand.finished) {
    return { ok: false, reason: 'no_active_hand' };
  }
  return asyncLock.withLock(`blackjack:${vkId}`, () => standLocked(vkId, hand));
}

async function standLocked(vkId, hand) {
  if (hand.finished) return { ok: false, reason: 'no_active_hand' };

  while (handValue(hand.dealerCards) < 17) {
    hand.dealerCards.push(hand.deck.pop());
  }

  const resolved = await finishHand(vkId, hand, true);
  return { ok: true, phase: 'finished', ...resolved };
}

// Считает исход и начисляет выплату. reveal=true означает "открыть все карты дилера в
// ответе" (всегда true к моменту вызова — раздача либо дошла до стенда, либо завершилась
// перебором/натуральным блэкджеком, прятать вторую карту дилера больше не от кого).
async function finishHand(vkId, hand, reveal, opts) {
  clearTimeoutFor(hand);
  hand.finished = true;
  activeHands.delete(vkId);

  const playerTotal = handValue(hand.playerCards);
  const dealerTotal = handValue(hand.dealerCards);
  const playerBJ = isBlackjack(hand.playerCards);
  const dealerBJ = isBlackjack(hand.dealerCards);
  const playerBust = playerTotal > 21;
  const dealerBust = dealerTotal > 21;

  const forcedTimeout = opts && opts.forcedTimeout;

  let outcome; // 'win' | 'blackjack' | 'push' | 'lose'
  let win = 0;

  if (forcedTimeout) {
    outcome = 'lose';
  } else if (playerBust) {
    outcome = 'lose';
  } else if (playerBJ && dealerBJ) {
    outcome = 'push';
    win = hand.bet;
  } else if (playerBJ) {
    outcome = 'blackjack';
    win = Math.round(hand.bet + hand.bet * C.BLACKJACK_NATURAL_MULT);
  } else if (dealerBJ) {
    outcome = 'lose';
  } else if (dealerBust) {
    outcome = 'win';
    win = hand.bet * 2;
  } else if (playerTotal > dealerTotal) {
    outcome = 'win';
    win = hand.bet * 2;
  } else if (playerTotal === dealerTotal) {
    outcome = 'push';
    win = hand.bet;
  } else {
    outcome = 'lose';
  }

  let balance = null;
  if (win > 0) {
    balance = await players.updateBalance(vkId, win);
  } else {
    const player = await players.getPlayer(vkId);
    balance = player ? Number(player.balance) : null;
  }

  await blackjackDb
    .insertBlackjackHand(vkId, hand.bet, win, outcome, hand.playerCards.map(cardKey), hand.dealerCards.map(cardKey))
    .catch((err) => console.error('[Blackjack] Не удалось записать раздачу в БД:', err));

  return {
    bet: hand.bet,
    win,
    net: win - hand.bet,
    outcome,
    playerCards: hand.playerCards.slice(),
    dealerCards: hand.dealerCards.slice(),
    playerTotal,
    dealerTotal,
    balance,
  };
}

function cardKey(card) {
  return `${card.rank}_${card.suit}`;
}

module.exports = { start, hit, stand, isBusy, getHand, handValue, isBlackjack };
