'use strict';

const Jimp = require('jimp');
const GIFEncoder = require('gifencoder');
const C = require('./constants');
const R = require('./renderUtils');
const calc = require('./calc');

// ===================== АНИМАЦИЯ (гифка вместо статичной картинки) =====================
// Раньше renderSpin рисовал один статичный кадр с уже готовым результатом — по факту
// это была просто цифра без ощущения "казино". Теперь рендерим полноценную гифку:
// барабаны крутятся вразнобой и останавливаются один за другим слева направо (как в
// настоящих слотах), а итог показывается только на последних кадрах.
//
// Длительность гифки намеренно равна C.CASINO_SPIN_MS — game/casino.js держит игрока
// "занятым" (нельзя запустить вторую партию) ровно на этот же срок, синхронно с тем,
// сколько реально крутится анимация на экране.
const FRAME_DELAY_MS = 80; // ~12.5 кадра/сек — достаточно для ощущения вращения, гифка не разрастается
const LAST_FRAME_HOLD_MS = 1800; // последний кадр с итогом держим дольше остальных, чтобы результат успел прочитаться
// Моменты (в долях от общей длительности), когда останавливается каждый барабан —
// левый первым, правый последним, как в классических слотах.
const REEL_LOCK_FRACTIONS = [0.35, 0.6, 0.82];

// Символы рисуются простыми геометрическими фигурами (не эмодзи!) — растровый шрифт
// проекта (assets/fonts) содержит только латиницу/кириллицу и отфильтрованный набор
// символов, цветные эмодзи-глифы (🍒🍋🔔⭐💎7️⃣) он не отрисует (см. renderUtils.js:
// sanitizeText). Тот же приём, что и с иконкой завода в workRender.js — просто кружок/
// фигура нужного цвета вместо картинки.
const REEL_W = 170;
const REEL_H = 170;
const REEL_GAP = 24;
const MARGIN_SIDE = 30;
const CABINET_BORDER = 10; // золотая "рамка автомата" вокруг всей игровой зоны
const MARQUEE_HEIGHT = 14; // полоса лампочек под заголовком
const HEADER_HEIGHT = 74;
const PADDING_TOP = 20; // отступ между лампочками и барабанами
const FOOTER_HEIGHT = 80; // +12px запаса от базового текста до нижнего края — там рисуется золотая рамка корпуса (CABINET_BORDER)
const BORDER = 3;
const CORNER_RADIUS = 16;
const SYMBOL_SIZE = 96;

const MARGIN_TOP = HEADER_HEIGHT + MARQUEE_HEIGHT + PADDING_TOP;

const GOLD = 0xffc94dff;
const GOLD_DIM = 0x5a4a1fff;
const SPARKLE_COLORS = [0xffe082ff, 0xfff59dff, 0xffffffff, 0x4fc3f7ff];

const symbolIconCache = new Map();

// Рисует символ как фигуру size x size с прозрачным фоном (кешируется по ключу символа —
// фигур всего 6, дешевле нарисовать один раз и переиспользовать, как factoryIcon в
// workRender.js). Каждая фигура теперь получает тонкий контрастный ободок и небольшой
// "блик" в углу — раньше иконки были совсем плоскими одноцветными пятнами, с ободком и
// бликом они выглядят как настоящие лакированные фишки/жетоны, а не просто заливка.
function buildSymbolIcon(sym, size) {
  const icon = new Jimp(size, size, 0x00000000);
  const cx = size / 2;
  const cy = size / 2;
  const outline = darken(sym.color, 0.45);

  switch (sym.key) {
    case 'cherry': {
      // два кружка рядом — стилизованная "вишня", плюс тонкий "стебелёк" сверху
      const r = size * 0.22;
      R.drawRect(icon, cx - size * 0.03, cy - r * 1.9, size * 0.06, r * 1.1, darken(sym.color, 0.25));
      R.drawCircle(icon, cx - r * 0.9, cy + r * 0.5, r, outline);
      R.drawCircle(icon, cx + r * 0.9, cy + r * 0.5, r, outline);
      R.drawCircle(icon, cx - r * 0.9, cy + r * 0.5, r * 0.82, sym.color);
      R.drawCircle(icon, cx + r * 0.9, cy + r * 0.5, r * 0.82, sym.color);
      break;
    }
    case 'lemon': {
      R.drawEllipse(icon, cx, cy, size * 0.34, size * 0.24, outline);
      R.drawEllipse(icon, cx, cy, size * 0.29, size * 0.2, sym.color);
      break;
    }
    case 'bell': {
      R.drawCircle(icon, cx, cy - size * 0.05, size * 0.32, outline);
      R.drawRect(icon, cx - size * 0.22, cy + size * 0.18, size * 0.44, size * 0.1, outline);
      R.drawCircle(icon, cx, cy - size * 0.05, size * 0.27, sym.color);
      R.drawRect(icon, cx - size * 0.19, cy + size * 0.2, size * 0.38, size * 0.07, sym.color);
      R.drawCircle(icon, cx, cy + size * 0.32, size * 0.045, outline);
      break;
    }
    case 'star': {
      R.drawStar(icon, cx, cy, size * 0.4, size * 0.17, outline);
      R.drawStar(icon, cx, cy, size * 0.34, size * 0.14, sym.color);
      break;
    }
    case 'diamond': {
      R.drawDiamond(icon, cx, cy, size * 0.36, outline);
      R.drawDiamond(icon, cx, cy, size * 0.3, sym.color);
      R.drawDiamond(icon, cx - size * 0.06, cy - size * 0.08, size * 0.09, 0xffffffaa);
      break;
    }
    case 'seven': {
      R.drawRect(icon, cx - size * 0.3, cy - size * 0.34, size * 0.6, size * 0.14, outline);
      R.drawRect(icon, cx + size * 0.02, cy - size * 0.34, size * 0.16, size * 0.68, outline);
      R.drawRect(icon, cx - size * 0.27, cy - size * 0.31, size * 0.54, size * 0.08, sym.color);
      R.drawRect(icon, cx + 0.05 * size, cy - size * 0.31, size * 0.1, size * 0.62, sym.color);
      break;
    }
    default:
      R.drawCircle(icon, cx, cy, size * 0.3, sym.color);
  }
  return icon;
}

// Затемняет ARGB-цвет (0xRRGGBBAA) на factor (0..1) — используется, чтобы получить
// контрастный ободок того же тона, что и заливка фигуры, вместо произвольного чёрного.
function darken(colorArgb, factor) {
  const rgba = Jimp.intToRGBA(colorArgb);
  const r = Math.round(rgba.r * (1 - factor));
  const g = Math.round(rgba.g * (1 - factor));
  const b = Math.round(rgba.b * (1 - factor));
  return Jimp.rgbaToInt(r, g, b, rgba.a);
}

function getSymbolIcon(sym) {
  if (!symbolIconCache.has(sym.key)) {
    symbolIconCache.set(sym.key, buildSymbolIcon(sym, SYMBOL_SIZE));
  }
  return symbolIconCache.get(sym.key);
}

// Случайный символ для "вращающихся" (ещё не остановленных) барабанов — визуальный шум,
// никак не связанный с реальными весами исхода (тот уже посчитан в game/casino.js
// ДО рендера; рисуем только то, что игрок увидит на экране).
function randomSpinningSymbol() {
  const list = C.CASINO_SLOT_SYMBOLS;
  return list[Math.floor(Math.random() * list.length)];
}

// Рисует один кадр анимации поверх готового фона (background уже склонирован вызывающим
// кодом — здесь можно мутировать его напрямую).
function drawFrame(frame, width, height, fontTitle, fontLabel, reelSymbols, revealing, session, frameIndex) {
  R.drawHeader(frame, width, HEADER_HEIGHT, '🎰 КАЗИНО — СЛОТЫ', fontTitle);

  // Гирлянда лампочек под заголовком — "бегущие огни", смещаются на каждом кадре.
  R.drawMarqueeLights(frame, MARGIN_SIDE, HEADER_HEIGHT + MARQUEE_HEIGHT / 2, width - MARGIN_SIDE * 2, 18, GOLD, GOLD_DIM, frameIndex);

  for (let i = 0; i < 3; i++) {
    const x = MARGIN_SIDE + i * (REEL_W + REEL_GAP);
    const y = MARGIN_TOP;
    // Подсвечиваем зелёным только когда все барабаны уже остановлены (revealing) и есть
    // выигрыш — до этого момента цвет ячеек нейтральный, даже если конкретный барабан
    // уже "встал" на свой финальный символ (чтобы не спойлерить исход раньше времени).
    // Выигрыш теперь только при полном совпадении всех трёх (game/casino.js:
    // resolveOutcome), так что тут либо все 3 ячейки зелёные, либо ни одной — частичного
    // выигрыша/подсветки 2 из 3 больше не бывает.
    const isWinningReel = revealing && session.matchType === 'three';
    const cellColor = isWinningReel ? 0x2c3a2eff : R.PALETTE.cell;
    const borderColor = isWinningReel ? 0x66bb6aff : R.PALETTE.cellBorder;

    if (isWinningReel) {
      // Мягкое золотое сияние позади ячейки — победный момент теперь виден не только по
      // смене цвета рамки, но и по "подсветке" вокруг символа.
      R.drawGlow(frame, x + REEL_W / 2, y + REEL_H / 2, REEL_W * 0.72, { r: 255, g: 215, b: 90 });
    }

    R.drawCardWithShadow(frame, x, y, REEL_W, REEL_H, cellColor, CORNER_RADIUS);
    R.drawFrame(frame, x, y, REEL_W, REEL_H, BORDER, borderColor);
    if (isWinningReel) {
      // Второй, более тонкий золотой контур поверх зелёной рамки — делает ячейку заметно
      // "наряднее", чем просто перекраска в один цвет.
      R.drawFrame(frame, x - 2, y - 2, REEL_W + 4, REEL_H + 4, 2, GOLD);
    }

    const icon = getSymbolIcon(reelSymbols[i]);
    const ix = x + Math.round((REEL_W - SYMBOL_SIZE) / 2);
    const iy = y + Math.round((REEL_H - SYMBOL_SIZE) / 2);
    frame.composite(icon, ix, iy);
  }

  const footerY = MARGIN_TOP + REEL_H + 12;
  if (revealing) {
    if (session.win > 0) {
      // На финальном (удержанном дольше) кадре добавляем конфетти-искры над всей игровой
      // зоной — раньше выигрыш ощущался только текстом, теперь картинка тоже "празднует".
      R.drawSparkles(frame, MARGIN_SIDE, MARGIN_TOP - 10, width - MARGIN_SIDE * 2, REEL_H + 20, 14, SPARKLE_COLORS);
    }
    const resultLine =
      session.win > 0
        ? `✅ Выигрыш: +${calc.formatNumber(session.win)} вирт (ставка ${calc.formatNumber(session.bet)})`
        : `❌ Проигрыш: -${calc.formatNumber(session.bet)} вирт`;
    R.printBoxed(frame, fontLabel, MARGIN_SIDE, footerY, width - MARGIN_SIDE * 2, 28, resultLine, Jimp.HORIZONTAL_ALIGN_CENTER);
    R.printBoxed(
      frame,
      fontLabel,
      MARGIN_SIDE,
      footerY + 28,
      width - MARGIN_SIDE * 2,
      24,
      `Баланс: ${calc.formatNumber(session.balance)} вирт`,
      Jimp.HORIZONTAL_ALIGN_CENTER
    );
  } else {
    R.printBoxed(
      frame,
      fontLabel,
      MARGIN_SIDE,
      footerY,
      width - MARGIN_SIDE * 2,
      28,
      '🎰 Крутим барабаны…',
      Jimp.HORIZONTAL_ALIGN_CENTER
    );
  }

  // "Корпус автомата" — золотая рамка по периметру, рисуется САМОЙ ПОСЛЕДНЕЙ (поверх
  // заголовка/барабанов/футера), иначе header и содержимое перекрывали бы её своей
  // заливкой и рамка была бы не видна почти по всему периметру, кроме нижнего края.
  R.drawFrame(frame, 0, 0, width, height, CABINET_BORDER, GOLD);
  R.drawFrame(
    frame,
    CABINET_BORDER - 2,
    CABINET_BORDER - 2,
    width - (CABINET_BORDER - 2) * 2,
    height - (CABINET_BORDER - 2) * 2,
    2,
    GOLD_DIM
  );
}

// session: { bet, win, matchType, reels: [symbol, symbol, symbol], balance }
// Возвращает Buffer с анимированным GIF: барабаны крутятся и останавливаются по очереди
// слева направо, итог (выигрыш/проигрыш + баланс) появляется только на последних кадрах.
async function renderSpin(session) {
  const width = MARGIN_SIDE * 2 + REEL_W * 3 + REEL_GAP * 2;
  const height = MARGIN_TOP + REEL_H + FOOTER_HEIGHT;

  const [background, { fontTitle, fontLabel }] = await Promise.all([R.buildBackground(width, height), R.getFonts()]);

  const totalFrames = Math.max(20, Math.round(C.CASINO_SPIN_MS / FRAME_DELAY_MS));
  const lockAt = REEL_LOCK_FRACTIONS.map((frac) => Math.round(totalFrames * frac));

  const encoder = new GIFEncoder(width, height);
  encoder.start();
  encoder.setRepeat(-1); // проиграть один раз и остановиться на итоговом кадре, не зацикливать
  encoder.setQuality(12); // палитра чуть грубее ради размера файла — на плоских иконках почти незаметно
  encoder.setDelay(FRAME_DELAY_MS);

  for (let f = 0; f < totalFrames; f++) {
    const revealing = f >= lockAt[2];
    const reelSymbols = [
      f >= lockAt[0] ? session.reels[0] : randomSpinningSymbol(),
      f >= lockAt[1] ? session.reels[1] : randomSpinningSymbol(),
      f >= lockAt[2] ? session.reels[2] : randomSpinningSymbol(),
    ];

    const frame = background.clone();
    drawFrame(frame, width, height, fontTitle, fontLabel, reelSymbols, revealing, session, f);

    if (f === totalFrames - 1) encoder.setDelay(LAST_FRAME_HOLD_MS);
    encoder.addFrame(frame.bitmap.data);
  }

  encoder.finish();
  return encoder.out.getData();
}

module.exports = { renderSpin };
