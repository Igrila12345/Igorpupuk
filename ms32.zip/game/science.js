'use strict';

const C = require('./constants');
const calc = require('./calc');
const players = require('../db/players');

async function buildCenter(vkId) {
  const player = await players.getPlayer(vkId);
  if (!player) return { ok: false, reason: 'not_registered' };

  const limit = calc.currentScienceLimit(player.science_limit_level);
  if ((player.science_centers || 0) >= limit) {
    return { ok: false, reason: 'limit_reached', limit };
  }

  if (player.factories < C.SCIENCE_BUILD_FACTORY_COST) {
    return {
      ok: false,
      reason: 'not_enough_factories',
      need: C.SCIENCE_BUILD_FACTORY_COST,
      have: player.factories,
    };
  }

  // Цена растёт каждые SCIENCE_BUILD_COST_STEP_SIZE построенных центров (см. calc.scienceBuildCost)
  const cost = calc.scienceBuildCost(player.science_centers || 0);
  if (Number(player.balance) < cost) {
    return {
      ok: false,
      reason: 'not_enough_money',
      cost,
      missing: cost - Number(player.balance),
    };
  }

  await players.decrementFactories(vkId, C.SCIENCE_BUILD_FACTORY_COST);
  await players.updateBalance(vkId, -cost);
  await players.addScienceCenters(vkId, 1);

  return { ok: true, cost };
}

async function expandLimit(vkId) {
  const player = await players.getPlayer(vkId);
  if (!player) return { ok: false, reason: 'not_registered' };

  const currentLevel = player.science_limit_level || 1;
  const nextRow = C.SCIENCE_LIMIT_LEVELS.find((l) => l.level === currentLevel + 1);
  if (!nextRow) {
    return { ok: false, reason: 'max_level' };
  }

  if (Number(player.balance) < nextRow.cost) {
    return { ok: false, reason: 'not_enough_money', cost: nextRow.cost, missing: nextRow.cost - Number(player.balance) };
  }

  await players.updateBalance(vkId, -nextRow.cost);
  await players.setScienceLimitLevel(vkId, nextRow.level);

  return { ok: true, newLevel: nextRow.level, newLimit: nextRow.limit, cost: nextRow.cost };
}

module.exports = { buildCenter, expandLimit };
