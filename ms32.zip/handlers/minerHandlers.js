'use strict';

const players = require('../db/players');
const calc = require('../game/calc');
const C = require('../game/constants');

async function handleStatus(ctx) {
  const player = await players.getPlayer(ctx.senderId);
  if (!player || player.registration_step !== 'done') {
    await ctx.send('⛔ Вы ещё не зарегистрированы. Напишите старт');
    return;
  }

  if (!calc.isMinerActive(player)) {
    await ctx.send(
      `⛏️ Майнер у вас не активен.\n` +
        `Майнер — донат-предмет: выдаётся администратором после оплаты и пассивно приносит немного вирт и жетонов каждый час, без каких-либо действий с вашей стороны.`
    );
    return;
  }

  await ctx.send(
    `⛏️ Майнер активен до ${new Date(player.miner_until).toLocaleString('ru-RU')}.\n` +
      `Каждый час пассивно приносит: ${calc.formatNumber(C.MINER_HOURLY_VIRTS_MIN)} вирт + ${
        C.MINER_HOURLY_TOKENS
      } жетонов.`
  );
}

module.exports = { handleStatus };
