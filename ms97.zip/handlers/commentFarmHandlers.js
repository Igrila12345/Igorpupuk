'use strict';

const C = require('../game/constants');
const calc = require('../game/calc');
const commentFarm = require('../game/commentFarm');

// ctx — CommentContext от vk-io (см. bot.js: onWallReply). Отвечаем игроку ЛИЧНЫМ
// сообщением (bot.notifyUser), а не ответом в самой ветке комментариев — так проще и
// безопаснее (не нужно оформлять wall.createComment от имени сообщества, отдельные
// права/лимиты), и это тот же канал, которым бот уже пользуется для прочих уведомлений
// (см. game/steal.js, game/zoneWar.js и т.д.).
async function handleWallReply(ctx) {
  if (!ctx.isWallComment || !ctx.isNew) return;

  const vkId = ctx.fromId;
  // Комментарии от самого сообщества (например, служебные) идут с отрицательным
  // fromId — их пропускаем, это не игрок.
  if (!vkId || vkId <= 0) return;

  if (!commentFarm.containsTrigger(ctx.text)) return;

  const result = await commentFarm.tryClaim(vkId, ctx.objectId, ctx.text);
  if (!result.ok) {
    // not_registered / already_claimed — намеренно молча, без уведомления: это не
    // ошибка игрока, на которую нужно реагировать, а просто "бонус тут не сработал".
    return;
  }

  if (ctx.bot) {
    await ctx.bot
      .notifyUser(
        vkId,
        `🌾 Бонус за комментарий «${C.COMMENT_FARM_TRIGGER_WORD}»: +${calc.formatNumber(result.virt)} вирт, +${
          result.tokens
        } 🎫 жетонов!`
      )
      .catch(() => {});
  }
}

module.exports = { handleWallReply };
