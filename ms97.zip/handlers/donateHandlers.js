'use strict';

const { Keyboard } = require('vk-io');
const C = require('../game/constants');
const msg = require('../utils/messages');
const calc = require('../game/calc');
const donateBuffs = require('../game/donateBuffs');
const donateBusiness = require('../game/donateBusiness');
const miner = require('../game/miner');
const images = require('../game/commandImages');

// ===================== ПАГИНАЦИЯ ДОНАТ-МЕНЮ ПО ТЕМАМ =====================
// Раньше "!донат" был одним длинным текстом. Теперь он разбит на темы (топики) с инлайн-кнопками
// переключения — тот же принцип постраничности, что и в handlers/businessHandlers.js (shopKeyboard),
// только вместо номеров страниц — смысловые разделы. ВАЖНО: у инлайн-клавиатуры ВК жёсткий лимит
// 10 кнопок суммарно на сообщение — 5 тем (в 2 ряда: 3+2) укладываются с запасом.
const TOPICS = [
  { id: 'forever', label: '👑 Навсегда' },
  { id: 'business', label: '🏢 Донат-бизнесы' },
  { id: 'boosts', label: '⚡ Ускорители' },
  { id: 'daily', label: '🔥 Дневные баффы' },
  { id: 'new', label: '🎉 Новое' },
];

function isValidTopic(id) {
  return TOPICS.some((t) => t.id === id);
}

function topicKeyboard(activeId) {
  const rows = [];
  for (let i = 0; i < TOPICS.length; i += 3) {
    const chunk = TOPICS.slice(i, i + 3);
    rows.push(
      chunk.map((t) =>
        Keyboard.textButton({
          label: t.label,
          payload: { cmd: 'donate_page', topic: t.id },
          color: t.id === activeId ? Keyboard.PRIMARY_COLOR : Keyboard.SECONDARY_COLOR,
        })
      )
    );
  }
  return Keyboard.keyboard(rows).inline();
}

function adminLinksText() {
  return C.ADMIN_IDS.map((id) => msg.mentionLink(id, 'администратору')).join(', ');
}

function paymentFooter() {
  return (
    `\n💳 Как оплатить: напишите ${adminLinksText()}, укажите, что хотите приобрести — товар будет выдан сразу после получения оплаты.`
  );
}

function foreverText() {
  return (
    `👑═══════ НАВСЕГДА (разовая покупка) ═══════👑\n\n` +
    `👑 VIP — ${C.DONATE_VIP_PRICE_RUB_MONTH} ₽ / месяц\n` +
    `    ▸ +${Math.round(C.VIP_INCOME_BONUS * 100)}% к доходу\n` +
    `    ▸ кулдауны робота короче на ${Math.round((1 - C.VIP_ROBOT_COOLDOWN_MULT) * 100)}%\n` +
    `    ▸ лимит построек завода в час x${C.VIP_FACTORY_BUILD_LIMIT_MULTIPLIER} (${C.FACTORY_BUILD_LIMIT_PER_HOUR} → ${
      C.FACTORY_BUILD_LIMIT_PER_HOUR * C.VIP_FACTORY_BUILD_LIMIT_MULTIPLIER
    })\n` +
    `    ▸ награда за «работу» и «инспекцию» x${C.VIP_WORK_INSPECTION_BONUS_MULTIPLIER}\n` +
    `    ▸ x${C.VIP_EXCHANGE_LIMIT_MULTIPLIER} дневного лимита обменов жетонов на завод/науку\n` +
    `    (есть дешёвый разовый вход — «VIP-день», см. вкладку 🔥 Дневные баффы)\n\n` +
    `🛡️ Защита от кражи — ${C.DONATE_STEAL_PROTECTION_PRICE_RUB_MONTH} ₽ / месяц (отдельно от VIP)\n` +
    `    ▸ пока активна — у вас нельзя украсть баланс командой «кража»\n\n` +
    `⛏️ Майнер — ${C.DONATE_MINER_PRICE_RUB} ₽\n` +
    `    ▸ пассивно ${calc.formatNumber(C.MINER_HOURLY_VIRTS_MIN)} вирт + ${C.MINER_HOURLY_TOKENS} жетонов/час, без действий\n` +
    `    ▸ прокачка уровня 0-${C.MINER_MAX_LEVEL}: ${C.MINER_LEVEL_UP_PRICE_RUB} ₽/уровень, +${Math.round(
      C.MINER_LEVEL_TOKEN_BONUS_PER_LEVEL * 100
    )}% жетонов/час за каждый (на макс. уровне — ${miner.tokensForLevel(C.MINER_MAX_LEVEL)} жетонов/час)\n\n` +
    `🤖 Суперробот — ${C.DONATE_SUPER_ROBOT_PRICE_RUB} ₽\n` +
    `    ▸ открывает суперробота (1 уровень), дальше качается вирт-командой «суперробот прокачать»\n\n` +
    `🎨 Персональный стиль — ${C.DONATE_PERSONAL_STYLE_PRICE_RUB} ₽\n` +
    `    ▸ кастомное фото/видео профиля, попадает в ваш инвентарь стилей (команда «стиль»)\n` +
    `    ▸ можно позже перепродать другому игроку на витрине («витрина»)\n\n` +
    eternalBusinessText() +
    paymentFooter()
  );
}

// "💎 Вечная Династия" — флагманский донат-бизнес, покупается один раз и не истекает (см.
// tier.permanent в game/constants.js). Отдельным блоком в топике "Навсегда", а не в общем
// списке подписочных донат-бизнесов (businessText), чтобы не путать разовую и месячную оплату.
function eternalBusinessText() {
  const tier = C.DONATE_BUSINESS_TIERS.find((t) => t.permanent);
  if (!tier) return '';
  const maxLevel = tier.maxLevel;
  const maxMult = tier.levelMultipliers[maxLevel];
  const totalToMax = tier.priceRub + tier.levelUpRub * (maxLevel - 1);
  return (
    `💎 ${tier.name} — ${tier.priceRub} ₽ (НАВСЕГДА, не нужно продлевать)\n` +
    `    ▸ пассивно ${calc.formatNumber(tier.hourlyVirtsMin)}-${calc.formatNumber(tier.hourlyVirtsMax)} вирт + ${tier.hourlyTokens} жетонов/час на 1 ур.\n` +
    `    ▸ раз в ${C.DONATE_BUSINESS_WEEKLY_DAYS} дней: +${tier.weekly.amount} ${tier.weekly.label} (тоже растёт с уровнем)\n` +
    `    ▸ ${maxLevel} уровней прокачки, ${tier.levelUpRub} ₽/уровень — с каждым уровнем доход растёт всё сильнее\n` +
    `    ▸ на макс. уровне (${maxLevel}) множитель дохода x${maxMult} — сильнее любого обычного тира\n` +
    `    ▸ ранги по ходу прокачки: ${C.DONATE_BUSINESS_ETERNAL_RANKS.map((r) => r.name).join(' → ')}\n` +
    `    ▸ занимает обычный слот донат-бизнеса, полная прокачка "под ключ" — ${calc.formatNumber(totalToMax)} ₽\n`
  );
}

function businessText() {
  return (
    `🏢═══════ ДОНАТ-БИЗНЕСЫ (подписка на ${C.DONATE_BUSINESS_DURATION_DAYS} дней) ═══════🏢\n\n` +
    `Пассивный доход каждый час — гарантированно, без шанса (как майнер), плюс третий\n` +
    `ресурс раз в ${C.DONATE_BUSINESS_WEEKLY_DAYS} дней. Можно иметь НЕСКОЛЬКО донат-бизнесов сразу —\n` +
    `1 бесплатный слот + до ${C.DONATE_BUSINESS_MAX_EXTRA_SLOTS} доп. слотов (по ${C.DONATE_BUSINESS_EXTRA_SLOT_PRICE_RUB} ₽ каждый,\n` +
    `итого максимум ${C.DONATE_BUSINESS_BASE_SLOTS + C.DONATE_BUSINESS_MAX_EXTRA_SLOTS} штук), в любом сочетании тиров.\n\n` +
    C.DONATE_BUSINESS_TIERS.filter((t) => !t.permanent).map(
      (t) =>
        `${t.name} — ${t.priceRub} ₽ / ${C.DONATE_BUSINESS_DURATION_DAYS} дней\n` +
        `    ▸ пассивно ${calc.formatNumber(t.hourlyVirtsMin)}-${calc.formatNumber(t.hourlyVirtsMax)} вирт + ${t.hourlyTokens} жетонов/час (на 1 уровне)\n` +
        `    ▸ раз в ${C.DONATE_BUSINESS_WEEKLY_DAYS} дней бонусом: +${t.weekly.amount} ${t.weekly.label}\n` +
        `    ▸ прокачка уровня за рубли: ${t.levelUpRub} ₽ / уровень (макс. ${C.DONATE_BUSINESS_MAX_LEVEL} ур.)`
    ).join('\n\n') +
    `\n\n📈 Уровень поднимает ВЕСЬ доход бизнеса (часовой + еженедельный) по той же шкале, что и\n` +
    `обычные бизнесы: ${Object.entries(C.BUSINESS_LEVEL_MULTIPLIERS)
      .map(([lvl, mult]) => `${lvl} ур. — x${mult}`)
      .join(', ')}.\n` +
    `(в отличие от Майнера — не навсегда, нужно продлевать; статус и таймер: донат бизнес)\n` +
    `Есть и НАВСЕГДА-версия с 25 уровнями и намного большей отдачей — см. вкладку 👑 Навсегда.` +
    paymentFooter()
  );
}

function boostsText() {
  return (
    `⚡═══════ МГНОВЕННЫЕ УСКОРИТЕЛИ (разовые) ═══════⚡\n\n` +
    `🔓 Сброс кулдауна робота/суперробота/дозора — ${C.DONATE_INSTANT_COOLDOWN_PRICE_RUB} ₽\n` +
    `🏭 Мгновенное завершение производства — ${C.DONATE_INSTANT_PRODUCTION_PRICE_RUB} ₽\n` +
    `👷 +${C.DONATE_WORK_EXTRA_ATTEMPTS} попыток «работы» сверх дневного лимита — ${C.DONATE_WORK_EXTRA_PRICE_RUB} ₽\n` +
    `🔁 Снять сегодняшний лимит обмена жетонов на завод/науку — ${C.DONATE_EXCHANGE_LIMIT_LIFT_PRICE_RUB} ₽` +
    paymentFooter()
  );
}

function dailyText() {
  return (
    `🔥═══════ ДНЕВНЫЕ БАФФЫ (истекают по времени) ═══════🔥\n\n` +
    `💰 Буст дохода на ${C.DONATE_INCOME_BOOST_DURATION_HOURS}ч\n` +
    `    ▸ x1.5 — ${C.DONATE_INCOME_BOOST_PRICE_RUB_X15} ₽  |  x2 — ${C.DONATE_INCOME_BOOST_PRICE_RUB_X2} ₽\n\n` +
    `🛡️ Щит на ${C.DONATE_SHIELD_DURATION_DAYS} дня — ${C.DONATE_SHIELD_PRICE_RUB} ₽\n` +
    `    ▸ защита от ЛЮБОГО оружия, КРОМЕ ядерного (ядерный удар пробивает щит полностью)\n\n` +
    `🪙 Двойные жетоны за «работу» на ${C.DONATE_WORK_DOUBLE_DURATION_HOURS}ч — ${C.DONATE_WORK_DOUBLE_PRICE_RUB} ₽\n` +
    `⛏️ Ускорение фермы (x${C.DONATE_FARM_BOOST_MULTIPLIER}) на ${C.DONATE_FARM_BOOST_DURATION_HOURS}ч — ${C.DONATE_FARM_BOOST_PRICE_RUB} ₽\n` +
    `👑 VIP-день — ${C.DONATE_VIP_DAY_PRICE_RUB} ₽\n` +
    `    ▸ весь VIP на 1 сутки — дешёвый разовый вход вместо целого месяца\n\n` +
    `👹 x2 награда за попадание по мировому боссу, СТРОГО на 1 день — ${C.DONATE_BOSS_DOUBLE_PRICE_RUB} ₽\n` +
    `    ▸ действует только пока идёт ивент «босс» (команда игрокам: «босс»)\n\n` +
    `🔥 СТРИК: покупайте эти дневные баффы день в день — за каждый день подряд длительность\n` +
    `купленного баффа растёт на +${C.DONATE_STREAK_BONUS_HOURS_PER_DAY}ч сверху (максимум +${C.DONATE_STREAK_MAX_BONUS_HOURS}ч),\n` +
    `пропуск дня сбрасывает стрик.` +
    paymentFooter()
  );
}

function newText() {
  return (
    `🎉═══════ НОВЫЕ ВРЕМЕННЫЕ ТОВАРЫ ═══════🎉\n\n` +
    `${C.FARM_PRO_NAME} — ${C.FARM_PRO_PRICE_RUB_MONTH} ₽ / ${C.FARM_PRO_DURATION_DAYS} дней\n` +
    `    ▸ работает точь-в-точь как обычная майнинг-ферма (тот же уровень, автономность, курс продажи ₿), просто x${C.FARM_PRO_MULTIPLIER} к добыче, пока подписка активна\n` +
    `    ▸ стакается с временным ускорением фермы (см. вкладку 🔥 Дневные баффы) — вместе дают x${C.FARM_PRO_MULTIPLIER * C.DONATE_FARM_BOOST_MULTIPLIER}\n` +
    `    ▸ нужно продлевать каждые ${C.FARM_PRO_DURATION_DAYS} дней, статус и таймер: ферма\n\n` +
    `😎 Смайлик-статус у ника на ${C.DONATE_EMOJI_TAG_DURATION_DAYS} дн. — ${C.DONATE_EMOJI_TAG_PRICE_RUB} ₽\n` +
    `    ▸ косметика: свой эмодзи/тег рядом с ником в профиле, без игровых бонусов\n\n` +
    `🎓 x${C.DONATE_SCIENCE_BOOST_MULTIPLIER} науки с обмена жетонов на ${C.DONATE_SCIENCE_BOOST_DURATION_HOURS}ч — ${C.DONATE_SCIENCE_BOOST_PRICE_RUB} ₽\n` +
    `🍀 x${C.DONATE_STEAL_BOOST_MULTIPLIER} доля вора при «краже» на ${C.DONATE_STEAL_BOOST_DURATION_HOURS}ч — ${C.DONATE_STEAL_BOOST_PRICE_RUB} ₽\n` +
    `🎯 x${C.DONATE_PATROL_BOOST_MULTIPLIER} награда за «дозор» на ${C.DONATE_PATROL_BOOST_DURATION_HOURS}ч — ${C.DONATE_PATROL_BOOST_PRICE_RUB} ₽\n` +
    `🔍 x${C.DONATE_INSPECTION_BOOST_MULTIPLIER} награда за «инспекцию» на ${C.DONATE_INSPECTION_BOOST_DURATION_HOURS}ч — ${C.DONATE_INSPECTION_BOOST_PRICE_RUB} ₽\n` +
    `    ▸ стакается с VIP-бонусом на инспекцию (множители перемножаются)` +
    paymentFooter()
  );
}

const TOPIC_TEXT = {
  forever: foreverText,
  business: businessText,
  boosts: boostsText,
  daily: dailyText,
  new: newText,
};

async function handleDonate(ctx, topicArg) {
  const topic = isValidTopic(topicArg) ? topicArg : 'forever';
  let text = TOPIC_TEXT[topic]();

  if (topic === 'daily') {
    const flashOffer = await donateBuffs.getFlashOffer();
    if (flashOffer) {
      text +=
        `\n\n🎯═══════ СЕЙЧАС ИДЁТ ФЛЕШ-АКЦИЯ ═══════🎯\n` +
        `«${flashOffer.itemLabel}» со скидкой ${flashOffer.discountPercent}%!\n` +
        `Успей до ${msg.formatDateTimeMsk(flashOffer.expiresAt)} — подробности: акция`;
    }
    text +=
      `\n\n🎉 Также иногда проводятся бесплатные сезонные ивенты (зима/весна/лето/осень) — валюта капает\n` +
      `просто за игру, обменять её на заводы/науку/VIP можно в ивент-магазине. Подробнее: ивент`;
  }

  await ctx.send(images.withImage('donate', { message: text, keyboard: topicKeyboard(topic) }));
}

async function handleFlashOffer(ctx) {
  const flashOffer = await donateBuffs.getFlashOffer();
  if (!flashOffer) {
    await ctx.send('Сейчас никаких флеш-акций нет. Полный прайс-лист: донат');
    return;
  }
  await ctx.send(
    `🎯 ФЛЕШ-АКЦИЯ!\n\n` +
      `«${flashOffer.itemLabel}» со скидкой ${flashOffer.discountPercent}%\n` +
      `Успей до: ${msg.formatDateTimeMsk(flashOffer.expiresAt)}\n\n` +
      `Чтобы купить — напишите администратору (команда «донат» покажет ссылку и полный прайс-лист).`
  );
}

// "!донат бизнес" — статус ВСЕХ донат-бизнесов игрока (номер слота, тир, уровень, таймер до
// истечения, когда следующий еженедельный бонус) либо приглашение купить, если ничего не активно.
async function handleBusinessStatus(ctx) {
  const slots = await donateBusiness.getSlotsInfo(ctx.senderId);
  if (!slots) {
    await ctx.send('⛔ Вы ещё не зарегистрированы. Напишите !старт');
    return;
  }

  const list = await donateBusiness.listStatus(ctx.senderId);
  if (!list.length) {
    await ctx.send(
      `🏢 У вас сейчас нет ни одного донат-бизнеса.\n` +
        `Слотов доступно: ${slots.total} (${slots.base} бесплатный + ${slots.extra} доп.)\n` +
        `Посмотреть тиры и цены: донат\nКупить — напишите ${adminLinksText()}.`
    );
    return;
  }

  const blocks = list.map(({ slot, tier, level, until, weeklyAt }) => {
    const mult = donateBusiness.levelMultiplier(tier, level);
    const nextWeeklyMs = new Date(weeklyAt).getTime() + C.DONATE_BUSINESS_WEEKLY_DAYS * 24 * 60 * 60 * 1000;
    const rankSuffix = tier.permanent ? ` — ранг «${donateBusiness.eternalRankName(level)}»` : '';
    const untilLine = donateBusiness.isForever({ until }, tier)
      ? `    ⏳ Срок: НАВСЕГДА 👑`
      : `    ⏳ Активен до: ${msg.formatDateTimeMsk(until)}`;
    return (
      `№${slot} — ${tier.name} (уровень ${level}/${donateBusiness.maxLevelForTier(tier)}, x${mult} к доходу)${rankSuffix}\n` +
      `    📈 Пассивно: ${calc.formatNumber(Math.round(tier.hourlyVirtsMin * mult))}-${calc.formatNumber(
        Math.round(tier.hourlyVirtsMax * mult)
      )} вирт + ${Math.round(tier.hourlyTokens * mult)} жетонов/час\n` +
      `    🎁 Следующий бонус (+${Math.round(tier.weekly.amount * mult)} ${tier.weekly.label}): ${msg.formatDateTimeMsk(
        new Date(nextWeeklyMs)
      )}\n` +
      untilLine
    );
  });

  await ctx.send(
    `🏢 Ваши донат-бизнесы (${slots.used}/${slots.total} слотов занято):\n\n` +
      blocks.join('\n\n') +
      `\n\nПродлить/сменить тир, добавить слот или прокачать уровень — напишите администратору (см. «донат»).`
  );
}

module.exports = { handleDonate, handleFlashOffer, handleBusinessStatus };
