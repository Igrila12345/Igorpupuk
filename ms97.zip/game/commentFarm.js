'use strict';

// ===================== БОНУС ЗА КОММЕНТАРИЙ "ФАРМ" =====================
// Игрок пишет комментарий со словом "фарм" под постом сообщества — получает разовый
// бонус (см. C.COMMENT_FARM_* в game/constants.js). Срабатывает через VK Bots Long Poll
// событие wall_reply_new (см. bot.js: onWallReply, handlers/commentFarmHandlers.js) —
// ВАЖНО: в настройках сообщества (Управление → Работа с API → Long Poll API → Типы
// событий) должен быть включён пункт "Добавление комментария к записи", иначе VK вообще
// не пришлёт это событие боту, и код ниже никогда не вызовется.

const C = require('./constants');
const players = require('../db/players');
const commentFarmClaims = require('../db/commentFarmClaims');

// Ищем слово "фарм" как ОТДЕЛЬНОЕ слово (без учёта регистра), а не подстроку — иначе
// триггерились бы "выфармил", "фармить", "фармзона" и т.п. Границы слова — не
// кириллическая буква (или начало/конец строки) с обеих сторон; цифры/подчёркивание
// в кириллице не участвуют, поэтому обычная \b (латинская) для этого не подходит.
const FARM_WORD_RE = new RegExp(`(?:^|[^а-яёa-z])${C.COMMENT_FARM_TRIGGER_WORD}(?:[^а-яёa-z]|$)`, 'i');

function containsTrigger(text) {
  return FARM_WORD_RE.test(String(text || '').toLowerCase());
}

// vkId — автор комментария, postId — id поста (wall_reply_new: post_id), на который
// он оставлен. Возвращает { ok, reason? } либо { ok: true, virt, tokens } при успехе.
async function tryClaim(vkId, postId, commentText) {
  if (!containsTrigger(commentText)) {
    return { ok: false, reason: 'no_trigger' };
  }

  const player = await players.getPlayer(vkId);
  if (!player || player.registration_step !== 'done') {
    return { ok: false, reason: 'not_registered' };
  }

  // Атомарная проверка "уже получал бонус под этим постом" — см. комментарий в
  // db/commentFarmClaims.js: одного запроса достаточно, отдельный SELECT не нужен.
  const claimed = await commentFarmClaims.tryClaim(vkId, postId);
  if (!claimed) {
    return { ok: false, reason: 'already_claimed' };
  }

  await players.updateBalance(vkId, C.COMMENT_FARM_VIRT_REWARD);
  await players.addTokens(vkId, C.COMMENT_FARM_TOKEN_REWARD);

  return { ok: true, virt: C.COMMENT_FARM_VIRT_REWARD, tokens: C.COMMENT_FARM_TOKEN_REWARD };
}

module.exports = { tryClaim, containsTrigger };
