-- ===================== СХЕМА БАЗЫ ДАННЫХ =====================

CREATE TABLE IF NOT EXISTS players (
    vk_id BIGINT PRIMARY KEY,
    state_name TEXT UNIQUE,               -- название государства
    x INTEGER,                            -- координата X
    y INTEGER,                            -- координата Y
    balance BIGINT NOT NULL DEFAULT 100,  -- вирты
    factories INTEGER NOT NULL DEFAULT 0, -- количество активных (не уничтоженных) заводов
    gold_mines INTEGER[] DEFAULT '{}',    -- индексы заводов "золотая жила" (условно, храним как счётчик ниже)
    gold_mine_count INTEGER NOT NULL DEFAULT 0, -- сколько из заводов — золотые жилы (x2 дохода)
    destroyed_factories INTEGER NOT NULL DEFAULT 0, -- статистика: сколько заводов у игрока снесли навсегда (восстановление отключено)
    arsenal JSONB NOT NULL DEFAULT '{}',        -- {"Герань-2": 3, "Калибр": 1}
    air_defense JSONB NOT NULL DEFAULT '{}',    -- {"Бук-М3": 1}
    air_defense_damage JSONB NOT NULL DEFAULT '{}', -- накопленный урон по "прочности" текущей единицы ПВО каждого типа, см. AIR_DEFENSE.durability
    blocked_factories JSONB NOT NULL DEFAULT '[]', -- [{"count": 3, "unblock_at": "ISO"}]
    radiation_until TIMESTAMPTZ,           -- радиация действует до
    clan_id INTEGER,
    clan_role TEXT,                        -- 'leader' | 'member'
    registration_step TEXT NOT NULL DEFAULT 'done', -- 'awaiting_name' | 'done'
    factory_damage INTEGER NOT NULL DEFAULT 0, -- накопленные "единицы урона" по заводам для системы ХП (см. HITS_TO_DESTROY)
    enemy_factories_destroyed INTEGER NOT NULL DEFAULT 0, -- статистика: сколько вражеских заводов снёс безвозвратно
    last_daily_bonus TIMESTAMPTZ,          -- когда последний раз забирали ежедневный бонус
    vip_until TIMESTAMPTZ,                 -- VIP-статус активен до этой даты (донат-бонусы)
    robot_level INTEGER NOT NULL DEFAULT 1,        -- уровень робота (1-50)
    robot_last_farm_at TIMESTAMPTZ,                -- когда робот последний раз мгновенно приносил вирты (команда "робот")
    robot_last_send_at TIMESTAMPTZ,                -- когда робота последний раз "отправляли" за жетонами (команда "отправить")
    last_seen TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    profile_photo TEXT,                    -- кастомное фото профиля, выдаётся админом (attachment-строка VK)
    profile_video TEXT,                    -- кастомное видео профиля, выдаётся админом (attachment-строка VK)
    patrol_last_at TIMESTAMPTZ             -- когда последний раз выполнялся "дозор" (короткий КД-филлер)
);

CREATE INDEX IF NOT EXISTS idx_players_factories ON players (factories DESC);
CREATE INDEX IF NOT EXISTS idx_players_balance ON players (balance DESC);
-- Ускоряет economy.processRadiationExpiry (минутный cron), который ищет игроков
-- с истёкшей радиацией. Частичный индекс — не занимает место для игроков без радиации.
CREATE INDEX IF NOT EXISTS idx_players_radiation_until
  ON players (radiation_until) WHERE radiation_until IS NOT NULL;
-- Ускоряет players.getPlayersWithBlockedFactories (минутный тик processFactoryUnblocks):
-- у подавляющего большинства игроков blocked_factories = '[]', индекс позволяет находить
-- редкие непустые записи, не сканируя всю таблицу.
CREATE INDEX IF NOT EXISTS idx_players_blocked_factories
  ON players (vk_id) WHERE blocked_factories <> '[]'::jsonb;

-- Восстановление заводов отключено, таблица больше не используется в новой логике,
-- но оставлена для обратной совместимости со старыми БД (данные не удаляются).
CREATE TABLE IF NOT EXISTS destroyed_factories (
    id SERIAL PRIMARY KEY,
    player_id BIGINT NOT NULL REFERENCES players(vk_id) ON DELETE CASCADE,
    destroyed_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    restore_at TIMESTAMPTZ NOT NULL
);

-- Клановые данные
CREATE TABLE IF NOT EXISTS clans (
    id SERIAL PRIMARY KEY,
    name TEXT UNIQUE NOT NULL,
    leader_id BIGINT NOT NULL REFERENCES players(vk_id),
    vault BIGINT NOT NULL DEFAULT 0,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    bonus_forsazh_until TIMESTAMPTZ,
    bonus_eshelon_until TIMESTAMPTZ,
    bonus_industry_until TIMESTAMPTZ,
    bonus_forsazh_cooldown TIMESTAMPTZ,
    bonus_eshelon_cooldown TIMESTAMPTZ,
    bonus_industry_cooldown TIMESTAMPTZ,
    clan_photo TEXT,                       -- кастомное фото клана, выдаёт глава клана (attachment-строка VK)
    clan_video TEXT                        -- кастомное видео клана, выдаёт глава клана (attachment-строка VK)
);

-- Приглашения в клан
CREATE TABLE IF NOT EXISTS clan_invites (
    id SERIAL PRIMARY KEY,
    clan_id INTEGER NOT NULL REFERENCES clans(id) ON DELETE CASCADE,
    player_id BIGINT NOT NULL REFERENCES players(vk_id) ON DELETE CASCADE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE(clan_id, player_id)
);

-- Очереди производства
CREATE TABLE IF NOT EXISTS production_queue (
    id SERIAL PRIMARY KEY,
    player_id BIGINT NOT NULL REFERENCES players(vk_id) ON DELETE CASCADE,
    weapon TEXT NOT NULL,
    quantity INTEGER NOT NULL,
    factories_used INTEGER NOT NULL,
    started_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    ready_at TIMESTAMPTZ NOT NULL,
    collected BOOLEAN NOT NULL DEFAULT FALSE
);
-- Ускоряет: getFactoriesInUse/getReady/getPending (db/production.js), которые дёргаются
-- на каждого игрока в часовом тике (game/economy.js) и на каждую команду производства/сбора.
-- Без индекса это последовательное сканирование всей таблицы на каждый такой запрос.
CREATE INDEX IF NOT EXISTS idx_production_queue_player_collected
  ON production_queue (player_id, collected);
CREATE INDEX IF NOT EXISTS idx_production_queue_collected_ready
  ON production_queue (collected, ready_at) WHERE collected = FALSE;

-- Атаки в полёте
CREATE TABLE IF NOT EXISTS attacks_in_flight (
    id SERIAL PRIMARY KEY,
    attacker_id BIGINT NOT NULL REFERENCES players(vk_id) ON DELETE CASCADE,
    defender_id BIGINT NOT NULL REFERENCES players(vk_id) ON DELETE CASCADE,
    weapon TEXT NOT NULL,
    quantity INTEGER NOT NULL,
    distance_km NUMERIC NOT NULL,
    launched_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    arrival_at TIMESTAMPTZ NOT NULL,
    resolved BOOLEAN NOT NULL DEFAULT FALSE,
    peer_id BIGINT -- id беседы для глобального лога, если атака была инициирована из беседы (иначе NULL)
);
-- Ускоряет минутный тик attackResolver.resolvePendingAttacks (db/combat.js: getPendingAttacks/
-- getUnresolvedAttacks), который сканирует эту таблицу каждую минуту фоновым cron-заданием.
CREATE INDEX IF NOT EXISTS idx_attacks_in_flight_resolved_arrival
  ON attacks_in_flight (resolved, arrival_at) WHERE resolved = FALSE;

-- Кулдауны атак на конкретную цель
CREATE TABLE IF NOT EXISTS attack_cooldowns (
    attacker_id BIGINT NOT NULL REFERENCES players(vk_id) ON DELETE CASCADE,
    defender_id BIGINT NOT NULL REFERENCES players(vk_id) ON DELETE CASCADE,
    last_attack_at TIMESTAMPTZ NOT NULL,
    PRIMARY KEY (attacker_id, defender_id)
);

-- Кулдауны переводов вирт одному и тому же игроку (1 раз в 2 часа на получателя)
CREATE TABLE IF NOT EXISTS transfer_cooldowns (
    sender_id BIGINT NOT NULL REFERENCES players(vk_id) ON DELETE CASCADE,
    receiver_id BIGINT NOT NULL REFERENCES players(vk_id) ON DELETE CASCADE,
    last_transfer_at TIMESTAMPTZ NOT NULL,
    PRIMARY KEY (sender_id, receiver_id)
);

-- Лог построек заводов, для лимита "не более 10 заводов в час"
CREATE TABLE IF NOT EXISTS factory_build_log (
    id SERIAL PRIMARY KEY,
    player_id BIGINT NOT NULL REFERENCES players(vk_id) ON DELETE CASCADE,
    built_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_factory_build_log_player_time ON factory_build_log (player_id, built_at);

-- На случай если таблица players уже существовала до добавления новых колонок (миграция)
ALTER TABLE players ADD COLUMN IF NOT EXISTS factory_damage INTEGER NOT NULL DEFAULT 0;
ALTER TABLE players ADD COLUMN IF NOT EXISTS last_daily_bonus TIMESTAMPTZ;
ALTER TABLE players ADD COLUMN IF NOT EXISTS enemy_factories_destroyed INTEGER NOT NULL DEFAULT 0;

-- ===================== РОБОТ (переработан, старый питомец-майнер удалён) =====================
-- Раньше был "питомец": запускался в добычу, доход копился и его нужно было забирать отдельной
-- командой. Новый робот работает мгновенно: команда "робот" сразу зачисляет доход (раз в час),
-- а "отправить" сразу выдаёт жетоны (тоже раз в час). Переносим уровень со старой колонки
-- pet_level в robot_level, если апгрейд идёт со старой БД, и убираем колонки старого механизма
-- добычи, которые больше не используются.
DO $$
BEGIN
  IF EXISTS (
    SELECT 1 FROM information_schema.columns WHERE table_name = 'players' AND column_name = 'pet_level'
  ) AND NOT EXISTS (
    SELECT 1 FROM information_schema.columns WHERE table_name = 'players' AND column_name = 'robot_level'
  ) THEN
    ALTER TABLE players RENAME COLUMN pet_level TO robot_level;
  END IF;
END $$;
ALTER TABLE players ADD COLUMN IF NOT EXISTS robot_level INTEGER NOT NULL DEFAULT 1;
ALTER TABLE players ADD COLUMN IF NOT EXISTS robot_last_farm_at TIMESTAMPTZ;
ALTER TABLE players ADD COLUMN IF NOT EXISTS robot_last_send_at TIMESTAMPTZ;
-- Кулдаун боевой атаки прокачанного робота-питомца (открывается с ROBOT_FACTORY_DESTROY_UNLOCK_LEVEL,
-- см. game/robot.js / handlers/robotHandlers.js). Отдельное поле от super_robot_last_attack_at ниже.
ALTER TABLE players ADD COLUMN IF NOT EXISTS robot_last_attack_at TIMESTAMPTZ;
ALTER TABLE players DROP COLUMN IF EXISTS pet_mining_started_at;
ALTER TABLE players DROP COLUMN IF EXISTS pet_last_collected_at;

-- Магазин (текущий ассортимент)
CREATE TABLE IF NOT EXISTS shop_state (
    id INTEGER PRIMARY KEY DEFAULT 1,
    items JSONB NOT NULL DEFAULT '[]', -- [{"key": "Герань-2", "type": "weapon", "qty": 3}]
    refreshed_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    locked_until TIMESTAMPTZ -- блокировка магазина после покупки ядерки
);

INSERT INTO shop_state (id, items) VALUES (1, '[]') ON CONFLICT (id) DO NOTHING;

-- Глобальный peer_id беседы для трансляции логов (если бот добавлен в беседу)
CREATE TABLE IF NOT EXISTS broadcast_chats (
    peer_id BIGINT PRIMARY KEY
);

-- Метаданные (последний раз выданы ежедневные награды и т.п.)
CREATE TABLE IF NOT EXISTS game_meta (
    key TEXT PRIMARY KEY,
    value TEXT
);

-- ===================== НОВЫЕ МЕХАНИКИ =====================

-- Работа и жетоны (мгновенная награда через мини-игру)
ALTER TABLE players ADD COLUMN IF NOT EXISTS tokens INTEGER NOT NULL DEFAULT 0;
ALTER TABLE players DROP COLUMN IF EXISTS work_started_at; -- механика ожидания смены удалена
ALTER TABLE players ADD COLUMN IF NOT EXISTS last_work_time TIMESTAMPTZ;
ALTER TABLE players ADD COLUMN IF NOT EXISTS work_count_today INTEGER NOT NULL DEFAULT 0;
ALTER TABLE players ADD COLUMN IF NOT EXISTS work_day DATE;
-- Текущая сессия мини-игры "работа": {round, boxes, correctIndex, expiresAt}, NULL если игра не идёт
ALTER TABLE players ADD COLUMN IF NOT EXISTS work_session JSONB;

-- Инспекция — вторая, отдельная мини-игра (не заменяет "работу", а дополняет её отдельным
-- дневным лимитом/кулдауном): найти "аномальный" значок в сетке. Награда — вирты, а не жетоны,
-- чтобы это была самостоятельная активность, а не дубликат работы. См. game/inspection.js.
ALTER TABLE players ADD COLUMN IF NOT EXISTS last_inspection_time TIMESTAMPTZ;
ALTER TABLE players ADD COLUMN IF NOT EXISTS inspection_count_today INTEGER NOT NULL DEFAULT 0;
ALTER TABLE players ADD COLUMN IF NOT EXISTS inspection_day DATE;
-- Текущая сессия "инспекции": {round, cells, anomalyIndex, expiresAt}, NULL если игра не идёт
ALTER TABLE players ADD COLUMN IF NOT EXISTS inspection_session JSONB;

-- Мировой босс: личный дневной лимит ракет "Орешник" на игрока (глобальное состояние
-- самого босса — счётчики попаданий/промахов/участников — хранится не в players, а в
-- game_meta под ключом BOSS_META_KEY, см. game/boss.js).
ALTER TABLE players ADD COLUMN IF NOT EXISTS last_boss_launch_time TIMESTAMPTZ;
ALTER TABLE players ADD COLUMN IF NOT EXISTS boss_launch_count_today INTEGER NOT NULL DEFAULT 0;
ALTER TABLE players ADD COLUMN IF NOT EXISTS boss_launch_day DATE;
-- Донат-бафф x2 к награде за попадание по боссу — продаётся только на 1 день (см. DONATE_BOSS_DOUBLE_*)
ALTER TABLE players ADD COLUMN IF NOT EXISTS boss_double_until TIMESTAMPTZ;

-- Кража у топ-5 (см. game/steal.js): личный дневной лимит попыток + КД между попытками.
ALTER TABLE players ADD COLUMN IF NOT EXISTS last_steal_at TIMESTAMPTZ;
ALTER TABLE players ADD COLUMN IF NOT EXISTS steal_count_today INTEGER NOT NULL DEFAULT 0;
ALTER TABLE players ADD COLUMN IF NOT EXISTS steal_day DATE;

-- Дневные лимиты обмена жетонов (склад-"кейс" и обмен на заводы), сбрасываются
-- в 00:00 МСК по тому же принципу, что и work_count_today/work_day выше.
ALTER TABLE players ADD COLUMN IF NOT EXISTS exchange_factory_count_today INTEGER NOT NULL DEFAULT 0;
ALTER TABLE players ADD COLUMN IF NOT EXISTS exchange_factory_day DATE;
ALTER TABLE players ADD COLUMN IF NOT EXISTS exchange_case_count_today INTEGER NOT NULL DEFAULT 0;
ALTER TABLE players ADD COLUMN IF NOT EXISTS exchange_case_day DATE;
ALTER TABLE players ADD COLUMN IF NOT EXISTS exchange_science_count_today INTEGER NOT NULL DEFAULT 0;
ALTER TABLE players ADD COLUMN IF NOT EXISTS exchange_science_day DATE;

-- Обратный обмен: научные центры -> заводы (game/science.js exchangeToFactories), тот же
-- принцип сброса в 00:00 МСК, что и остальные дневные лимиты обмена выше.
ALTER TABLE players ADD COLUMN IF NOT EXISTS exchange_science_to_factory_count_today INTEGER NOT NULL DEFAULT 0;
ALTER TABLE players ADD COLUMN IF NOT EXISTS exchange_science_to_factory_day DATE;

-- Реферальная программа: кто пригласил + начислена ли уже награда
ALTER TABLE players ADD COLUMN IF NOT EXISTS referred_by BIGINT;
ALTER TABLE players ADD COLUMN IF NOT EXISTS referral_rewarded BOOLEAN NOT NULL DEFAULT FALSE;

-- Научные центры
ALTER TABLE players ADD COLUMN IF NOT EXISTS science_centers INTEGER NOT NULL DEFAULT 0;
ALTER TABLE players ADD COLUMN IF NOT EXISTS science_limit_level INTEGER NOT NULL DEFAULT 1;

-- Торговые посты — механика удалена, колонка вычищается из старых БД
ALTER TABLE players DROP COLUMN IF EXISTS trade_post_level;

-- Расширение лимита заводов
ALTER TABLE players ADD COLUMN IF NOT EXISTS factory_limit_level INTEGER NOT NULL DEFAULT 0;

-- Аукцион между игроками
CREATE TABLE IF NOT EXISTS auctions (
    id SERIAL PRIMARY KEY,
    seller_id BIGINT NOT NULL REFERENCES players(vk_id) ON DELETE CASCADE,
    item_type TEXT NOT NULL,        -- 'weapon' | 'air_defense' | 'factory' | 'science'
    item_name TEXT NOT NULL,
    quantity INTEGER NOT NULL,
    start_price BIGINT NOT NULL,
    min_step BIGINT NOT NULL,
    end_time TIMESTAMPTZ NOT NULL,
    current_bid BIGINT,
    current_bidder_id BIGINT REFERENCES players(vk_id),
    status TEXT NOT NULL DEFAULT 'active', -- 'active' | 'completed' | 'cancelled'
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_auctions_status ON auctions (status, end_time);

-- Лот-стиль (item_type = 'style'): ссылка на конкретный стиль в player_styles (без FK-констрейнта,
-- т.к. таблица player_styles объявлена ниже по файлу — порядок ALTER важен при первом запуске).
-- Только админ может создавать такие лоты (см. game/auction.js: createStyleLot / handlers/adminHandlers.js:
-- 'аукционстиль') — стиль создаётся сразу при выставлении лота, а не берётся из чьего-то инвентаря.
ALTER TABLE auctions ADD COLUMN IF NOT EXISTS style_id INTEGER;

-- Промокоды
CREATE TABLE IF NOT EXISTS promocodes (
    code TEXT PRIMARY KEY,
    reward_type TEXT NOT NULL,      -- 'weapon' | 'air_defense' | 'virts' | 'tokens' | 'science'
    reward_name TEXT,               -- название оружия/ПВО (для остальных типов не нужно)
    reward_quantity INTEGER NOT NULL DEFAULT 1,
    max_uses INTEGER NOT NULL DEFAULT 1,
    used_count INTEGER NOT NULL DEFAULT 0,
    expires_at TIMESTAMPTZ,
    -- Если TRUE — активировать промокод может только игрок с активным VIP-статусом на момент
    -- активации (см. calc.isVipActive() в game/promo.js: redeem()). Задаётся при создании
    -- админом: промо создать ... vip
    vip_only BOOLEAN NOT NULL DEFAULT FALSE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
ALTER TABLE promocodes ADD COLUMN IF NOT EXISTS vip_only BOOLEAN NOT NULL DEFAULT FALSE;

-- Кто уже активировал какой промокод (1 раз на игрока)
CREATE TABLE IF NOT EXISTS promocode_redemptions (
    code TEXT NOT NULL REFERENCES promocodes(code) ON DELETE CASCADE,
    player_id BIGINT NOT NULL REFERENCES players(vk_id) ON DELETE CASCADE,
    redeemed_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    PRIMARY KEY (code, player_id)
);

-- Кулдауны запуска оружия по категориям (не привязаны к цели — см. game/combat.js)
ALTER TABLE players ADD COLUMN IF NOT EXISTS last_drone_attack_at TIMESTAMPTZ;
ALTER TABLE players ADD COLUMN IF NOT EXISTS last_missile_attack_at TIMESTAMPTZ;
ALTER TABLE players ADD COLUMN IF NOT EXISTS last_nuke_attack_at TIMESTAMPTZ;

-- Возможность отключить общую рассылку "кто-кого атаковал", которая приходит всем игрокам
ALTER TABLE players ADD COLUMN IF NOT EXISTS attack_log_notifications BOOLEAN NOT NULL DEFAULT TRUE;

-- ===================== VIP (донат-статус) =====================
-- Действует до этой даты; NULL / прошедшая дата = VIP не активен.
-- Выдаётся вручную админом после оплаты (см. !админ vip). Даёт бонус к доходу,
-- ускоренные кулдауны робота и увеличенный лимит построек в час — см. game/calc.js, game/robot.js, game/economy.js.
ALTER TABLE players ADD COLUMN IF NOT EXISTS vip_until TIMESTAMPTZ;

-- ===================== ЗАЩИТА ОТ КРАЖИ (отдельная донат-подписка, НЕ часть VIP) =====================
-- Действует до этой даты; NULL / прошедшая дата = защита не активна. Пока активна — у
-- игрока нельзя украсть баланс (см. game/steal.js: attemptSteal, calc.isStealProtectionActive).
-- Выдаётся вручную админом после оплаты (см. !админ кражазащита), отдельно от VIP —
-- своя цена и свой срок, покупается и продлевается независимо.
ALTER TABLE players ADD COLUMN IF NOT EXISTS steal_protection_until TIMESTAMPTZ;

-- ===================== БОНУС НОВИЧКА — ОДНОРАЗОВЫЙ =====================
-- TRUE = игрок УЖЕ достигал порога «не новичок» (заводы + наука*10 >= 150), бонус к доходу
-- для него отключён НАВСЕГДА и не возвращается, даже если заводов/науки станет меньше
-- (снесли в войне, продал и т.д.). См. game/calc.js: isNewbieBoostActive и
-- game/economy.js: syncNewbieBoostFlag, который выставляет флаг при пересечении порога.
ALTER TABLE players ADD COLUMN IF NOT EXISTS newbie_boost_ended BOOLEAN NOT NULL DEFAULT FALSE;

-- Разово помечаем всех, кто на момент миграции уже за порогом — чтобы им бонус не «вернулся»
-- после первого же падения числа заводов ниже 150.
UPDATE players
   SET newbie_boost_ended = TRUE
 WHERE newbie_boost_ended = FALSE
   AND (factories + COALESCE(science_centers, 0) * 10) >= 150;


-- ===================== МАЙНЕР (донат-предмет) =====================
-- Действует до этой даты; NULL / прошедшая дата = майнер не активен. Выдаётся вручную админом
-- после оплаты (см. !админ майнер), аналогично VIP. Пока активен — раз в час пассивно
-- начисляет немного вирт и с шансом жетон (см. game/miner.js, game/constants.js).
ALTER TABLE players ADD COLUMN IF NOT EXISTS miner_until TIMESTAMPTZ;
-- Прокачка майнера (0-15, см. MINER_MAX_LEVEL) — поднимает жетоны/час, см. game/miner.js
ALTER TABLE players ADD COLUMN IF NOT EXISTS miner_level INTEGER NOT NULL DEFAULT 0;

-- ===================== СУПЕРРОБОТ =====================
-- Отдельный от обычного робота боевой юнит (50 уровней, качается жетонами, тяжело).
-- 0 = ещё не построен/не прокачан ни разу. Умеет атаковать других игроков (снос заводов),
-- в отличие от обычного робота. См. game/superRobot.js.
ALTER TABLE players ADD COLUMN IF NOT EXISTS super_robot_level INTEGER NOT NULL DEFAULT 0;
ALTER TABLE players ADD COLUMN IF NOT EXISTS super_robot_last_attack_at TIMESTAMPTZ;

-- Система "прочности" ПВО (см. game/constants.js: AIR_DEFENSE.durability, WEAPONS.*.adWear):
-- накопленный урон по текущей "изнашиваемой" единице ПВО каждого типа. Когда накопленный
-- урон достигает durability этого типа ПВО — одна физическая единица реально уничтожается.
ALTER TABLE players ADD COLUMN IF NOT EXISTS air_defense_damage JSONB NOT NULL DEFAULT '{}';

-- Уровень сейфа клана: копится от ВСЕХ поступлений в сейф (налог с дохода + ручные пополнения)
-- и никогда не уменьшается тратами/снятием — это "прогресс" клана, а не баланс.
-- vault_total_collected — сколько всего когда-либо поступило в сейф (нарастающим итогом).
-- vault_level — текущий уровень (0-100), кэш от vault_total_collected / 10000, обновляется при пополнении.
ALTER TABLE clans ADD COLUMN IF NOT EXISTS vault_total_collected BIGINT NOT NULL DEFAULT 0;
ALTER TABLE clans ADD COLUMN IF NOT EXISTS vault_level INTEGER NOT NULL DEFAULT 0;

-- Часовые лимиты производства/получения оружия и ПВО (см. game/hourlyLimit.js).
-- Счётчик хранится "по часовому окну": hour_bucket = date_trunc('hour', NOW()) на момент
-- последнего расхода. Если текущий час не совпадает с hour_bucket — счётчик считается нулевым
-- (сброс не требует отдельной cron-задачи, просто игнорируем устаревшее значение при чтении/записи).
CREATE TABLE IF NOT EXISTS hourly_production_limits (
    player_id BIGINT NOT NULL REFERENCES players(vk_id) ON DELETE CASCADE,
    category TEXT NOT NULL, -- 'drone' | 'missile' | 'nuke' | 'air_defense'
    hour_bucket TIMESTAMPTZ NOT NULL,
    quantity INTEGER NOT NULL DEFAULT 0,
    PRIMARY KEY (player_id, category)
);

-- Кастомные фото/видео профиля, выдаваемые админом (VK attachment-строка вида
-- "photo-123456_789" / "video-123456_789"). Показывается в !профиль этого игрока
-- (если задано и фото, и видео — приоритет у фото). NULL — ничего не показывать.
-- Это поля "ТЕКУЩЕГО ЭКИПИРОВАННОГО" стиля — фактическая коллекция стилей игрока
-- лежит в таблице player_styles ниже (см. game/styles.js).
ALTER TABLE players ADD COLUMN IF NOT EXISTS profile_photo TEXT;
ALTER TABLE players ADD COLUMN IF NOT EXISTS profile_video TEXT;
ALTER TABLE clans ADD COLUMN IF NOT EXISTS clan_photo TEXT;
ALTER TABLE clans ADD COLUMN IF NOT EXISTS clan_video TEXT;

-- ===================== ИНВЕНТАРЬ СТИЛЕЙ (см. game/styles.js) =====================
-- Каждая выданная/купленная "стилевая" картинка/видео — отдельная строка. Игрок может
-- владеть несколькими стилями сразу и переключаться между ними командой "стиль выбрать".
CREATE TABLE IF NOT EXISTS player_styles (
    id SERIAL PRIMARY KEY,
    owner_vk_id BIGINT NOT NULL REFERENCES players(vk_id) ON DELETE CASCADE,
    kind TEXT NOT NULL CHECK (kind IN ('photo', 'video')),
    attachment TEXT NOT NULL,
    -- forced = true: стиль поставлен админом принудительно (!админ стильфикс) — владелец
    -- не может его продать или переключиться на другой, пока админ не снимет фиксацию.
    forced BOOLEAN NOT NULL DEFAULT false,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_player_styles_owner ON player_styles(owner_vk_id);

-- Ссылка на СЕЙЧАС экипированный стиль из player_styles (NULL — обычное оформление профиля
-- без кастомного фото/видео). style_locked = true, пока активен принудительный (forced) стиль —
-- в этом состоянии "стиль выбрать"/"стиль продать" полностью заблокированы для игрока.
ALTER TABLE players ADD COLUMN IF NOT EXISTS active_style_id INTEGER REFERENCES player_styles(id) ON DELETE SET NULL;
ALTER TABLE players ADD COLUMN IF NOT EXISTS style_locked BOOLEAN NOT NULL DEFAULT false;

-- Витрина стилей — игроки выставляют СВОИ стили на продажу за вирты другим игрокам.
CREATE TABLE IF NOT EXISTS style_listings (
    id SERIAL PRIMARY KEY,
    style_id INTEGER NOT NULL REFERENCES player_styles(id) ON DELETE CASCADE,
    seller_vk_id BIGINT NOT NULL,
    price INTEGER NOT NULL CHECK (price > 0),
    listed_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_style_listings_style ON style_listings(style_id);


-- Дозор: короткий (15 мин) филлер-экшен между часовыми КД робота — см. game/patrol.js
ALTER TABLE players ADD COLUMN IF NOT EXISTS patrol_last_at TIMESTAMPTZ;

-- Сезонные ивенты: единая ивент-валюта (эмодзи/название зависят от текущего активного сезона,
-- см. game/constants.js: EVENT_SEASONS, game/events.js). Активный сезон и статус ивент-магазина
-- (открыт/закрыт) хранятся в game_meta (ключи 'active_event' и 'event_shop_open') — отдельной
-- таблицы не требуется.
ALTER TABLE players ADD COLUMN IF NOT EXISTS event_currency INTEGER NOT NULL DEFAULT 0;

-- ===================== МАЙНИНГ-ФЕРМА =====================
-- Отдельная от донат-майнера (miner_until выше) механика: игрок строит и прокачивает ферму за
-- вирты (0 = не построена, максимум FARM_MAX_LEVEL = 999 — качается тяжело, см. game/constants.js).
-- Ферма копит ₿ НЕПРЕРЫВНО в реальном времени, пока включена (см. game/farm.js: считается "на лету"
-- по разнице времени, без почасового планировщика):
--   farm_enabled       — включена ли добыча прямо сейчас (переключается кнопкой/командой).
--   farm_balance       — накопленный на самой ферме баланс ₿, ещё не снятый игроком; заморожен
--                         (не растёт), пока farm_enabled = false.
--   farm_since_at      — момент, с которого считается текущий отрезок непрерывной добычи; сбрасывается
--                         при каждом включении фермы. Текущий баланс = farm_balance + ставка/час *
--                         часы с farm_since_at, но не больше потолка ставка/час * FARM_AUTONOMY_HOURS —
--                         по достижении потолка ферма считается автоматически выключенной ("Автономность" = 0).
-- farm_coins — ЛИЧНЫЙ кошелёк уже СНЯТЫХ ₿ (командой/кнопкой «Снять»), из которого они продаются
-- за вирты по плавающему курсу (см. ключ farm_exchange_rate в game_meta, обновляется раз в час).
-- farm_cycle_started_at / farm_cycle_ticks — легаси-поля старой (циклической) механики добычи,
-- больше не используются игровой логикой, оставлены в схеме, чтобы не терять историю на старых БД.
ALTER TABLE players ADD COLUMN IF NOT EXISTS farm_level INTEGER NOT NULL DEFAULT 0;
ALTER TABLE players ADD COLUMN IF NOT EXISTS farm_coins BIGINT NOT NULL DEFAULT 0;
ALTER TABLE players ADD COLUMN IF NOT EXISTS farm_cycle_started_at TIMESTAMPTZ;
ALTER TABLE players ADD COLUMN IF NOT EXISTS farm_cycle_ticks INTEGER NOT NULL DEFAULT 0;
ALTER TABLE players ADD COLUMN IF NOT EXISTS farm_enabled BOOLEAN NOT NULL DEFAULT FALSE;
ALTER TABLE players ADD COLUMN IF NOT EXISTS farm_balance BIGINT NOT NULL DEFAULT 0;
ALTER TABLE players ADD COLUMN IF NOT EXISTS farm_since_at TIMESTAMPTZ;
CREATE INDEX IF NOT EXISTS idx_players_farm_level ON players (farm_level DESC);

-- Прокачка обычной фермы за ЖЕТОНЫ (см. game/constants.js: FARM_TOKEN_BOOST_*, game/farm.js:
-- tokenBoostMultiplier/tokenUpgradeCost) — отдельный счётчик от farm_level выше (тот качается
-- за вирты и двигает "главную" ставку добычи). Каждый уровень здесь даёт фиксированные +3%
-- к итоговой ставке ₿/час, множитель мультипликативный к остальным (Турбоферма/буст).
ALTER TABLE players ADD COLUMN IF NOT EXISTS farm_token_level SMALLINT NOT NULL DEFAULT 0;

-- ===================== РАСХОДУЕМЫЕ ДОНАТ-БАФФЫ (см. game/constants.js: DONATE_*, game/donateBuffs.js) =====================
-- Все поля ниже — истекающие по времени баффы (кроме work_bonus_attempts_today, который
-- сгорает вместе с обычным дневным лимитом "работы"). Проверяются точно так же, как
-- vip_until/miner_until выше — "until > NOW()" в момент использования, без отдельного
-- планировщика на истечение.
ALTER TABLE players ADD COLUMN IF NOT EXISTS income_boost_until TIMESTAMPTZ;
ALTER TABLE players ADD COLUMN IF NOT EXISTS income_boost_mult NUMERIC(4,2);
ALTER TABLE players ADD COLUMN IF NOT EXISTS shield_until TIMESTAMPTZ; -- защита заводов от НЕядерного оружия (см. game/combat.js)
ALTER TABLE players ADD COLUMN IF NOT EXISTS work_double_until TIMESTAMPTZ; -- x2 жетонов за "работу"
ALTER TABLE players ADD COLUMN IF NOT EXISTS farm_boost_until TIMESTAMPTZ; -- ускоренная добыча на ферме
-- ⚡ Турбоферма (донат-подписка, x${FARM_PRO_MULTIPLIER} к ставке добычи, см. game/farm.js) — отдельно от
-- разового временного буста farm_boost_until выше, продлевается как VIP/донат-бизнесы.
ALTER TABLE players ADD COLUMN IF NOT EXISTS farm_pro_until TIMESTAMPTZ;

-- Новые расходуемые донат-товары (см. game/constants.js: DONATE_EMOJI_TAG_*/DONATE_SCIENCE_BOOST_*/
-- DONATE_STEAL_BOOST_*/DONATE_PATROL_BOOST_*/DONATE_INSPECTION_BOOST_*, game/donateBuffs.js)
ALTER TABLE players ADD COLUMN IF NOT EXISTS emoji_tag TEXT; -- косметический смайлик/тег рядом с ником в профиле
ALTER TABLE players ADD COLUMN IF NOT EXISTS emoji_tag_until TIMESTAMPTZ;
ALTER TABLE players ADD COLUMN IF NOT EXISTS science_boost_until TIMESTAMPTZ; -- x2 науки с обмена жетонов
ALTER TABLE players ADD COLUMN IF NOT EXISTS steal_boost_until TIMESTAMPTZ; -- x2 доля вора при краже
ALTER TABLE players ADD COLUMN IF NOT EXISTS patrol_boost_until TIMESTAMPTZ; -- x2 награда за дозор
ALTER TABLE players ADD COLUMN IF NOT EXISTS inspection_boost_until TIMESTAMPTZ; -- x2 награда за инспекцию
ALTER TABLE players ADD COLUMN IF NOT EXISTS work_bonus_attempts_today INTEGER NOT NULL DEFAULT 0; -- доп. попытки "работы" сверх лимита, сбрасывается вместе с work_count_today

-- Стрик покупки дневных баффов (доход/щит/дубль/ускорение) день в день по МСК — см.
-- DONATE_STREAK_* в game/constants.js и game/donateBuffs.js.
ALTER TABLE players ADD COLUMN IF NOT EXISTS donate_streak INTEGER NOT NULL DEFAULT 0;
ALTER TABLE players ADD COLUMN IF NOT EXISTS donate_streak_date DATE;

-- ===================== ЛОГИ СНЯТИЙ ИЗ СЕЙФА КЛАНА (см. db/clans.js, game/clan.js) =====================
-- Доступны главе и заму клана через "клан сейф логи": кто, сколько и когда снял.
CREATE TABLE IF NOT EXISTS clan_vault_logs (
  id SERIAL PRIMARY KEY,
  clan_id INTEGER NOT NULL REFERENCES clans(id) ON DELETE CASCADE,
  vk_id BIGINT NOT NULL,
  amount BIGINT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_clan_vault_logs_clan ON clan_vault_logs (clan_id, created_at DESC);

-- ===================== ЕЖЕДНЕВНЫЕ ЗАДАНИЯ И КАРЬЕРА (см. game/quests.js, game/career.js) =====================
-- quests_data хранит массив из 4 заданий на сегодня (id/type/target/progress/reward/xp/desc/completed),
-- пересобирается заново, когда quests_day не совпадает с текущей датой (МСК).
ALTER TABLE players ADD COLUMN IF NOT EXISTS quests_data JSONB NOT NULL DEFAULT '[]';
ALTER TABLE players ADD COLUMN IF NOT EXISTS quests_day DATE;
-- career_xp копится навсегда (не сбрасывается); career_rank — кэш текущего уровня по
-- CAREER_RANKS, нужен только чтобы разово выдать награду ровно один раз при повышении.
ALTER TABLE players ADD COLUMN IF NOT EXISTS career_xp INTEGER NOT NULL DEFAULT 0;
ALTER TABLE players ADD COLUMN IF NOT EXISTS career_rank INTEGER NOT NULL DEFAULT 1;

-- ===================== ШТРАФ ЗА НЕЛАЙКНУТЫЕ ПОСТЫ СООБЩЕСТВА (см. game/postLikes.js) =====================
-- Официальные посты сообщества (owner_id = -VK_GROUP_ID), которые нужно лайкнуть. Таблица
-- наполняется периодическим опросом wall.get (см. game/postLikes.js: syncPosts) — НЕ событием
-- wall_post_new: так надёжнее, не зависит от того, доходит ли конкретный апдейт Long Poll.
CREATE TABLE IF NOT EXISTS community_posts (
    owner_id BIGINT NOT NULL,
    post_id BIGINT NOT NULL,
    published_at TIMESTAMPTZ NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    PRIMARY KEY (owner_id, post_id)
);
CREATE INDEX IF NOT EXISTS idx_community_posts_published ON community_posts (published_at);

-- Кто из игроков лайкнул какой пост. Наполняется периодическим опросом likes.getList (см.
-- game/postLikes.js: syncLikes) — НЕ событием like_add: VK Bots Long Poll/Callback API для
-- СООБЩЕСТВ его не поддерживает (это событие есть только в личном Long Poll пользователя и
-- на практике никогда не приходит боту группы), поэтому единственный надёжный способ узнать
-- о лайке — самим периодически спрашивать likes.getList.
CREATE TABLE IF NOT EXISTS post_likes (
    owner_id BIGINT NOT NULL,
    post_id BIGINT NOT NULL,
    vk_id BIGINT NOT NULL,
    liked_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    PRIMARY KEY (owner_id, post_id, vk_id)
);
CREATE INDEX IF NOT EXISTS idx_post_likes_vk ON post_likes (vk_id);

-- Кэш признака "штраф за нелайкнутые посты активен" на самом игроке: incomePerHour
-- (game/calc.js) — синхронная чистая функция без доступа к БД, поэтому не может сама
-- проверять post_likes на каждый вызов. Флаг пересчитывается фоновой задачей раз в
-- POST_LIKE_SYNC_INTERVAL_MS (см. game/postLikes.js: recomputePenalties, game/scheduler.js).
ALTER TABLE players ADD COLUMN IF NOT EXISTS like_penalty_active BOOLEAN NOT NULL DEFAULT false;

-- Бизнес: доп. слоты сверх бесплатных BUSINESS_BASE_SLOTS, выдаются вручную админом после
-- оплаты доната (см. !админ бизнесслот, handlers/adminHandlers.js) — как и остальные
-- донат-бонусы в проекте, без автоматической оплаты через VK Pay.
ALTER TABLE players ADD COLUMN IF NOT EXISTS business_extra_slots INTEGER NOT NULL DEFAULT 0;

-- УСТАРЕЛО: старые колонки одного донат-бизнеса на игрока. С переходом на множественные
-- донат-бизнесы (см. таблицу donate_businesses ниже) код их больше не читает и не пишет —
-- оставлены только чтобы не терять историю на уже накатанных БД. Можно дропнуть отдельной
-- миграцией после переноса данных (см. комментарий у donate_businesses).
ALTER TABLE players ADD COLUMN IF NOT EXISTS donate_business_id TEXT;
ALTER TABLE players ADD COLUMN IF NOT EXISTS donate_business_until TIMESTAMPTZ;
ALTER TABLE players ADD COLUMN IF NOT EXISTS donate_business_weekly_at TIMESTAMPTZ;

-- Донат-бизнесы (ежемесячная подписка, см. game/donateBusiness.js, db/donateBusiness.js) —
-- теперь МНОЖЕСТВЕННЫЕ на игрока, по аналогии с обычными player_businesses ниже: админ может
-- выдать один и тот же тир повторно или разные тиры сразу — каждая выдача занимает отдельный
-- слот (см. donate_business_extra_slots — доп. слоты за донат, !админ донатбизнесслот).
-- tier_id — ключ тира (C.DONATE_BUSINESS_TIERS). level — 1..DONATE_BUSINESS_MAX_LEVEL,
-- прокачивается за рубли (!админ донатбизнесуровень), множитель дохода — как у обычных
-- бизнесов (BUSINESS_LEVEL_MULTIPLIERS). weekly_at — когда последний раз выдавался
-- еженедельный бонус ЭТОГО слота.
--
-- МИГРАЦИЯ СО СТАРОЙ СХЕМЫ: если в players ещё остались непустые donate_business_id для
-- игроков без записей в donate_businesses, перенесите их разовым скриптом вида:
--   INSERT INTO donate_businesses (player_id, tier_id, level, until, weekly_at)
--   SELECT vk_id, donate_business_id, 1, donate_business_until, donate_business_weekly_at
--   FROM players WHERE donate_business_id IS NOT NULL AND donate_business_until > NOW();
CREATE TABLE IF NOT EXISTS donate_businesses (
    id SERIAL PRIMARY KEY,
    player_id BIGINT NOT NULL REFERENCES players(vk_id) ON DELETE CASCADE,
    tier_id TEXT NOT NULL,
    level INTEGER NOT NULL DEFAULT 1,
    until TIMESTAMPTZ NOT NULL,
    weekly_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_donate_businesses_player ON donate_businesses (player_id);
-- Ускоряет donateBusiness.hourlyTick/dailyTick (см. game/scheduler.js): выборка всех ещё
-- действующих донат-бизнесов без полного скана таблицы.
CREATE INDEX IF NOT EXISTS idx_donate_businesses_until ON donate_businesses (until);

-- Доп. слоты под ДОНАТ-бизнесы сверх бесплатного (DONATE_BUSINESS_BASE_SLOTS), выдаются вручную
-- админом после оплаты (см. !админ донатбизнесслот, DONATE_BUSINESS_EXTRA_SLOT_PRICE_RUB = 250₽).
-- Отдельная колонка от business_extra_slots — это разные слоты для разных систем (донат-бизнес
-- vs обычный бизнес за вирты).
ALTER TABLE players ADD COLUMN IF NOT EXISTS donate_business_extra_slots INTEGER NOT NULL DEFAULT 0;

-- Бизнесы, купленные игроками. Доход считается "на лету" по business_since_at (как ферма
-- в game/farm.js), НО только пока business_stock_until не пройден — после этого начисление
-- останавливается, и если business_grace_until тоже пройден без пополнения сырья, бизнес
-- удаляется фоновой задачей (game/business.js: processDecay, вызывается из scheduler.js).
CREATE TABLE IF NOT EXISTS player_businesses (
    id SERIAL PRIMARY KEY,
    player_id BIGINT NOT NULL REFERENCES players(vk_id) ON DELETE CASCADE,
    business_type_id INTEGER NOT NULL,     -- индекс в constants.BUSINESS_TYPES
    level INTEGER NOT NULL DEFAULT 1,      -- 1..BUSINESS_MAX_LEVEL
    accrued_balance NUMERIC NOT NULL DEFAULT 0, -- накопленный, но ещё не собранный доход (забирается кнопкой "Собрать")
    since_at TIMESTAMPTZ NOT NULL DEFAULT NOW(), -- с какого момента считать доп. накопление "на лету"
    stock_until TIMESTAMPTZ NOT NULL,      -- до какого момента хватает сырья
    grace_until TIMESTAMPTZ,               -- если сырьё кончилось — крайний срок пополнения, иначе бизнес слетает
    level4_since_at TIMESTAMPTZ,           -- с какого момента бизнес непрерывно на 4 уровне (для апгрейда 4->5)
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_player_businesses_player ON player_businesses (player_id);
-- Ускоряет business.processDecay (минутный cron): поиск бизнесов с истёкшим сырьём/сроком
-- пополнения (stock_until/grace_until). Без индекса — сканирование всей таблицы каждую минуту.
CREATE INDEX IF NOT EXISTS idx_player_businesses_stock_until ON player_businesses (stock_until);
CREATE INDEX IF NOT EXISTS idx_player_businesses_grace_until
  ON player_businesses (grace_until) WHERE grace_until IS NOT NULL;

-- ===================== ВОЙНА КЛАНОВ ЗА ЗОНЫ (см. game/zoneWar.js) =====================
-- 9 именованных зон на карте (см. C.ZONE_WAR_ZONES) — фиксированный список, id 1..9.
-- Механика: ставки. Раз в ZONE_WAR_CYCLE_DAYS дней бот подводит итог по каждой НЕ
-- защищённой зоне (protected_until в прошлом либо ещё не захвачена) — владельцем
-- становится клан, вложивший за цикл больше всех. После захвата зона получает защиту на
-- ZONE_WAR_PROTECTION_DAYS — оспорить её раньше нельзя, даже если у неё есть владелец.
CREATE TABLE IF NOT EXISTS clan_zones (
    zone_id INTEGER PRIMARY KEY,
    owner_clan_id INTEGER REFERENCES clans(id) ON DELETE SET NULL,
    captured_at TIMESTAMPTZ,
    protected_until TIMESTAMPTZ,
    bonus_override NUMERIC          -- переопределение % дохода админом (NULL = дефолт из constants.js)
);

-- Текущие ставки кланов в АКТИВНОМ цикле войны. Обнуляются (DELETE) при подведении
-- итогов цикла — история не хранится здесь, а в clan_zone_history ниже.
CREATE TABLE IF NOT EXISTS clan_zone_stakes (
    zone_id INTEGER NOT NULL,
    clan_id INTEGER NOT NULL REFERENCES clans(id) ON DELETE CASCADE,
    amount BIGINT NOT NULL DEFAULT 0,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    PRIMARY KEY (zone_id, clan_id)
);

-- Донат-буст: временно умножает эффективный вес ставок клана в войне за зоны (выдаётся
-- вручную админом после оплаты, как и весь остальной донат — см. game/donateBuffs.js).
-- Истекает сам — чтобы купить снова, нужен новый платёж (это намеренно, см. описание фичи).
CREATE TABLE IF NOT EXISTS clan_zone_boosts (
    clan_id INTEGER PRIMARY KEY REFERENCES clans(id) ON DELETE CASCADE,
    multiplier NUMERIC NOT NULL DEFAULT 1,
    boost_until TIMESTAMPTZ
);

-- История захватов — лента событий для игроков (см. !зоны история)
CREATE TABLE IF NOT EXISTS clan_zone_history (
    id SERIAL PRIMARY KEY,
    zone_id INTEGER NOT NULL,
    clan_id INTEGER REFERENCES clans(id) ON DELETE SET NULL,
    amount BIGINT NOT NULL,
    captured_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_clan_zone_history_zone ON clan_zone_history (zone_id, captured_at DESC);

-- Донат: разовые покупки расширения сейфа клана (см. CLAN_VAULT_EXTRA_CAPACITY_AMOUNT/_PRICE_RUB
-- в constants.js, выдаётся через !админ кланвместимость) — складывается при повторных покупках,
-- никогда не уменьшается, прибавляется напрямую к effectiveMaxVault в game/clan.js.
ALTER TABLE clans ADD COLUMN IF NOT EXISTS vault_extra_capacity BIGINT NOT NULL DEFAULT 0;

-- Навыки "Дозор" и "Кража" (см. game/skills.js) — суммарный счётчик успешных попыток за
-- всё время, из которого выводится уровень навыка (0-50) и бонус к награде (+3%/уровень).
-- steal_count_today/steal_day уже были для дневного лимита — это ОТДЕЛЬНЫЙ счётчик,
-- который никогда не обнуляется.
ALTER TABLE players ADD COLUMN IF NOT EXISTS patrol_count_total INTEGER NOT NULL DEFAULT 0;
ALTER TABLE players ADD COLUMN IF NOT EXISTS steal_count_total INTEGER NOT NULL DEFAULT 0;

-- Казино — слоты (см. game/casino.js, handlers/casinoHandlers.js). Каждая прокрутка — одна
-- строка: bet списан сразу, win начислен сразу (0, если проигрыш). net хранится отдельно
-- только для истории/дебага — на топ он НЕ влияет: топ считается по SUM(win), которая
-- растёт исключительно на выигрышах и никогда не уменьшается от последующих проигрышей
-- (см. db/casino.js: getTopWinners — если игрок выиграл 1000, а потом проиграл 500, в топе
-- всё ещё остаётся 1000, а не 500).
CREATE TABLE IF NOT EXISTS casino_spins (
    id BIGSERIAL PRIMARY KEY,
    vk_id BIGINT NOT NULL REFERENCES players(vk_id) ON DELETE CASCADE,
    bet BIGINT NOT NULL,
    win BIGINT NOT NULL DEFAULT 0,
    net BIGINT NOT NULL, -- win - bet, только для истории
    reels TEXT[] NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
-- Ускоряет топ по периодам (день/неделя/месяц/всего) — фильтр по времени + сумма по игроку.
CREATE INDEX IF NOT EXISTS idx_casino_spins_vk_created ON casino_spins (vk_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_casino_spins_created_win ON casino_spins (created_at, win) WHERE win > 0;

-- Админский буст шанса выигрыша в казино для конкретного игрока (см. !админ казиношанс,
-- game/casino.js: rollReels). NULL/0 — обычные шансы (по весам символов, см. constants.js:
-- CASINO_SLOT_SYMBOLS). Значение — ТОЛЬКО 50 или 60 (упрощено по требованию: раньше был
-- произвольный процент 1-100) — с этой вероятностью на каждом спине ВСЕ три барабана
-- принудительно ставятся на один и тот же (случайно выбранный по весам) символ, то есть
-- игрок выигрывает 50%/60% спинов гарантированно (плюс исчезающе малая добавка от обычной
-- логики). Ставится/снимается вручную, не связано с донатом. Касается только слотов —
-- на блэкджек (game/blackjack.js, добавлен позже) этот буст не влияет, там честные
-- стандартные правила.
ALTER TABLE players ADD COLUMN IF NOT EXISTS casino_win_boost_percent SMALLINT;

-- Казино — блэкджек (см. game/blackjack.js, handlers/blackjackHandlers.js). Та же схема,
-- что и у casino_spins выше, только для другой игры: bet списан сразу при старте
-- раздачи, win начислен при завершении (0, если поражение). outcome — короткий тег исхода
-- ('win'/'blackjack'/'push'/'lose'), карты храним как массивы строк "ранг_масть" (только
-- для истории/дебага, на геймплей не влияют).
CREATE TABLE IF NOT EXISTS blackjack_hands (
    id BIGSERIAL PRIMARY KEY,
    vk_id BIGINT NOT NULL REFERENCES players(vk_id) ON DELETE CASCADE,
    bet BIGINT NOT NULL,
    win BIGINT NOT NULL DEFAULT 0,
    net BIGINT NOT NULL,
    outcome TEXT NOT NULL,
    player_cards TEXT[] NOT NULL,
    dealer_cards TEXT[] NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_blackjack_hands_vk_created ON blackjack_hands (vk_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_blackjack_hands_created_win ON blackjack_hands (created_at, win) WHERE win > 0;

-- Бонус за комментарий "фарм" под постом сообщества (см. game/commentFarm.js,
-- handlers/commentFarmHandlers.js). Уникальность по (vk_id, post_id) — 1 бонус на игрока
-- на КОНКРЕТНЫЙ пост, а не навсегда: новый пост с той же акцией снова даёт бонус.
CREATE TABLE IF NOT EXISTS comment_farm_claims (
    vk_id BIGINT NOT NULL REFERENCES players(vk_id) ON DELETE CASCADE,
    post_id BIGINT NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    PRIMARY KEY (vk_id, post_id)
);



