'use strict';

const C = require('./constants');
const players = require('../db/players');
const combatDb = require('../db/combat');
const clans = require('../db/clans');
const calc = require('./calc');

const ROMAN = ['I', 'II', 'III', 'IV', 'V', 'VI', 'VII', 'VIII', 'IX', 'X'];

function tierOf(level) {
  const safeLevel = Math.max(level, 1);
  const tier = Math.floor((safeLevel - 1) / C.SUPER_ROBOT_TIER_SIZE);
  return Math.min(tier, C.SUPER_ROBOT_TIER_NAMES.length - 1);
}

function levelName(level) {
  if (level <= 0) return 'Не построен';
  const tier = tierOf(level);
  const subIndex = (level - 1) % C.SUPER_ROBOT_TIER_SIZE;
  return `${C.SUPER_ROBOT_TIER_NAMES[tier]} ${ROMAN[subIndex]}`;
}

// Цена прокачки С currentLevel НА currentLevel+1, в виртах. Растёт значительно быстрее
// обычного робота — суперробота специально тяжело качать до максимума.
function upgradeCost(currentLevel) {
  return Math.round(C.SUPER_ROBOT_UPGRADE_BASE_COST * Math.pow(C.SUPER_ROBOT_UPGRADE_GROWTH, currentLevel));
}

// Сколько заводов сносит атака суперробота такого уровня (1 уровень = 1 завод,
// дальше +1 завод каждые SUPER_ROBOT_FACTORIES_PER_LEVEL уровней, максимум на 50 ур.)
function factoriesPerHit(level) {
  if (level <= 0) return 0;
  return Math.ceil(level / C.SUPER_ROBOT_FACTORIES_PER_LEVEL);
}

function buildLevelsTable() {
  const rows = [];
  for (let level = 1; level <= C.SUPER_ROBOT_MAX_LEVEL; level++) {
    rows.push({
      level,
      name: levelName(level),
      costToReach: upgradeCost(level - 1),
      factoriesPerHit: factoriesPerHit(level),
    });
  }
  return rows;
}

function msLeft(lastAt, cooldownMs) {
  if (!lastAt) return 0;
  const left = cooldownMs - (Date.now() - new Date(lastAt).getTime());
  return left > 0 ? left : 0;
}

// Прокачка уровня суперробота за ВИРТЫ (не жетоны!) — цена растёт быстро, качать тяжело.
async function upgradeSuperRobot(vkId) {
  const player = await players.getPlayer(vkId);
  if (!player) return { ok: false, reason: 'not_registered' };

  const level = player.super_robot_level || 0;
  if (level >= C.SUPER_ROBOT_MAX_LEVEL) {
    return { ok: false, reason: 'max_level' };
  }

  const cost = upgradeCost(level);
  const balance = Number(player.balance) || 0;
  if (balance < cost) {
    return { ok: false, reason: 'not_enough_balance', cost, missing: cost - balance };
  }

  await players.updateBalance(vkId, -cost);
  await players.setSuperRobotLevel(vkId, level + 1);

  return { ok: true, cost, newLevel: level + 1 };
}

// Запуск атаки суперроботом на другого игрока. Летит как обычное оружие (расстояние/скорость),
// разрешение атаки — resolveAttack ниже, вызывается планировщиком через attacks_in_flight.
async function launchAttack(attackerId, defenderId, peerId) {
  if (attackerId === defenderId) return { ok: false, reason: 'self_attack' };

  const attacker = await players.getPlayer(attackerId);
  const defender = await players.getPlayer(defenderId);
  if (!attacker || !defender) return { ok: false, reason: 'not_registered' };

  const level = attacker.super_robot_level || 0;
  if (level < 1) return { ok: false, reason: 'not_built' };

  if (attacker.factories < C.MIN_FACTORIES_TO_ATTACK) {
    return { ok: false, reason: 'attacker_too_small' };
  }

  if (defender.factories < C.MIN_FACTORIES_TO_BE_ATTACKED) {
    return { ok: false, reason: 'defender_too_small' };
  }

  const daysSinceLastSeen = (Date.now() - new Date(defender.last_seen).getTime()) / (1000 * 60 * 60 * 24);
  if (daysSinceLastSeen > C.INACTIVITY_ATTACK_BAN_DAYS) {
    return { ok: false, reason: 'defender_inactive' };
  }

  const left = msLeft(attacker.super_robot_last_attack_at, C.SUPER_ROBOT_ATTACK_COOLDOWN_MS);
  if (left > 0) {
    return { ok: false, reason: 'cooldown', msLeft: left };
  }

  const distance = calc.distanceKm(attacker.x, attacker.y, defender.x, defender.y);
  let speed = C.SUPER_ROBOT_SPEED_KMH * C.WEAPON_SPEED_MULTIPLIER;

  if (attacker.clan_id) {
    const clan = await clans.getClanById(attacker.clan_id);
    if (clan && clan.bonus_forsazh_until && new Date(clan.bonus_forsazh_until) > new Date()) {
      speed *= 2;
    }
  }

  const flightHours = distance / speed;
  const arrivalAt = new Date(Date.now() + flightHours * 60 * 60 * 1000);

  // Уровень на момент запуска сохраняем в поле quantity — на нём и считаем силу удара при прилёте.
  const attackRecord = await combatDb.createAttack(
    attackerId,
    defenderId,
    C.SUPER_ROBOT_WEAPON_KEY,
    level,
    distance,
    arrivalAt,
    peerId
  );

  await players.touchLastSeen(attackerId);
  await players.setSuperRobotLastAttack(attackerId, new Date());

  return {
    ok: true,
    attackRecord,
    distance,
    flightMs: flightHours * 60 * 60 * 1000,
    level,
    factoriesPerHit: factoriesPerHit(level),
    attackerId: attacker.vk_id,
    defenderId: defender.vk_id,
    attackerName: attacker.state_name,
    defenderName: defender.state_name,
  };
}

// Сносит N заводов у defender — та же компенсация виртами за снос, что и у обычного
// оружия (см. FACTORY_DESTROY_COMPENSATION_RATE в constants.js / game/combat.js).
async function destroyFactories(defenderVkId, count) {
  // Тот же общий потолок на разовый снос, что и у обычного оружия (см. constants.js).
  const cappedCount = Math.min(count, C.MAX_FACTORIES_DESTROYED_PER_ATTACK);
  let destroyedCount = 0;
  let compensation = 0;
  for (let i = 0; i < cappedCount; i++) {
    const current = await players.getPlayer(defenderVkId);
    if (!current || current.factories <= C.NEWBIE_PROTECTION_FACTORIES) break;
    const price = calc.nextFactoryPrice(Math.max(current.factories - 1, 0));
    compensation += Math.round(price * C.FACTORY_DESTROY_COMPENSATION_RATE);
    await players.destroyOneFactory(defenderVkId);
    destroyedCount += 1;
  }
  if (compensation > 0) {
    await players.updateBalance(defenderVkId, compensation);
  }
  return { destroyedCount, compensation };
}

// Разрешение прилетевшей атаки суперробота. Перехватить её на подлёте может ТОЛЬКО
// самое мощное ПВО (С-400 Триумф) — если у защитника оно есть и "охота" удалась,
// суперробот сбит (сам не теряется — уровень сохраняется), а защитник получает крупную
// награду виртами. Если нет — заводы сносятся, атакующий получает повышенные трофеи.
async function resolveAttack(attackRecord) {
  const attacker = await players.getPlayer(attackRecord.attacker_id);
  const defender = await players.getPlayer(attackRecord.defender_id);
  if (!attacker || !defender) {
    return { ok: false, reason: 'player_missing' };
  }

  const level = attackRecord.quantity;
  const destroyPower = factoriesPerHit(level);

  const AD_KEY = 'С-400 Триумф';
  const airDefense = defender.air_defense || {};
  const airDefenseDamage = defender.air_defense_damage || {};
  const adCount = airDefense[AD_KEY] || 0;

  let chanceMultiplier = 1;
  if (defender.clan_id) {
    const clan = await clans.getClanById(defender.clan_id);
    if (clan && clan.bonus_eshelon_until && new Date(clan.bonus_eshelon_until) > new Date()) {
      chanceMultiplier = 1.2;
    }
  }

  const defenderSkill = calc.getSkillTier(defender.factories);
  const skillBonus = defenderSkill ? defenderSkill.airDefenseBonus : 0;

  let intercepted = false;
  if (adCount > 0) {
    const chance = Math.min(C.AIR_DEFENSE[AD_KEY].chance * chanceMultiplier + skillBonus, 1);
    if (Math.random() < chance) {
      intercepted = true;

      // ===== "Прочность" ПВО (см. game/combat.js): суперробот — самая мощная угроза в игре, =====
      // ===== поэтому его "износ" по ПВО (SUPER_ROBOT_AD_WEAR) выше любого обычного оружия — =====
      // ===== хватает 1-2 перехватов, чтобы полностью снести даже С-400 Триумф.               =====
      const durability = C.AIR_DEFENSE[AD_KEY].durability || 1;
      airDefenseDamage[AD_KEY] = (airDefenseDamage[AD_KEY] || 0) + C.SUPER_ROBOT_AD_WEAR;

      while (airDefenseDamage[AD_KEY] >= durability && airDefense[AD_KEY] > 0) {
        airDefense[AD_KEY] -= 1;
        airDefenseDamage[AD_KEY] -= durability;
      }
      if (airDefense[AD_KEY] <= 0) {
        delete airDefense[AD_KEY];
        delete airDefenseDamage[AD_KEY];
      } else if (airDefenseDamage[AD_KEY] <= 0) {
        delete airDefenseDamage[AD_KEY];
      }

      await players.setAirDefense(defender.vk_id, airDefense);
      await players.setAirDefenseDamage(defender.vk_id, airDefenseDamage);
    }
  }

  if (intercepted) {
    const reward = calc.randomInt(C.SUPER_ROBOT_HUNT_REWARD_MIN, C.SUPER_ROBOT_HUNT_REWARD_MAX);
    await players.updateBalance(defender.vk_id, reward);
    return { ok: true, intercepted: true, level, reward, attacker, defender };
  }

  const { destroyedCount, compensation } = await destroyFactories(defender.vk_id, destroyPower);
  if (destroyedCount > 0) {
    await players.incrementEnemyFactoriesDestroyed(attacker.vk_id, destroyedCount);
  }

  const productionDb = require('../db/production');
  const factoriesInProd = await productionDb.getFactoriesInUse(defender.vk_id);
  const defenderIncome = calc.incomePerHour(await players.getPlayer(defender.vk_id), factoriesInProd);
  let loot = Math.round(defenderIncome * C.SUPER_ROBOT_LOOT_RATE);
  loot = Math.max(C.SUPER_ROBOT_LOOT_MIN, Math.min(C.SUPER_ROBOT_LOOT_MAX, loot));
  // Штраф, если защитник значительно слабее атакующего по заводам (фарм новичков менее выгоден)
  loot = Math.round(loot * calc.weakTargetLootMultiplier(attacker, defender));
  await players.updateBalance(attacker.vk_id, loot);

  return {
    ok: true,
    intercepted: false,
    level,
    destroyPower,
    destroyedCount,
    compensation,
    loot,
    attacker,
    defender,
  };
}

module.exports = {
  levelName,
  tierOf,
  upgradeCost,
  factoriesPerHit,
  buildLevelsTable,
  msLeft,
  upgradeSuperRobot,
  launchAttack,
  resolveAttack,
};
