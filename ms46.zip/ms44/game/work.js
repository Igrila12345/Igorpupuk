'use strict';

const C = require('./constants');
const calc = require('./calc');
const players = require('../db/players');
const workGame = require('./workGame');

// Дата "по игре" — всегда по московскому времени, чтобы дневной лимит сбрасывался
// ровно в 00:00 МСК (как и остальные ежедневные события, см. game/scheduler.js), а не
// в полночь по системному часовому поясу сервера (который может быть в UTC).
function todayStr() {
  const parts = new Intl.DateTimeFormat('en-CA', {
    timeZone: 'Europe/Moscow',
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
  }).formatToParts(new Date());
  const map = {};
  for (const p of parts) map[p.type] = p.value;
  return `${map.year}-${map.month}-${map.day}`; // YYYY-MM-DD
}

// Если день сменился — обнуляем дневной счётчик работ.
// work_day теперь приходит из БД как обычная строка 'YYYY-MM-DD' (см. db/pool.js,
// где отключён часовой-поясной парсинг типа DATE), поэтому сравниваем строки
// напрямую, без прогона через new Date()/toISOString() — раньше это могло
// сдвигать дату на день из-за локального часового пояса процесса.
async function ensureDayReset(player) {
  const today = todayStr();
  const storedDay = player.work_day ? String(player.work_day).slice(0, 10) : null;
  if (storedDay !== today) {
    await players.resetWorkDay(player.vk_id, today);
    player.work_count_today = 0;
    player.work_day = today;
  }
  return player;
}

function buildSession(round, roundNumber) {
  return {
    round: roundNumber,
    boxes: round.boxes,
    correctIndex: round.correctIndex,
    expiresAt: new Date(Date.now() + C.WORK_ROUND_TIMEOUT_MS).toISOString(),
  };
}

// Начинает новую сессию мини-игры "работа" (или возвращает уже идущую, если есть).
// Попытка (дневной счётчик) и кулдаун списываются сразу при старте, а не по итогу,
// чтобы нельзя было спамить попытками, угадывая коробку наугад без потерь.
async function startWork(vkId) {
  let player = await players.getPlayer(vkId);
  if (!player) return { ok: false, reason: 'not_registered' };

  player = await ensureDayReset(player);

  if (player.work_session) {
    const session = player.work_session;
    const expired = session.expiresAt && new Date(session.expiresAt) < new Date();
    if (!expired) {
      const attemptsLeft = Math.max(0, C.WORK_MAX_PER_DAY - (player.work_count_today || 0));
      return { ok: true, resumed: true, session, attemptsLeft };
    }
    // Сессия протухла — считаем попытку сгоревшей и открываем возможность начать заново
    await players.setWorkSession(vkId, null);
  }

  if ((player.work_count_today || 0) >= C.WORK_MAX_PER_DAY) {
    return { ok: false, reason: 'daily_limit', attemptsLeft: 0 };
  }

  if (player.last_work_time) {
    const elapsed = Date.now() - new Date(player.last_work_time).getTime();
    if (elapsed < C.WORK_COOLDOWN_MS) {
      return { ok: false, reason: 'cooldown', remainingMs: C.WORK_COOLDOWN_MS - elapsed };
    }
  }

  const round = workGame.generateRound();
  const session = buildSession(round, 1);

  await players.incrementWorkCount(vkId, todayStr()); // тратит попытку + обновляет last_work_time
  await players.setWorkSession(vkId, session);

  const attemptsLeft = C.WORK_MAX_PER_DAY - ((player.work_count_today || 0) + 1);

  return { ok: true, resumed: false, session, attemptsLeft };
}

// Обрабатывает нажатие кнопки с коробкой в текущем раунде.
async function pickBox(vkId, boxIndex, expectedRound) {
  const player = await players.getPlayer(vkId);
  if (!player) return { ok: false, reason: 'not_registered' };

  const attemptsLeft = Math.max(0, C.WORK_MAX_PER_DAY - (player.work_count_today || 0));

  const session = player.work_session;
  if (!session || Number(session.round) !== Number(expectedRound)) {
    return { ok: false, reason: 'no_session' };
  }

  if (session.expiresAt && new Date(session.expiresAt) < new Date()) {
    await players.setWorkSession(vkId, null);
    return { ok: false, reason: 'timeout', attemptsLeft };
  }

  if (!Number.isInteger(boxIndex) || boxIndex < 0 || boxIndex >= session.boxes.length) {
    return { ok: false, reason: 'invalid_box' };
  }

  if (boxIndex !== session.correctIndex) {
    await players.setWorkSession(vkId, null);
    return { ok: false, reason: 'wrong', attemptsLeft };
  }

  if (session.round >= C.WORK_ROUNDS) {
    await players.setWorkSession(vkId, null);
    const tokens = calc.randomInt(C.WORK_TOKENS_MIN, C.WORK_TOKENS_MAX);
    const totalTokens = await players.addTokens(vkId, tokens);
    return { ok: true, status: 'completed', tokens, totalTokens, attemptsLeft };
  }

  const round = workGame.generateRound();
  const nextSession = buildSession(round, session.round + 1);
  await players.setWorkSession(vkId, nextSession);

  return { ok: true, status: 'next_round', session: nextSession, attemptsLeft };
}

// Статус для меню "работа": сколько попыток использовано сегодня, есть ли
// незавершённая попытка (и на каком она раунде), сколько жетонов у игрока.
// Ничего не списывает и не начинает — только читает состояние.
async function getStatus(vkId) {
  let player = await players.getPlayer(vkId);
  if (!player) return { ok: false, reason: 'not_registered' };

  player = await ensureDayReset(player);

  const attemptsUsed = player.work_count_today || 0;
  const attemptsLeft = Math.max(0, C.WORK_MAX_PER_DAY - attemptsUsed);

  let activeRound = null;
  if (player.work_session) {
    const session = player.work_session;
    const expired = session.expiresAt && new Date(session.expiresAt) < new Date();
    if (!expired) activeRound = session.round;
  }

  return {
    ok: true,
    attemptsUsed,
    attemptsLeft,
    activeRound,
    tokens: player.tokens || 0,
  };
}

module.exports = { startWork, pickBox, getStatus };
