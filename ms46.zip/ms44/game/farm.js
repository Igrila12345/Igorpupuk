'use strict';

const C = require('./constants');
const players = require('../db/players');
const shopDb = require('../db/shop'); // getMeta/setMeta — курс нанокоина живёт в общей таблице game_meta

// ===================== Уровень / цена прокачки =====================

// currentLevel = 0 -> это цена ПОСТРОЙКИ фермы (первый уровень), дальше — обычная прокачка
function upgradeCost(currentLevel) {
  if (currentLevel <= 0) return C.FARM_BUILD_COST;
  const raw = C.FARM_UPGRADE_BASE_COST * Math.pow(C.FARM_UPGRADE_GROWTH, currentLevel - 1);
  return Math.round(raw / 10) * 10;
}

// ===================== Добыча в час =====================

// Фиксированная ставка ₿/час на данном уровне (среднее старого диапазона min/max) — ферма
// теперь копит непрерывно в реальном времени, а не случайными часовыми "тиками".
function ratePerHour(level) {
  if (level <= 0) return 0;
  const min = C.FARM_YIELD_BASE_MIN + C.FARM_YIELD_GROWTH_MIN * Math.sqrt(level);
  const max = C.FARM_YIELD_BASE_MAX + C.FARM_YIELD_GROWTH_MAX * Math.sqrt(level);
  return (min + max) / 2;
}

// Оставлено под старым именем для обратной совместимости (используется в топах/справке)
function avgYieldPerHour(level) {
  return ratePerHour(level);
}

// Потолок накопления на самой ферме: ставка/час * часы автономности
function capFor(level) {
  return ratePerHour(level) * C.FARM_AUTONOMY_HOURS;
}

// ===================== Живое состояние фермы =====================
// Считаем баланс "на лету" по разнице времени с момента farm_since_at — никакого почасового
// планировщика для самой добычи больше не требуется (в отличие от старой циклической механики).
function computeLiveState(player, now = Date.now()) {
  const level = player.farm_level || 0;
  if (level <= 0) {
    return { level: 0, built: false, enabled: false, balance: 0, rate: 0, cap: 0, autonomyMsLeft: 0, full: false };
  }

  const rate = ratePerHour(level);
  const cap = capFor(level);
  let balance = Number(player.farm_balance) || 0;
  let enabled = !!player.farm_enabled;
  let autonomyMsLeft = 0;

  if (enabled) {
    const sinceMs = player.farm_since_at ? new Date(player.farm_since_at).getTime() : now;
    const elapsedMs = Math.max(now - sinceMs, 0);
    const elapsedHours = elapsedMs / 3600000;
    const live = balance + rate * elapsedHours;

    if (live >= cap) {
      balance = cap;
      enabled = false;
      autonomyMsLeft = 0;
    } else {
      balance = live;
      autonomyMsLeft = Math.max(C.FARM_AUTONOMY_HOURS * 3600000 - elapsedMs, 0);
    }
  } else {
    balance = Math.min(balance, cap);
  }

  return { level, built: true, enabled, balance, rate, cap, autonomyMsLeft, full: balance >= cap && cap > 0 };
}

// Пересчитывает и, если ферма успела упереться в потолок (авто-пауза), сохраняет состояние в БД.
// Возвращает актуальный live-снимок. Вызывать в начале любого действия с фермой.
async function settleFarm(vkId, player) {
  const live = computeLiveState(player);
  if (live.built && !!player.farm_enabled && !live.enabled) {
    // Ферма сама встала на паузу, упершись в потолок автономности — фиксируем это в БД
    await players.setFarmState(vkId, { enabled: false, balance: live.balance, sinceAt: null });
  }
  return live;
}

// ===================== Постройка / прокачка =====================

async function buildOrUpgrade(vkId) {
  const player = await players.getPlayer(vkId);
  if (!player) return { ok: false, reason: 'not_registered' };

  const level = player.farm_level || 0;
  if (level >= C.FARM_MAX_LEVEL) return { ok: false, reason: 'max_level' };

  const cost = upgradeCost(level);
  const balance = Number(player.balance) || 0;
  if (balance < cost) {
    return { ok: false, reason: 'not_enough_money', cost, missing: cost - balance };
  }

  // Замораживаем текущую живую добычу под старую ставку до момента апгрейда
  const live = await settleFarm(vkId, player);

  await players.updateBalance(vkId, -cost);
  await players.setFarmLevel(vkId, level + 1);

  // Если ферма была включена — продолжаем добычу сразу под новую (более высокую) ставку
  if (live.built && live.enabled) {
    await players.setFarmState(vkId, { enabled: true, balance: live.balance, sinceAt: new Date() });
  } else {
    await players.setFarmState(vkId, { enabled: false, balance: live.balance, sinceAt: null });
  }

  return { ok: true, cost, newLevel: level + 1, wasBuilt: level === 0 };
}

// ===================== Включение / выключение добычи =====================

async function enableFarm(vkId) {
  const player = await players.getPlayer(vkId);
  if (!player) return { ok: false, reason: 'not_registered' };

  const level = player.farm_level || 0;
  if (level <= 0) return { ok: false, reason: 'not_built' };

  const live = await settleFarm(vkId, player);
  if (live.enabled) return { ok: false, reason: 'already_on' };
  if (live.full) return { ok: false, reason: 'full', balance: live.balance };

  await players.setFarmState(vkId, { enabled: true, balance: live.balance, sinceAt: new Date() });
  return { ok: true, level, rate: live.rate };
}

async function disableFarm(vkId) {
  const player = await players.getPlayer(vkId);
  if (!player) return { ok: false, reason: 'not_registered' };

  const level = player.farm_level || 0;
  if (level <= 0) return { ok: false, reason: 'not_built' };

  const live = computeLiveState(player);
  if (!live.enabled) return { ok: false, reason: 'already_off' };

  await players.setFarmState(vkId, { enabled: false, balance: live.balance, sinceAt: null });
  return { ok: true, balance: live.balance };
}

// ===================== Статус (только чтение) =====================

async function getStatus(vkId) {
  const player = await players.getPlayer(vkId);
  if (!player) return { ok: false, reason: 'not_registered' };
  return { ok: true, player, state: await settleFarm(vkId, player) };
}

// ===================== Снятие накопленного ₿ =====================
// Переносит текущий живой баланс фермы в личный кошелёк игрока (farm_coins, продаётся отдельно),
// обнуляет баланс на ферме и перезапускает автономность — заодно включает ферму, если была выключена.
async function withdraw(vkId) {
  const player = await players.getPlayer(vkId);
  if (!player) return { ok: false, reason: 'not_registered' };

  const level = player.farm_level || 0;
  if (level <= 0) return { ok: false, reason: 'not_built' };

  const live = computeLiveState(player);
  const amount = Math.floor(live.balance);
  if (amount <= 0) return { ok: false, reason: 'nothing_to_withdraw' };

  await players.addFarmCoins(vkId, amount);
  await players.setFarmState(vkId, { enabled: true, balance: 0, sinceAt: new Date() });

  return { ok: true, amount };
}

// ===================== Курс обмена нанокоина =====================

async function getExchangeRate() {
  const raw = await shopDb.getMeta(C.FARM_EXCHANGE_META_KEY);
  if (raw === null || raw === undefined) return C.FARM_EXCHANGE_RATE_START;
  const val = parseFloat(raw);
  return Number.isFinite(val) ? val : C.FARM_EXCHANGE_RATE_START;
}

// Небольшое случайное блуждание курса в заданном коридоре — вызывается раз в час планировщиком.
// Не привязано к какой-либо реальной бирже, чисто игровой элемент.
async function updateExchangeRate() {
  const current = await getExchangeRate();
  const delta = (Math.random() * 2 - 1) * C.FARM_EXCHANGE_RATE_STEP;
  let next = current + delta;
  next = Math.max(C.FARM_EXCHANGE_RATE_MIN, Math.min(C.FARM_EXCHANGE_RATE_MAX, next));
  next = Math.round(next * 100) / 100;
  await shopDb.setMeta(C.FARM_EXCHANGE_META_KEY, String(next));
  return next;
}

// ===================== Продажа нанокоинов =====================

// amount — число монет либо строка 'all' (продать всё)
async function sellCoins(vkId, amount) {
  const player = await players.getPlayer(vkId);
  if (!player) return { ok: false, reason: 'not_registered' };

  const have = Number(player.farm_coins) || 0;
  const requested = amount === 'all' ? have : Math.floor(amount);

  if (!Number.isFinite(requested) || requested <= 0) {
    return { ok: false, reason: 'invalid_amount' };
  }
  if (have <= 0) return { ok: false, reason: 'nothing_to_sell' };
  if (requested > have) return { ok: false, reason: 'not_enough_coins', have };

  const rate = await getExchangeRate();
  const virts = Math.round(requested * rate);

  await players.addFarmCoins(vkId, -requested);
  await players.updateBalance(vkId, virts);

  return { ok: true, sold: requested, virts, rate };
}

module.exports = {
  upgradeCost,
  ratePerHour,
  avgYieldPerHour,
  capFor,
  computeLiveState,
  settleFarm,
  buildOrUpgrade,
  enableFarm,
  disableFarm,
  getStatus,
  withdraw,
  getExchangeRate,
  updateExchangeRate,
  sellCoins,
};
