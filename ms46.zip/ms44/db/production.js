'use strict';

const { query } = require('./pool');

async function createProduction(playerId, weapon, quantity, factoriesUsed, readyAt) {
  const res = await query(
    `INSERT INTO production_queue (player_id, weapon, quantity, factories_used, ready_at)
     VALUES ($1, $2, $3, $4, $5) RETURNING *`,
    [playerId, weapon, quantity, factoriesUsed, readyAt]
  );
  return res.rows[0];
}

async function getActiveProductionsByPlayer(playerId) {
  const res = await query(
    `SELECT * FROM production_queue WHERE player_id = $1 AND collected = FALSE ORDER BY ready_at ASC`,
    [playerId]
  );
  return res.rows;
}

async function getFactoriesInUse(playerId) {
  const res = await query(
    `SELECT COALESCE(SUM(factories_used), 0) AS total FROM production_queue
     WHERE player_id = $1 AND collected = FALSE`,
    [playerId]
  );
  return Number(res.rows[0].total);
}

async function getReadyUncollected(playerId, weapon) {
  const res = await query(
    `SELECT * FROM production_queue
     WHERE player_id = $1 AND weapon = $2 AND collected = FALSE AND ready_at <= NOW()
     ORDER BY ready_at ASC`,
    [playerId, weapon]
  );
  return res.rows;
}

async function markCollected(id) {
  await query('UPDATE production_queue SET collected = TRUE WHERE id = $1', [id]);
}

async function getAllPendingProductions() {
  const res = await query(
    `SELECT * FROM production_queue WHERE collected = FALSE`
  );
  return res.rows;
}

module.exports = {
  createProduction,
  getActiveProductionsByPlayer,
  getFactoriesInUse,
  getReadyUncollected,
  markCollected,
  getAllPendingProductions,
};
