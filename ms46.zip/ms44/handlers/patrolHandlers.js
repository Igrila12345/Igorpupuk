'use strict';

const players = require('../db/players');
const patrol = require('../game/patrol');
const calc = require('../game/calc');

async function requireRegistered(ctx) {
  const player = await players.getPlayer(ctx.senderId);
  if (!player || player.registration_step !== 'done') {
    await ctx.send('⛔ Вы ещё не зарегистрированы. Напишите старт');
    return null;
  }
  return player;
}

function resultLine(result) {
  const parts = [];
  if (result.virts > 0) parts.push(`+${calc.formatNumber(result.virts)} вирт`);
  if (result.tokens > 0) parts.push(`+${result.tokens} 🪙`);
  return parts.length ? parts.join(', ') : 'без трофеев';
}

async function handlePatrol(ctx) {
  const player = await requireRegistered(ctx);
  if (!player) return;

  const result = await patrol.runPatrol(ctx.senderId);
  if (!result.ok) {
    if (result.reason === 'cooldown') {
      await ctx.send(`⏳ Дозор недавно возвращался. Следующий выход через ${calc.formatDuration(result.msLeft)}.`);
    } else {
      await ctx.send('⛔ Не удалось отправить дозор.');
    }
    return;
  }

  const jackpotPrefix = result.type === 'jackpot' ? '🎉 УДАЧА! ' : '🔭 ';
  await ctx.send(
    `${jackpotPrefix}${result.flavorText}\n` +
      `Итог: ${resultLine(result)}\n` +
      `⏳ Следующий дозор через ${calc.formatDuration(result.cooldownMs)}.`
  );
}

module.exports = { handlePatrol };
