'use strict';

const players = require('../db/players');
const robot = require('../game/robot');
const calc = require('../game/calc');
const C = require('../game/constants');
const msg = require('../utils/messages');

async function requireRegistered(ctx) {
  const player = await players.getPlayer(ctx.senderId);
  if (!player || player.registration_step !== 'done') {
    await ctx.send('⛔ Вы ещё не зарегистрированы. Напишите старт');
    return null;
  }
  return player;
}

// Русское склонение "жетон/жетона/жетонов"
function pluralTokens(n) {
  const mod10 = n % 10;
  const mod100 = n % 100;
  if (mod10 === 1 && mod100 !== 11) return 'жетон';
  if ([2, 3, 4].includes(mod10) && ![12, 13, 14].includes(mod100)) return 'жетона';
  return 'жетонов';
}

function statusBlock(player) {
  const level = player.robot_level || 1;
  let text = `🤖 ${robot.levelName(level)} (уровень ${level}/${C.ROBOT_MAX_LEVEL})\n`;
  const range = robot.incomeRange(level);
  text += `💰 Мгновенный сбор («робот»): ${calc.formatNumber(range.min)}–${calc.formatNumber(
    range.max
  )} вирт (случайно), раз в час\n`;
  text += `🪙 Отправка («отправить»): ${robot.tokensPerSend(level)} ${pluralTokens(robot.tokensPerSend(level))}, раз в час\n`;
  if (level < C.ROBOT_MAX_LEVEL) {
    text += `📈 Прокачка до ур. ${level + 1} «${robot.levelName(level + 1)}»: ${calc.formatNumber(
      robot.upgradeCost(level)
    )} вирт — робот прокачать`;
  } else {
    text += `🏆 Максимальный уровень достигнут!`;
  }
  return text;
}

// "робот" — мгновенно приносит доход виртами, если кулдаун прошёл; иначе показывает статус.
async function handleFarm(ctx) {
  const player = await requireRegistered(ctx);
  if (!player) return;

  const result = await robot.farmVirts(ctx.senderId);
  if (!result.ok) {
    if (result.reason === 'cooldown') {
      await ctx.send(
        `${statusBlock(player)}\n\n⏳ Робот уже приносил доход недавно. Следующий сбор через ${calc.formatDuration(
          result.msLeft
        )}.`
      );
    } else {
      await ctx.send('⛔ Не удалось получить доход с робота.');
    }
    return;
  }

  await ctx.send(
    `🤖 ${robot.levelName(result.level)} мгновенно принёс ${calc.formatNumber(result.amount)} вирт!\n` +
      `⏳ Следующий сбор доступен через ${calc.formatDuration(result.cooldownMs)}.\n` +
      `Статистика: мой робот`
  );
}

async function handleUpgrade(ctx) {
  const player = await requireRegistered(ctx);
  if (!player) return;

  const result = await robot.upgradeRobot(ctx.senderId);
  if (!result.ok) {
    if (result.reason === 'max_level') {
      await ctx.send(`⛔ У робота уже максимальный уровень (${C.ROBOT_MAX_LEVEL}).`);
    } else if (result.reason === 'not_enough_money') {
      await ctx.send(
        `⛔ Недостаточно вирт. Нужно ${calc.formatNumber(result.cost)}, не хватает ${calc.formatNumber(
          result.missing
        )}.`
      );
    } else {
      await ctx.send('⛔ Не удалось прокачать робота.');
    }
    return;
  }

  const newRange = robot.incomeRange(result.newLevel);
  await ctx.send(
    `✅ Робот прокачан до уровня ${result.newLevel} — «${robot.levelName(result.newLevel)}»! ` +
      `Стоимость: ${calc.formatNumber(result.cost)} вирт.\n` +
      `Доход за сбор теперь: ${calc.formatNumber(newRange.min)}–${calc.formatNumber(
        newRange.max
      )} вирт (случайно), жетонов за отправку: ${robot.tokensPerSend(result.newLevel)}.`
  );
}

// "отправить" — мгновенно приносит жетоны, раз в час
async function handleSend(ctx) {
  const player = await requireRegistered(ctx);
  if (!player) return;

  const result = await robot.sendForTokens(ctx.senderId);
  if (!result.ok) {
    if (result.reason === 'cooldown') {
      await ctx.send(
        `⏳ Робот уже отправлялся недавно. Следующая отправка через ${calc.formatDuration(result.msLeft)}.`
      );
    } else {
      await ctx.send('⛔ Не удалось отправить робота.');
    }
    return;
  }

  await ctx.send(
    `📦 Робот вернулся с ${result.amount} ${pluralTokens(result.amount)}! ` +
      `Следующая отправка через ${calc.formatDuration(result.cooldownMs)}.`
  );
}

// "мой робот" — только статистика, без побочных эффектов (не расходует кулдауны)
async function handleMyStats(ctx) {
  const player = await requireRegistered(ctx);
  if (!player) return;

  const farmCooldownMs = robot.effectiveCooldownMs(player, C.ROBOT_FARM_COOLDOWN_MS);
  const sendCooldownMs = robot.effectiveCooldownMs(player, C.ROBOT_SEND_COOLDOWN_MS);
  const farmLeft = robot.msLeft(player.robot_last_farm_at, farmCooldownMs);
  const sendLeft = robot.msLeft(player.robot_last_send_at, sendCooldownMs);

  let text = statusBlock(player) + '\n\n';
  if (calc.isVipActive(player)) {
    text += `👑 VIP активен до ${msg.formatDateTimeMsk(player.vip_until)} — доход +${Math.round(
      C.VIP_INCOME_BONUS * 100
    )}%, кулдауны робота короче на ${Math.round((1 - C.VIP_ROBOT_COOLDOWN_MULT) * 100)}%.\n\n`;
  }
  text +=
    farmLeft > 0
      ? `⏳ Сбор вирт («робот»): через ${calc.formatDuration(farmLeft)}\n`
      : `✅ Сбор вирт («робот») доступен прямо сейчас!\n`;
  text +=
    sendLeft > 0
      ? `⏳ Отправка за жетонами («отправить»): через ${calc.formatDuration(sendLeft)}`
      : `✅ Отправка за жетонами («отправить») доступна прямо сейчас!`;

  await ctx.send(text.trim());
}

// "роботы" — полная таблица всех 50 уровней (имена, цена прокачки, доход, жетоны, мощность)
async function handleLevelsList(ctx) {
  const rows = robot.buildLevelsTable();
  const half = Math.ceil(rows.length / 2);
  const chunks = [rows.slice(0, half), rows.slice(half)];

  for (let i = 0; i < chunks.length; i++) {
    const fromLevel = chunks[i][0].level;
    const toLevel = chunks[i][chunks[i].length - 1].level;
    let text = `🤖 ВСЕ УРОВНИ РОБОТА (${fromLevel}-${toLevel} из ${rows.length})\n\n`;

    for (const row of chunks[i]) {
      const costLabel = row.costToReach ? `${calc.formatNumber(row.costToReach)} вирт` : 'старт (уровень 1)';
      text += `${row.level}. «${row.name}»\n`;
      text += `   💵 Цена прокачки до этого уровня: ${costLabel}\n`;
      text += `   💰 Доход за сбор: ${calc.formatNumber(row.incomeRange.min)}–${calc.formatNumber(
        row.incomeRange.max
      )} вирт | 🪙 Жетонов: ${row.tokensPerSend} | 🏭 Мощность: ${row.factoriesPower}\n`;
    }

    if (i === chunks.length - 1) {
      text += `\nℹ️ «Мощность» — справочный показатель силы модели робота (растёт на 1 каждые ${C.ROBOT_TIER_SIZE} уровней), в бою напрямую не участвует.`;
    }

    await ctx.send(text.trim());
  }
}

module.exports = {
  handleFarm,
  handleUpgrade,
  handleSend,
  handleMyStats,
  handleLevelsList,
};
