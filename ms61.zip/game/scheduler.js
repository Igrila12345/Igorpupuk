'use strict';

const cron = require('node-cron');
const economy = require('./economy');
const miner = require('./miner');
const farm = require('./farm');
const shop = require('./shop');
const ratings = require('./ratings');
const attackResolver = require('./attackResolver');
const auction = require('./auction');
const shopDb = require('../db/shop');
const postLikes = require('./postLikes');
const C = require('./constants');

function startScheduler(bot) {
  // Каждую минуту: проверяем прилетевшие атаки, готовые производства не требуют тика (забираются вручную),
  // разблокировки заводов по времени, снятие радиации.
  cron.schedule('* * * * *', async () => {
    try {
      await attackResolver.resolvePendingAttacks(bot);
      await economy.processFactoryUnblocks();
      await economy.processRadiationExpiry();
      await auction.resolveExpiredAuctions(bot);
    } catch (err) {
      console.error('[Scheduler] Ошибка в минутном тике:', err);
    }
  });

  // Каждый час: доход, налоги, курс нанокоина майнинг-фермы (сама добыча теперь считается
  // "на лету" в реальном времени в game/farm.js, почасовой тик ей не требуется)
  cron.schedule('0 * * * *', async () => {
    try {
      await economy.hourlyTick(bot);
      await miner.hourlyMinerTick();
      await farm.updateExchangeRate();
    } catch (err) {
      console.error('[Scheduler] Ошибка в часовом тике (доход/налоги):', err);
    }
  });

  // Каждые 5 минут: обновление магазина
  cron.schedule('*/5 * * * *', async () => {
    try {
      await shop.refreshShop();
    } catch (err) {
      console.error('[Scheduler] Ошибка обновления магазина:', err);
    }
  });

  // Каждую минуту: подтягиваем новые посты сообщества и лайки к ним, пересчитываем штраф
  // -50% к доходу за нелайкнутые посты (см. game/postLikes.js). Раньше было раз в 5 минут —
  // по просьбе владельца ужали до минуты, чтобы штраф выставлялся/снимался максимально быстро
  // после публикации поста или лайка, а не ждал до 5 минут. Не совмещаем с часовым тиком
  // дохода намеренно: сам доход всё равно начисляется раз в час, но флаг штрафа должен быть
  // актуален уже к моменту этого начисления, а не отставать от него.
  cron.schedule('* * * * *', async () => {
    try {
      await postLikes.syncAndRecompute(bot);
    } catch (err) {
      console.error('[Scheduler] Ошибка синхронизации лайков постов:', err);
    }
  });

  // Ежедневно в 00:00 по МСК (сервер должен быть настроен на TZ=Europe/Moscow либо укажем явно)
  cron.schedule(
    '0 0 * * *',
    async () => {
      try {
        await ratings.distributeDailyRewards(bot);
      } catch (err) {
        console.error('[Scheduler] Ошибка выдачи ежедневных наград:', err);
      }
    },
    { timezone: 'Europe/Moscow' }
  );

  console.log('[Scheduler] Все фоновые задачи запущены.');
}

// Восстановление состояния при старте: если магазин пуст, генерируем сразу
async function bootstrapState() {
  const state = await shopDb.getShopState();
  if (!state.items || state.items.length === 0) {
    await shop.refreshShop();
  }
}

// Первый прогон синхронизации лайков сразу при старте (не дожидаясь первого 5-минутного
// тика) — чтобы штрафной флаг был актуален с самого запуска бота, а не пустым до 5 минут.
// bot передаётся отдельно (а не через bootstrapState(bot)), т.к. на момент запуска scheduler
// ещё не стартован — вызывается из index.js после создания Bot, см. комментарий там же.
async function bootstrapPostLikes(bot) {
  try {
    await postLikes.syncAndRecompute(bot);
  } catch (err) {
    console.error('[Scheduler] Ошибка первичной синхронизации лайков постов:', err);
  }
}

module.exports = { startScheduler, bootstrapState, bootstrapPostLikes };
