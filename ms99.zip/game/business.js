'use strict';

const C = require('./constants');
const players = require('../db/players');
const businessDb = require('../db/business');
const asyncLock = require('./asyncLock');

const HOUR_MS = 60 * 60 * 1000;

function getCatalog() {
  return C.BUSINESS_TYPES;
}

function getTypeById(businessTypeId) {
  return C.BUSINESS_TYPES.find((t) => t.id === businessTypeId) || null;
}

function sellPriceFor(type) {
  return Math.round(type.price * C.BUSINESS_SELL_RATE);
}

function refillCostFor(type) {
  return Math.round(type.price * C.BUSINESS_REFILL_RATE);
}

// Сколько всего слотов доступно игроку (бесплатные + доп. купленные за донат, с потолком)
function getSlotLimit(player) {
  const extra = Math.min(player.business_extra_slots || 0, C.BUSINESS_MAX_EXTRA_SLOTS);
  return C.BUSINESS_BASE_SLOTS + extra;
}

// Множитель СУММАРНОГО дохода от бизнесов в зависимости от числа заводов игрока (отдельная система)
function getFactoryMultiplier(factories) {
  const n = factories || 0;
  for (const tier of C.BUSINESS_FACTORY_MULTIPLIER_TIERS) {
    if (n >= tier.min) return tier.mult;
  }
  return 1;
}

function levelMultiplier(level) {
  return C.BUSINESS_LEVEL_MULTIPLIERS[level] || 1;
}

// Базовый доход/ч бизнеса на его текущем уровне (без учёта множителя заводов — тот считается
// один раз на ВСЮ пачку бизнесов игрока при отображении/сборе, не на каждый бизнес отдельно)
function baseIncomePerHour(business) {
  const type = getTypeById(business.business_type_id);
  if (!type) return 0;
  return type.incomePerHour * levelMultiplier(business.level);
}

// Считает "на лету" сколько дохода накопилось сверх accrued_balance с момента since_at, но
// только пока не кончилось сырьё (stock_until) — начисление не идёт дальше этой точки.
// Аналог game/farm.js: computeLiveState / settleFarm, но БЕЗ верхнего потолка накопления —
// у бизнеса своего "кэпа" нет, только остановка при исчерпании сырья.
function computeLive(business, now = Date.now()) {
  const sinceMs = new Date(business.since_at).getTime();
  const stockUntilMs = new Date(business.stock_until).getTime();
  const rate = baseIncomePerHour(business);

  const accountUntilMs = Math.min(now, stockUntilMs);
  const elapsedMs = Math.max(accountUntilMs - sinceMs, 0);
  const gained = rate * (elapsedMs / HOUR_MS);

  const stockActive = now < stockUntilMs;
  const graceUntilMs = business.grace_until ? new Date(business.grace_until).getTime() : null;
  const graceExpired = !stockActive && graceUntilMs !== null && now >= graceUntilMs;

  return {
    rate,
    accrued: Number(business.accrued_balance || 0) + gained,
    stockActive,
    stockUntilMs,
    graceUntilMs,
    graceExpired,
  };
}

// Фиксирует накопленное в БД (переносит "на лету" начисленное в accrued_balance, двигает
// since_at). Если сырьё как раз закончилось прямо сейчас (stockActive стало false, а
// grace_until ещё не выставлен) — проставляет grace_until. Вызывать в начале любого действия
// с конкретным бизнесом, чтобы дальнейшие расчёты шли от актуального состояния.
async function settle(business, now = Date.now()) {
  const live = computeLive(business, now);
  const fields = {
    accruedBalance: live.accrued,
    sinceAt: new Date(Math.min(now, live.stockUntilMs)),
  };
  if (!live.stockActive && !business.grace_until) {
    fields.graceUntil = new Date(live.stockUntilMs + C.BUSINESS_GRACE_HOURS * HOUR_MS);
  }
  const updated = await businessDb.updateBusiness(business.id, fields);
  return { business: updated, live: computeLive(updated, now) };
}

// Список бизнесов игрока с уже расчитанным (settled) актуальным состоянием
async function listMy(vkId) {
  const businesses = await businessDb.getBusinessesByPlayer(vkId);
  const result = [];
  for (const b of businesses) {
    const { business, live } = await settle(b);
    result.push({ business, live, type: getTypeById(business.business_type_id) });
  }
  return result;
}

async function buy(vkId, businessTypeId) {
  return asyncLock.withLock(`business:${vkId}`, () => buyLocked(vkId, businessTypeId));
}

async function buyLocked(vkId, businessTypeId) {
  const player = await players.getPlayer(vkId);
  if (!player) return { ok: false, reason: 'not_registered' };

  const type = getTypeById(businessTypeId);
  if (!type) return { ok: false, reason: 'invalid_type' };

  const count = await businessDb.countByPlayer(vkId);
  const limit = getSlotLimit(player);
  if (count >= limit) return { ok: false, reason: 'slots_full', limit };

  if (Number(player.balance) < type.price) {
    return { ok: false, reason: 'not_enough_money', price: type.price, missing: type.price - Number(player.balance) };
  }

  await players.updateBalance(vkId, -type.price);
  const stockUntil = new Date(Date.now() + C.BUSINESS_STOCK_HOURS * HOUR_MS);
  const business = await businessDb.createBusiness(vkId, type.id, stockUntil);

  return { ok: true, business, type };
}

async function sell(vkId, businessId) {
  return asyncLock.withLock(`business:${vkId}`, () => sellLocked(vkId, businessId));
}

async function sellLocked(vkId, businessId) {
  const business = await businessDb.getOwnedBusiness(vkId, businessId);
  if (!business) return { ok: false, reason: 'not_found' };

  const type = getTypeById(business.business_type_id);
  const price = sellPriceFor(type);

  await players.updateBalance(vkId, price);
  await businessDb.deleteBusiness(business.id);

  return { ok: true, price, type };
}

async function collect(vkId, businessId) {
  return asyncLock.withLock(`business:${vkId}`, () => collectLocked(vkId, businessId));
}

async function collectLocked(vkId, businessId) {
  const business = await businessDb.getOwnedBusiness(vkId, businessId);
  if (!business) return { ok: false, reason: 'not_found' };

  const player = await players.getPlayer(vkId);
  const { business: settled, live } = await settle(business);

  const factoryMult = getFactoryMultiplier(player.factories);
  const amount = Math.floor(live.accrued * factoryMult);
  if (amount <= 0) return { ok: false, reason: 'nothing_to_collect' };

  await players.updateBalance(vkId, amount);
  await businessDb.updateBusiness(settled.id, { accruedBalance: 0 });

  return { ok: true, amount, factoryMult };
}

async function collectAll(vkId) {
  return asyncLock.withLock(`business:${vkId}`, () => collectAllLocked(vkId));
}

async function collectAllLocked(vkId) {
  const player = await players.getPlayer(vkId);
  if (!player) return { ok: false, reason: 'not_registered' };

  const businesses = await businessDb.getBusinessesByPlayer(vkId);
  const factoryMult = getFactoryMultiplier(player.factories);

  let total = 0;
  for (const b of businesses) {
    const { business: settled, live } = await settle(b);
    const amount = Math.floor(live.accrued * factoryMult);
    if (amount > 0) {
      total += amount;
      await businessDb.updateBusiness(settled.id, { accruedBalance: 0 });
    }
  }

  if (total <= 0) return { ok: false, reason: 'nothing_to_collect' };
  await players.updateBalance(vkId, total);
  return { ok: true, amount: total, factoryMult, count: businesses.length };
}

async function refill(vkId, businessId) {
  return asyncLock.withLock(`business:${vkId}`, () => refillLocked(vkId, businessId));
}

async function refillLocked(vkId, businessId) {
  const business = await businessDb.getOwnedBusiness(vkId, businessId);
  if (!business) return { ok: false, reason: 'not_found' };

  const player = await players.getPlayer(vkId);
  const type = getTypeById(business.business_type_id);
  const cost = refillCostFor(type);

  if (Number(player.balance) < cost) {
    return { ok: false, reason: 'not_enough_money', cost, missing: cost - Number(player.balance) };
  }

  // Фиксируем то, что уже накопилось (на случай если сырьё как раз кончилось) ДО пополнения
  const { business: settled } = await settle(business);

  await players.updateBalance(vkId, -cost);
  const now = Date.now();
  // БАГ (был): stockUntil всегда ставился как now + 72ч, из-за чего повторное пополнение
  // ДО истечения текущего запаса просто затирало остаток вместо того, чтобы прибавлять
  // к нему (например: 61ч осталось + 72ч пополнение = должно стать 133ч, а показывало 72ч).
  // Исправлено: если сырьё ещё не кончилось (settled.stock_until в будущем), 72ч добавляются
  // СВЕРХУ остатка; если уже кончилось — считаем как раньше, от текущего момента.
  const currentStockUntilMs = settled.stock_until ? new Date(settled.stock_until).getTime() : 0;
  const base = currentStockUntilMs > now ? currentStockUntilMs : now;
  await businessDb.updateBusiness(settled.id, {
    stockUntil: new Date(base + C.BUSINESS_STOCK_HOURS * HOUR_MS),
    graceUntil: null,
    sinceAt: new Date(now),
  });

  return { ok: true, cost };
}

async function upgrade(vkId, businessId) {
  return asyncLock.withLock(`business:${vkId}`, () => upgradeLocked(vkId, businessId));
}

async function upgradeLocked(vkId, businessId) {
  const business = await businessDb.getOwnedBusiness(vkId, businessId);
  if (!business) return { ok: false, reason: 'not_found' };

  if (business.level >= C.BUSINESS_MAX_LEVEL) return { ok: false, reason: 'max_level' };

  const cost = C.BUSINESS_UPGRADE_COSTS[business.level];
  const player = await players.getPlayer(vkId);

  // Апгрейд 4->5 требует ещё и выдержать BUSINESS_LEVEL4_HOLD_HOURS часов непрерывно на 4 уровне
  if (cost.holdHours) {
    if (!business.level4_since_at) {
      return { ok: false, reason: 'hold_not_started' };
    }
    const heldMs = Date.now() - new Date(business.level4_since_at).getTime();
    const neededMs = cost.holdHours * HOUR_MS;
    if (heldMs < neededMs) {
      return { ok: false, reason: 'hold_not_enough', hoursLeft: Math.ceil((neededMs - heldMs) / HOUR_MS) };
    }
  }

  if (Number(player.balance) < cost.virts) {
    return { ok: false, reason: 'not_enough_money', cost: cost.virts, missing: cost.virts - Number(player.balance) };
  }
  const tokensNeeded = cost.tokens || 0;
  if (tokensNeeded > 0 && (player.tokens || 0) < tokensNeeded) {
    return { ok: false, reason: 'not_enough_tokens', tokensNeeded, tokensMissing: tokensNeeded - (player.tokens || 0) };
  }

  // Фиксируем накопленное под старым уровнем/ставкой перед переходом на новый
  const { business: settled } = await settle(business);

  await players.updateBalance(vkId, -cost.virts);
  if (tokensNeeded > 0) await players.addTokens(vkId, -tokensNeeded);

  const newLevel = business.level + 1;
  const fields = { level: newLevel };
  // Как только дошли ровно до 4 уровня — запускаем отсчёт "выдержки" для будущего апгрейда 4->5
  if (newLevel === 4) fields.level4SinceAt = new Date();

  await businessDb.updateBusiness(settled.id, fields);

  return { ok: true, newLevel, cost };
}

// Фоновая задача (каждую минуту, см. game/scheduler.js): удаляет бизнесы, у которых сырьё
// кончилось и льготный период (BUSINESS_GRACE_HOURS) истёк без пополнения.
async function processDecay(bot) {
  const expired = await businessDb.getExpiredGrace(C.BUSINESS_GRACE_HOURS);
  for (const business of expired) {
    const type = getTypeById(business.business_type_id);
    await businessDb.deleteBusiness(business.id);
    if (bot) {
      bot
        .notifyUser(
          business.player_id,
          `⚠️ Бизнес «${type ? type.name : '?'}» слетел — сырьё кончилось, а пополнить его вовремя не успели.`
        )
        .catch(() => {});
    }
  }
}

module.exports = {
  getCatalog,
  getTypeById,
  sellPriceFor,
  refillCostFor,
  getSlotLimit,
  getFactoryMultiplier,
  levelMultiplier,
  baseIncomePerHour,
  computeLive,
  settle,
  listMy,
  buy,
  sell,
  collect,
  collectAll,
  refill,
  upgrade,
  processDecay,
};
