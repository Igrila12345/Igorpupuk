'use strict';

const cron = require('node-cron');
const economy = require('./economy');
const miner = require('./miner');
const farm = require('./farm');
const business = require('./business');
const shop = require('./shop');
const ratings = require('./ratings');
const casino = require('./casino');
const zoneWar = require('./zoneWar');
const factoryRace = require('./factoryRace');
const donateBusiness = require('./donateBusiness');
const attackResolver = require('./attackResolver');
const auction = require('./auction');
const shopDb = require('../db/shop');
const postLikes = require('./postLikes');
const C = require('./constants');

function startScheduler(bot) {
  // Прилёты атак — раз в 3 минуты вместо каждой минуты. Компенсировано увеличением
  // реального времени полёта оружия (game/constants.js: WEAPON_SPEED_MULTIPLIER 3 -> 1),
  // так что худший случай ожидания результата удара практически не изменился по факту —
  // раньше снаряд летел ~15-45 сек и лежал в очереди до минутного тика (итого до ~1 мин),
  // теперь летит ~1-2.5 мин и лежит в очереди до 3-минутного тика (итого до ~3-5 мин),
  // разница ощущается некритично, а количество обращений к БД падает в 3 раза.
  cron.schedule('*/3 * * * *', async () => {
    try {
      await attackResolver.resolvePendingAttacks(bot);
    } catch (err) {
      console.error('[Scheduler] Ошибка обработки прилётов:', err);
    }
  });

  // Фоновая "уборка" без ощутимого игроками таймера — разблокировка заводов по времени,
  // снятие радиации, истечение аукционов, деградация бизнеса, а также подведение итогов
  // войны за зоны/гонки заводов (maybeResolveCycle сама проверяет, наступило ли время —
  // это просто дешёвая проверка даты, реальная работа внутри запускается, только когда
  // цикл действительно истёк). Раньше подведение итогов зон/гонки жило ТОЛЬКО в
  // ежедневном тике ровно в 00:00 МСК (см. блок ниже) — если процесс в эту ТОЧНУЮ минуту
  // не работал (перезапуск/деплой/краш), тик пропускался целиком и цикл "зависал" молча
  // до следующей полуночи (а если и та тоже была пропущена — то и дальше). Здесь же,
  // раз в 5 минут, отставание не может превысить 5 минут, даже если бот был выключен
  // прямо в момент истечения цикла — при следующем запуске тик просто доберёт то, что
  // просрочено. Остальные задачи (разблокировка заводов, радиация, аукционы, деградация
  // бизнеса, магазин) тоже раньше проверялись каждую минуту, хотя ни одна из них не
  // требует секундной точности.
  cron.schedule('*/5 * * * *', async () => {
    try {
      await economy.processFactoryUnblocks();
      await economy.processRadiationExpiry();
      await auction.resolveExpiredAuctions(bot);
      await business.processDecay(bot);
      await shop.refreshShop();
    } catch (err) {
      console.error('[Scheduler] Ошибка в 5-минутном тике:', err);
    }
    try {
      await zoneWar.maybeResolveCycle(bot);
    } catch (err) {
      console.error('[Scheduler] Ошибка подведения итогов войны за зоны:', err);
    }
    try {
      await factoryRace.maybeResolveCycle(bot);
    } catch (err) {
      console.error('[Scheduler] Ошибка подведения итогов гонки заводов:', err);
    }
  });

  // Синхронизация лайков постов — раз в 20 минут вместо каждой минуты. Штраф за
  // нелайкнутый пост и так даётся с запасом по грейс-периоду (см. C.POST_LIKE_GRACE_PERIOD_MS),
  // разница в 20 минут на срабатывание/снятие штрафа для игроков не критична, а именно
  // эта задача была одной из самых "прожорливых" по compute — тяжёлый пересчёт по всем
  // игрокам + опрос VK API на каждом тике.
  cron.schedule('*/20 * * * *', async () => {
    try {
      await postLikes.syncAndRecompute(bot);
    } catch (err) {
      console.error('[Scheduler] Ошибка синхронизации лайков постов:', err);
    }
  });

  // Каждый час: доход, налоги, курс нанокоина майнинг-фермы (сама добыча теперь считается
  // "на лету" в реальном времени в game/farm.js, почасовой тик ей не требуется)
  cron.schedule('0 * * * *', async () => {
    try {
      await economy.hourlyTick(bot);
      await miner.hourlyMinerTick();
      await donateBusiness.hourlyTick(bot);
      await farm.updateExchangeRate();
    } catch (err) {
      console.error('[Scheduler] Ошибка в часовом тике (доход/налоги):', err);
    }
  });

  // Ежедневно в 00:00 по МСК (сервер должен быть настроен на TZ=Europe/Moscow либо укажем явно)
  // Война за зоны и гонка заводов здесь больше НЕ подводятся — см. 5-минутный тик выше:
  // там то же самое maybeResolveCycle(), но без риска молча пропустить единственную
  // минуту в сутки, когда это могло случиться.
  cron.schedule(
    '0 0 * * *',
    async () => {
      try {
        await ratings.distributeDailyRewards(bot);
      } catch (err) {
        console.error('[Scheduler] Ошибка выдачи ежедневных наград:', err);
      }
      try {
        await casino.distributeDailyRewards(bot);
      } catch (err) {
        console.error('[Scheduler] Ошибка выдачи ежедневных наград казино:', err);
      }
      try {
        await donateBusiness.dailyTick(bot);
      } catch (err) {
        console.error('[Scheduler] Ошибка тика донат-бизнесов:', err);
      }
    },
    { timezone: 'Europe/Moscow' }
  );

  console.log('[Scheduler] Все фоновые задачи запущены.');
}

// Восстановление состояния при старте: если магазин пуст, генерируем сразу
async function bootstrapState() {
  const state = await shopDb.getShopState();
  if (!state.items || state.items.length === 0) {
    await shop.refreshShop();
  }
}

// Первый прогон подведения итогов зон/гонки заводов сразу при старте — чтобы просроченный
// (например, из-за простоя бота на момент истечения цикла) цикл не ждал ближайшего
// 5-минутного тика (см. startScheduler выше), а закрывался сразу же, как только бот снова
// поднялся. bot передаётся отдельно — та же причина, что и у bootstrapPostLikes ниже: на
// момент bootstrapState() бот ещё не создан.
async function bootstrapCycles(bot) {
  try {
    await zoneWar.maybeResolveCycle(bot);
  } catch (err) {
    console.error('[Scheduler] Ошибка первичного подведения итогов войны за зоны:', err);
  }
  try {
    await factoryRace.maybeResolveCycle(bot);
  } catch (err) {
    console.error('[Scheduler] Ошибка первичного подведения итогов гонки заводов:', err);
  }
}

// Первый прогон синхронизации лайков сразу при старте (не дожидаясь первого 20-минутного
// тика) — чтобы штрафной флаг был актуален с самого запуска бота, а не пустым до 20 минут.
// bot передаётся отдельно (а не через bootstrapState(bot)), т.к. на момент запуска scheduler
// ещё не стартован — вызывается из index.js после создания Bot, см. комментарий там же.
async function bootstrapPostLikes(bot) {
  try {
    await postLikes.syncAndRecompute(bot);
  } catch (err) {
    console.error('[Scheduler] Ошибка первичной синхронизации лайков постов:', err);
  }
}

module.exports = { startScheduler, bootstrapState, bootstrapCycles, bootstrapPostLikes };
