'use strict';

const { query } = require('./pool');
const C = require('../game/constants');

// Уровень сейфа по общей сумме собранного. Уровни 1-550 — как раньше, линейно
// (по CLAN_VAULT_LEVEL_STEP на уровень). Уровни 551-999 — резко тяжелее: "стоимость"
// каждого следующего уровня растёт (шаг = CLAN_VAULT_HARD_STEP_BASE * номер_доп_уровня),
// поэтому суммарный прогресс там квадратичный, а не линейный — см. constants.js.
function totalRequiredForLevel(level) {
  const threshold = C.CLAN_VAULT_HARD_LEVEL_THRESHOLD;
  if (level <= threshold) return level * C.CLAN_VAULT_LEVEL_STEP;
  const base = threshold * C.CLAN_VAULT_LEVEL_STEP;
  const n = level - threshold;
  const extra = (C.CLAN_VAULT_HARD_STEP_BASE * n * (n + 1)) / 2;
  return base + extra;
}

function levelFromTotal(total) {
  const value = Number(total);
  const threshold = C.CLAN_VAULT_HARD_LEVEL_THRESHOLD;
  const easyMax = threshold * C.CLAN_VAULT_LEVEL_STEP;

  if (value <= easyMax) {
    return Math.min(C.CLAN_VAULT_MAX_LEVEL, Math.floor(value / C.CLAN_VAULT_LEVEL_STEP));
  }

  const remaining = value - easyMax;
  // Обратная задача к сумме треугольных чисел: HARD_STEP_BASE * n*(n+1)/2 <= remaining.
  const n = Math.floor((-1 + Math.sqrt(1 + (8 * remaining) / C.CLAN_VAULT_HARD_STEP_BASE)) / 2);
  return Math.min(C.CLAN_VAULT_MAX_LEVEL, threshold + Math.max(0, n));
}

async function getClanById(id) {
  const res = await query('SELECT * FROM clans WHERE id = $1', [id]);
  return res.rows[0] || null;
}

async function getClanByName(name) {
  const res = await query('SELECT * FROM clans WHERE LOWER(name) = LOWER($1)', [name]);
  return res.rows[0] || null;
}

async function createClan(name, leaderId) {
  const res = await query(
    `INSERT INTO clans (name, leader_id) VALUES ($1, $2) RETURNING *`,
    [name, leaderId]
  );
  return res.rows[0];
}

async function getClanMembers(clanId) {
  const res = await query('SELECT * FROM players WHERE clan_id = $1', [clanId]);
  return res.rows;
}

// Пополнение сейфа (налог с дохода или ручной взнос игрока). Сам сейф капается по maxVault,
// но vault_total_collected растёт на всю сумму без ограничения — именно он определяет уровень сейфа.
//
// GREATEST(vault, $3) — защита от «усушки» сейфа: вместимость зависит от суммы заводов клана
// (см. game/clan.js: getClanVaultInfo — baseMaxVault = заводы * CLAN_VAULT_PER_FACTORY), а
// заводы могут ПРОПАСТЬ (снесли в войне, участники вышли из клана). Если после этого
// вместимость окажется НИЖЕ уже накопленного, простой LEAST(vault + amount, maxVault) вернул
// бы maxVault, то есть очередное начисление молча ОБРЕЗАЛО бы сейф до нового потолка: клан с
// полным сейфом на 50 000 после потери заводов терял бы разом 30 000+ вирт, причём именно в
// момент «прихода дохода». Теперь потолок для этой операции — не ниже текущего остатка:
// сверх лимита ничего не добавляется, но и уже накопленное не отнимается. Тратится такой
// «переполненный» сейф как обычно (spendVault/withdrawVault), и по мере трат приходит в норму.
async function addVault(clanId, amount, maxVault) {
  const res = await query(
    `UPDATE clans
     SET vault = LEAST(vault + $2, GREATEST(vault, $3)),
         vault_total_collected = vault_total_collected + $2
     WHERE id = $1
     RETURNING vault, vault_total_collected`,
    [clanId, amount, maxVault]
  );
  if (!res.rows[0]) return null;
  return {
    vault: Number(res.rows[0].vault),
    totalCollected: Number(res.rows[0].vault_total_collected),
  };
}

// Пересчитывает и сохраняет уровень сейфа исходя из общей суммы, когда-либо собранной.
// Уровень — это прогресс клана, поэтому он никогда не пересчитывается в меньшую сторону.
async function syncVaultLevel(clanId, totalCollected) {
  const level = levelFromTotal(Number(totalCollected));
  const res = await query(
    `UPDATE clans SET vault_level = $2 WHERE id = $1 AND vault_level < $2 RETURNING vault_level`,
    [clanId, level]
  );
  return { level, leveledUp: res.rows.length > 0 };
}

// Трата сейфа на клановые бонусы — не влияет на vault_total_collected/уровень.
async function spendVault(clanId, amount) {
  const res = await query(
    `UPDATE clans SET vault = vault - $2 WHERE id = $1 AND vault >= $2 RETURNING vault`,
    [clanId, amount]
  );
  return res.rows[0] ? Number(res.rows[0].vault) : null;
}

// Донат: разово прибавляет вечную вместимость сейфа (см. CLAN_VAULT_EXTRA_CAPACITY_AMOUNT в
// constants.js) — складывается при повторных покупках, никогда не уменьшается сама по себе.
async function addExtraVaultCapacity(clanId, amount) {
  const res = await query(
    `UPDATE clans SET vault_extra_capacity = vault_extra_capacity + $2 WHERE id = $1
     RETURNING vault_extra_capacity`,
    [clanId, amount]
  );
  return res.rows[0] ? Number(res.rows[0].vault_extra_capacity) : null;
}

// Возврат средств в сейф клана — используется как страховка, если после списания
// (spendVault) последующий шаг всё же не удался, чтобы деньги не терялись впустую.
async function refundVault(clanId, amount) {
  const res = await query(`UPDATE clans SET vault = vault + $2 WHERE id = $1 RETURNING vault`, [
    clanId,
    amount,
  ]);
  return res.rows[0] ? Number(res.rows[0].vault) : null;
}

// Снятие сейфа главой клана себе на баланс — тоже не влияет на уровень (он только растёт).
async function withdrawVault(clanId, amount) {
  const res = await query(
    `UPDATE clans SET vault = vault - $2 WHERE id = $1 AND vault >= $2 RETURNING vault`,
    [clanId, amount]
  );
  return res.rows[0] ? Number(res.rows[0].vault) : null;
}

// Лог снятия из сейфа — виден главе и заму через "клан сейф логи" (см. game/clan.js: withdrawVault()).
async function logVaultWithdraw(clanId, vkId, amount) {
  await query('INSERT INTO clan_vault_logs (clan_id, vk_id, amount) VALUES ($1, $2, $3)', [
    clanId,
    vkId,
    amount,
  ]);
}

async function getVaultLogs(clanId, limit = 15) {
  const res = await query(
    `SELECT l.vk_id, l.amount, l.created_at, p.state_name
     FROM clan_vault_logs l
     LEFT JOIN players p ON p.vk_id = l.vk_id
     WHERE l.clan_id = $1
     ORDER BY l.created_at DESC
     LIMIT $2`,
    [clanId, limit]
  );
  return res.rows;
}

async function setBonusActive(clanId, bonusKey, until, cooldownUntil) {
  const colUntil = `bonus_${bonusKey}_until`;
  const colCd = `bonus_${bonusKey}_cooldown`;
  await query(
    `UPDATE clans SET ${colUntil} = $2, ${colCd} = $3 WHERE id = $1`,
    [clanId, until, cooldownUntil]
  );
}

async function createInvite(clanId, playerId) {
  await query(
    `INSERT INTO clan_invites (clan_id, player_id) VALUES ($1, $2)
     ON CONFLICT (clan_id, player_id) DO NOTHING`,
    [clanId, playerId]
  );
}

async function hasInvite(clanId, playerId) {
  const res = await query(
    'SELECT 1 FROM clan_invites WHERE clan_id = $1 AND player_id = $2',
    [clanId, playerId]
  );
  return res.rows.length > 0;
}

async function removeInvite(clanId, playerId) {
  await query('DELETE FROM clan_invites WHERE clan_id = $1 AND player_id = $2', [
    clanId,
    playerId,
  ]);
}

async function getClanFactoriesSum(clanId) {
  const res = await query(
    'SELECT COALESCE(SUM(factories), 0) AS total FROM players WHERE clan_id = $1',
    [clanId]
  );
  return Number(res.rows[0].total);
}

async function getTopClansByFactories(limit = 10) {
  const res = await query(
    `SELECT c.id, c.name, c.vault, c.leader_id, COALESCE(SUM(p.factories), 0) AS total_factories
     FROM clans c
     LEFT JOIN players p ON p.clan_id = c.id
     GROUP BY c.id
     ORDER BY total_factories DESC
     LIMIT $1`,
    [limit]
  );
  return res.rows;
}

// Снимок заводов ВСЕХ кланов (не только топ-N) — нужен гонке заводов (game/factoryRace.js),
// чтобы на финише недели посчитать прирост даже у клана, который сейчас не в топе.
async function getClansFactoriesSnapshot() {
  const res = await query(
    `SELECT c.id, c.name, COALESCE(SUM(p.factories), 0) AS total_factories
     FROM clans c
     LEFT JOIN players p ON p.clan_id = c.id
     GROUP BY c.id`
  );
  return res.rows;
}

async function setLeader(clanId, newLeaderId) {
  await query('UPDATE clans SET leader_id = $2 WHERE id = $1', [clanId, newLeaderId]);
}

// value — VK attachment-строка ("photo-123456_789") или null, чтобы снять.
async function setClanPhoto(clanId, value) {
  await query('UPDATE clans SET clan_photo = $2 WHERE id = $1', [clanId, value]);
}

async function setClanVideo(clanId, value) {
  await query('UPDATE clans SET clan_video = $2 WHERE id = $1', [clanId, value]);
}

async function getAllClans() {
  const res = await query('SELECT * FROM clans');
  return res.rows;
}

// Снимает клан со всех участников разом (используется при роспуске клана).
async function clearMembersClan(clanId) {
  await query('UPDATE players SET clan_id = NULL, clan_role = NULL WHERE clan_id = $1', [clanId]);
}

async function deleteClan(clanId) {
  await query('DELETE FROM clans WHERE id = $1', [clanId]);
}

module.exports = {
  getClanById,
  getClanByName,
  createClan,
  getClanMembers,
  addVault,
  syncVaultLevel,
  levelFromTotal,
  totalRequiredForLevel,
  spendVault,
  refundVault,
  addExtraVaultCapacity,
  withdrawVault,
  logVaultWithdraw,
  getVaultLogs,
  setBonusActive,
  createInvite,
  hasInvite,
  removeInvite,
  getClanFactoriesSum,
  getTopClansByFactories,
  getClansFactoriesSnapshot,
  getAllClans,
  clearMembersClan,
  deleteClan,
  setLeader,
  setClanPhoto,
  setClanVideo,
};
