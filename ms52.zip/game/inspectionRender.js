'use strict';

const Jimp = require('jimp');
const C = require('./constants');

const CELL = 150;
const GAP = 16;
const MARGIN_SIDE = 30;
const MARGIN_TOP = 90;
const MARGIN_BOTTOM = 30;
const BORDER = 4;
const ICON_SIZE = 46;

const BG_COLOR = 0x14181fff;
const CELL_COLOR = 0x232a36ff;
const CELL_BORDER_COLOR = 0x4fc3f7ff;
const ICON_COLOR = 0xffa726ff;
const ICON_BORDER_COLOR = 0x7a4a00ff;

let fontTitleCache = null;
let fontLabelCache = null;

async function getFonts() {
  if (!fontTitleCache) fontTitleCache = await Jimp.loadFont(Jimp.FONT_SANS_32_WHITE);
  if (!fontLabelCache) fontLabelCache = await Jimp.loadFont(Jimp.FONT_SANS_32_WHITE);
  return { fontTitle: fontTitleCache, fontLabel: fontLabelCache };
}

async function buildFactoryIcon() {
  const icon = await new Jimp(ICON_SIZE, ICON_SIZE, ICON_COLOR);
  for (let x = 0; x < ICON_SIZE; x++) {
    for (let y = 0; y < ICON_SIZE; y++) {
      if (x === 0 || y === 0 || x === ICON_SIZE - 1 || y === ICON_SIZE - 1) {
        icon.setPixelColor(ICON_BORDER_COLOR, x, y);
      }
    }
  }
  return icon;
}

async function drawCellFrame(image, x, y, size, color) {
  const top = await new Jimp(size, BORDER, color);
  const bottom = await new Jimp(size, BORDER, color);
  const left = await new Jimp(BORDER, size, color);
  const right = await new Jimp(BORDER, size, color);
  image.composite(top, x, y);
  image.composite(bottom, x, y + size - BORDER);
  image.composite(left, x, y);
  image.composite(right, x + size - BORDER, y);
}

// session: { round, size, cols, anomalyIndex }
async function renderRound(session) {
  const size = session.size;
  const cols = Math.ceil(Math.sqrt(size));
  const rows = Math.ceil(size / cols);

  const width = MARGIN_SIDE * 2 + cols * CELL + (cols - 1) * GAP;
  const height = MARGIN_TOP + rows * CELL + (rows - 1) * GAP + MARGIN_BOTTOM;

  const image = await new Jimp(width, height, BG_COLOR);
  const { fontTitle, fontLabel } = await getFonts();
  const normalIcon = await buildFactoryIcon();
  const anomalyIcon = normalIcon.clone().rotate(45, false);

  image.print(
    fontTitle,
    0,
    15,
    {
      text: `🔍 ИНСПЕКЦИЯ — раунд ${session.round}/${C.INSPECTION_ROUNDS}`,
      alignmentX: Jimp.HORIZONTAL_ALIGN_CENTER,
      alignmentY: Jimp.VERTICAL_ALIGN_MIDDLE,
    },
    width,
    40
  );

  for (let i = 0; i < size; i++) {
    const col = i % cols;
    const row = Math.floor(i / cols);
    const cellX = MARGIN_SIDE + col * (CELL + GAP);
    const cellY = MARGIN_TOP + row * (CELL + GAP);

    const fill = await new Jimp(CELL, CELL, CELL_COLOR);
    image.composite(fill, cellX, cellY);
    await drawCellFrame(image, cellX, cellY, CELL, CELL_BORDER_COLOR);

    image.print(
      fontLabel,
      cellX,
      cellY - 55,
      {
        text: `${i + 1}`,
        alignmentX: Jimp.HORIZONTAL_ALIGN_CENTER,
        alignmentY: Jimp.VERTICAL_ALIGN_MIDDLE,
      },
      CELL,
      40
    );

    const icon = i === session.anomalyIndex ? anomalyIcon : normalIcon;
    const iconX = cellX + Math.round((CELL - icon.bitmap.width) / 2);
    const iconY = cellY + Math.round((CELL - icon.bitmap.height) / 2);
    image.composite(icon, iconX, iconY);
  }

  return image.getBufferAsync(Jimp.MIME_PNG);
}

module.exports = { renderRound };
