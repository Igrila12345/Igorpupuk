'use strict';

const C = require('./constants');

// Генерирует один раунд "инспекции": INSPECTION_GRID_SIZE одинаковых значков-заводов,
// один из которых "аномальный" (в рендере — развёрнут на 45° и обведён красным).
// Игрок должен найти его и нажать номер соответствующей ячейки.
function generateRound() {
  const size = C.INSPECTION_GRID_SIZE;
  const anomalyIndex = Math.floor(Math.random() * size);
  return { size, anomalyIndex };
}

module.exports = { generateRound };
