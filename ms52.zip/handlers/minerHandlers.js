'use strict';

const players = require('../db/players');
const calc = require('../game/calc');
const C = require('../game/constants');
const msg = require('../utils/messages');

async function handleStatus(ctx) {
  const player = await players.getPlayer(ctx.senderId);
  if (!player || player.registration_step !== 'done') {
    await ctx.send('⛔ Вы ещё не зарегистрированы. Напишите старт');
    return;
  }

  if (!calc.isMinerActive(player)) {
    await ctx.send(
      `⛏️ Майнер у вас не активен.\n` +
        `Майнер — донат-предмет: выдаётся администратором после оплаты и пассивно приносит немного вирт и жетонов каждый час, без каких-либо действий с вашей стороны.`
    );
    return;
  }

  const untilText = calc.isMinerForever(player) ? 'НАВСЕГДА' : `до ${msg.formatDateTimeMsk(player.miner_until)}`;

  await ctx.send(
    `⛏️ Майнер активен ${untilText}.\n` +
      `Каждый час пассивно приносит: ${calc.formatNumber(C.MINER_HOURLY_VIRTS_MIN)} вирт + ${
        C.MINER_HOURLY_TOKENS
      } жетонов.`
  );
}

module.exports = { handleStatus };
