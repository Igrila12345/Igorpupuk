'use strict';

const C = require('../game/constants');
const msg = require('../utils/messages');
const calc = require('../game/calc');
const donateBuffs = require('../game/donateBuffs');

async function handleDonate(ctx) {
  const adminLinks = C.ADMIN_IDS.map((id) => msg.mentionLink(id, 'администратору')).join(', ');
  const flashOffer = await donateBuffs.getFlashOffer();

  const text =
    `💎═══════════════════════════💎\n` +
    `      Д О Н А Т — П Р А Й С\n` +
    `💎═══════════════════════════💎\n\n` +
    `┌─── 👑 НАВСЕГДА (разовая покупка) ───┐\n\n` +
    `👑 VIP — ${C.DONATE_VIP_PRICE_RUB_MONTH} ₽ / месяц\n` +
    `    ▸ +${Math.round(C.VIP_INCOME_BONUS * 100)}% к доходу\n` +
    `    ▸ кулдауны робота короче на ${Math.round((1 - C.VIP_ROBOT_COOLDOWN_MULT) * 100)}%\n` +
    `    ▸ +${C.VIP_BUILD_LIMIT_BONUS} построек завода в час\n` +
    `    (есть дешёвый разовый вход — «VIP-день», см. ниже)\n\n` +
    `⛏️ Майнер — ${C.DONATE_MINER_PRICE_RUB} ₽\n` +
    `    ▸ пассивно ${calc.formatNumber(C.MINER_HOURLY_VIRTS_MIN)} вирт + ${C.MINER_HOURLY_TOKENS} жетонов/час, без действий\n\n` +
    `🤖 Суперробот — ${C.DONATE_SUPER_ROBOT_PRICE_RUB} ₽\n` +
    `    ▸ открывает суперробота (1 уровень), дальше качается вирт-командой «суперробот прокачать»\n\n` +
    `🎨 Персональный стиль — ${C.DONATE_PERSONAL_STYLE_PRICE_RUB} ₽\n` +
    `    ▸ кастомное фото/видео профиля, попадает в ваш инвентарь стилей (команда «стиль»)\n` +
    `    ▸ можно позже перепродать другому игроку на витрине («витрина»)\n\n` +
    `┌─── ⚡ МГНОВЕННЫЕ УСКОРИТЕЛИ (разовые) ───┐\n\n` +
    `🔓 Сброс кулдауна робота/суперробота/дозора — ${C.DONATE_INSTANT_COOLDOWN_PRICE_RUB} ₽\n` +
    `🏭 Мгновенное завершение производства — ${C.DONATE_INSTANT_PRODUCTION_PRICE_RUB} ₽\n` +
    `👷 +${C.DONATE_WORK_EXTRA_ATTEMPTS} попыток «работы» сверх дневного лимита — ${C.DONATE_WORK_EXTRA_PRICE_RUB} ₽\n` +
    `🔁 Снять сегодняшний лимит обмена жетонов на завод/науку — ${C.DONATE_EXCHANGE_LIMIT_LIFT_PRICE_RUB} ₽\n\n` +
    `┌─── 🔥 ДНЕВНЫЕ БАФФЫ (истекают по времени) ───┐\n\n` +
    `💰 Буст дохода на ${C.DONATE_INCOME_BOOST_DURATION_HOURS}ч\n` +
    `    ▸ x1.5 — ${C.DONATE_INCOME_BOOST_PRICE_RUB_X15} ₽  |  x2 — ${C.DONATE_INCOME_BOOST_PRICE_RUB_X2} ₽\n\n` +
    `🛡️ Щит на ${C.DONATE_SHIELD_DURATION_DAYS} дня — ${C.DONATE_SHIELD_PRICE_RUB} ₽\n` +
    `    ▸ защита от ЛЮБОГО оружия, КРОМЕ ядерного (ядерный удар пробивает щит полностью)\n\n` +
    `🪙 Двойные жетоны за «работу» на ${C.DONATE_WORK_DOUBLE_DURATION_HOURS}ч — ${C.DONATE_WORK_DOUBLE_PRICE_RUB} ₽\n` +
    `⛏️ Ускорение фермы (x${C.DONATE_FARM_BOOST_MULTIPLIER}) на ${C.DONATE_FARM_BOOST_DURATION_HOURS}ч — ${C.DONATE_FARM_BOOST_PRICE_RUB} ₽\n` +
    `👑 VIP-день — ${C.DONATE_VIP_DAY_PRICE_RUB} ₽\n` +
    `    ▸ весь VIP на 1 сутки — дешёвый разовый вход вместо целого месяца\n\n` +
    `👹 x2 награда за попадание по мировому боссу, СТРОГО на 1 день — ${C.DONATE_BOSS_DOUBLE_PRICE_RUB} ₽\n` +
    `    ▸ действует только пока идёт ивент «босс» (команда игрокам: «босс»)\n\n` +
    `🔥 СТРИК: покупайте дневные баффы (доход/щит/дубль/ускорение) день в день — за каждый\n` +
    `день подряд длительность купленного баффа растёт на +${C.DONATE_STREAK_BONUS_HOURS_PER_DAY}ч сверху\n` +
    `(максимум +${C.DONATE_STREAK_MAX_BONUS_HOURS}ч), пропуск дня сбрасывает стрик.\n\n` +
    (flashOffer
      ? `┌─── 🎯 СЕЙЧАС ИДЁТ ФЛЕШ-АКЦИЯ ───┐\n\n` +
        `«${flashOffer.itemLabel}» со скидкой ${flashOffer.discountPercent}%!\n` +
        `Успей до ${msg.formatDateTimeMsk(flashOffer.expiresAt)} — подробности: акция\n\n`
      : '') +
    `💳 Как оплатить: напишите ${adminLinks}, укажите, что хотите приобрести — товар будет выдан сразу после получения оплаты.\n\n` +
    `🎉 Также иногда проводятся бесплатные сезонные ивенты (зима/весна/лето/осень) — валюта капает\n` +
    `просто за игру, обменять её на заводы/науку/VIP можно в ивент-магазине. Подробнее: ивент`;

  await ctx.send(text);
}

async function handleFlashOffer(ctx) {
  const flashOffer = await donateBuffs.getFlashOffer();
  if (!flashOffer) {
    await ctx.send('Сейчас никаких флеш-акций нет. Полный прайс-лист: донат');
    return;
  }
  await ctx.send(
    `🎯 ФЛЕШ-АКЦИЯ!\n\n` +
      `«${flashOffer.itemLabel}» со скидкой ${flashOffer.discountPercent}%\n` +
      `Успей до: ${msg.formatDateTimeMsk(flashOffer.expiresAt)}\n\n` +
      `Чтобы купить — напишите администратору (команда «донат» покажет ссылку и полный прайс-лист).`
  );
}

module.exports = { handleDonate, handleFlashOffer };
