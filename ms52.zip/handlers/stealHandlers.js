'use strict';

const players = require('../db/players');
const steal = require('../game/steal');
const quests = require('../game/quests');
const calc = require('../game/calc');
const C = require('../game/constants');
const msg = require('../utils/messages');

function bonusText(bonus) {
  if (!bonus) return '';
  if (bonus.type === 'science') return `\n🎁 Бонус за ${C.STEAL_BONUS_EVERY}-ю кражу: +${bonus.amount} 🔬 научный центр (списан у жертвы)!`;
  return `\n🎁 Бонус за ${C.STEAL_BONUS_EVERY}-ю кражу: +${bonus.amount} 🏭 заводов (списаны у жертвы)!`;
}

async function handleSteal(ctx, targetId, peerId) {
  const vkId = ctx.senderId;
  const player = await players.getPlayer(vkId);
  if (!player || player.registration_step !== 'done') {
    await ctx.send('⛔ Вы ещё не зарегистрированы. Напишите !старт');
    return;
  }

  if (!targetId) {
    await ctx.send(`⛔ Формат: !кража @юзер (цель — только топ-${C.STEAL_TOP_N} по заводам, см. !топ заводы)`);
    return;
  }

  const result = await steal.attemptSteal(vkId, targetId);

  if (!result.ok) {
    const reasons = {
      self: '⛔ Нельзя красть у самого себя.',
      not_registered: '⛔ Вы ещё не зарегистрированы. Напишите !старт',
      target_not_registered: '⛔ Цель не зарегистрирована в игре.',
      not_top: `⛔ Красть можно только у топ-${result.topN || C.STEAL_TOP_N} игроков по заводам (см. !топ заводы).`,
      daily_limit: `⛔ Дневной лимит краж исчерпан (${result.limit || C.STEAL_DAILY_LIMIT}/день). Возвращайтесь завтра.`,
      target_broke: '⛔ У цели сейчас нечего красть.',
    };
    if (result.reason === 'cooldown') {
      await ctx.send(`⏳ Кулдаун кражи. Осталось: ${calc.formatDuration(result.msLeft)}.`);
      return;
    }
    await ctx.send(reasons[result.reason] || '⛔ Кража не удалась.');
    return;
  }

  const attackerLink = msg.mentionLink(result.attackerId, result.attackerName);
  const targetLink = msg.mentionLink(result.targetId, result.targetName);

  const questNotices = await quests.trackProgress(vkId, 'steal', 1);

  await ctx.send(
    `🕵️ «${attackerLink}» тайно обчистил казну «${targetLink}»!\n` +
      `Украдено у цели: ${calc.formatNumber(result.stolen)} вирт\n` +
      `Вам досталось: ${calc.formatNumber(result.attackerGain)} вирт (остальное затерялось при отходе)\n` +
      `Краж сегодня: ${result.stealsToday}/${result.dailyLimit}` +
      bonusText(result.bonus) +
      (questNotices.length ? `\n\n${questNotices.join('\n')}` : '')
  );

  if (ctx.bot) {
    await ctx.bot
      .notifyUser(
        result.targetId,
        `🕵️ Вашу казну обчистил неизвестный! Потеряно ${calc.formatNumber(result.stolen)} вирт.` +
          (result.bonus
            ? result.bonus.type === 'science'
              ? ` Также похищен ${result.bonus.amount} научный центр.`
              : ` Также похищено ${result.bonus.amount} заводов.`
            : '')
      )
      .catch(() => {});

    if (peerId) {
      await ctx.bot
        .sendToChat(peerId, `🕵️ «${attackerLink}» обчистил казну «${targetLink}».`)
        .catch(() => {});
    }
  }
}

module.exports = { handleSteal };
