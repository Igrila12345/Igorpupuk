'use strict';

const combat = require('../game/combat');
const players = require('../db/players');
const calc = require('../game/calc');
const C = require('../game/constants');
const msg = require('../utils/messages');
const events = require('../game/events');
const quests = require('../game/quests');

const CATEGORY_LABEL = { drone: 'БПЛА', missile: 'ракет', nuke: 'ядерного оружия' };

function findWeaponKey(name) {
  const lower = (name || '').toLowerCase();
  return Object.keys(C.WEAPONS).find((k) => k.toLowerCase() === lower);
}

async function handleAttack(ctx, targetId, weaponArg, qtyArg, peerId) {
  const vkId = ctx.senderId;
  const player = await players.getPlayer(vkId);
  if (!player || player.registration_step !== 'done') {
    await ctx.send('⛔ Вы ещё не зарегистрированы. Напишите !старт');
    return;
  }

  if (!targetId) {
    await ctx.send('⛔ Укажите цель: !атака @юзер [оружие] [количество]');
    return;
  }

  const weaponKey = findWeaponKey(weaponArg);
  if (!weaponKey) {
    await ctx.send('⛔ Неизвестное оружие.');
    return;
  }

  const quantity = parseInt(qtyArg, 10) || 1;

  const result = await combat.launchAttack(vkId, targetId, weaponKey, quantity, peerId);

  if (!result.ok) {
    const reasons = {
      self_attack: '⛔ Нельзя атаковать самого себя.',
      not_registered: '⛔ Цель не зарегистрирована в игре.',
      attacker_too_small: `⛔ Для этого оружия нужно от ${result.minRequired || C.MIN_FACTORIES_TO_ATTACK} заводов. Сначала развейте экономику.`,
      defender_too_small: `⛔ Нельзя атаковать игрока с менее чем ${C.MIN_FACTORIES_TO_BE_ATTACKED} заводами.`,
      invalid_quantity: `⛔ Некорректное количество. Максимум за раз: ${result.max}.`,
      not_enough_weapons: `⛔ У вас недостаточно этого оружия (в наличии: ${result.have}).`,
      unknown_weapon: '⛔ Неизвестное оружие.',
    };
    if (result.reason === 'category_cooldown') {
      await ctx.send(
        `⏳ Кулдаун на запуск ${CATEGORY_LABEL[result.category] || 'этого оружия'}. Осталось: ${calc.formatDuration(
          result.remainingMs
        )}.`
      );
      return;
    }
    await ctx.send(reasons[result.reason] || '⛔ Атака невозможна.');
    return;
  }

  const weapon = C.WEAPONS[weaponKey];
  const effectText = msg.weaponEffectSummary(weapon);

  const attackerLink = msg.mentionLink(result.attackerId, result.attackerName);
  const defenderLink = msg.mentionLink(result.defenderId, result.defenderName);

  const drop = await events.awardDrop(vkId);
  const questNotices = await quests.trackProgress(vkId, 'attack', 1);

  await ctx.send(
    `🚀 ГОСУДАРСТВО «${attackerLink}» ЗАПУСТИЛО:\n` +
      `Оружие: ${weaponKey} (x${quantity})\n` +
      `Цель: ${defenderLink}\n` +
      `Расстояние: ${Math.round(result.distance)} км\n` +
      `Прилёт через: ${calc.formatDuration(result.flightMs)}\n\n` +
      `Эффект: ${effectText}` +
      events.dropSuffix(drop) +
      (questNotices.length ? `\n\n${questNotices.join('\n')}` : '')
  );

  // Уведомление жертве — название атакующего кликабельно и ведёт на его страницу
  if (ctx.bot) {
    await ctx.bot
      .notifyUser(
        targetId,
        `⚠️ Государство «${attackerLink}» запустило ${weaponKey} по вашему городу! Прилёт через ${calc.formatDuration(
          result.flightMs
        )}.`
      )
      .catch(() => {});

    if (peerId) {
      await ctx.bot
        .sendToChat(
          peerId,
          `⚔️ «${attackerLink}» атакует «${defenderLink}» (${weaponKey}). Прилёт через ${calc.formatDuration(
            result.flightMs
          )}.`
        )
        .catch(() => {});
    }
  }
}

async function handleRecon(ctx, targetId) {
  const vkId = ctx.senderId;
  const player = await players.getPlayer(vkId);
  if (!player || player.registration_step !== 'done') {
    await ctx.send('⛔ Вы ещё не зарегистрированы. Напишите !старт');
    return;
  }

  if (!targetId) {
    await ctx.send('⛔ Укажите цель: !разведка @юзер');
    return;
  }

  const target = await players.getPlayer(targetId);
  if (!target || target.registration_step !== 'done') {
    await ctx.send('⛔ Эта цель не найдена.');
    return;
  }

  if (Number(player.balance) < C.RECON_COST) {
    await ctx.send(`⛔ Недостаточно вирт. Нужно ${C.RECON_COST}.`);
    return;
  }

  await players.updateBalance(vkId, -C.RECON_COST);

  const exact = calc.distanceKm(player.x, player.y, target.x, target.y);
  const lower = Math.max(0, Math.round(exact - 50));
  const upper = Math.round(exact + 50);

  await ctx.send(
    `🕵️ РАЗВЕДКА ДОЛОЖИЛА:\n` +
      `Цель: ${msg.mentionLink(target.vk_id, target.state_name)}\n` +
      `Расстояние: примерно ${lower}-${upper} км.\n` +
      `Стоимость: ${C.RECON_COST} вирт.`
  );
}

module.exports = { handleAttack, handleRecon };
