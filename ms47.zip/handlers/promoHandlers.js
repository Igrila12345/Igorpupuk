'use strict';

const players = require('../db/players');
const promoDb = require('../db/promocodes');
const promo = require('../game/promo');
const calc = require('../game/calc');
const C = require('../game/constants');
const { isAdmin } = require('./adminHandlers');

// промо создать [код] [тип] [название_или_-] [количество] [лимит] [часов_жизни_или_0] [vip]
// Необязательный 7-й аргумент "vip" — если указан, активировать промокод сможет только игрок
// с активным VIP-статусом на момент активации (см. game/promo.js: redeem()).
async function handleCreate(ctx, args) {
  if (!isAdmin(ctx.senderId)) {
    await ctx.send('⛔ Команда недоступна.');
    return;
  }

  const [code, type, nameRaw, qtyArg, limitArg, hoursArg, vipArg] = args;
  const rewardName = nameRaw && nameRaw !== '-' ? nameRaw : null;
  const quantity = parseInt(qtyArg, 10);
  const maxUses = parseInt(limitArg, 10);
  const hours = hoursArg ? parseFloat(hoursArg) : null;
  const vipOnly = (vipArg || '').toLowerCase() === 'vip';

  if (!code || !type || !Number.isInteger(quantity) || !Number.isInteger(maxUses)) {
    await ctx.send(
      '⛔ Формат: промо создать [код] [тип: weapon/air_defense/virts/tokens/science] [название или -] [количество] [лимит] [часов_жизни (0 = бессрочно)] [vip — необязательно, только для VIP]'
    );
    return;
  }

  const result = await promo.createPromo(code, type, rewardName, quantity, maxUses, hours, vipOnly);
  if (!result.ok) {
    const reasons = {
      invalid_type: '⛔ Неизвестный тип награды.',
      invalid_reward_name: '⛔ Неизвестное название оружия/ПВО.',
      already_exists: '⛔ Такой промокод уже существует.',
    };
    await ctx.send(reasons[result.reason] || '⛔ Не удалось создать промокод.');
    return;
  }

  await ctx.send(
    `✅ Промокод «${result.promo.code}» создан: ${type} ${rewardName || ''} x${quantity}, лимит активаций: ${maxUses}${
      vipOnly ? ', только для VIP 👑' : ''
    }.`
  );
}

async function handleList(ctx) {
  if (!isAdmin(ctx.senderId)) {
    await ctx.send('⛔ Команда недоступна.');
    return;
  }

  const promos = await promoDb.getActivePromos();
  if (!promos.length) {
    await ctx.send('Активных промокодов нет.');
    return;
  }

  let text = `🎟️ АКТИВНЫЕ ПРОМОКОДЫ\n\n`;
  for (const p of promos) {
    text += `${p.code} — ${p.reward_type} ${p.reward_name || ''} x${p.reward_quantity} (${p.used_count}/${p.max_uses})${
      p.vip_only ? ' 👑 только VIP' : ''
    }\n`;
  }
  await ctx.send(text.trim());
}

async function handleDelete(ctx, code) {
  if (!isAdmin(ctx.senderId)) {
    await ctx.send('⛔ Команда недоступна.');
    return;
  }
  if (!code) {
    await ctx.send('⛔ Формат: промо удалить [код]');
    return;
  }
  await promoDb.deletePromo(code.toUpperCase());
  await ctx.send(`✅ Промокод «${code.toUpperCase()}» удалён.`);
}

async function handleRedeem(ctx, code) {
  const vkId = ctx.senderId;
  const player = await players.getPlayer(vkId);
  if (!player || player.registration_step !== 'done') {
    await ctx.send('⛔ Вы ещё не зарегистрированы. Напишите старт');
    return;
  }

  if (!code) {
    await ctx.send('⛔ Формат: промо [код]');
    return;
  }

  const result = await promo.redeem(vkId, code);
  if (!result.ok) {
    const reasons = {
      not_found: '⛔ Такого промокода не существует.',
      expired: '⛔ Срок действия промокода истёк.',
      exhausted: '⛔ Лимит активаций промокода исчерпан.',
      already_used: '⛔ Вы уже активировали этот промокод.',
      vip_only: '⛔ Этот промокод только для игроков с активным VIP-статусом.',
    };
    await ctx.send(reasons[result.reason] || '⛔ Не удалось активировать промокод.');
    return;
  }

  const p = result.promo;
  const rewardText = p.reward_name ? `${p.reward_name} (${p.reward_quantity} шт.)` : `${p.reward_quantity} ${p.reward_type}`;
  await ctx.send(`🎉 Поздравляем! Вы получили ${rewardText} по промокоду ${p.code}!`);
}

module.exports = { handleCreate, handleList, handleDelete, handleRedeem };
