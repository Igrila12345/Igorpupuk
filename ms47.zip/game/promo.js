'use strict';

const C = require('./constants');
const players = require('../db/players');
const promoDb = require('../db/promocodes');
const calc = require('./calc');

const VALID_TYPES = ['weapon', 'air_defense', 'virts', 'tokens', 'science'];

async function createPromo(code, rewardType, rewardName, rewardQuantity, maxUses, expiresHours, vipOnly) {
  if (!VALID_TYPES.includes(rewardType)) return { ok: false, reason: 'invalid_type' };
  if ((rewardType === 'weapon' && !C.WEAPONS[rewardName]) || (rewardType === 'air_defense' && !C.AIR_DEFENSE[rewardName])) {
    return { ok: false, reason: 'invalid_reward_name' };
  }

  const expiresAt = expiresHours ? new Date(Date.now() + expiresHours * 60 * 60 * 1000) : null;
  const promo = await promoDb.createPromo(
    code.toUpperCase(),
    rewardType,
    rewardName || null,
    rewardQuantity,
    maxUses,
    expiresAt,
    vipOnly
  );
  if (!promo) return { ok: false, reason: 'already_exists' };
  return { ok: true, promo };
}

async function redeem(vkId, code) {
  const player = await players.getPlayer(vkId);
  if (!player) return { ok: false, reason: 'not_registered' };

  const promo = await promoDb.getPromo(code.toUpperCase());
  if (!promo) return { ok: false, reason: 'not_found' };
  if (promo.expires_at && new Date(promo.expires_at) <= new Date()) return { ok: false, reason: 'expired' };
  if (promo.used_count >= promo.max_uses) return { ok: false, reason: 'exhausted' };
  if (promo.vip_only && !calc.isVipActive(player)) return { ok: false, reason: 'vip_only' };

  const already = await promoDb.hasRedeemed(promo.code, vkId);
  if (already) return { ok: false, reason: 'already_used' };

  switch (promo.reward_type) {
    case 'virts':
      await players.updateBalance(vkId, promo.reward_quantity);
      break;
    case 'tokens':
      await players.addTokens(vkId, promo.reward_quantity);
      break;
    case 'weapon':
      await players.addToArsenal(vkId, promo.reward_name, promo.reward_quantity);
      break;
    case 'air_defense':
      await players.addToAirDefense(vkId, promo.reward_name, promo.reward_quantity);
      break;
    case 'science':
      await players.addScienceCenters(vkId, promo.reward_quantity);
      break;
    default:
      break;
  }

  await promoDb.incrementUsage(promo.code);
  await promoDb.recordRedemption(promo.code, vkId);

  return { ok: true, promo };
}

module.exports = { createPromo, redeem };
