'use strict';

const combat = require('./combat');
const superRobot = require('./superRobot');
const robot = require('./robot');
const combatDb = require('../db/combat');
const calc = require('./calc');
const C = require('./constants');
const msg = require('../utils/messages');

function formatAdSummary(adUsedCounts) {
  const parts = Object.entries(adUsedCounts || {}).map(([key, count]) => `${key} (x${count})`);
  return parts.join(', ');
}

// Разрешает одну прилетевшую атаку целиком (запись в БД + рассылка уведомлений).
// Вынесено в отдельную функцию, чтобы resolvePendingAttacks могла обрабатывать
// пачку прилетевших атак параллельно (см. ниже), а не по одной последовательно —
// при 100-150 одновременно прилетевших атаках последовательная обработка с ожиданием
// каждого уведомления заметно "тормозит" минутный тик планировщика.
async function resolveOneAttack(bot, attackRecord) {
  await combatDb.markAttackResolved(attackRecord.id);

  // Атака суперроботом резолвится отдельной веткой (не обычное оружие из C.WEAPONS)
  if (attackRecord.weapon === C.SUPER_ROBOT_WEAPON_KEY) {
    await resolveSuperRobotDelivery(bot, attackRecord);
    return;
  }

  // Атака боевой способностью робота-питомца (с уровня ROBOT_FACTORY_DESTROY_UNLOCK_LEVEL) —
  // тоже отдельная ветка, аналогичная суперроботу, но снос всегда фиксирован в 1 завод.
  if (attackRecord.weapon === C.ROBOT_WEAPON_KEY) {
    await resolveRobotAttackDelivery(bot, attackRecord);
    return;
  }

  const result = await combat.resolveAttack(attackRecord);
  if (!result.ok) return;

  const { attacker, defender, weapon, intercepted, penetrated, quantity, adUsedCounts } = result;
  const attackerLink = msg.mentionLink(attacker.vk_id, attacker.state_name);
  const defenderLink = msg.mentionLink(defender.vk_id, defender.state_name);
  const adSummary = formatAdSummary(adUsedCounts);

  // ===== Волна полностью отражена =====
  if (result.allIntercepted) {
    await bot
      .notifyUser(
        attacker.vk_id,
        `💥 Ваше ${weapon.key} (x${quantity}) полностью сбито ПВО противника (${defenderLink}): ${adSummary}. Потери: ${quantity} шт.`
      )
      .catch(() => {});

    await bot
      .notifyUser(
        defender.vk_id,
        `🎯 Ваше ПВО отразило всю атаку «${attackerLink}»: ${weapon.key} x${quantity} — сбито силами ${adSummary}!`
      )
      .catch(() => {});

    if (attackRecord.peer_id) {
      await bot
        .sendToChat(attackRecord.peer_id, `🛡️ «${defenderLink}» полностью отразил атаку «${attackerLink}» (${weapon.key} x${quantity})`)
        .catch(() => {});
    }
    return;
  }

  // ===== Волна прорвалась частично или полностью =====
  // Если ПВО сбило часть партии — сообщаем об этом отдельной строкой перед эффектом атаки.
  const interceptLine =
    intercepted > 0
      ? `🛡️ ПВО сбило ${intercepted} из ${quantity} (${adSummary}), но ${penetrated} прорвалось!\n`
      : '';
  const interceptLineDefender =
    intercepted > 0
      ? `🛡️ Ваше ПВО сбило ${intercepted} из ${quantity} (${adSummary}), но ${penetrated} прорвалось!\n`
      : '';

  const { effectResult, loot } = result;

  if (effectResult.type === 'block') {
    const destroyedLine = effectResult.destroyedCount
      ? `\n💀 Снесено навсегда: ${effectResult.destroyedCount} ${msg.pluralFactories(effectResult.destroyedCount)}!`
      : '';
    const totalLine =
      effectResult.destroyedCount && effectResult.totalDestroyed != null
        ? `\n📊 Всего снесено вражеских заводов: ${effectResult.totalDestroyed}.`
        : '';
    const compensationLine = effectResult.compensation
      ? `\n💵 Компенсация за снесённые заводы: +${effectResult.compensation} вирт.`
      : '';

    await bot
      .notifyUser(
        attacker.vk_id,
        `${interceptLine}🔥 ПРЯМОЕ ПОПАДАНИЕ по городу «${defenderLink}»! Прорвалось ${penetrated} из ${quantity} ${weapon.key}.${destroyedLine}${totalLine} Трофеи: +${loot} вирт.`
      )
      .catch(() => {});

    await bot
      .notifyUser(
        defender.vk_id,
        `${interceptLineDefender}💥 Государство «${attackerLink}» прорвало вашу оборону: ${penetrated} из ${quantity} ${weapon.key} долетело!${destroyedLine}${compensationLine}`
      )
      .catch(() => {});

    if (attackRecord.peer_id) {
      await bot
        .sendToChat(
          attackRecord.peer_id,
          `💥 «${attackerLink}» нанёс удар по «${defenderLink}» (${penetrated}/${quantity} прорвалось)${
            effectResult.destroyedCount ? `, снесено ${effectResult.destroyedCount}` : ''
          }`
        )
        .catch(() => {});
    }
  } else if (effectResult.type === 'nuke_strike') {
    // Ядерное оружие: всегда сносит несколько заводов + у некоторых видов есть побочный эффект.
    const destroyedLine = effectResult.destroyedCount
      ? `\n💀 Снесено навсегда: ${effectResult.destroyedCount} ${msg.pluralFactories(effectResult.destroyedCount)}!`
      : '';
    const totalLine =
      effectResult.destroyedCount && effectResult.totalDestroyed != null
        ? `\n📊 Всего снесено вражеских заводов: ${effectResult.totalDestroyed}.`
        : '';
    const compensationLine = effectResult.compensation
      ? `\n💵 Компенсация за снесённые заводы: +${effectResult.compensation} вирт.`
      : '';
    const extraLines =
      (effectResult.radiation ? `\n☢️ + радиация: -20% дохода на 2 часа всем оставшимся заводам.` : '') +
      (effectResult.wipedAirDefense ? `\n🌊 + всё ПВО противника уничтожено!` : '');

    await bot
      .notifyUser(
        attacker.vk_id,
        `${interceptLine}☢️ ЯДЕРНЫЙ УДАР по городу «${defenderLink}»!${destroyedLine}${totalLine}${extraLines} Трофеи: +${loot} вирт.`
      )
      .catch(() => {});

    await bot
      .notifyUser(
        defender.vk_id,
        `${interceptLineDefender}☢️ ЯДЕРНЫЙ УДАР государства «${attackerLink}» по вашему городу!${destroyedLine}${compensationLine}${extraLines}`
      )
      .catch(() => {});

    if (attackRecord.peer_id) {
      await bot
        .sendToChat(
          attackRecord.peer_id,
          `☢️ «${attackerLink}» нанёс ядерный удар по «${defenderLink}» (${weapon.key})${
            effectResult.destroyedCount ? `: снесено ${effectResult.destroyedCount} ${msg.pluralFactories(effectResult.destroyedCount)}` : ''
          }${effectResult.wipedAirDefense ? ', ПВО уничтожено' : ''}`
        )
        .catch(() => {});
    }
  }
}

// Обрабатывает все прилетевшие атаки за минутный тик. Раньше это был последовательный
// for-of с await на каждой атаке — при 100-150 одновременно прилетевших атаках
// (например, после активного игрового вечера) это могло растянуться на десятки секунд
// и заметно тормозило минутный тик планировщика. Теперь атаки резолвятся пачками
// параллельно (BATCH_SIZE за раз), а не все 150 разом — чтобы не создавать всплеск
// одновременных запросов к VK API и не упереться в rate-limit.
const RESOLVE_BATCH_SIZE = 20;

async function resolvePendingAttacks(bot) {
  const due = await combatDb.getDueAttacks();

  for (let i = 0; i < due.length; i += RESOLVE_BATCH_SIZE) {
    const batch = due.slice(i, i + RESOLVE_BATCH_SIZE);
    await Promise.all(
      batch.map((attackRecord) =>
        resolveOneAttack(bot, attackRecord).catch((err) => {
          console.error(`[AttackResolver] Ошибка резолва атаки #${attackRecord.id}:`, err);
        })
      )
    );
  }
}

// Разрешение прилетевшей атаки суперроботом: либо её "охотой" сбивает С-400 Триумф защитника
// (робот не теряется, но защитник получает крупную награду виртами), либо она прорывается —
// сносит заводы и приносит атакующему повышенные трофеи.
async function resolveSuperRobotDelivery(bot, attackRecord) {
  const result = await superRobot.resolveAttack(attackRecord);
  if (!result.ok) return;

  const { attacker, defender, level, intercepted } = result;
  const attackerLink = msg.mentionLink(attacker.vk_id, attacker.state_name);
  const defenderLink = msg.mentionLink(defender.vk_id, defender.state_name);
  const name = superRobot.levelName(level);

  if (intercepted) {
    await bot
      .notifyUser(
        attacker.vk_id,
        `🛡️ Ваш суперробот «${name}» (ур. ${level}) сбит ПВО С-400 Триумф государства «${defenderLink}» на подлёте к цели! Миссия провалена, но сам робот цел — можно атаковать снова через ${calc.formatDuration(
          C.SUPER_ROBOT_ATTACK_COOLDOWN_MS
        )}.`
      )
      .catch(() => {});

    await bot
      .notifyUser(
        defender.vk_id,
        `🎯 Ваше ПВО С-400 Триумф перехватило суперробота «${attackerLink}»! Награда за успешную охоту: +${result.reward} вирт.`
      )
      .catch(() => {});

    if (attackRecord.peer_id) {
      await bot
        .sendToChat(attackRecord.peer_id, `🛡️ «${defenderLink}» перехватил ПВО суперробота «${attackerLink}»!`)
        .catch(() => {});
    }
    return;
  }

  const destroyedLine = result.destroyedCount
    ? `Снесено: ${result.destroyedCount} ${msg.pluralFactories(result.destroyedCount)}!`
    : 'Все заводы защищены — снести уже нечего (защита новичков).';
  const totalLine = result.destroyedCount && result.totalDestroyed != null ? ` 📊 Всего снесено: ${result.totalDestroyed}.` : '';
  const compensationLine = result.compensation
    ? ` 💵 Компенсация за снесённые заводы: +${result.compensation} вирт.`
    : '';

  await bot
    .notifyUser(
      attacker.vk_id,
      `🤖 Суперробот «${name}» (ур. ${level}) прорвался к цели «${defenderLink}»! ${destroyedLine}${totalLine} Трофеи: +${result.loot} вирт.`
    )
    .catch(() => {});

  await bot
    .notifyUser(
      defender.vk_id,
      `💥 Суперробот государства «${attackerLink}» атаковал ваш город! ${destroyedLine}${compensationLine}`
    )
    .catch(() => {});

  if (attackRecord.peer_id) {
    await bot
      .sendToChat(
        attackRecord.peer_id,
        `🤖 «${attackerLink}» атаковал «${defenderLink}» суперроботом (ур. ${level}): ${destroyedLine}`
      )
      .catch(() => {});
  }
}

// Разрешение прилетевшей атаки боевой способностью робота-питомца (с уровня
// ROBOT_FACTORY_DESTROY_UNLOCK_LEVEL) — та же ПВО-логика, что и у суперробота (перехватить
// может только С-400 Триумф), но снос всегда фиксирован в 1 завод, независимо от уровня робота.
async function resolveRobotAttackDelivery(bot, attackRecord) {
  const result = await robot.resolveAttack(attackRecord);
  if (!result.ok) return;

  const { attacker, defender, level, intercepted } = result;
  const attackerLink = msg.mentionLink(attacker.vk_id, attacker.state_name);
  const defenderLink = msg.mentionLink(defender.vk_id, defender.state_name);
  const name = robot.levelName(level);

  if (intercepted) {
    await bot
      .notifyUser(
        attacker.vk_id,
        `🛡️ Ваш робот «${name}» (ур. ${level}) сбит ПВО С-400 Триумф государства «${defenderLink}» на подлёте к цели! Миссия провалена, но сам робот цел — можно атаковать снова через ${calc.formatDuration(
          C.ROBOT_ATTACK_COOLDOWN_MS
        )}.`
      )
      .catch(() => {});

    await bot
      .notifyUser(
        defender.vk_id,
        `🎯 Ваше ПВО С-400 Триумф перехватило робота-питомца «${attackerLink}»! Награда за успешную охоту: +${result.reward} вирт.`
      )
      .catch(() => {});

    if (attackRecord.peer_id) {
      await bot
        .sendToChat(attackRecord.peer_id, `🛡️ «${defenderLink}» перехватил ПВО робота-питомца «${attackerLink}»!`)
        .catch(() => {});
    }
    return;
  }

  const destroyedLine = result.destroyedCount
    ? `Снесено: ${result.destroyedCount} ${msg.pluralFactories(result.destroyedCount)}!`
    : 'Все заводы защищены — снести уже нечего (защита новичков).';
  const totalLine = result.destroyedCount && result.totalDestroyed != null ? ` 📊 Всего снесено: ${result.totalDestroyed}.` : '';
  const compensationLine = result.compensation
    ? ` 💵 Компенсация за снесённый завод: +${result.compensation} вирт.`
    : '';

  await bot
    .notifyUser(
      attacker.vk_id,
      `🤖 Робот «${name}» (ур. ${level}) прорвался к цели «${defenderLink}»! ${destroyedLine}${totalLine} Трофеи: +${result.loot} вирт.`
    )
    .catch(() => {});

  await bot
    .notifyUser(
      defender.vk_id,
      `💥 Робот-питомец государства «${attackerLink}» атаковал ваш город! ${destroyedLine}${compensationLine}`
    )
    .catch(() => {});

  if (attackRecord.peer_id) {
    await bot
      .sendToChat(
        attackRecord.peer_id,
        `🤖 «${attackerLink}» атаковал «${defenderLink}» роботом-питомцем (ур. ${level}): ${destroyedLine}`
      )
      .catch(() => {});
  }
}

module.exports = { resolvePendingAttacks };
