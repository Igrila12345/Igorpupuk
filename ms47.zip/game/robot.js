'use strict';

const C = require('./constants');
const players = require('../db/players');
const calc = require('./calc');
const combatDb = require('../db/combat');
const clans = require('../db/clans');

const ROMAN = ['I', 'II', 'III', 'IV', 'V', 'VI', 'VII', 'VIII', 'IX', 'X'];

// Номер "модели" робота (0 = первая, растёт каждые ROBOT_TIER_SIZE уровней)
function tierOf(level) {
  const tier = Math.floor((level - 1) / C.ROBOT_TIER_SIZE);
  return Math.min(tier, C.ROBOT_TIER_NAMES.length - 1);
}

// Название уровня, например "Скрап-Бот I", "Штамповщик VII", "Голиаф-Прораб X"
function levelName(level) {
  const tier = tierOf(level);
  const subIndex = (level - 1) % C.ROBOT_TIER_SIZE;
  return `${C.ROBOT_TIER_NAMES[tier]} ${ROMAN[subIndex]}`;
}

// Цена прокачки С currentLevel НА currentLevel+1. Двухфазная кривая — см. комментарий у
// ROBOT_UPGRADE_POST_TIER1_GROWTH в constants.js: быстрый рост до ROBOT_UPGRADE_TIER1_MAX_LEVEL,
// затем заметно медленнее (иначе единая экспонента на 998 шагов улетает за пределы разумного).
function upgradeCost(currentLevel) {
  const tier1Max = C.ROBOT_UPGRADE_TIER1_MAX_LEVEL;
  const cappedLevel = Math.min(currentLevel, tier1Max);
  let raw = C.ROBOT_UPGRADE_BASE_COST * Math.pow(C.ROBOT_UPGRADE_GROWTH, cappedLevel - 1);
  if (currentLevel > tier1Max) {
    const extraLevels = currentLevel - tier1Max;
    raw *= Math.pow(C.ROBOT_UPGRADE_POST_TIER1_GROWTH, extraLevels);
  }
  return Math.round(raw / 10) * 10;
}

// Диапазон [min;max] вирт за один мгновенный сбор ("робот") на данном уровне.
// Награда случайная внутри диапазона, оба края растут с уровнем.
function incomeRange(level) {
  const min = C.ROBOT_FARM_MIN_BASE + (level - 1) * C.ROBOT_FARM_MIN_STEP;
  const max = C.ROBOT_FARM_MAX_BASE + (level - 1) * C.ROBOT_FARM_MAX_STEP;
  return { min, max };
}

// Случайная сумма сбора вирт на данном уровне (используется при фактическом сборе).
function rollFarmAmount(level) {
  const { min, max } = incomeRange(level);
  return Math.floor(Math.random() * (max - min + 1)) + min;
}

// Сколько жетонов зачисляется за одну отправку ("отправить") — растёт по "модели" робота
function tokensPerSend(level) {
  return tierOf(level) + 1;
}

// Справочный показатель мощности модели (для команды "роботы") — сколько условно вражеских
// заводов "по силам" снести роботу такого уровня. Чисто информационная характеристика модели,
// растёт на 1 каждые ROBOT_TIER_SIZE уровней прокачки — в бою автоматически не применяется.
function factoriesPower(level) {
  return tierOf(level);
}

function msLeft(lastAt, cooldownMs) {
  if (!lastAt) return 0;
  const left = cooldownMs - (Date.now() - new Date(lastAt).getTime());
  return left > 0 ? left : 0;
}

// Кулдаун с учётом VIP: у VIP-игроков "робот"/"отправить" доступны чаще (x VIP_ROBOT_COOLDOWN_MULT).
function effectiveCooldownMs(player, baseCooldownMs) {
  return calc.isVipActive(player) ? Math.round(baseCooldownMs * C.VIP_ROBOT_COOLDOWN_MULT) : baseCooldownMs;
}

async function upgradeRobot(vkId) {
  const player = await players.getPlayer(vkId);
  if (!player) return { ok: false, reason: 'not_registered' };

  const level = player.robot_level || 1;
  if (level >= C.ROBOT_MAX_LEVEL) {
    return { ok: false, reason: 'max_level' };
  }

  const cost = upgradeCost(level);
  if (Number(player.balance) < cost) {
    return { ok: false, reason: 'not_enough_money', cost, missing: cost - Number(player.balance) };
  }

  await players.updateBalance(vkId, -cost);
  await players.setRobotLevel(vkId, level + 1);

  return { ok: true, cost, newLevel: level + 1 };
}

// Мгновенный сбор вирт (заменяет старую механику "старт добычи -> забрать"). Не чаще раза в час.
async function farmVirts(vkId) {
  const player = await players.getPlayer(vkId);
  if (!player) return { ok: false, reason: 'not_registered' };

  const cooldownMs = effectiveCooldownMs(player, C.ROBOT_FARM_COOLDOWN_MS);
  const left = msLeft(player.robot_last_farm_at, cooldownMs);
  if (left > 0) {
    return { ok: false, reason: 'cooldown', msLeft: left };
  }

  const level = player.robot_level || 1;
  const amount = rollFarmAmount(level);

  await players.updateBalance(vkId, amount);
  await players.setRobotLastFarm(vkId, new Date());

  return { ok: true, amount, level, cooldownMs };
}

// Мгновенная отправка робота за жетонами. Не чаще раза в час.
async function sendForTokens(vkId) {
  const player = await players.getPlayer(vkId);
  if (!player) return { ok: false, reason: 'not_registered' };

  const cooldownMs = effectiveCooldownMs(player, C.ROBOT_SEND_COOLDOWN_MS);
  const left = msLeft(player.robot_last_send_at, cooldownMs);
  if (left > 0) {
    return { ok: false, reason: 'cooldown', msLeft: left };
  }

  const level = player.robot_level || 1;
  const amount = tokensPerSend(level);

  await players.addTokens(vkId, amount);
  await players.setRobotLastSend(vkId, new Date());

  return { ok: true, amount, level, cooldownMs };
}

// Полная таблица всех уровней робота — для команды "роботы"
function buildLevelsTable() {
  const rows = [];
  for (let level = 1; level <= C.ROBOT_MAX_LEVEL; level++) {
    rows.push({
      level,
      name: levelName(level),
      costToReach: level === 1 ? 0 : upgradeCost(level - 1),
      incomeRange: incomeRange(level),
      tokensPerSend: tokensPerSend(level),
      destroyPower: destroyPower(level),
    });
  }
  return rows;
}

// ===================== БОЕВАЯ СПОСОБНОСТЬ ПРОКАЧАННОГО РОБОТА (с уровня ROBOT_FACTORY_DESTROY_UNLOCK_LEVEL) =====================
// С ROBOT_FACTORY_DESTROY_UNLOCK_LEVEL робот-питомец открывает боевую атаку — летит как оружие
// (расстояние/скорость, как у суперробота), перехватывается только топовым ПВО (С-400 Триумф).
// Сила растёт с уровнем (+1 завод каждые ROBOT_FACTORY_DESTROY_LEVELS_PER_STEP уровней), но
// с потолком ROBOT_FACTORY_DESTROY_MAX — специально держится ниже максимума суперробота, чтобы
// это оставалось бонусной способностью питомца, а не заменой суперробота.
function canAttack(level) {
  return (level || 0) >= C.ROBOT_FACTORY_DESTROY_UNLOCK_LEVEL;
}

// Сколько заводов сносит атака робота-питомца такого уровня (0, если способность ещё закрыта)
function destroyPower(level) {
  if (!canAttack(level)) return 0;
  const steps = Math.floor((level - C.ROBOT_FACTORY_DESTROY_UNLOCK_LEVEL) / C.ROBOT_FACTORY_DESTROY_LEVELS_PER_STEP);
  return Math.min(1 + steps, C.ROBOT_FACTORY_DESTROY_MAX);
}

async function launchAttack(attackerId, defenderId, peerId) {
  if (attackerId === defenderId) return { ok: false, reason: 'self_attack' };

  const attacker = await players.getPlayer(attackerId);
  const defender = await players.getPlayer(defenderId);
  if (!attacker || !defender) return { ok: false, reason: 'not_registered' };

  const level = attacker.robot_level || 1;
  if (!canAttack(level)) {
    return { ok: false, reason: 'level_too_low', required: C.ROBOT_FACTORY_DESTROY_UNLOCK_LEVEL };
  }

  if (attacker.factories < C.MIN_FACTORIES_TO_ATTACK) {
    return { ok: false, reason: 'attacker_too_small' };
  }

  if (defender.factories < C.MIN_FACTORIES_TO_BE_ATTACKED) {
    return { ok: false, reason: 'defender_too_small' };
  }

  const left = msLeft(attacker.robot_last_attack_at, C.ROBOT_ATTACK_COOLDOWN_MS);
  if (left > 0) {
    return { ok: false, reason: 'cooldown', msLeft: left };
  }

  const distance = calc.distanceKm(attacker.x, attacker.y, defender.x, defender.y);
  let speed = C.ROBOT_ATTACK_SPEED_KMH * C.WEAPON_SPEED_MULTIPLIER;

  if (attacker.clan_id) {
    const clan = await clans.getClanById(attacker.clan_id);
    if (clan && clan.bonus_forsazh_until && new Date(clan.bonus_forsazh_until) > new Date()) {
      speed *= 2;
    }
  }

  const flightHours = distance / speed;
  const arrivalAt = new Date(Date.now() + flightHours * 60 * 60 * 1000);

  const power = destroyPower(level);
  // Уровень на момент запуска сохраняем в поле quantity — на нём же считаем силу удара при
  // прилёте (та же схема, что и у суперробота, см. game/superRobot.js: launchAttack()).
  const attackRecord = await combatDb.createAttack(
    attackerId,
    defenderId,
    C.ROBOT_WEAPON_KEY,
    level,
    distance,
    arrivalAt,
    peerId
  );

  await players.touchLastSeen(attackerId);
  await players.setRobotLastAttack(attackerId, new Date());

  return {
    ok: true,
    attackRecord,
    distance,
    flightMs: flightHours * 60 * 60 * 1000,
    level,
    power,
    attackerId: attacker.vk_id,
    defenderId: defender.vk_id,
    attackerName: attacker.state_name,
    defenderName: defender.state_name,
  };
}

// Сносит до count заводов у defender (та же механика/компенсация, что и у суперробота —
// см. destroyFactories в game/superRobot.js).
async function destroyFactories(defenderVkId, count) {
  const cappedCount = Math.min(count, C.MAX_FACTORIES_DESTROYED_PER_ATTACK);
  let destroyedCount = 0;
  let compensation = 0;
  for (let i = 0; i < cappedCount; i++) {
    const current = await players.getPlayer(defenderVkId);
    if (!current || current.factories <= C.NEWBIE_PROTECTION_FACTORIES) break;
    const price = calc.nextFactoryPrice(Math.max(current.factories - 1, 0));
    compensation += Math.round(price * C.FACTORY_DESTROY_COMPENSATION_RATE);
    await players.destroyOneFactory(defenderVkId);
    destroyedCount += 1;
  }
  if (compensation > 0) {
    await players.updateBalance(defenderVkId, compensation);
  }
  return { destroyedCount, compensation };
}

// Разрешение прилетевшей атаки робота-питомца — то же ПВО-правило, что и у суперробота
// (перехватить может только С-400 Триумф), сила удара растёт с уровнем (см. destroyPower()).
async function resolveAttack(attackRecord) {
  const attacker = await players.getPlayer(attackRecord.attacker_id);
  const defender = await players.getPlayer(attackRecord.defender_id);
  if (!attacker || !defender) {
    return { ok: false, reason: 'player_missing' };
  }

  const level = attackRecord.quantity;
  const power = destroyPower(level);

  const AD_KEY = 'С-400 Триумф';
  const airDefense = defender.air_defense || {};
  const airDefenseDamage = defender.air_defense_damage || {};
  const adCount = airDefense[AD_KEY] || 0;

  let chanceMultiplier = 1;
  if (defender.clan_id) {
    const clan = await clans.getClanById(defender.clan_id);
    if (clan && clan.bonus_eshelon_until && new Date(clan.bonus_eshelon_until) > new Date()) {
      chanceMultiplier = 1.2;
    }
  }

  const defenderSkill = calc.getSkillTier(defender.factories);
  const skillBonus = defenderSkill ? defenderSkill.airDefenseBonus : 0;

  let intercepted = false;
  if (adCount > 0) {
    const chance = Math.min(C.AIR_DEFENSE[AD_KEY].chance * chanceMultiplier + skillBonus, 1);
    if (Math.random() < chance) {
      intercepted = true;

      const durability = C.AIR_DEFENSE[AD_KEY].durability || 1;
      airDefenseDamage[AD_KEY] = (airDefenseDamage[AD_KEY] || 0) + C.SUPER_ROBOT_AD_WEAR;

      while (airDefenseDamage[AD_KEY] >= durability && airDefense[AD_KEY] > 0) {
        airDefense[AD_KEY] -= 1;
        airDefenseDamage[AD_KEY] -= durability;
      }
      if (airDefense[AD_KEY] <= 0) {
        delete airDefense[AD_KEY];
        delete airDefenseDamage[AD_KEY];
      } else if (airDefenseDamage[AD_KEY] <= 0) {
        delete airDefenseDamage[AD_KEY];
      }

      await players.setAirDefense(defender.vk_id, airDefense);
      await players.setAirDefenseDamage(defender.vk_id, airDefenseDamage);
    }
  }

  if (intercepted) {
    const reward = calc.randomInt(C.SUPER_ROBOT_HUNT_REWARD_MIN, C.SUPER_ROBOT_HUNT_REWARD_MAX);
    await players.updateBalance(defender.vk_id, reward);
    return { ok: true, intercepted: true, level, reward, attacker, defender };
  }

  const { destroyedCount, compensation } = await destroyFactories(defender.vk_id, power);
  let totalDestroyed = null;
  if (destroyedCount > 0) {
    totalDestroyed = await players.incrementEnemyFactoriesDestroyed(attacker.vk_id, destroyedCount);
  }

  const productionDb = require('../db/production');
  const factoriesInProd = await productionDb.getFactoriesInUse(defender.vk_id);
  const defenderIncome = calc.incomePerHour(await players.getPlayer(defender.vk_id), factoriesInProd);
  let loot = Math.round(defenderIncome * C.SUPER_ROBOT_LOOT_RATE);
  loot = Math.max(C.SUPER_ROBOT_LOOT_MIN, Math.min(C.SUPER_ROBOT_LOOT_MAX, loot));
  loot = Math.round(loot * calc.weakTargetLootMultiplier(attacker, defender));
  await players.updateBalance(attacker.vk_id, loot);

  return {
    ok: true,
    intercepted: false,
    level,
    power,
    destroyedCount,
    compensation,
    totalDestroyed,
    loot,
    attacker,
    defender,
  };
}

module.exports = {
  levelName,
  tierOf,
  upgradeCost,
  destroyPower,
  incomeRange,
  rollFarmAmount,
  tokensPerSend,
  factoriesPower,
  msLeft,
  effectiveCooldownMs,
  upgradeRobot,
  farmVirts,
  sendForTokens,
  buildLevelsTable,
  canAttack,
  launchAttack,
  resolveAttack,
};
