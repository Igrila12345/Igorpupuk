'use strict';

const { query } = require('./pool');

async function createPromo(code, rewardType, rewardName, rewardQuantity, maxUses, expiresAt, vipOnly) {
  const res = await query(
    `INSERT INTO promocodes (code, reward_type, reward_name, reward_quantity, max_uses, expires_at, vip_only)
     VALUES ($1, $2, $3, $4, $5, $6, $7)
     ON CONFLICT (code) DO NOTHING
     RETURNING *`,
    [code, rewardType, rewardName, rewardQuantity, maxUses, expiresAt, !!vipOnly]
  );
  return res.rows[0] || null;
}

async function getPromo(code) {
  const res = await query('SELECT * FROM promocodes WHERE code = $1', [code]);
  return res.rows[0] || null;
}

async function getActivePromos() {
  const res = await query(
    `SELECT * FROM promocodes WHERE used_count < max_uses AND (expires_at IS NULL OR expires_at > NOW()) ORDER BY created_at DESC`
  );
  return res.rows;
}

async function deletePromo(code) {
  await query('DELETE FROM promocodes WHERE code = $1', [code]);
}

async function incrementUsage(code) {
  await query('UPDATE promocodes SET used_count = used_count + 1 WHERE code = $1', [code]);
}

async function hasRedeemed(code, playerId) {
  const res = await query(
    'SELECT 1 FROM promocode_redemptions WHERE code = $1 AND player_id = $2',
    [code, playerId]
  );
  return res.rows.length > 0;
}

async function recordRedemption(code, playerId) {
  await query(
    'INSERT INTO promocode_redemptions (code, player_id) VALUES ($1, $2) ON CONFLICT DO NOTHING',
    [code, playerId]
  );
}

module.exports = {
  createPromo,
  getPromo,
  getActivePromos,
  deletePromo,
  incrementUsage,
  hasRedeemed,
  recordRedemption,
};
