'use strict';

const players = require('../db/players');
const steal = require('../game/steal');
const quests = require('../game/quests');
const calc = require('../game/calc');
const C = require('../game/constants');
const msg = require('../utils/messages');
const images = require('../game/commandImages');
const skills = require('../game/skills');

function bonusText(bonus) {
  if (!bonus) return '';
  const parts = [];
  if (bonus.factories > 0) parts.push(`+${bonus.factories} 🏭 завод(ов)`);
  if (bonus.science > 0) parts.push(`+${bonus.science} 🔬 научный(ых) центр(ов)`);
  if (!parts.length) return '';
  return `\n🎁 Бонус за каждую ${C.STEAL_BONUS_EVERY}-ю кражу: ${parts.join(' и ')}!`;
}

function skillLine(skillAfter, leveledUp) {
  const levelUpNote = leveledUp ? ` 🆙 Новый уровень навыка!` : '';
  if (skillAfter.isMax) {
    return `🎓 Навык «Кража»: ${skillAfter.level}/50 (максимум, +${skillAfter.bonusPercent}% к награде)${levelUpNote}`;
  }
  return (
    `🎓 Навык «Кража»: ${skillAfter.level}/50 (+${skillAfter.bonusPercent}% к награде), ` +
    `до след. уровня: ${skillAfter.remaining} краж(и)${levelUpNote}`
  );
}

async function handleSteal(ctx, targetId, peerId) {
  const vkId = ctx.senderId;
  const player = await players.getPlayer(vkId);
  if (!player || player.registration_step !== 'done') {
    await ctx.send('⛔ Вы ещё не зарегистрированы. Напишите !старт');
    return;
  }

  if (!targetId) {
    await ctx.send(`⛔ Формат: !кража @юзер (цель — только топ-${C.STEAL_TOP_N} по виртам, см. !топ вирты)`);
    return;
  }

  const result = await steal.attemptSteal(vkId, targetId);

  if (!result.ok) {
    const reasons = {
      self: '⛔ Нельзя красть у самого себя.',
      not_registered: '⛔ Вы ещё не зарегистрированы. Напишите !старт',
      target_not_registered: '⛔ Цель не зарегистрирована в игре.',
      not_top: `⛔ Красть можно только у топ-${result.topN || C.STEAL_TOP_N} игроков по виртам (см. !топ вирты).`,
      target_protected: '⛔ У этого игрока активна защита от кражи — красть у него нельзя.',
      daily_limit: `⛔ Дневной лимит краж исчерпан (${result.limit || C.STEAL_DAILY_LIMIT}/день). Возвращайтесь завтра.`,
      target_broke: '⛔ У цели сейчас нечего красть.',
    };
    if (result.reason === 'cooldown') {
      await ctx.send(`⏳ Кулдаун кражи. Осталось: ${calc.formatDuration(result.msLeft)}.`);
      return;
    }
    await ctx.send(reasons[result.reason] || '⛔ Кража не удалась.');
    return;
  }

  const attackerLink = msg.mentionLink(result.attackerId, result.attackerName);
  const targetLink = msg.mentionLink(result.targetId, result.targetName);

  const questNotices = await quests.trackProgress(vkId, 'steal', 1);

  let text =
    `🕵️ «${attackerLink}» тайно обчистил казну «${targetLink}»!\n` +
    `Украдено у цели: ${calc.formatNumber(result.stolen)} вирт\n` +
    `Вам досталось: ${calc.formatNumber(result.attackerGain)} вирт (остальное затерялось при отходе)${
      result.stealBoosted ? ' (🍀 донат-буст x2)' : ''
    }\n` +
    `Краж сегодня: ${result.stealsToday}/${result.dailyLimit}` +
    bonusText(result.bonus);
  if (result.skillLeveledUp || result.skillAfter.bonusPercent > 0) {
    text += `\n${skillLine(result.skillAfter, result.skillLeveledUp)}`;
  }
  if (questNotices.length) text += `\n\n${questNotices.join('\n')}`;

  await ctx.send(images.withImage('steal', text));

  if (ctx.bot) {
    await ctx.bot
      .notifyUser(
        result.targetId,
        `🕵️ Вас обокрали! Потеряно ${calc.formatNumber(result.stolen)} вирт.`
      )
      .catch(() => {});

    if (peerId) {
      await ctx.bot
        .sendToChat(peerId, `🕵️ «${attackerLink}» обчистил казну «${targetLink}».`)
        .catch(() => {});
    }
  }
}

async function handleStats(ctx) {
  const player = await players.getPlayer(ctx.senderId);
  if (!player || player.registration_step !== 'done') {
    await ctx.send('⛔ Вы ещё не зарегистрированы. Напишите !старт');
    return;
  }

  const info = skills.progressInfo(player.steal_count_total || 0);
  const text =
    `🕵️ НАВЫК «КРАЖА»\n` +
    `Уровень: ${info.level}/50 (+${info.bonusPercent}% к награде за кражу)\n` +
    `Всего успешных краж: ${player.steal_count_total || 0}\n` +
    (info.isMax ? `Максимальный уровень достигнут!` : `До следующего уровня: ${info.remaining} краж(и)`);
  await ctx.send(text);
}

module.exports = { handleSteal, handleStats };
