'use strict';

const { Keyboard } = require('vk-io');
const C = require('../game/constants');
const calc = require('../game/calc');
const players = require('../db/players');
const depositsDb = require('../db/deposits');
const deposits = require('../game/deposits');
const images = require('../game/commandImages');

// ===== Мастер создания депозита (в памяти процесса, живёт максимум C.DEPOSIT_WIZARD_TTL_MS) =====
// vkId -> { step: 'amount' | 'days', amount?, expiresAt }
const pending = new Map();

function clearPending(vkId) {
  pending.delete(vkId);
}

function getPending(vkId) {
  const state = pending.get(vkId);
  if (!state) return null;
  if (Date.now() > state.expiresAt) {
    pending.delete(vkId);
    return null;
  }
  return state;
}

async function requireRegistered(ctx) {
  const player = await players.getPlayer(ctx.senderId);
  if (!player || player.registration_step !== 'done') {
    await ctx.send('⛔ Вы ещё не зарегистрированы. Напишите !старт');
    return null;
  }
  return player;
}

function formatFullDuration(ms) {
  if (ms <= 0) return '0сек.';
  const totalSeconds = Math.ceil(ms / 1000);
  const days = Math.floor(totalSeconds / 86400);
  const hours = Math.floor((totalSeconds % 86400) / 3600);
  const minutes = Math.floor((totalSeconds % 3600) / 60);
  const seconds = totalSeconds % 60;
  const parts = [];
  if (days > 0) parts.push(`${days}д.`);
  if (days > 0 || hours > 0) parts.push(`${hours}ч.`);
  parts.push(`${minutes}мин.`);
  parts.push(`${seconds}сек.`);
  return parts.join(' ');
}

function send(ctx, payload) {
  return ctx.send(images.withImage('deposit', payload));
}

function isMatured(dep) {
  return new Date(dep.matures_at).getTime() <= Date.now();
}

function menuKeyboard(activeDeposits) {
  const rows = [];
  for (const dep of activeDeposits) {
    if (isMatured(dep)) {
      // Срок вышел — снимать больше нечего, только забрать полную сумму + проценты.
      rows.push([
        Keyboard.textButton({
          label: `✅ Собрать 🆔${dep.id}`,
          payload: { cmd: 'deposit_collect', id: dep.id },
          color: Keyboard.POSITIVE_COLOR,
        }),
      ]);
    } else {
      rows.push([
        Keyboard.textButton({
          label: `❌ Снять 🆔${dep.id}`,
          payload: { cmd: 'deposit_withdraw', id: dep.id },
          color: Keyboard.NEGATIVE_COLOR,
        }),
      ]);
    }
  }
  if (activeDeposits.length < C.DEPOSIT_MAX_ACTIVE_PER_PLAYER) {
    rows.push([
      Keyboard.textButton({ label: '➕ Создать', payload: { cmd: 'deposit_create' }, color: Keyboard.POSITIVE_COLOR }),
    ]);
  }
  return Keyboard.keyboard(rows).inline();
}

function termKeyboard() {
  const rows = C.DEPOSIT_TERMS.map((term) => [
    Keyboard.textButton({
      label: `${term.label} (+${term.profitPercent}%)`,
      payload: { cmd: 'deposit_days', days: term.days },
      color: Keyboard.PRIMARY_COLOR,
    }),
  ]);
  rows.push([Keyboard.textButton({ label: '❌ Отмена', payload: { cmd: 'deposit_cancel' }, color: Keyboard.SECONDARY_COLOR })]);
  return Keyboard.keyboard(rows).inline();
}

function cancelOnlyKeyboard() {
  return Keyboard.keyboard([
    [Keyboard.textButton({ label: '❌ Отмена', payload: { cmd: 'deposit_cancel' }, color: Keyboard.SECONDARY_COLOR })],
  ]).inline();
}

function describeDeposit(dep) {
  const term = deposits.getTerm(dep.term_days);
  const profitPercent = Number(dep.profit_percent);
  const fullPayout = deposits.fullPayout(Number(dep.amount), profitPercent);
  const profit = fullPayout - Number(dep.amount);
  const msLeft = new Date(dep.matures_at).getTime() - Date.now();
  const namePart = dep.name ? `«${dep.name}» ` : '';
  const statusLine = msLeft <= 0 ? `✅ Готов к сбору — нажмите «Собрать»!` : `До готовности: ${formatFullDuration(msLeft)}`;
  return (
    `Депозит: ${namePart}🆔${dep.id}\n` +
    `Сумма: ${calc.formatNumber(Number(dep.amount))} вирт\n` +
    `Срок: ${term ? term.label : dep.term_days + ' дн.'}\n` +
    `Проценты: ${calc.formatNumber(profit)} вирт [${profitPercent}%]\n` +
    `${statusLine}`
  );
}

async function handleMenu(ctx) {
  const player = await requireRegistered(ctx);
  if (!player) return;

  clearPending(ctx.senderId);

  const active = await deposits.listActive(ctx.senderId);

  const termsText = C.DEPOSIT_TERMS.map((t) => `• ${t.label} — +${t.profitPercent}% к сумме`).join('\n');

  let text = `🏦 ДЕПОЗИТЫ\n\n`;
  if (active.length) {
    text += active.map(describeDeposit).join('\n\n') + '\n\n';
  } else {
    text += 'У вас пока нет открытых депозитов.\n\n';
  }
  text += `Условия:\n${termsText}\n\n`;
  text += `Мин. сумма: ${calc.formatNumber(C.DEPOSIT_MIN_AMOUNT)} вирт, макс.: ${calc.formatNumber(C.DEPOSIT_MAX_AMOUNT)} вирт.\n`;
  text += `Одновременно открыто может быть не более ${C.DEPOSIT_MAX_ACTIVE_PER_PLAYER} депозитов.\n`;
  text += `Снять деньги можно и досрочно — но тогда проценты начислятся не полностью, а пропорционально тому, сколько депозит фактически пролежал.\n`;
  text += `По истечении срока депозит НЕ выплачивается сам — придёт уведомление, а забрать сумму + проценты нужно вручную: депозит собрать <id>.\n`;
  text += `Название депозиту можно дать командой: депозит назвать <id> <название> (до ${C.DEPOSIT_NAME_MAX_LENGTH} симв.).\n\n`;
  text += active.length < C.DEPOSIT_MAX_ACTIVE_PER_PLAYER
    ? `Нажмите «➕ Создать» или введите: депозит <сумма> <дней>`
    : `⛔ Достигнут лимит открытых депозитов.`;

  await send(ctx, { message: text, keyboard: menuKeyboard(active) });
}

async function startWizard(ctx) {
  const player = await requireRegistered(ctx);
  if (!player) return;

  const activeCount = await depositsDb.countActiveDeposits(ctx.senderId);
  if (activeCount >= C.DEPOSIT_MAX_ACTIVE_PER_PLAYER) {
    await ctx.send(`⛔ У вас уже открыто максимум депозитов (${C.DEPOSIT_MAX_ACTIVE_PER_PLAYER}). Сначала дождитесь выплаты или снимите один.`);
    return;
  }

  // Очищаем возможный "чужой" мастер (своя сумма для сбора с бизнеса) у того же игрока —
  // иначе следующее голое число могло бы перехватить не тот мастер (lazy require — иначе
  // circular dependency, businessHandlers сам требует depositHandlers.clearPending).
  require('./businessHandlers').clearPendingCollect(ctx.senderId);

  pending.set(ctx.senderId, { step: 'amount', expiresAt: Date.now() + C.DEPOSIT_WIZARD_TTL_MS });

  await send(ctx, {
    message:
      `Введите сумму, которую хотите внести на депозит.\n` +
      `От ${calc.formatNumber(C.DEPOSIT_MIN_AMOUNT)} до ${calc.formatNumber(C.DEPOSIT_MAX_AMOUNT)} вирт.\n` +
      `Ваш баланс: ${calc.formatNumber(Number(player.balance))} вирт.`,
    keyboard: cancelOnlyKeyboard(),
  });
}

async function handleCancel(ctx) {
  clearPending(ctx.senderId);
  await ctx.send('❌ Создание депозита отменено.');
}

// Перехватывает голое число, отправленное в ответ на приглашение ввести сумму (шаг
// мастера создания депозита). Возвращает true, если сообщение было обработано как
// часть мастера (диспетчер не должен дальше пытаться разобрать его как команду).
async function handlePendingAmount(ctx) {
  const vkId = ctx.senderId;
  const state = getPending(vkId);
  if (!state || state.step !== 'amount') return false;

  const text = (ctx.text || '').trim();
  const cleaned = text.replace(/[\s.]/g, '');
  // Не голое число — не наш случай, пусть сообщение идёт по обычному пути диспетчера
  // (например, игрок передумал и просто написал что-то другое / другую команду).
  if (!/^\d+$/.test(cleaned)) return false;

  const amount = parseInt(cleaned, 10);

  const player = await players.getPlayer(vkId);
  if (!player || player.registration_step !== 'done') {
    clearPending(vkId);
    return false;
  }

  if (!Number.isInteger(amount) || amount < C.DEPOSIT_MIN_AMOUNT) {
    await ctx.send(`⛔ Минимальная сумма депозита: ${calc.formatNumber(C.DEPOSIT_MIN_AMOUNT)} вирт. Попробуйте снова или нажмите «Отмена».`);
    return true;
  }
  if (amount > C.DEPOSIT_MAX_AMOUNT) {
    await ctx.send(`⛔ Максимальная сумма депозита: ${calc.formatNumber(C.DEPOSIT_MAX_AMOUNT)} вирт. Попробуйте снова или нажмите «Отмена».`);
    return true;
  }
  if (amount > Number(player.balance)) {
    await ctx.send(`⛔ Недостаточно вирт. У вас: ${calc.formatNumber(Number(player.balance))}. Попробуйте снова или нажмите «Отмена».`);
    return true;
  }

  pending.set(vkId, { step: 'days', amount, expiresAt: Date.now() + C.DEPOSIT_WIZARD_TTL_MS });

  await send(ctx, {
    message: `Сумма: ${calc.formatNumber(amount)} вирт.\nВыберите срок вклада:`,
    keyboard: termKeyboard(),
  });
  return true;
}

async function handlePickDays(ctx, daysArg) {
  const vkId = ctx.senderId;
  const state = getPending(vkId);
  if (!state || state.step !== 'days' || !state.amount) {
    await ctx.send('⛔ Сначала введите сумму: нажмите «депозит» → «➕ Создать».');
    return;
  }

  const days = parseInt(daysArg, 10);
  const result = await deposits.createDeposit(vkId, state.amount, days);
  clearPending(vkId);

  await finishCreateResult(ctx, result);
}

// Прямое создание одной командой: депозит <сумма> <дней>
async function handleCreateDirect(ctx, amountArg, daysArg) {
  const player = await requireRegistered(ctx);
  if (!player) return;

  const amount = parseInt(String(amountArg).replace(/[\s.]/g, ''), 10);
  const days = parseInt(daysArg, 10);

  if (!Number.isInteger(amount) || !Number.isInteger(days)) {
    await ctx.send('⛔ Формат: депозит <сумма> <дней> (дней: 1, 3 или 7). Или просто «депозит» для меню с кнопками.');
    return;
  }

  const result = await deposits.createDeposit(ctx.senderId, amount, days);
  await finishCreateResult(ctx, result);
}

async function finishCreateResult(ctx, result) {
  if (!result.ok) {
    const messages = {
      bad_term: `⛔ Некорректный срок. Доступно: ${C.DEPOSIT_TERMS.map((t) => t.days).join(', ')} дней.`,
      bad_amount: `⛔ Минимальная сумма депозита: ${calc.formatNumber(C.DEPOSIT_MIN_AMOUNT)} вирт.`,
      too_much: `⛔ Максимальная сумма депозита: ${calc.formatNumber(C.DEPOSIT_MAX_AMOUNT)} вирт.`,
      not_registered: '⛔ Вы ещё не зарегистрированы. Напишите !старт',
      not_enough_money: `⛔ Недостаточно вирт${result.missing ? `. Не хватает ${calc.formatNumber(result.missing)}` : ''}.`,
      max_active: `⛔ У вас уже открыто максимум депозитов (${result.max}). Сначала дождитесь выплаты или снимите один.`,
    };
    await ctx.send(messages[result.reason] || '⛔ Не удалось создать депозит.');
    return;
  }

  const dep = result.deposit;
  const term = deposits.getTerm(dep.term_days);
  await send(ctx, {
    message:
      `✅ Депозит открыт!\n\n${describeDeposit(dep)}\n\n` +
      `📥 При выплате по сроку вы получите: ${calc.formatNumber(result.maturityPayout)} вирт (+${term ? term.profitPercent : ''}%).`,
  });
}

async function handleWithdrawPrompt(ctx, idArg) {
  const player = await requireRegistered(ctx);
  if (!player) return;

  const id = parseInt(idArg, 10);
  if (!Number.isInteger(id)) {
    await ctx.send('⛔ Укажите номер депозита: депозит снять <id>');
    return;
  }

  const deposit = await depositsDb.getDepositById(id);
  if (!deposit || deposit.player_id !== ctx.senderId || deposit.status !== 'active') {
    await ctx.send('⛔ Депозит не найден или уже закрыт.');
    return;
  }

  const preview = deposits.earlyPayout(deposit, Date.now());
  const fullPayout = deposits.fullPayout(Number(deposit.amount), Number(deposit.profit_percent));

  await send(ctx, {
    message:
      `⚠️ Снять депозит 🆔${deposit.id} досрочно?\n\n` +
      `Сейчас вы получите: ${calc.formatNumber(preview)} вирт.\n` +
      `Если дождаться срока — получите: ${calc.formatNumber(fullPayout)} вирт.\n\n` +
      `Это действие нельзя отменить.`,
    keyboard: Keyboard.keyboard([
      [
        Keyboard.textButton({
          label: '✅ Снять сейчас',
          payload: { cmd: 'deposit_withdraw_confirm', id: deposit.id },
          color: Keyboard.NEGATIVE_COLOR,
        }),
      ],
      [Keyboard.textButton({ label: '◀️ Назад', payload: { cmd: 'deposit_menu' }, color: Keyboard.SECONDARY_COLOR })],
    ]).inline(),
  });
}

async function handleWithdrawConfirm(ctx, idArg) {
  const player = await requireRegistered(ctx);
  if (!player) return;

  const id = parseInt(idArg, 10);
  const result = await deposits.withdrawEarly(ctx.senderId, id);

  if (!result.ok) {
    const messages = {
      not_found: '⛔ Депозит не найден или уже закрыт.',
      already_matured: '⛔ Срок депозита уже истёк — он вот-вот будет выплачен автоматически, полностью и с процентами.',
      already_closed: '⛔ Этот депозит уже закрыт.',
    };
    await ctx.send(messages[result.reason] || '⛔ Не удалось снять депозит.');
    return;
  }

  await ctx.send(`✅ Депозит 🆔${result.deposit.id} снят досрочно. Начислено: ${calc.formatNumber(result.payout)} вирт.`);
}

// Ручной сбор депозита, у которого срок уже вышел ("депозит собрать <id>" или кнопка
// «✅ Собрать» в меню). В отличие от досрочного снятия тут нечего выбирать/подтверждать —
// выплата всегда полная и это чистая выгода, поэтому действие сразу выполняется.
async function handleCollect(ctx, idArg) {
  const player = await requireRegistered(ctx);
  if (!player) return;

  const id = parseInt(idArg, 10);
  if (!Number.isInteger(id)) {
    await ctx.send('⛔ Укажите номер депозита: депозит собрать <id>');
    return;
  }

  const result = await deposits.collectMatured(ctx.senderId, id);
  if (!result.ok) {
    const messages = {
      not_found: '⛔ Депозит не найден или уже закрыт.',
      not_matured: '⛔ Срок депозита ещё не истёк. Посмотрите оставшееся время в меню «депозит».',
      already_closed: '⛔ Этот депозит уже закрыт.',
    };
    await ctx.send(messages[result.reason] || '⛔ Не удалось собрать депозит.');
    return;
  }

  const namePart = result.deposit.name ? `«${result.deposit.name}» ` : '';
  await ctx.send(`✅ Депозит ${namePart}🆔${result.deposit.id} собран! Начислено: ${calc.formatNumber(result.payout)} вирт.`);
}

// Задать/сменить название депозита: "депозит назвать <id> <название>".
async function handleRename(ctx, idArg, nameArg) {
  const player = await requireRegistered(ctx);
  if (!player) return;

  const id = parseInt(idArg, 10);
  const name = (nameArg || '').trim();
  if (!Number.isInteger(id) || !name) {
    await ctx.send(
      `⛔ Формат: депозит назвать <id> <название> (до ${C.DEPOSIT_NAME_MAX_LENGTH} симв.). Например: депозит назвать 5 На отпуск`
    );
    return;
  }

  const result = await deposits.renameDeposit(ctx.senderId, id, name);
  if (!result.ok) {
    const messages = {
      not_found: '⛔ Депозит не найден — проверьте номер (id) в меню «депозит».',
    };
    await ctx.send(messages[result.reason] || '⛔ Не удалось переименовать депозит.');
    return;
  }

  await ctx.send(`✅ Депозит 🆔${result.deposit.id} теперь называется «${result.deposit.name}».`);
}

module.exports = {
  handleMenu,
  startWizard,
  handleCancel,
  handlePendingAmount,
  handlePickDays,
  handleCreateDirect,
  handleWithdrawPrompt,
  handleWithdrawConfirm,
  handleCollect,
  handleRename,
  clearPending,
};
