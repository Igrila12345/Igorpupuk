'use strict';

const C = require('./constants');
const players = require('../db/players');
const depositsDb = require('../db/deposits');
const asyncLock = require('./asyncLock');

const DAY_MS = 24 * 60 * 60 * 1000;

function getTerm(days) {
  return C.DEPOSIT_TERMS_BY_DAYS[days] || null;
}

// Полная выплата (сумма + проценты) при закрытии ПО СРОКУ.
function fullPayout(amount, profitPercent) {
  return amount + Math.floor((amount * profitPercent) / 100);
}

// Выплата при ДОСРОЧНОМ снятии: проценты начисляются линейно за фактически "отлежанное"
// время — чем меньше продержали депозит относительно полного срока, тем меньше прибавка
// сверх изначальной суммы (в пределе — 0 при снятии сразу же, но сама сумма при этом не
// теряется). Не может ни превысить, ни сравняться с полной выплатой по сроку, пока срок
// не истёк по-настоящему (это по-прежнему отдельная ветка — см. maturity в scheduler).
function earlyPayout(deposit, now) {
  const amount = Number(deposit.amount);
  const profitPercent = Number(deposit.profit_percent);
  const termMs = Number(deposit.term_days) * DAY_MS;
  const createdAt = new Date(deposit.created_at).getTime();
  const elapsedMs = Math.max(0, Math.min(termMs, now - createdAt));
  const elapsedShare = termMs > 0 ? elapsedMs / termMs : 0;
  const profit = Math.floor(amount * (profitPercent / 100) * elapsedShare);
  return amount + profit;
}

async function listActive(vkId) {
  return depositsDb.getActiveDepositsByPlayer(vkId);
}

async function createDeposit(vkId, amount, days) {
  const term = getTerm(days);
  if (!term) return { ok: false, reason: 'bad_term' };

  if (!Number.isInteger(amount) || amount < C.DEPOSIT_MIN_AMOUNT) {
    return { ok: false, reason: 'bad_amount' };
  }
  if (amount > C.DEPOSIT_MAX_AMOUNT) {
    return { ok: false, reason: 'too_much' };
  }

  return asyncLock.withLock(`deposit:${vkId}`, async () => {
    const player = await players.getPlayer(vkId);
    if (!player || player.registration_step !== 'done') {
      return { ok: false, reason: 'not_registered' };
    }
    if (Number(player.balance) < amount) {
      return { ok: false, reason: 'not_enough_money', missing: amount - Number(player.balance) };
    }

    const activeCount = await depositsDb.countActiveDeposits(vkId);
    if (activeCount >= C.DEPOSIT_MAX_ACTIVE_PER_PLAYER) {
      return { ok: false, reason: 'max_active', max: C.DEPOSIT_MAX_ACTIVE_PER_PLAYER };
    }

    await players.updateBalance(vkId, -amount);
    const maturesAt = new Date(Date.now() + term.days * DAY_MS);
    const deposit = await depositsDb.createDeposit(vkId, amount, term.days, term.profitPercent, maturesAt);

    return { ok: true, deposit, maturityPayout: fullPayout(amount, term.profitPercent) };
  });
}

async function withdrawEarly(vkId, depositId) {
  return asyncLock.withLock(`deposit:${vkId}`, async () => {
    const deposit = await depositsDb.getDepositById(depositId);
    if (!deposit || deposit.player_id !== vkId || deposit.status !== 'active') {
      return { ok: false, reason: 'not_found' };
    }

    const now = Date.now();
    if (new Date(deposit.matures_at).getTime() <= now) {
      // Срок уже наступил — не даём "досрочно" снять по заниженной формуле, когда депозит
      // на самом деле уже дозрел. Дальше игроку прямая дорога — "депозит собрать" (см.
      // collectMatured), там полная выплата по сроку.
      return { ok: false, reason: 'already_matured' };
    }

    const payout = earlyPayout(deposit, now);
    const closed = await depositsDb.closeDeposit(depositId, 'withdrawn', payout);
    if (!closed) return { ok: false, reason: 'already_closed' };

    await players.updateBalance(vkId, payout);
    return { ok: true, deposit: closed, payout };
  });
}

// Ручной сбор депозита, у которого уже наступил срок (кнопка "✅ Собрать" / команда
// "депозит собрать <id>"). По ТЗ депозит больше НЕ выплачивается сам по себе по сроку —
// игрок получает уведомление (см. processMaturedDeposits ниже) и должен зайти и забрать
// вклад сам, выбрав нужный из списка. Выплата всегда полная (сумма + 100% процентов по
// сроку) — как и при плановой выплате раньше, просто теперь по действию игрока, а не тика.
async function collectMatured(vkId, depositId) {
  return asyncLock.withLock(`deposit:${vkId}`, async () => {
    const deposit = await depositsDb.getDepositById(depositId);
    if (!deposit || deposit.player_id !== vkId || deposit.status !== 'active') {
      return { ok: false, reason: 'not_found' };
    }
    if (new Date(deposit.matures_at).getTime() > Date.now()) {
      return { ok: false, reason: 'not_matured' };
    }

    const payout = fullPayout(Number(deposit.amount), Number(deposit.profit_percent));
    const closed = await depositsDb.closeDeposit(depositId, 'paid', payout);
    if (!closed) return { ok: false, reason: 'already_closed' };

    await players.updateBalance(vkId, payout);
    return { ok: true, deposit: closed, payout };
  });
}

// Задать/сменить пользовательское название вклада ("депозит назвать <id> <название>").
// Разрешено для любого своего депозита (в т.ч. уже закрытого — чисто для памяти), не
// только активного — переименование само по себе не влияет на баланс/выплаты.
async function renameDeposit(vkId, depositId, rawName) {
  return asyncLock.withLock(`deposit:${vkId}`, async () => {
    const deposit = await depositsDb.getDepositById(depositId);
    if (!deposit || deposit.player_id !== vkId) {
      return { ok: false, reason: 'not_found' };
    }

    const name = (rawName || '').trim().slice(0, C.DEPOSIT_NAME_MAX_LENGTH) || null;
    const updated = await depositsDb.renameDeposit(depositId, name);
    return { ok: true, deposit: updated };
  });
}

// Уведомления о созревших депозитах — вызывается из scheduler.js. Депозит больше НЕ
// закрывается и НЕ выплачивается здесь автоматически: только шлём игроку уведомление
// (один раз на депозит, см. markMaturedNotified) о том, что срок вышел и пора зайти
// собрать вклад самому.
async function processMaturedDeposits(bot) {
  const due = await depositsDb.getUnnotifiedMaturedDeposits();
  for (const deposit of due) {
    try {
      const marked = await depositsDb.markMaturedNotified(deposit.id);
      if (!marked) continue; // кто-то уже пометил/собрал буквально в последний момент

      if (bot) {
        const calc = require('./calc');
        const term = getTerm(deposit.term_days);
        const payout = fullPayout(Number(deposit.amount), Number(deposit.profit_percent));
        const label = deposit.name ? `«${deposit.name}» (🆔${deposit.id})` : `🆔${deposit.id}`;
        await bot
          .notifyUser(
            deposit.player_id,
            `🏦 Срок депозита ${label} истёк!\n` +
              `💰 К получению: ${calc.formatNumber(payout)} вирт (+${term ? term.profitPercent : ''}%).\n` +
              `Зайдите в «депозит» и нажмите «✅ Собрать», чтобы забрать вклад.`
          )
          .catch(() => {});
      }
    } catch (err) {
      console.error(`[Deposits] Ошибка уведомления по депозиту #${deposit.id}:`, err);
    }
  }
}

async function getTopByPayout(limit = 10) {
  return depositsDb.getTopByDepositPayout(limit, C.DEPOSIT_TOP_MIN_HOLD_HOURS);
}

module.exports = {
  getTerm,
  fullPayout,
  earlyPayout,
  listActive,
  createDeposit,
  withdrawEarly,
  collectMatured,
  renameDeposit,
  processMaturedDeposits,
  getTopByPayout,
};
