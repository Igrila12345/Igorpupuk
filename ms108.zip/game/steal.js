'use strict';

// Кража у топ-5 игроков (по виртам/балансу — тот же рейтинг, что и в "!топ виртов").
// Специально сбалансирована, чтобы не сносить топеров: см. комментарий к константам
// STEAL_* в game/constants.js.

const C = require('./constants');
const players = require('../db/players');
const gameDate = require('./gameDate');
const calc = require('./calc');
const skills = require('./skills');

function msLeft(lastAt, cooldownMs) {
  if (!lastAt) return 0;
  const left = cooldownMs - (Date.now() - new Date(lastAt).getTime());
  return left > 0 ? left : 0;
}

function randomInt(min, max) {
  return min + Math.floor(Math.random() * (max - min + 1));
}

// Раз в STEAL_BONUS_EVERY успешных краж — бесплатный бонус вору: случайное число заводов
// (STEAL_BONUS_FACTORIES_MIN-MAX) и научных центров (STEAL_BONUS_SCIENCE_MIN-MAX). Это НЕ
// кража у жертвы, а прямая выдача, поэтому ограничена только лимитами самого вора (лимит
// заводов/лимит науки, см. calc.currentFactoryLimit/currentScienceLimit) — если места не
// хватает, выдаётся столько, сколько влезает (может быть 0 по одному из двух ресурсов).
async function tryBonusDrop(attackerVkId) {
  const attacker = await players.getPlayer(attackerVkId);
  if (!attacker) return null;

  const wantFactories = randomInt(C.STEAL_BONUS_FACTORIES_MIN, C.STEAL_BONUS_FACTORIES_MAX);
  const factoryLimit = calc.currentFactoryLimit(attacker.factory_limit_level);
  const factoryRoom = Math.max(0, factoryLimit - (attacker.factories || 0));
  const factoriesGiven = Math.min(wantFactories, factoryRoom);
  if (factoriesGiven > 0) {
    await players.addFactories(attackerVkId, factoriesGiven);
  }

  const wantScience = randomInt(C.STEAL_BONUS_SCIENCE_MIN, C.STEAL_BONUS_SCIENCE_MAX);
  const scienceLimit = calc.currentScienceLimit(attacker.science_limit_level);
  const scienceRoom = Math.max(0, scienceLimit - (attacker.science_centers || 0));
  const scienceGiven = Math.min(wantScience, scienceRoom);
  if (scienceGiven > 0) {
    await players.addScienceCenters(attackerVkId, scienceGiven);
  }

  if (factoriesGiven <= 0 && scienceGiven <= 0) return null;
  return { factories: factoriesGiven, science: scienceGiven };
}

async function attemptSteal(attackerVkId, targetVkId) {
  if (String(attackerVkId) === String(targetVkId)) {
    return { ok: false, reason: 'self' };
  }

  const attacker = await players.getPlayer(attackerVkId);
  if (!attacker || attacker.registration_step !== 'done') {
    return { ok: false, reason: 'not_registered' };
  }

  const target = await players.getPlayer(targetVkId);
  if (!target || target.registration_step !== 'done') {
    return { ok: false, reason: 'target_not_registered' };
  }

  // 🛡️ Защита от кражи — ОТДЕЛЬНАЯ донат-подписка (НЕ часть VIP, см. calc.isStealProtectionActive
  // и !админ кражазащита). Проверяем ДО проверки топ-N ниже — быть под защитой важнее, чем не
  // быть в топе.
  if (calc.isStealProtectionActive(target)) {
    return { ok: false, reason: 'target_protected' };
  }

  const rank = await players.getBalanceRank(targetVkId);
  if (!rank || rank > C.STEAL_TOP_N) {
    return { ok: false, reason: 'not_top', topN: C.STEAL_TOP_N };
  }

  const today = gameDate.todayStr();
  let dayCount = attacker.steal_count_today || 0;
  if (attacker.steal_day && String(attacker.steal_day).slice(0, 10) !== today) {
    // Раньше сброс дня учитывался только в локальной переменной dayCount (для проверки
    // лимита ниже), но никогда не писался в БД — resetStealDay существовал, но нигде не
    // вызывался. incrementStealCount() ниже всегда делает steal_count_today + 1 к СТАРОМУ
    // значению из БД, поэтому счётчик не обнулялся по факту никогда: на второй день лимит
    // "не обновлялся", т.к. накопленное вчера продолжало расти. Обнуляем в БД сразу здесь,
    // как это уже делает game/inspection.js: ensureDayReset().
    await players.resetStealDay(attackerVkId, today);
    dayCount = 0;
  }

  const left = msLeft(attacker.last_steal_at, C.STEAL_COOLDOWN_MS);
  if (left > 0) {
    return { ok: false, reason: 'cooldown', msLeft: left };
  }

  if (dayCount >= C.STEAL_DAILY_LIMIT) {
    return { ok: false, reason: 'daily_limit', limit: C.STEAL_DAILY_LIMIT };
  }

  const targetBalance = Number(target.balance) || 0;
  // Сумма, списываемая с жертвы — случайная в фиксированном диапазоне (не % от баланса),
  // но не больше, чем у жертвы реально есть на балансе.
  // 💰 "Штраф для богатых": если у жертвы больше STEAL_RICH_TARGET_THRESHOLD вирт на балансе,
  // списываем вдвое больше базового ролла (см. константы STEAL_RICH_TARGET_* в constants.js).
  // На то, сколько реально получает вор (attackerGain ниже), это не влияет.
  const richTarget = targetBalance > C.STEAL_RICH_TARGET_THRESHOLD;
  let baseStolen = randomInt(C.STEAL_MIN_AMOUNT, C.STEAL_MAX_AMOUNT);
  if (richTarget) baseStolen *= C.STEAL_RICH_TARGET_MULTIPLIER;
  const stolen = Math.min(targetBalance, baseStolen);

  if (stolen <= 0) {
    return { ok: false, reason: 'target_broke' };
  }

  // 🍀 Донат-бафф: x2 доход вора, пока активен steal_boost_until (см. game/donateBuffs.js:
  // grantStealBoost, DONATE_STEAL_BOOST_* в constants.js). Сумма, снятая с жертвы (stolen),
  // от этого баффа НЕ меняется — увеличивается только то, что реально получает вор.
  const stealBoosted = calc.isStealBoostActive(attacker);
  const shareMult = stealBoosted ? C.DONATE_STEAL_BOOST_MULTIPLIER : 1;
  // 🎓 Навык "Кража" (см. game/skills.js): +3% к награде за уровень, до +150% на 50 ур.
  // Считаем по счётчику ДО этой попытки — сама попытка учтётся в счётчике только ниже,
  // после успешного списания, так что уровень не "подскакивает" в середине этого же действия.
  const skillLevelBefore = skills.levelFromCount(attacker.steal_count_total || 0);
  const skillMult = skills.rewardMultiplier(skillLevelBefore);
  const attackerGain = Math.round(randomInt(C.STEAL_ATTACKER_GAIN_MIN, C.STEAL_ATTACKER_GAIN_MAX) * shareMult * skillMult);

  await players.updateBalance(targetVkId, -stolen);
  if (attackerGain > 0) {
    await players.updateBalance(attackerVkId, attackerGain);
  }

  const counts = await players.incrementStealCount(attackerVkId, today);
  const stealsToday = counts ? counts.steal_count_today : dayCount + 1;
  const stealsTotal = counts ? counts.steal_count_total : (attacker.steal_count_total || 0) + 1;
  const skillAfter = skills.progressInfo(stealsTotal);

  let bonus = null;
  if (stealsToday % C.STEAL_BONUS_EVERY === 0) {
    bonus = await tryBonusDrop(attackerVkId);
  }

  return {
    ok: true,
    stolen,
    attackerGain,
    bonus,
    stealsToday,
    dailyLimit: C.STEAL_DAILY_LIMIT,
    targetId: target.vk_id,
    targetName: target.state_name,
    attackerId: attacker.vk_id,
    attackerName: attacker.state_name,
    stealBoosted,
    richTarget,
    skillLevel: skillLevelBefore,
    skillLeveledUp: skillAfter.level > skillLevelBefore,
    skillAfter,
  };
}

module.exports = { attemptSteal };

