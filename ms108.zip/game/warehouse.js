'use strict';

const C = require('./constants');
const calc = require('./calc');
const players = require('../db/players');
const gameDate = require('./gameDate');

// Проверяет, сменился ли игровой день (МСК) для данного дневного счётчика,
// и если да — сбрасывает его в БД и в переданном объекте player (по месту).
// Тот же принцип, что и ensureDayReset() в game/work.js, только обобщённо
// для двух разных счётчиков (кейс и обмен на завод).
async function ensureDayReset(player, countField, dayField, resetFn) {
  const today = gameDate.todayStr();
  const storedDay = player[dayField] ? String(player[dayField]).slice(0, 10) : null;
  if (storedDay !== today) {
    await resetFn(player.vk_id, today);
    player[countField] = 0;
    player[dayField] = today;
  }
  return player;
}

function rollReward() {
  const roll = Math.random() * 100;
  let cumulative = 0;
  for (const reward of C.WAREHOUSE_REWARDS) {
    cumulative += reward.chance;
    if (roll < cumulative) return reward;
  }
  return C.WAREHOUSE_REWARDS[0];
}

async function openBox(vkId, boxNumber) {
  let player = await players.getPlayer(vkId);
  if (!player) return { ok: false, reason: 'not_registered' };

  if (!Number.isInteger(boxNumber) || boxNumber < 1 || boxNumber > C.WAREHOUSE_BOX_COUNT) {
    return { ok: false, reason: 'invalid_box' };
  }

  player = await ensureDayReset(player, 'exchange_case_count_today', 'exchange_case_day', players.resetExchangeCaseDay);
  if ((player.exchange_case_count_today || 0) >= C.EXCHANGE_CASE_MAX_PER_DAY) {
    return { ok: false, reason: 'daily_limit', limit: C.EXCHANGE_CASE_MAX_PER_DAY };
  }

  if ((player.tokens || 0) < C.WAREHOUSE_COST_TOKENS) {
    return { ok: false, reason: 'not_enough_tokens', missing: C.WAREHOUSE_COST_TOKENS - (player.tokens || 0) };
  }

  await players.addTokens(vkId, -C.WAREHOUSE_COST_TOKENS);
  await players.incrementExchangeCaseCount(vkId, gameDate.todayStr());
  const attemptsLeft = C.EXCHANGE_CASE_MAX_PER_DAY - ((player.exchange_case_count_today || 0) + 1);

  const reward = rollReward();
  const qty = reward.min === reward.max ? reward.min : calc.randomInt(reward.min, reward.max);

  switch (reward.type) {
    case 'virts':
      await players.updateBalance(vkId, qty);
      break;
    case 'tokens':
      await players.addTokens(vkId, qty);
      break;
    case 'weapon':
      await players.addToArsenal(vkId, reward.key, qty);
      break;
    case 'air_defense':
      await players.addToAirDefense(vkId, reward.key, qty);
      break;
    case 'factory':
      await players.addFactories(vkId, qty, false);
      break;
    case 'gold_mine':
      // Превращаем 1 обычный завод в "золотую жилу" (если заводов нет — просто добавляем новый золотой)
      if (player.factories > 0) {
        await players.addFactories(vkId, 0, true); // 0 новых заводов, +1 к gold_mine_count
      } else {
        await players.addFactories(vkId, 1, true);
      }
      break;
    default:
      break;
  }

  return { ok: true, reward, qty, attemptsLeft };
}

// Прямой гарантированный обмен: EXCHANGE_FACTORY_COST_TOKENS жетонов -> 1 завод.
// Не больше EXCHANGE_FACTORY_MAX_PER_DAY раз в день (сброс в 00:00 МСК) — игрокам с активным
// VIP лимит x${C.VIP_EXCHANGE_LIMIT_MULTIPLIER} (см. VIP_EXCHANGE_LIMIT_MULTIPLIER).
async function exchangeForFactory(vkId) {
  let player = await players.getPlayer(vkId);
  if (!player) return { ok: false, reason: 'not_registered' };

  player = await ensureDayReset(
    player,
    'exchange_factory_count_today',
    'exchange_factory_day',
    players.resetExchangeFactoryDay
  );
  const limit = calc.isVipActive(player)
    ? C.EXCHANGE_FACTORY_MAX_PER_DAY * C.VIP_EXCHANGE_LIMIT_MULTIPLIER
    : C.EXCHANGE_FACTORY_MAX_PER_DAY;
  if ((player.exchange_factory_count_today || 0) >= limit) {
    return { ok: false, reason: 'daily_limit', limit };
  }

  if ((player.tokens || 0) < C.EXCHANGE_FACTORY_COST_TOKENS) {
    return {
      ok: false,
      reason: 'not_enough_tokens',
      missing: C.EXCHANGE_FACTORY_COST_TOKENS - (player.tokens || 0),
    };
  }

  const remainingTokens = await players.addTokens(vkId, -C.EXCHANGE_FACTORY_COST_TOKENS);
  await players.addFactories(vkId, 1, false);
  await players.incrementExchangeFactoryCount(vkId, gameDate.todayStr());
  const attemptsLeft = limit - ((player.exchange_factory_count_today || 0) + 1);

  return { ok: true, remainingTokens, attemptsLeft, limit };
}

// Массовый обмен жетонов на заводы: "обменять всё" — за один проход считает, сколько
// обменов реально помещается (по жетонам и по остатку дневного лимита), и списывает/начисляет
// всё разом одним обновлением в БД (а не N последовательных вызовов exchangeForFactory).
// requestedCount — необязательное число обменов от игрока ("обменять заводы 30"); если не
// задано (или задано больше, чем помещается) — обменивается максимум возможного.
async function exchangeForFactoryBulk(vkId, requestedCount) {
  let player = await players.getPlayer(vkId);
  if (!player) return { ok: false, reason: 'not_registered' };

  player = await ensureDayReset(
    player,
    'exchange_factory_count_today',
    'exchange_factory_day',
    players.resetExchangeFactoryDay
  );
  const limit = calc.isVipActive(player)
    ? C.EXCHANGE_FACTORY_MAX_PER_DAY * C.VIP_EXCHANGE_LIMIT_MULTIPLIER
    : C.EXCHANGE_FACTORY_MAX_PER_DAY;
  const limitRemaining = Math.max(0, limit - (player.exchange_factory_count_today || 0));

  if (limitRemaining <= 0) {
    return { ok: false, reason: 'daily_limit', limit };
  }

  const affordable = Math.floor((player.tokens || 0) / C.EXCHANGE_FACTORY_COST_TOKENS);
  if (affordable <= 0) {
    return {
      ok: false,
      reason: 'not_enough_tokens',
      missing: C.EXCHANGE_FACTORY_COST_TOKENS - (player.tokens || 0),
    };
  }

  let count = Math.min(limitRemaining, affordable);
  if (Number.isInteger(requestedCount) && requestedCount > 0) {
    count = Math.min(count, requestedCount);
  }

  const spent = count * C.EXCHANGE_FACTORY_COST_TOKENS;
  const remainingTokens = await players.addTokens(vkId, -spent);
  await players.addFactories(vkId, count, false);
  await players.incrementExchangeFactoryCountBy(vkId, gameDate.todayStr(), count);
  const attemptsLeft = limit - ((player.exchange_factory_count_today || 0) + count);

  return { ok: true, count, spent, remainingTokens, attemptsLeft, limit };
}

// Прямой обмен жетонов на научный центр: EXCHANGE_SCIENCE_COST_TOKENS жетонов -> 1 центр.
// Доступен ТОЛЬКО игрокам с активным VIP-статусом. Не больше EXCHANGE_SCIENCE_MAX_PER_DAY
// раз в день (сброс в 00:00 МСК), x${C.VIP_EXCHANGE_LIMIT_MULTIPLIER} для VIP (как и обмен на
// завод выше — раз доступ уже требует VIP, лимит для всех пользователей этой функции удвоен),
// и нельзя превысить обычный лимит числа научных центров (как и при обычной постройке).
async function exchangeForScience(vkId) {
  let player = await players.getPlayer(vkId);
  if (!player) return { ok: false, reason: 'not_registered' };

  if (!calc.isVipActive(player)) {
    return { ok: false, reason: 'vip_required' };
  }

  player = await ensureDayReset(
    player,
    'exchange_science_count_today',
    'exchange_science_day',
    players.resetExchangeScienceDay
  );
  const limit = C.EXCHANGE_SCIENCE_MAX_PER_DAY * C.VIP_EXCHANGE_LIMIT_MULTIPLIER;
  if ((player.exchange_science_count_today || 0) >= limit) {
    return { ok: false, reason: 'daily_limit', limit };
  }

  const scienceLimit = calc.currentScienceLimit(player.science_limit_level);
  if ((player.science_centers || 0) >= scienceLimit) {
    return { ok: false, reason: 'limit_reached', limit: scienceLimit };
  }

  if ((player.tokens || 0) < C.EXCHANGE_SCIENCE_COST_TOKENS) {
    return {
      ok: false,
      reason: 'not_enough_tokens',
      missing: C.EXCHANGE_SCIENCE_COST_TOKENS - (player.tokens || 0),
    };
  }

  // 🎓 Донат-бафф: x2 научных центров за обмен, пока активен science_boost_until (см.
  // game/donateBuffs.js: grantScienceBoost, DONATE_SCIENCE_BOOST_* в constants.js).
  // Не даём выдать сверх личного лимита научных центров — как и обычный обмен выше.
  const scienceBoosted = calc.isScienceBoostActive(player);
  const room = scienceLimit - (player.science_centers || 0);
  const gained = Math.min(scienceBoosted ? C.DONATE_SCIENCE_BOOST_MULTIPLIER : 1, room);

  const remainingTokens = await players.addTokens(vkId, -C.EXCHANGE_SCIENCE_COST_TOKENS);
  await players.addScienceCenters(vkId, gained);
  await players.incrementExchangeScienceCount(vkId, gameDate.todayStr());
  const attemptsLeft = limit - ((player.exchange_science_count_today || 0) + 1);

  return { ok: true, remainingTokens, attemptsLeft, gained, scienceBoosted, limit };
}

module.exports = { openBox, rollReward, exchangeForFactory, exchangeForFactoryBulk, exchangeForScience };
