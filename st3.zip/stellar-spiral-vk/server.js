'use strict';
/**
 * Звёздная спираль: сервер для VK Mini Apps.
 * Без зависимостей: Node.js 22.13+ (встроенные node:sqlite, node:http, node:crypto).
 *
 * Сервер хранит состояние игроков и общий мир (рынок, цены, капитаны-боты), сам выполняет
 * все действия и сам решает, кого показывать в рейтинге. Клиент только просит выполнить действие.
 */
const http=require('node:http');
const fs=require('node:fs');
const path=require('node:path');
const crypto=require('node:crypto');
const {DatabaseSync}=require('node:sqlite');
const Core=require('./src/core.js');

/* ---------- конфигурация ---------- */
/* Разбор .env: строки KEY=VALUE, комментарии после пробела и # в конце строки отбрасываются, кавычки снимаются */
function parseEnv(text){
  const out={};
  for(const line of String(text).split(/\r?\n/)){
    if(/^\s*#/.test(line))continue;
    const m=/^\s*([A-Z0-9_]+)\s*=\s*(.*?)\s*$/.exec(line);
    if(!m)continue;
    let val=m[2];
    const q=/^(["'])(.*?)\1(?:\s+#.*)?$/.exec(val);
    if(q)val=q[2];else val=val.replace(/\s+#.*$/,'').trim();
    out[m[1]]=val;
  }
  return out;
}
function loadEnvFile(file){
  let text;try{text=fs.readFileSync(file,'utf8');}catch(e){return;}
  const parsed=parseEnv(text);
  for(const k of Object.keys(parsed))if(process.env[k]===undefined)process.env[k]=parsed[k];
}
function readConfig(env){
  const list=v=>String(v||'').split(',').map(x=>x.trim()).filter(Boolean);
  return {
    port:+env.PORT||3000,
    host:env.HOST||'127.0.0.1',
    dbPath:env.DB_PATH||path.join(__dirname,'data','stellar.db'),
    publicDir:env.PUBLIC_DIR||path.join(__dirname,'public'),
    vkAppId:String(env.VK_APP_ID||''),
    vkSecret:String(env.VK_SECRET||''),
    devIds:list(env.DEV_IDS),
    adminIds:list(env.ADMIN_IDS),
    allowDemo:env.ALLOW_DEMO==='1',
    demoDev:env.DEMO_DEV==='1',
    demoTopup:env.DEMO_TOPUP==='1',
    bots:env.BOTS==='1',
    photoHosts:list(env.PHOTO_HOSTS),
    corsOrigin:env.CORS_ORIGIN||'*',
    presenceMs:(+env.PRESENCE_MIN||30)*60000,
    signKey:String(env.SIGN_KEY||''),
    requireSign:env.REQUIRE_SIGN!=='0',
    sessionMs:(+env.SESSION_HOURS||12)*3600000,
    launchMaxAgeMs:(env.LAUNCH_MAX_AGE_HOURS===undefined||env.LAUNCH_MAX_AGE_HOURS===''?24:+env.LAUNCH_MAX_AGE_HOURS)*3600000,
    trustProxy:env.TRUST_PROXY==='1',
    allowTestPayments:env.ALLOW_TEST_PAYMENTS==='1',
    bridgeRefresh:env.BRIDGE_REFRESH==='1'
  };
}

/* ---------- проверка подписи запуска VK ---------- */
const b64url=b=>b.toString('base64').replace(/\+/g,'-').replace(/\//g,'_').replace(/=+$/,'');
function safeEq(a,b){const x=Buffer.from(String(a)),y=Buffer.from(String(b));return x.length===y.length&&crypto.timingSafeEqual(x,y);}
function vkSign(params,secret){
  const keys=Object.keys(params).filter(k=>k.startsWith('vk_')).sort();
  const str=keys.map(k=>encodeURIComponent(k)+'='+encodeURIComponent(params[k])).join('&');
  return b64url(crypto.createHmac('sha256',secret).update(str).digest());
}
/* why(причина): необязательная функция для журнала сервера, клиенту причина не сообщается */
function verifyVkLaunch(search,cfg,now,why){
  const q=new URLSearchParams(String(search||'').replace(/^\?/,''));
  const params={};for(const [k,v] of q)params[k]=v;
  const no=r=>{if(why)why(r);return null;};
  if(!cfg.vkSecret)return no('в .env не задан VK_SECRET');
  if(!params.sign||!params.vk_user_id)return no('в запросе нет параметров запуска VK (sign, vk_user_id): игру открыли не из VK или адрес приложения указан неверно');
  if(cfg.vkAppId&&params.vk_app_id!==cfg.vkAppId)return no('vk_app_id='+params.vk_app_id+' не совпадает с VK_APP_ID='+cfg.vkAppId);
  if(!safeEq(vkSign(params,cfg.vkSecret),params.sign))return no('подпись не сошлась: VK_SECRET должен быть «защищённым ключом» именно этого приложения (app_id='+params.vk_app_id+')');
  /* ссылка запуска не должна работать вечно: проверяем возраст vk_ts */
  if(cfg.launchMaxAgeMs>0&&now){
    const ts=+params.vk_ts;
    if(!(ts>0)||now-ts*1000>cfg.launchMaxAgeMs){if(why)why('ссылка запуска устарела (vk_ts)');return {error:'launch expired'};}
  }
  return {uid:'vk'+params.vk_user_id,vkId:params.vk_user_id};
}
/* подпись уведомлений VK Payments: md5(отсортированные key=value + секрет) */
function paymentSig(params,secret){
  const s=Object.keys(params).filter(k=>k!=='sig').sort().map(k=>k+'='+params[k]).join('');
  return crypto.createHash('md5').update(s+secret).digest('hex');
}

/* ---------- утилиты ---------- */
const cleanName=s=>String(s||'').replace(/[\u0000-\u001f<>&"'`]/g,'').trim().slice(0,32);
const VK_PHOTO_HOSTS=['userapi.com','userapidns.com','vk.com','vk.ru','vk.me','vk-cdn.net','vkuser.net','vkuseraudio.net','mycdn.me','vk-portal.net','vkontakte.ru'];
/* Аватар присылает клиент, поэтому принимаем только https-ссылки на домены VK (иначе чужой браузер пойдёт на произвольный адрес) */
function cleanPhoto(s,extraHosts){
  s=String(s||'');
  if(!/^https:\/\/[^\s"'<>]{4,1000}$/.test(s))return '';
  let host;try{host=new URL(s).hostname.toLowerCase();}catch(e){return '';}
  const ok=VK_PHOTO_HOSTS.concat(extraHosts||[]).some(h=>host===h||host.endsWith('.'+h));
  return ok?s:'';
}
const PACK_BY_ITEM={};Core.PACKS.forEach(p=>{PACK_BY_ITEM['crystals_'+p.id]=p;});
/* проверка аргументов действий: тип и границы, всё остальное отклоняется */
const isInt=(v,lo,hi)=>typeof v==='number'&&Number.isInteger(v)&&v>=lo&&v<=hi;
const isId=v=>typeof v==='string'&&/^[A-Za-z0-9_:.\-]{1,40}$/.test(v);
const ARGS={
  doScan:[],doFight:[v=>typeof v==='boolean'],buyUpg:[v=>['engines','shields','weapons','hold','scanner','reactor'].includes(v)],
  build:[v=>isInt(v,0,60),v=>['mine','farm','factory','lab','trade','beacon'].includes(v)],upBld:[v=>isInt(v,0,60)],sellBld:[v=>isInt(v,0,60)],
  unlock:[v=>isInt(v,0,9999),v=>isInt(v,1,12)],travel:[v=>isInt(v,0,9999),v=>isInt(v,1,12)],
  useItem:[v=>isInt(v,0,5000)],equip:[v=>isInt(v,0,5000)],unequip:[v=>isInt(v,0,10)],discard:[v=>isInt(v,0,5000)],
  sellBot:[isId,v=>isInt(v,1,1e7)],listLot:[v=>isInt(v,0,5000),v=>isInt(v,1,1e7),v=>isInt(v,1,1e12)],
  cancelLot:[isId],buyLot:[isId],buyVip:[v=>isInt(v,1,10)],redeem:[v=>typeof v==='string'&&v.length<=40],
  joinGuild:[isId],leaveGuild:[],craftStart:[isId],craftClaim:[],demoPack:[isId],
  sortInv:[v=>['type','rar','price','time'].includes(v)],tipsOff:[]
};
function checkArgs(op,args){
  const spec=ARGS[op];
  if(!spec||!Array.isArray(args)||args.length!==spec.length)return false;
  return spec.every((f,i)=>f(args[i]));
}
const DEV_OPS=new Set(['give','tp','setb','bal','sim','reset','bot']);
function cleanDevArgs(a){
  const out={};
  if(!a||typeof a!=='object'||Array.isArray(a))return out;
  for(const k of Object.keys(a).slice(0,12)){
    const v=a[k];
    if(typeof v==='string')out[k]=v.slice(0,64);else if(typeof v==='number'&&isFinite(v))out[k]=v;
  }
  return out;
}

/* ---------- приложение ---------- */
function createApp(cfg){
  fs.mkdirSync(path.dirname(cfg.dbPath),{recursive:true});
  const db=new DatabaseSync(cfg.dbPath);
  db.exec(`
    PRAGMA journal_mode=WAL;
    CREATE TABLE IF NOT EXISTS players(
      uid TEXT PRIMARY KEY,data TEXT NOT NULL,name TEXT,photo TEXT,
      is_dev INTEGER DEFAULT 0,is_admin INTEGER DEFAULT 0,
      bal REAL DEFAULT 0,xp REAL DEFAULT 0,inc REAL DEFAULT 0,vip INTEGER DEFAULT 0,lvl INTEGER DEFAULT 1,
      loc_t INTEGER DEFAULT 0,loc_s INTEGER DEFAULT 1,guild TEXT,seen INTEGER DEFAULT 0,created INTEGER DEFAULT 0);
    CREATE INDEX IF NOT EXISTS idx_players_loc ON players(loc_t,loc_s,seen);
    CREATE TABLE IF NOT EXISTS kv(k TEXT PRIMARY KEY,v TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS orders(order_id TEXT PRIMARY KEY,uid TEXT,item TEXT,crystals INTEGER,ts INTEGER);
    CREATE TABLE IF NOT EXISTS admin_log(id INTEGER PRIMARY KEY AUTOINCREMENT,ts INTEGER,admin_uid TEXT,admin_name TEXT,action TEXT,target TEXT,details TEXT);
  `);
  if(!db.prepare('PRAGMA table_info(players)').all().some(c=>c.name==='banned'))db.exec('ALTER TABLE players ADD COLUMN banned INTEGER DEFAULT 0');
  const q={
    get:db.prepare('SELECT data FROM players WHERE uid=?'),
    upsert:db.prepare(`INSERT INTO players(uid,data,name,photo,is_dev,is_admin,bal,xp,inc,vip,lvl,loc_t,loc_s,guild,seen,created)
      VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
      ON CONFLICT(uid) DO UPDATE SET data=excluded.data,name=excluded.name,photo=excluded.photo,is_dev=excluded.is_dev,is_admin=excluded.is_admin,
        bal=excluded.bal,xp=excluded.xp,inc=excluded.inc,vip=excluded.vip,lvl=excluded.lvl,loc_t=excluded.loc_t,loc_s=excluded.loc_s,guild=excluded.guild,seen=excluded.seen`),
    kvGet:db.prepare('SELECT v FROM kv WHERE k=?'),
    kvSet:db.prepare('INSERT INTO kv(k,v) VALUES(?,?) ON CONFLICT(k) DO UPDATE SET v=excluded.v'),
    supply:db.prepare('SELECT COALESCE(SUM(bal),0) AS s FROM players'),
    order:db.prepare('INSERT OR IGNORE INTO orders(order_id,uid,item,crystals,ts) VALUES(?,?,?,?,?)')
  };

  /* ---------- Content-Sign: подпись запросов ---------- */
  /* После входа по подписи VK сервер выдаёт сессию (sid) и ключ. Каждый запрос подписывается HMAC-SHA256:
     метод, путь, время, одноразовый nonce и хеш тела. Ключ выводится из sid и серверного секрета, сервер его не хранит. */
  let SKEY;
  if(cfg.signKey)SKEY=crypto.createHash('sha256').update(cfg.signKey).digest();
  else{
    const r=db.prepare('SELECT v FROM kv WHERE k=?').get('sign_key');
    if(r)SKEY=Buffer.from(r.v,'hex');
    else{SKEY=crypto.randomBytes(32);db.prepare('INSERT INTO kv(k,v) VALUES(?,?)').run('sign_key',SKEY.toString('hex'));}
  }
  const hmacB=(key,msg)=>crypto.createHmac('sha256',key).update(msg).digest();
  function issueSession(uid,now){
    const iat=Math.floor(now/1000),salt=b64url(crypto.randomBytes(12));
    const body=b64url(Buffer.from(uid,'utf8'))+'.'+iat+'.'+salt;
    const sid='v1.'+body+'.'+b64url(hmacB(SKEY,'sid|'+body));
    return {sid,key:b64url(hmacB(SKEY,'key|'+sid)),exp:iat*1000+cfg.sessionMs};
  }
  function readSession(sid,now){
    const m=/^v1\.([A-Za-z0-9_-]+)\.(\d{9,11})\.([A-Za-z0-9_-]+)\.([A-Za-z0-9_-]{43})$/.exec(String(sid||''));
    if(!m)return {error:'bad session'};
    const body=m[1]+'.'+m[2]+'.'+m[3];
    if(!safeEq(b64url(hmacB(SKEY,'sid|'+body)),m[4]))return {error:'bad session'};
    const exp=+m[2]*1000+cfg.sessionMs;
    if(now>exp)return {error:'session expired'};
    return {uid:Buffer.from(m[1],'base64url').toString('utf8'),exp,key:b64url(hmacB(SKEY,'key|'+sid)),tail:m[4]};
  }
  const seenNonces=new Map();
  function verifySigned(req,raw,pathname,now){
    const h=req.headers,sid=h['x-sid'],ts=h['x-ts'],nonce=h['x-nonce'],sig=h['content-sign'];
    if(!sid||!ts||!nonce||!sig)return {error:'sign required'};
    const s=readSession(sid,now);if(s.error)return s;
    if(!/^\d{12,14}$/.test(ts)||Math.abs(now-(+ts))>60000)return {error:'stale timestamp'};
    if(!/^[0-9a-f]{16,64}$/.test(nonce))return {error:'bad nonce'};
    const bodyHash=crypto.createHash('sha256').update(raw,'utf8').digest('hex');
    const expected=b64url(hmacB(Buffer.from(s.key,'base64url'),req.method+'\n'+pathname+'\n'+ts+'\n'+nonce+'\n'+bodyHash));
    if(!safeEq(expected,String(sig)))return {error:'bad signature'};
    const nk=s.tail+':'+nonce;
    if(seenNonces.has(nk))return {error:'replay'};   // одноразовость: повтор перехваченного запроса не пройдёт
    seenNonces.set(nk,now+120000);
    return {uid:s.uid,vkId:s.uid.startsWith('vk')?s.uid.slice(2):null,session:s};
  }
  function purgeNonces(now){for(const [k,e] of seenNonces)if(e<now)seenNonces.delete(k);}
  const withSession=(obj,auth,now)=>{
    if(!auth.session||auth.session.exp-now<cfg.sessionMs/2)obj.session=issueSession(auth.uid,now);
    return obj;
  };
  const ipBuckets=new Map();
  function ipOk(ip){
    const now=Date.now(),b=ipBuckets.get(ip)||{t:now,c:0};
    if(now-b.t>60000){b.t=now;b.c=0;}
    b.c++;ipBuckets.set(ip,b);
    if(ipBuckets.size>5000)for(const [k,x] of ipBuckets)if(now-x.t>120000)ipBuckets.delete(k);
    return b.c<=30;
  }

  /* общий мир */
  let W=null;
  const wr=q.kvGet.get('world');
  if(wr){try{W=JSON.parse(wr.v);}catch(e){W=null;}}
  if(!W||W.v!==1)W=Core.newWorld(Date.now(),{staff:false,bots:cfg.bots});
  Core.setWorld(W);
  if(!W.promos)W.promos={};
  Core.setBots(cfg.bots,false);   // BOTS=0: в мире только реальные игроки (старые боты из базы удаляются)
  const persistWorld=()=>{Core.setWorld(W);q.kvSet.run('world',JSON.stringify(W));};
  function worldTick(now){
    Core.setWorld(W);
    W.extraSupply=q.supply.get().s;
    Core.worldCatchUp(now);
  }

  /* игроки */
  function loadPlayer(uid){const r=q.get.get(uid);if(!r)return null;try{return JSON.parse(r.data);}catch(e){return null;}}
  /* keepSeen: изменение чужого аккаунта администратором не считается его активностью */
  function savePlayer(S,keepSeen){
    Core.syncLots(S);
    const now=Date.now(),inc=Core.income(S,now);
    let seen=now;
    if(keepSeen){const r=db.prepare('SELECT seen FROM players WHERE uid=?').get(S.uid);seen=r?r.seen:0;}
    q.upsert.run(S.uid,JSON.stringify(S),S.name,S.photo||'',S.is_dev?1:0,S.is_admin?1:0,S.credits,S.xp,inc,Core.vipLvl(S,now),Core.levelOf(S.xp),S.loc.t,S.loc.s,S.guild||null,seen,S.created||now);
  }
  function flagsFor(auth){
    if(auth.vkId)return {is_dev:cfg.devIds.includes(auth.vkId),is_admin:cfg.adminIds.includes(auth.vkId)};
    return {is_dev:cfg.demoDev,is_admin:false};
  }
  /* открыть сессию: догнать мир и игрока до текущего момента */
  function session(auth,body,isLogin){
    const now=Date.now();
    worldTick(now);
    const fl=flagsFor(auth);
    let S=loadPlayer(auth.uid),created=false;
    if(!S){
      S=Core.newGame({uid:auth.uid,name:cleanName(body&&body.name)||'Капитан',photo:cleanPhoto(body&&body.photo,cfg.photoHosts),is_dev:fl.is_dev,is_admin:fl.is_admin});
      Core.spawnCompanions(S.loc);created=true;
    }
    S.is_dev=fl.is_dev;S.is_admin=fl.is_admin;  // флаги всегда от сервера
    if(S.banned&&!S.is_dev&&!S.is_admin)throw {banned:true,reason:S.banReason||''};
    if(isLogin&&body){const n=cleanName(body.name);if(n)S.name=n;const p=cleanPhoto(body.photo,cfg.photoHosts);if(p)S.photo=p;}
    /* время в игре считает сервер: только пока клиент шлёт запросы (не реже раза в 2 минуты) */
    const gap=now-(S.lastSeen||now),away=created?0:gap;
    if(gap>0&&gap<120000)S.stats.playSec+=gap/1000;
    const sum=Core.catchUp(S,now);
    return {S,sum,created,now,away};
  }

  /* представления */
  function marketView(S,now){
    const out=[];
    for(const l of W.market){
      if(l.status!=='active'||l.exp<=now)continue;
      out.push({id:l.id,seller:l.seller,k:l.k,n:l.n,p:l.p,u:l.u,exp:l.exp,mine:l.owner===S.uid,real:!!l.owner});
    }
    out.sort((a,b)=>a.p*a.n-b.p*b.n);
    return out.slice(0,250);
  }
  function pricesView(){const p={};for(const k of Core.KEYS)p[k]=Core.avgPrice(null,k);return p;}
  function stateView(S,now){
    const v=JSON.parse(JSON.stringify(S));
    if(!S.is_dev)v.devLog=[];
    return {state:v,world:{market:marketView(S,now),prices:pricesView()},serverNow:now};
  }
  function crewList(t,s,selfUid){
    Core.setWorld(W);
    const rows=db.prepare('SELECT uid,name,photo,lvl,vip,guild FROM players WHERE loc_t=? AND loc_s=? AND is_dev=0 AND is_admin=0 AND banned=0 AND seen>? AND uid!=? LIMIT 40').all(t,s,Date.now()-cfg.presenceMs,selfUid);
    const real=rows.map(r=>({id:'p'+r.uid,name:r.name,photo:r.photo||'',lvl:r.lvl,vip:r.vip,guild:r.guild||null,loc:{t,s},real:true}));
    return real.concat(Core.crewAt(null,t,s)).slice(0,60);
  }
  function crewCounts(t,selfUid){
    Core.setWorld(W);
    const c=Core.crewCounts(null,t);
    for(const r of db.prepare('SELECT loc_s AS s,COUNT(*) AS c FROM players WHERE loc_t=? AND is_dev=0 AND is_admin=0 AND banned=0 AND seen>? AND uid!=? GROUP BY loc_s').all(t,Date.now()-cfg.presenceMs,selfUid))c[r.s]=(c[r.s]||0)+r.c;
    return c;
  }
  const TOPCOL={bal:'bal',xp:'xp',inc:'inc'};
  /* Публичный рейтинг. Аккаунты is_dev и is_admin исключаются на сервере, в ответ они не попадают. */
  function topView(S,kind){
    const col=TOPCOL[kind];if(!col)return null;
    Core.setWorld(W);
    const rows=db.prepare('SELECT uid,name,photo,lvl,bal,xp,inc,vip FROM players WHERE is_dev=0 AND is_admin=0 AND banned=0 ORDER BY '+col+' DESC LIMIT 50').all()
      .map(r=>({id:'p'+r.uid,name:r.name,photo:r.photo||'',lvl:r.lvl,bal:r.bal,xp:r.xp,inc:r.inc,vip:r.vip,me:r.uid===S.uid}));
    let npcN=0;
    if(cfg.bots)for(const n of W.npcs){if(n.is_dev||n.is_admin)continue;npcN++;rows.push({id:n.id,name:n.name,photo:'',lvl:Core.levelOf(Core.npcXp(n)),bal:n.bal,xp:Core.npcXp(n),inc:Core.npcInc(n),vip:n.vip,me:false});}
    rows.sort((a,b)=>b[kind]-a[kind]);
    const hidden=!!(S.is_dev||S.is_admin);
    let myRank=null,me=null;
    if(!hidden){
      const mine=kind==='bal'?S.credits:kind==='xp'?S.xp:Core.income(S);
      const above=db.prepare('SELECT COUNT(*) AS c FROM players WHERE is_dev=0 AND is_admin=0 AND banned=0 AND uid!=? AND '+col+'>?').get(S.uid,mine).c
        +(cfg.bots?W.npcs.filter(n=>!n.is_dev&&!n.is_admin&&(kind==='bal'?n.bal:kind==='xp'?Core.npcXp(n):Core.npcInc(n))>mine).length:0);
      myRank=above+1;
      me={id:'p'+S.uid,name:S.name,photo:S.photo||'',lvl:Core.levelOf(S.xp),bal:S.credits,xp:S.xp,inc:Core.income(S),vip:Core.vipLvl(S),me:true};
    }
    const total=db.prepare('SELECT COUNT(*) AS c FROM players WHERE is_dev=0 AND is_admin=0 AND banned=0').get().c+npcN;
    return {rows:rows.slice(0,50),myRank,me,total,hidden};
  }
  function devView(){
    const rows=db.prepare('SELECT name,bal,is_dev,is_admin FROM players ORDER BY bal DESC LIMIT 8').all()
      .map(r=>({name:r.name,bal:r.bal,is_dev:!!r.is_dev,is_admin:!!r.is_admin}));
    return {econ:W.econ.slice(-24),fullTop:rows,players:db.prepare('SELECT COUNT(*) AS c FROM players').get().c};
  }

  /* ---------- админ-панель (доступна is_admin и is_dev, проверяет сервер) ---------- */
  const alogIns=db.prepare('INSERT INTO admin_log(ts,admin_uid,admin_name,action,target,details) VALUES(?,?,?,?,?,?)');
  const alog=(S,action,target,details)=>alogIns.run(Date.now(),S.uid,S.name,action,target||'',JSON.stringify(details||{}).slice(0,500));
  const ADMIN_OPS=new Set(['overview','users','user','ban','unban','grant','lots','removeLot','promos','promoCreate','promoDelete','log']);
  const UID_RE=/^[A-Za-z0-9_-]{1,40}$/;
  const numIn=(v,lo,hi)=>{v=Number(v);return Number.isFinite(v)&&v>=lo&&v<=hi?v:null;};
  function adminUserRow(r){return {uid:r.uid,name:r.name,photo:r.photo||'',lvl:r.lvl,bal:r.bal,xp:r.xp,vip:r.vip,seen:r.seen,banned:!!r.banned,is_dev:!!r.is_dev,is_admin:!!r.is_admin,loc:{t:r.loc_t,s:r.loc_s}};}
  function adminOp(S,op,a,now){
    const A=x=>({err:x});
    switch(op){
      case 'overview':{
        const c=db.prepare('SELECT COUNT(*) AS n,COALESCE(SUM(bal),0) AS bal,COALESCE(SUM(banned),0) AS banned FROM players').get();
        const cnt=(sql,...p)=>db.prepare(sql).get(...p).n;
        const d0=new Date();d0.setHours(0,0,0,0);
        const o=db.prepare('SELECT COUNT(*) AS n,COALESCE(SUM(crystals),0) AS cr FROM orders').get();
        return {ok:true,data:{players:c.n,banned:c.banned,totalBal:c.bal,online5:cnt('SELECT COUNT(*) AS n FROM players WHERE seen>?',now-300000),active24:cnt('SELECT COUNT(*) AS n FROM players WHERE seen>?',now-86400000),newToday:cnt('SELECT COUNT(*) AS n FROM players WHERE created>?',d0.getTime()),staff:cnt('SELECT COUNT(*) AS n FROM players WHERE is_dev=1 OR is_admin=1'),lots:W.market.filter(l=>l.status==='active'&&l.exp>now).length,orders:o.n,crystalsSold:o.cr,vol:W.vol,econ:W.econ.slice(-24)}};
      }
      case 'users':{
        const qs=String(a.q||'').trim().slice(0,32),page=Math.max(0,Math.floor(+a.page||0)),esc=qs.replace(/[\\%_]/g,m=>'\\'+m);
        const rows=db.prepare("SELECT * FROM players WHERE (?='' OR name LIKE ? ESCAPE '\\' OR uid=? OR uid='vk'||?) ORDER BY seen DESC LIMIT 21 OFFSET ?").all(qs,'%'+esc+'%',qs,qs,page*20);
        return {ok:true,data:{rows:rows.slice(0,20).map(adminUserRow),more:rows.length>20,page}};
      }
      case 'user':{
        if(!UID_RE.test(String(a.uid||'')))return A('Неверный id');
        const T=loadPlayer(a.uid),row=db.prepare('SELECT * FROM players WHERE uid=?').get(a.uid);
        if(!T||!row)return A('Игрок не найден');
        Core.setWorld(W);Core.syncLots(T);
        return {ok:true,data:Object.assign(adminUserRow(row),{credits:T.credits,premium:T.premium,vipLevel:T.vipLevel,vipUntil:T.vipUntil,upg:T.upg,stats:T.stats,created:row.created,lots:T.lots.length,buildings:Core.allBuildings(T).length,levels:Core.sumLevels(T),banReason:T.banReason||'',inv:T.inv.length,log:T.log.slice(0,8),promoUsed:T.promoUsed})};
      }
      case 'ban':case 'unban':{
        if(!UID_RE.test(String(a.uid||'')))return A('Неверный id');
        const T=loadPlayer(a.uid),row=db.prepare('SELECT * FROM players WHERE uid=?').get(a.uid);
        if(!T||!row)return A('Игрок не найден');
        if(a.uid===S.uid)return A('Нельзя менять свой статус');
        if(op==='ban'&&(row.is_dev||row.is_admin))return A('Нельзя заблокировать служебный аккаунт');
        const reason=String(a.reason||'').slice(0,80);
        T.banned=op==='ban';T.banReason=op==='ban'?reason:'';
        if(op==='ban')for(const l of W.market)if(l.owner===a.uid&&l.status==='active'){l.status='expired';l.exp=now;}   // лоты возвращаются владельцу после разблокировки
        savePlayer(T,true);db.prepare('UPDATE players SET banned=? WHERE uid=?').run(T.banned?1:0,a.uid);
        alog(S,op,a.uid,{name:row.name,reason});
        return {ok:true,msg:op==='ban'?'Игрок заблокирован':'Игрок разблокирован'};
      }
      case 'grant':{
        if(!UID_RE.test(String(a.uid||'')))return A('Неверный id');
        const T=loadPlayer(a.uid);if(!T)return A('Игрок не найден');
        const cr=a.credits==null||a.credits===''?0:numIn(a.credits,-1e12,1e12),pr=a.premium==null||a.premium===''?0:numIn(a.premium,-1e6,1e6),vd=a.vipDays==null||a.vipDays===''?0:numIn(a.vipDays,0,3650),vl=a.vipLevel==null||a.vipLevel===''?0:numIn(a.vipLevel,0,10),qty=a.qty==null||a.qty===''?1:numIn(a.qty,1,9999);
        if(cr===null||pr===null||vd===null||vl===null||qty===null)return A('Числа вне допустимых границ');
        const parts=[];
        if(cr){T.credits=Math.max(0,T.credits+cr);parts.push((cr>0?'+':'')+cr+' кредитов');}
        if(pr){T.premium=Math.max(0,Math.floor(T.premium+pr));parts.push((pr>0?'+':'')+pr+' кристаллов');}
        if(vd>0){
          const active=Core.vipActive(T,now),lvl=Math.max(1,Math.floor(vl)||(active?T.vipLevel:1));
          if(active){T.vipLevel=Math.max(T.vipLevel,lvl);T.vipUntil+=vd*86400000;}else{T.vipLevel=lvl;T.vipUntil=now+vd*86400000;}
          parts.push('VIP '+T.vipLevel+' на '+vd+' дн.');
        }
        if(a.item){
          Core.setWorld(W);
          if(!Core.KEYS.includes(a.item))return A('Неизвестный предмет');
          const left=Core.addItem(T,a.item,Math.floor(qty));parts.push(Core.info(a.item).name+' ×'+(Math.floor(qty)-left)+(left?' (нет места: '+left+')':''));
        }
        if(!parts.length)return A('Нечего выдавать');
        Core.logAdd(T,'Администратор: '+parts.join(', '));
        savePlayer(T,true);alog(S,'grant',a.uid,{parts});
        return {ok:true,msg:'Выдано: '+parts.join(', ')};
      }
      case 'lots':{
        const rows=W.market.filter(l=>l.owner).sort((x,y)=>x.exp-y.exp).slice(0,100).map(l=>({id:l.id,seller:l.seller,owner:l.owner,k:l.k,n:l.n,p:l.p,u:l.u?{name:l.u.name}:null,exp:l.exp,status:l.status}));
        return {ok:true,data:{rows}};
      }
      case 'removeLot':{
        const l=W.market.find(x=>x.id===a.id&&x.owner);if(!l)return A('Лот не найден');
        l.status='expired';l.exp=now;   // предметы вернутся владельцу при его следующем входе
        alog(S,'removeLot',l.owner,{lot:l.id,k:l.k,n:l.n,p:l.p,reason:String(a.reason||'').slice(0,80)});persistWorld();
        return {ok:true,msg:'Лот снят, предметы вернутся владельцу'};
      }
      case 'promos':{
        const all=[];
        for(const code of Object.keys(Core.PROMOS))all.push(Object.assign({code,builtin:true,uses:W.promoTotals[code]||0},Core.PROMOS[code]));
        for(const code of Object.keys(W.promos))all.push(Object.assign({code,builtin:false,uses:W.promoTotals[code]||0},W.promos[code]));
        return {ok:true,data:{rows:all}};
      }
      case 'promoCreate':{
        const code=String(a.code||'').trim().toUpperCase();
        if(!/^[A-Z0-9_]{3,24}$/.test(code))return A('Код: 3-24 символа, латиница, цифры, _');
        if(Core.PROMOS[code]||W.promos[code])return A('Такой код уже есть');
        const cr=numIn(a.credits||0,0,1e9),pr=numIn(a.premium||0,0,1e5),vd=numIn(a.vip_days||0,0,365),ut=numIn(a.uses_total||1,1,1e6),days=numIn(a.days||30,1,365),ml=numIn(a.min_level||0,0,1000),upu=numIn(a.uses_per_user||1,1,10);
        if([cr,pr,vd,ut,days,ml,upu].includes(null))return A('Числа вне допустимых границ');
        if(!cr&&!pr&&!vd)return A('Укажите награду');
        const exp=new Date(now+days*86400000),expires=exp.getFullYear()+'-'+String(exp.getMonth()+1).padStart(2,'0')+'-'+String(exp.getDate()).padStart(2,'0');
        const reward={};if(cr)reward.credits=Math.floor(cr);if(pr)reward.premium=Math.floor(pr);if(vd)reward.vip_days=Math.floor(vd);
        W.promos[code]={type:ut===1?'single':'multi',reward,uses_total:Math.floor(ut),uses_per_user:Math.floor(upu),expires,min_level:Math.floor(ml),max_level:null};
        alog(S,'promoCreate',code,{reward,ut,expires});persistWorld();
        return {ok:true,msg:'Промокод '+code+' создан, действует до '+expires};
      }
      case 'promoDelete':{
        const code=String(a.code||'').toUpperCase();
        if(!W.promos[code])return A('Можно удалить только созданные вручную коды');
        delete W.promos[code];alog(S,'promoDelete',code,{});persistWorld();
        return {ok:true,msg:'Промокод удалён'};
      }
      case 'log':{
        const rows=db.prepare('SELECT ts,admin_name,action,target,details FROM admin_log ORDER BY id DESC LIMIT 60').all();
        return {ok:true,data:{rows}};
      }
    }
    return A('Неизвестная команда');
  }

  /* ---------- HTTP ---------- */
  const buckets=new Map();
  function rateOk(uid){
    const now=Date.now(),b=buckets.get(uid)||{t:now,c:0};
    if(now-b.t>5000){b.t=now;b.c=0;}
    b.c++;buckets.set(uid,b);
    if(buckets.size>5000)for(const [k,v] of buckets)if(now-v.t>60000)buckets.delete(k);
    return b.c<=60;
  }
  function headers(extra){
    return Object.assign({
      'Access-Control-Allow-Origin':cfg.corsOrigin,'Access-Control-Allow-Headers':'Authorization, Content-Type, X-Sid, X-Ts, X-Nonce, Content-Sign','Access-Control-Allow-Methods':'GET, POST, OPTIONS',
      'X-Content-Type-Options':'nosniff','Referrer-Policy':'no-referrer','Cache-Control':'no-store'
    },extra||{});
  }
  function send(res,code,obj){const b=JSON.stringify(obj);res.writeHead(code,headers({'Content-Type':'application/json; charset=utf-8'}));res.end(b);}
  function readBody(req,limit){
    return new Promise((resolve,reject)=>{
      let size=0;const chunks=[];
      req.on('data',c=>{size+=c.length;if(size>limit){reject(new Error('too large'));req.destroy();}else chunks.push(c);});
      req.on('end',()=>resolve(Buffer.concat(chunks).toString('utf8')));
      req.on('error',reject);
    });
  }
  const rejectSeen=new Map();
  /* отказы во входе пишем в журнал (не чаще раза в 30 секунд на причину), чтобы было видно, что не так с настройкой */
  function logReject(reason){
    if(process.env.NODE_ENV==='test')return;
    const t=Date.now();
    if(t-(rejectSeen.get(reason)||0)<30000)return;
    rejectSeen.set(reason,t);
    console.warn('[вход отклонён] '+reason);
  }
  function authenticateLaunch(req,now){
    const h=String(req.headers.authorization||'');
    if(h.startsWith('VK '))return verifyVkLaunch(h.slice(3),cfg,now,logReject);
    if(cfg.allowDemo&&h.startsWith('Demo ')){
      const id=h.slice(5).trim();
      if(/^[A-Za-z0-9_-]{3,32}$/.test(id))return {uid:'demo_'+id,vkId:null};
    }
    return null;
  }
  /* VK Bridge отдаём со своего адреса: раньше он грузился с CDN, и если CDN недоступен или тормозит, VK бесконечно показывает загрузку */
  const BRIDGE_URLS=['https://cdn.jsdelivr.net/npm/@vkontakte/vk-bridge@2/dist/browser.min.js','https://unpkg.com/@vkontakte/vk-bridge@2/dist/browser.min.js'];
  const bridgeFile=path.join(path.dirname(cfg.dbPath),'vk-bridge.js');
  let bridgeBuf=null,bridgeLoading=null;
  function loadBridge(){
    if(bridgeBuf)return Promise.resolve(bridgeBuf);
    if(bridgeLoading)return bridgeLoading;
    bridgeLoading=(async()=>{
      try{const st=fs.statSync(bridgeFile);if(Date.now()-st.mtimeMs<7*86400000||!cfg.bridgeRefresh){bridgeBuf=fs.readFileSync(bridgeFile);return bridgeBuf;}}catch(e){}
      for(const url of BRIDGE_URLS){
        try{
          const ctl=new AbortController(),to=setTimeout(()=>ctl.abort(),8000);
          const r=await fetch(url,{signal:ctl.signal});clearTimeout(to);
          const text=r.ok?await r.text():'';
          if(text.length>5000&&text.indexOf('vkBridge')>=0){bridgeBuf=Buffer.from(text,'utf8');fs.writeFileSync(bridgeFile,bridgeBuf);return bridgeBuf;}
        }catch(e){}
      }
      try{bridgeBuf=fs.readFileSync(bridgeFile);return bridgeBuf;}catch(e){}   // старая копия лучше, чем ничего
      return null;
    })().finally(()=>{bridgeLoading=null;});
    return bridgeLoading;
  }
  if(process.env.NODE_ENV!=='test')loadBridge().then(b=>console.log(b?'VK Bridge готов ('+b.length+' байт)':'VK Bridge не удалось загрузить: игра в VK не откроется, проверьте доступ сервера к cdn.jsdelivr.net')).catch(()=>{});
  const CSP="default-src 'self'; script-src 'self' 'unsafe-inline' https://cdn.jsdelivr.net; style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; font-src https://fonts.gstatic.com; img-src 'self' data: https:; connect-src 'self'"+(cfg.corsOrigin!=='*'?' '+cfg.corsOrigin:' https:')+"; frame-ancestors https://vk.com https://*.vk.com https://vk.ru https://*.vk.ru https://*.vk-apps.com";
  function serveStatic(req,res){
    const u=new URL(req.url,'http://x');
    let p=u.pathname==='/'?'/index.html':u.pathname;
    if(p!=='/index.html'){res.writeHead(404,headers({'Content-Type':'text/plain'}));return res.end('not found');}
    fs.readFile(path.join(cfg.publicDir,'index.html'),(e,buf)=>{
      if(e){res.writeHead(404,headers({'Content-Type':'text/plain'}));return res.end('index.html not found: run "npm run build"');}
      res.writeHead(200,headers({'Content-Type':'text/html; charset=utf-8','Content-Security-Policy':CSP,'Cache-Control':'no-cache'}));
      res.end(buf);
    });
  }

  /* VK Payments */
  function handlePayments(params){
    const fail=(code,msg,critical)=>({error:{error_code:code,error_msg:msg,critical:!!critical}});
    if(!cfg.vkSecret)return fail(20,'not configured',true);
    if(cfg.vkAppId&&String(params.app_id)!==cfg.vkAppId)return fail(11,'bad app',true);
    if(!params.sig||!safeEq(paymentSig(params,cfg.vkSecret),params.sig))return fail(10,'Несовпадение вычисленной и переданной подписи запроса.',true);
    const type=String(params.notification_type||'');
    /* тестовые уведомления принимаются только пока включён режим проверки платежей */
    if(/_test$/.test(type)&&!cfg.allowTestPayments)return fail(100,'Тестовые платежи отключены.',true);
    const pack=PACK_BY_ITEM[params.item];
    if(type==='get_item'||type==='get_item_test'){
      if(!pack)return fail(20,'Товара не существует.',true);
      return {response:{item_id:params.item,title:'Кристаллы: '+(pack.n+pack.bonus),photo_url:'',price:pack.price}};
    }
    if(type==='order_status_change'||type==='order_status_change_test'){
      if(params.status!=='chargeable')return fail(100,'Неизвестный статус заказа.',true);
      if(!pack)return fail(20,'Товара не существует.',true);
      const uid='vk'+params.user_id,S=loadPlayer(uid);
      if(!S)return fail(22,'Пользователь не найден.',true);
      const total=pack.n+pack.bonus,ins=q.order.run(String(params.order_id),uid,params.item,total,Date.now());
      if(ins.changes===1){
        Core.setWorld(W);
        const S2=loadPlayer(uid);S2.premium+=total;Core.logAdd(S2,'Покупка: +'+total+' ◆');savePlayer(S2,true);
      }
      return {response:{order_id:+params.order_id||0,app_order_id:String(params.order_id)}};
    }
    return fail(100,'Неизвестный тип уведомления.',true);
  }

  const server=http.createServer(async(req,res)=>{
    try{
      const url=new URL(req.url,'http://x'),p=url.pathname;
      if(req.method==='OPTIONS'){res.writeHead(204,headers());return res.end();}
      if(req.method==='GET'&&(p==='/'||p==='/index.html'))return serveStatic(req,res);
      if(req.method==='GET'&&p==='/vk-bridge.js'){
        const b=await loadBridge();
        if(!b){res.writeHead(502,headers({'Content-Type':'text/plain'}));return res.end('bridge unavailable');}
        res.writeHead(200,headers({'Content-Type':'application/javascript; charset=utf-8','Cache-Control':'public, max-age=86400'}));return res.end(b);
      }
      if(req.method==='GET'&&p==='/api/ping')return send(res,200,{ok:true,game:'stellar-spiral',v:2,demo:cfg.allowDemo,demoTopup:cfg.demoTopup});
      if(req.method==='GET'&&p==='/health')return send(res,200,{ok:true});
      if(req.method!=='POST')return send(res,404,{error:'not found'});

      if(p==='/vk/payments'){
        const raw=await readBody(req,16384),params={};
        for(const [k,v] of new URLSearchParams(raw))params[k]=v;
        return send(res,200,handlePayments(params));
      }
      if(!p.startsWith('/api/'))return send(res,404,{error:'not found'});

      const raw=await readBody(req,32768),tNow=Date.now();
      let auth;
      if(p==='/api/login'||!cfg.requireSign){
        if(p==='/api/login'){
          const ip=cfg.trustProxy?String(req.headers['x-forwarded-for']||'').split(',')[0].trim()||req.socket.remoteAddress:req.socket.remoteAddress;
          if(!ipOk(ip))return send(res,429,{error:'too many logins'});
        }
        auth=authenticateLaunch(req,tNow);
        if(auth&&auth.error)return send(res,401,{error:auth.error});
      }else{
        auth=verifySigned(req,raw,p,tNow);
        if(auth.error)return send(res,401,{error:auth.error});
      }
      if(!auth)return send(res,401,{error:'unauthorized'});
      if(!rateOk(auth.uid))return send(res,429,{error:'too many requests'});
      let body={};
      if(raw){try{body=JSON.parse(raw);}catch(e){return send(res,400,{error:'bad json'});}}
      if(!body||typeof body!=='object'||Array.isArray(body))body={};

      if(p==='/api/login'||p==='/api/sync'){
        const {S,sum,created,now,away}=session(auth,body,p==='/api/login');
        Core.checkAch(S);savePlayer(S);
        return send(res,200,Object.assign(withSession(stateView(S,now),auth,now),{created,away,events:sum.ev,sum:{credits:sum.credits,res:sum.res,lost:sum.lost,sold:sum.sold,mins:sum.mins},cfg:{demo:cfg.allowDemo,demoTopup:cfg.demoTopup,packs:Core.PACKS}}));
      }
      if(p==='/api/act'){
        const op=body.op,args=body.args||[];
        if(typeof op!=='string'||!Object.prototype.hasOwnProperty.call(Core.OPS,op)||!checkArgs(op,args))return send(res,400,{error:'bad action'});
        const {S,sum,now}=session(auth,null,false);
        let result;
        if(op==='demoPack'&&!cfg.demoTopup)result={err:'Пополнение в демо отключено'};
        else{
          try{result=Core.OPS[op](S,...args);}catch(e){result={err:'Ошибка выполнения'};}
        }
        const ach=Core.checkAch(S).map(a=>({name:a.name,reward:a.reward}));
        savePlayer(S);
        return send(res,200,Object.assign(withSession(stateView(S,now),auth,now),{result,ach,events:sum.ev}));
      }
      if(p==='/api/crew'){
        if(!isInt(body.t,0,9999)||!isInt(body.s,1,12))return send(res,400,{error:'bad args'});
        return send(res,200,{crew:crewList(body.t,body.s,auth.uid)});
      }
      if(p==='/api/counts'){
        if(!isInt(body.t,0,9999))return send(res,400,{error:'bad args'});
        return send(res,200,{counts:crewCounts(body.t,auth.uid)});
      }
      if(p==='/api/top'){
        const {S}=session(auth,null,false);savePlayer(S);
        const t=topView(S,body.kind);if(!t)return send(res,400,{error:'bad kind'});
        return send(res,200,{top:t});
      }
      if(p==='/api/dev'){
        const {S,now}=session(auth,null,false);
        if(!S.is_dev)return send(res,403,{error:'forbidden'});
        const op=body.op;
        if(op==='view')return send(res,200,Object.assign(stateView(S,now),{dev:devView()}));
        if(typeof op!=='string'||!DEV_OPS.has(op))return send(res,400,{error:'bad action'});
        let result;
        try{result=Core.dev(S,op,cleanDevArgs(body.args));}catch(e){result={err:'Ошибка выполнения'};}
        savePlayer(S);
        return send(res,200,Object.assign(stateView(S,now),{result,dev:devView()}));
      }
      if(p==='/api/admin'){
        const {S,now}=session(auth,null,false);
        if(!(S.is_admin||S.is_dev))return send(res,403,{error:'forbidden'});
        const op=body.op;
        if(typeof op!=='string'||!ADMIN_OPS.has(op))return send(res,400,{error:'bad action'});
        let result;
        try{result=adminOp(S,op,cleanDevArgs(body.args),now);}catch(e){result={err:'Ошибка выполнения'};if(process.env.NODE_ENV!=='test')console.error(e);}
        savePlayer(S);
        return send(res,200,{result});
      }
      return send(res,404,{error:'not found'});
    }catch(e){
      if(e&&e.banned&&!res.headersSent)return send(res,403,{error:'banned',reason:e.reason||''});
      if(!res.headersSent)send(res,500,{error:'server error'});
      if(process.env.NODE_ENV!=='test')console.error(e);
    }
  });

  const tick=setInterval(()=>{try{worldTick(Date.now());persistWorld();purgeNonces(Date.now());}catch(e){console.error(e);}},30000);
  tick.unref();
  function close(){clearInterval(tick);try{persistWorld();}catch(e){}return new Promise(r=>{server.close(()=>{try{db.close();}catch(e){}r();});if(server.closeAllConnections)server.closeAllConnections();});}
  return {server,db,close,persistWorld,cfg,_W:()=>W};
}

module.exports={createApp,readConfig,parseEnv,vkSign,paymentSig,verifyVkLaunch};

if(require.main===module){
  loadEnvFile(path.join(__dirname,'.env'));
  const cfg=readConfig(process.env);
  if(!cfg.allowDemo&&(!cfg.vkAppId||!cfg.vkSecret)){
    console.error('Задайте VK_APP_ID и VK_SECRET в .env (или ALLOW_DEMO=1 для локальной проверки).');
    process.exit(1);
  }
  const app=createApp(cfg);
  app.server.listen(cfg.port,cfg.host,()=>console.log('Звёздная спираль: http://'+cfg.host+':'+cfg.port+(cfg.allowDemo?' (демо-режим включён)':'')));
  const stop=()=>app.close().then(()=>process.exit(0));
  process.on('SIGINT',stop);process.on('SIGTERM',stop);
}
