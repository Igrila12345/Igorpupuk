'use strict';

const { query } = require('./pool');

async function setCooldown(senderId, receiverId) {
  await query(
    `INSERT INTO transfer_cooldowns (sender_id, receiver_id, last_transfer_at)
     VALUES ($1, $2, NOW())
     ON CONFLICT (sender_id, receiver_id) DO UPDATE SET last_transfer_at = NOW()`,
    [senderId, receiverId]
  );
}

async function getCooldown(senderId, receiverId) {
  const res = await query(
    'SELECT last_transfer_at FROM transfer_cooldowns WHERE sender_id = $1 AND receiver_id = $2',
    [senderId, receiverId]
  );
  return res.rows[0] ? res.rows[0].last_transfer_at : null;
}

// Полная запись о переводе — см. db/schema.sql: transfer_log. Пишется ПОСЛЕ фактического
// списания/зачисления в handleTransfer, чисто для аудита (расследование мультиаккаунтов,
// накрутки клановой казны и т.п. — см. !админ переводы).
async function logTransfer(senderId, receiverId, amount, commission, received) {
  await query(
    `INSERT INTO transfer_log (sender_id, receiver_id, amount, commission, received)
     VALUES ($1, $2, $3, $4, $5)`,
    [senderId, receiverId, amount, commission, received]
  );
}

// Сводка для ручного расследования: сколько игрок отправил/получил всего, и с кем именно —
// сгруппировано по контрагенту, отсортировано по сумме. Один "донат другу раз в пару недель"
// даёт 1-2 строки с небольшой суммой; кольцо мультиаккаунтов обычно выглядит как регулярные
// переводы от одних и тех же ID с общей суммой в разы больше обычной активности игрока.
async function getTransferPartners(vkId, direction, limit = 15) {
  const column = direction === 'sent' ? 'sender_id' : 'receiver_id';
  const partnerColumn = direction === 'sent' ? 'receiver_id' : 'sender_id';
  const amountColumn = direction === 'sent' ? 'amount' : 'received';
  const res = await query(
    `SELECT ${partnerColumn} AS partner_id,
            COUNT(*) AS transfer_count,
            SUM(${amountColumn}) AS total_amount,
            MAX(created_at) AS last_at
     FROM transfer_log
     WHERE ${column} = $1
     GROUP BY ${partnerColumn}
     ORDER BY total_amount DESC
     LIMIT $2`,
    [vkId, limit]
  );
  return res.rows;
}

// Для ограничения на связанные (мульти) аккаунты: сумма переводов, ушедших ВНУТРИ
// группы (между любыми парами аккаунтов из groupIds) за последние windowMs миллисекунд.
// Считаем по amount (списано у отправителя), не по received, чтобы комиссия не позволяла
// незаметно обходить лимит.
async function getGroupInternalTransferSum(groupIds, windowMs) {
  if (!groupIds || groupIds.length === 0) return 0;
  const res = await query(
    `SELECT COALESCE(SUM(amount), 0) AS total FROM transfer_log
     WHERE sender_id = ANY($1)
       AND receiver_id = ANY($1)
       AND sender_id <> receiver_id
       AND created_at >= NOW() - ($2 || ' milliseconds')::interval`,
    [groupIds, windowMs]
  );
  return Number(res.rows[0].total);
}

module.exports = {
  setCooldown,
  getCooldown,
  logTransfer,
  getTransferPartners,
  getGroupInternalTransferSum,
};

