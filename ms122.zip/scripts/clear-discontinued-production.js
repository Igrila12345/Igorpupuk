'use strict';

// Скрипт для снятия с производства оружия, которого больше нет в игре (снято из
// C.WEAPONS), но у части игроков оно застряло в очереди производства — они не могут
// собрать его командой !забрать (findWeaponKey ищет только среди актуального C.WEAPONS),
// и при этом выделенные под него заводы навсегда считаются занятыми
// (db/production.js: getFactoriesInUse суммирует ВСЕ collected = FALSE записи, независимо
// от того, существует ли ещё такое оружие).
//
// Запуск из корня проекта (там, где index.js и .env):
//   node scripts/clear-discontinued-production.js
//
// Сначала выполняется "сухой прогон" — только показывает, что было бы снято, ничего
// не меняет. Чтобы реально применить — раскомментируй DRY_RUN = false ниже.

require('dotenv').config();
const { pool } = require('../db/pool');

// ⚠️ Впиши сюда точные названия оружия, которых больше нет в C.WEAPONS (как они хранятся
// в колонке weapon таблицы production_queue — обычно совпадает с тем, что видно в
// "!статус производства").
const DISCONTINUED_WEAPON_NAMES = ['Кинжал'];

// Вирт за единицу, которую вернуть игроку в качестве компенсации за списанное
// производство (0 = без компенсации — оружия и так больше не существует, отдавать
// нечего). Если решишь компенсировать — впиши сюда productionCost, который было
// у этого оружия, пока его не убрали из C.WEAPONS.
const REFUND_PER_UNIT = 0;

// true = ничего не меняет в БД, только печатает, что нашлось. Поставь false, чтобы
// реально снять с производства.
const DRY_RUN = true;

async function main() {
  if (!DISCONTINUED_WEAPON_NAMES.length) {
    console.log('Список DISCONTINUED_WEAPON_NAMES пуст — нечего чистить.');
    return;
  }

  const { rows } = await pool.query(
    `SELECT pq.id, pq.player_id, pq.weapon, pq.quantity, pq.factories_used, pq.ready_at,
            p.state_name
       FROM production_queue pq
       LEFT JOIN players p ON p.vk_id = pq.player_id
      WHERE pq.collected = FALSE
        AND pq.weapon = ANY($1)
      ORDER BY pq.player_id`,
    [DISCONTINUED_WEAPON_NAMES]
  );

  if (!rows.length) {
    console.log('Ничего не найдено — ни у кого нет застрявшего производства этого оружия.');
    return;
  }

  const byPlayer = new Map();
  for (const r of rows) {
    if (!byPlayer.has(r.player_id)) byPlayer.set(r.player_id, []);
    byPlayer.get(r.player_id).push(r);
  }

  console.log(`Найдено записей: ${rows.length}, игроков: ${byPlayer.size}.`);
  console.log(DRY_RUN ? '--- СУХОЙ ПРОГОН (ничего не меняется) ---' : '--- ПРИМЕНЯЮ ИЗМЕНЕНИЯ ---');

  let totalRefund = 0;

  for (const [playerId, records] of byPlayer) {
    const name = records[0].state_name || '???';
    const totalQty = records.reduce((s, r) => s + r.quantity, 0);
    const totalFactories = records.reduce((s, r) => s + r.factories_used, 0);
    const refund = totalQty * REFUND_PER_UNIT;
    totalRefund += refund;

    console.log(
      `  vk_id=${playerId} (${name}): ${records.length} запис., оружия x${totalQty}, ` +
        `освобождается заводов: ${totalFactories}${refund ? `, возврат: ${refund} вирт` : ''}`
    );

    if (!DRY_RUN) {
      const ids = records.map((r) => r.id);
      await pool.query(`UPDATE production_queue SET collected = TRUE WHERE id = ANY($1)`, [ids]);
      if (refund > 0) {
        await pool.query(`UPDATE players SET balance = balance + $2 WHERE vk_id = $1`, [playerId, refund]);
      }
    }
  }

  console.log(`\nИтого: заводов освободится ${rows.reduce((s, r) => s + r.factories_used, 0)}` +
    (REFUND_PER_UNIT ? `, компенсация всего: ${totalRefund} вирт.` : '.'));

  if (DRY_RUN) {
    console.log('\nЭто был сухой прогон. Чтобы применить — поставь DRY_RUN = false в скрипте и запусти снова.');
  } else {
    console.log('\nГотово. Записи помечены collected = TRUE (заводы освобождены, оружие в арсенал не начислено).');
  }
}

main()
  .catch((err) => {
    console.error('Ошибка при очистке производства:', err);
    process.exitCode = 1;
  })
  .finally(() => {
    pool.end();
  });
