'use strict';

// ===================== ДОНАТ-БИЗНЕСЫ (многослотовые) =====================
// См. комментарий у C.DONATE_BUSINESS_* в game/constants.js. Оплата и выдача — вручную через
// администратора после получения денег, как и весь остальной донат в проекте (см. game/donateBuffs.js).
//
// В отличие от старой версии (один активный донат-бизнес на игрока, хранился прямо в колонках
// players) теперь это МНОЖЕСТВЕННЫЕ записи в таблице donate_businesses (db/donateBusiness.js) —
// у игрока может быть несколько бизнесов одновременно (одного тира или разных), ограничение —
// только количество купленных слотов (см. getSlotsInfo). Каждая запись ещё и прокачивается по
// уровню за рубли (level, 1..DONATE_BUSINESS_MAX_LEVEL) — множитель дохода как у обычных
// бизнесов (BUSINESS_LEVEL_MULTIPLIERS).

const C = require('./constants');
const calc = require('./calc');
const players = require('../db/players');
const db = require('../db/donateBusiness');

function getTierById(id) {
  return C.DONATE_BUSINESS_TIERS.find((t) => t.id === id) || null;
}

function isRowActive(row) {
  return !!(row && row.until && new Date(row.until) > new Date());
}

// tier опционален для обратной совместимости старых вызовов (level-only) — но у "вечного"
// тира (permanent: true) СВОЯ 25-уровневая шкала (DONATE_BUSINESS_ETERNAL_LEVEL_MULTIPLIERS),
// поэтому везде, где известен тир, его нужно передавать первым аргументом.
function levelMultiplier(tierOrLevel, maybeLevel) {
  const tier = typeof tierOrLevel === 'object' ? tierOrLevel : null;
  const level = tier ? maybeLevel : tierOrLevel;
  if (tier && tier.levelMultipliers) return tier.levelMultipliers[level] || 1;
  return C.BUSINESS_LEVEL_MULTIPLIERS[level] || 1;
}

function maxLevelForTier(tier) {
  return (tier && tier.maxLevel) || C.DONATE_BUSINESS_MAX_LEVEL;
}

function clampLevel(tier, level) {
  return Math.max(1, Math.min(maxLevelForTier(tier), level));
}

// Ставит "until" далеко в будущее — для permanent-тира ("💎 Вечная Династия" и т.п.), по
// аналогии с Майнером (MINER_FOREVER_YEARS). Игнорирует переданные дни продления.
function foreverUntil() {
  return new Date(Date.now() + C.DONATE_BUSINESS_ETERNAL_FOREVER_YEARS * 365 * 24 * 60 * 60 * 1000);
}

// "Навсегда" считаем, если срок настолько далеко в будущем, что это точно permanent-запись, а
// не просто очень длинное продление обычного тира (см. calc.isMinerForever — тот же принцип).
function isForever(row, tier) {
  if (tier && tier.permanent) return true;
  if (!row || !row.until) return false;
  const yearsLeft = (new Date(row.until).getTime() - Date.now()) / (365 * 24 * 60 * 60 * 1000);
  return yearsLeft > 20;
}

// Ранг "вечного" бизнеса по уровню (см. DONATE_BUSINESS_ETERNAL_RANKS) — для красоты в статусе.
function eternalRankName(level) {
  const ranks = C.DONATE_BUSINESS_ETERNAL_RANKS;
  let name = ranks[0] ? ranks[0].name : '';
  for (const r of ranks) {
    if (level >= r.minLevel) name = r.name;
  }
  return name;
}

// ===================== СЛОТЫ =====================

async function getSlotsInfo(vkId) {
  const player = await players.getPlayer(vkId);
  if (!player) return null;

  const extra = Math.min(player.donate_business_extra_slots || 0, C.DONATE_BUSINESS_MAX_EXTRA_SLOTS);
  const total = C.DONATE_BUSINESS_BASE_SLOTS + extra;
  const used = await db.countActiveByPlayer(vkId);
  return { base: C.DONATE_BUSINESS_BASE_SLOTS, extra, total, used, free: Math.max(total - used, 0) };
}

// ===================== СТАТУС =====================

// Возвращает список ВСЕХ действующих донат-бизнесов игрока с "порядковым номером" (1-based,
// по порядку выдачи) — этот номер использует админ в командах уровня/снятия конкретного слота.
async function listStatus(vkId) {
  const rows = await db.listByPlayer(vkId);
  const active = rows.filter(isRowActive);
  return active.map((row, i) => {
    const tier = getTierById(row.tier_id);
    return { slot: i + 1, id: row.id, row, tier, level: row.level, until: row.until, weeklyAt: row.weekly_at };
  });
}

// Резолвит "номер слота" (1-based, как показывает listStatus) в конкретную запись БД, либо
// null, если такого номера нет. Считает нумерацию среди ДЕЙСТВУЮЩИХ бизнесов игрока.
async function resolveSlot(vkId, slotNumber) {
  const list = await listStatus(vkId);
  const found = list.find((x) => x.slot === slotNumber);
  return found ? found.row : null;
}

// ===================== ВЫДАЧА / ПРОДЛЕНИЕ / СМЕНА ТИРА =====================

// Выдаёт НОВЫЙ донат-бизнес (отдельный слот) — можно выдавать один и тот же тир повторно, это
// создаст второй независимый слот. Требует свободный слот (см. getSlotsInfo).
async function grantNew(vkId, tierId, days = C.DONATE_BUSINESS_DURATION_DAYS) {
  const tier = getTierById(tierId);
  if (!tier) return { ok: false, reason: 'unknown_tier' };

  const player = await players.getPlayer(vkId);
  if (!player) return { ok: false, reason: 'not_registered' };

  const slots = await getSlotsInfo(vkId);
  if (slots.free <= 0) return { ok: false, reason: 'no_free_slots', slots };

  const until = tier.permanent ? foreverUntil() : new Date(Date.now() + days * 24 * 60 * 60 * 1000);
  const row = await db.create(vkId, tier.id, until, 1);
  return { ok: true, tier, until, level: row.level, id: row.id };
}

// Продлевает/меняет тир на КОНКРЕТНОМ уже существующем слоте (по номеру из listStatus). Срок
// продлевается сверху остатка, как остальные донат-баффы, уровень не сбрасывается.
async function extendSlot(vkId, slotNumber, tierId, days = C.DONATE_BUSINESS_DURATION_DAYS) {
  const tier = getTierById(tierId);
  if (!tier) return { ok: false, reason: 'unknown_tier' };

  const row = await resolveSlot(vkId, slotNumber);
  if (!row) return { ok: false, reason: 'slot_not_found' };

  let until;
  if (tier.permanent) {
    until = foreverUntil();
  } else {
    const now = Date.now();
    const currentUntilMs = row.until ? new Date(row.until).getTime() : 0;
    const base = currentUntilMs > now ? currentUntilMs : now;
    until = new Date(base + days * 24 * 60 * 60 * 1000);
  }

  await db.updateTierAndUntil(row.id, tier.id, until);
  return { ok: true, tier, until, level: row.level, id: row.id };
}

// Снимает конкретный слот по номеру (см. listStatus). Если slotNumber не передан — снимает
// ВСЕ действующие донат-бизнесы игрока разом (обратная совместимость со старой командой).
async function removeSlot(vkId, slotNumber) {
  if (!slotNumber) {
    await db.removeAllForPlayer(vkId);
    return { ok: true, removedAll: true };
  }

  const row = await resolveSlot(vkId, slotNumber);
  if (!row) return { ok: false, reason: 'slot_not_found' };

  await db.remove(row.id);
  return { ok: true, id: row.id };
}

// ===================== УРОВЕНЬ (прокачка за рубли) =====================

// delta — на сколько уровней сдвинуть (+1 / -1 / +2 ...), результат клампится в 1..MAX_LEVEL.
async function adjustLevel(vkId, slotNumber, delta) {
  const row = await resolveSlot(vkId, slotNumber);
  if (!row) return { ok: false, reason: 'slot_not_found' };

  const tier = getTierById(row.tier_id);
  const newLevel = clampLevel(tier, row.level + delta);
  if (newLevel === row.level) return { ok: true, tier, level: newLevel, unchanged: true };

  await db.updateLevel(row.id, newLevel);
  return { ok: true, tier, level: newLevel, from: row.level };
}

async function setLevel(vkId, slotNumber, level) {
  const row = await resolveSlot(vkId, slotNumber);
  if (!row) return { ok: false, reason: 'slot_not_found' };

  const tier = getTierById(row.tier_id);
  const newLevel = clampLevel(tier, level);
  await db.updateLevel(row.id, newLevel);
  return { ok: true, tier, level: newLevel, from: row.level };
}

// ===================== ОЦЕНКА ДОХОДА (для профиля, см. handlers/profile.js) =====================

// Оценочный доход в час от ВСЕХ активных донат-бизнесов игрока (среднее hourlyVirtsMin/Max,
// умноженное на множитель уровня слота и C.DONATE_BUSINESS_INCOME_MULTIPLIER — та же формула,
// что использует hourlyTick при реальном начислении). Добавлено, т.к. раньше доход от
// донат-бизнесов нигде не попадал в "Итого доход" в профиле — начислялся на баланс, но не
// учитывался в отображаемой сумме.
async function estimateHourlyIncome(vkId) {
  const list = await listStatus(vkId);
  let total = 0;
  for (const entry of list) {
    if (!entry.tier) continue;
    const mult = levelMultiplier(entry.tier, entry.level) * C.DONATE_BUSINESS_INCOME_MULTIPLIER;
    const avgVirts = (entry.tier.hourlyVirtsMin + entry.tier.hourlyVirtsMax) / 2;
    total += avgVirts * mult;
  }
  return Math.round(total);
}

// ===================== ТИКИ (см. game/scheduler.js) =====================

// Часовой тик: вирты + жетоны каждый час, гарантированно, помноженные на уровень слота И
// на постоянный доп. множитель C.DONATE_BUSINESS_INCOME_MULTIPLIER (еженедельный бонус ниже — нет).
async function hourlyTick() {
  const rows = await db.listAllActive();
  for (const row of rows) {
    const tier = getTierById(row.tier_id);
    if (!tier) continue;
    const mult = levelMultiplier(tier, row.level) * C.DONATE_BUSINESS_INCOME_MULTIPLIER;
    const virts = Math.round(calc.randomInt(tier.hourlyVirtsMin, tier.hourlyVirtsMax) * mult);
    const tokens = Math.round(tier.hourlyTokens * mult);
    await players.updateBalance(row.player_id, virts);
    await players.addTokens(row.player_id, tokens);
  }
}

// Суточный тик: снимает истёкшие слоты и раз в DONATE_BUSINESS_WEEKLY_DAYS дней выдаёт третий,
// уникальный для тира ресурс (тоже помноженный на уровень слота).
async function dailyTick(bot) {
  const expired = await db.listAllExpired();
  for (const row of expired) {
    await db.remove(row.id);
    if (bot) {
      bot
        .notifyUser(row.player_id, `⌛ Срок вашего донат-бизнеса истёк. Продлить можно у администратора (см. "донат").`)
        .catch(() => {});
    }
  }

  const active = await db.listAllActive();
  const now = Date.now();
  for (const row of active) {
    const tier = getTierById(row.tier_id);
    if (!tier) continue;

    const weeklyAtMs = row.weekly_at ? new Date(row.weekly_at).getTime() : 0;
    if (now - weeklyAtMs < C.DONATE_BUSINESS_WEEKLY_DAYS * 24 * 60 * 60 * 1000) continue;

    const mult = levelMultiplier(tier, row.level);
    const amount = Math.round(tier.weekly.amount * mult);

    if (tier.weekly.type === 'event_currency') {
      await players.addEventCurrency(row.player_id, amount);
    } else if (tier.weekly.type === 'science') {
      await players.addScienceCenters(row.player_id, amount);
    }

    await db.updateWeeklyAt(row.id, new Date());
    if (bot) {
      bot
        .notifyUser(
          row.player_id,
          `🎁 Еженедельный бонус от «${tier.name}»: +${amount} ${tier.weekly.label}!`
        )
        .catch(() => {});
    }
  }
}

module.exports = {
  getTierById,
  isRowActive,
  levelMultiplier,
  maxLevelForTier,
  isForever,
  eternalRankName,
  getSlotsInfo,
  listStatus,
  resolveSlot,
  grantNew,
  extendSlot,
  removeSlot,
  adjustLevel,
  setLevel,
  estimateHourlyIncome,
  hourlyTick,
  dailyTick,
};
