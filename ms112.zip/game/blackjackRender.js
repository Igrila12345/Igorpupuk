'use strict';

const { createCanvas, GlobalFonts } = require('@napi-rs/canvas');
const path = require('path');
const fs = require('fs');
const calc = require('./calc');

// ===================== СТОЛ БЛЭКДЖЕКА (СТАТИЧНОЕ ФОТО, @napi-rs/canvas) =====================
// В отличие от слотов (game/casinoRender.js — гифка на Jimp с анимацией прокрутки), у
// блэкджека нет одного "момента спина": раздача состоит из нескольких шагов (ставка →
// раздача карт → игрок берёт ещё карты или останавливается → дилер доигрывает). Поэтому
// здесь рисуется одна статичная картинка стола, которую handlers/blackjackHandlers.js
// отправляет ПОВТОРНО (новым сообщением) после КАЖДОГО действия игрока — визуально это
// выглядит как "фото меняется": после ставки на фото раздача, после "хит" — на фото
// прибавилась карта, после "стенд" — на фото открылись карты дилера и итог.
//
// Рисуем через настоящий canvas (@napi-rs/canvas), а не Jimp-примитивы, как остальные
// мини-игры проекта: у карточных мастей ♠♥♦♣ нужны плавные кривые (сердце/пика — это
// bezier-кривые, не многоугольники), Canvas 2D API с ctx.bezierCurveTo даёт нормальную
// форму "из одного удара", тогда как ручная растеризация полигонов на Jimp (см. старую
// версию этого файла) даёт заметно более грубый, "квадратный" результат.

// Шрифт с поддержкой кириллицы. Если рядом с проектом лежит собственный .ttf (например,
// DejaVu Sans, из которого и сгенерированы битмап-шрифты assets/fonts/*.fnt для Jimp-
// рендеров), регистрируем и используем его по имени. Если файла нет — используем системный
// sans-serif: на типичном Linux-сервере (Ubuntu/Debian) через fontconfig это почти всегда
// резолвится в DejaVu Sans или аналог с кириллицей, так что текст не превратится в "тофу"
// даже без явного файла — но для гарантии лучше положить .ttf в assets (см. ниже).
const FONT_CANDIDATES = ['font-sans.ttf', 'font.ttf', 'DejaVuSans-Bold.ttf', 'DejaVuSans.ttf'];
let FONT = 'sans-serif';
for (const name of FONT_CANDIDATES) {
  const candidatePath = path.join(__dirname, '..', 'assets', name);
  if (fs.existsSync(candidatePath)) {
    try {
      GlobalFonts.registerFromPath(candidatePath, 'BJFont');
      FONT = 'BJFont';
    } catch (err) {
      console.error('[Blackjack render] Не удалось зарегистрировать шрифт', candidatePath, err);
    }
    break;
  }
}
if (FONT === 'sans-serif') {
  // Не критично (см. комментарий выше про фолбэк на системный шрифт), но полезно видеть
  // в логах при первом деплое — если кириллица вдруг отрисуется криво, это подсказка, куда
  // положить файл.
  console.log(
    '[Blackjack render] Файл шрифта не найден в assets/ (ожидались: ' +
      FONT_CANDIDATES.join(', ') +
      '), использую системный sans-serif.'
  );
}

const CARD_W = 70;
const CARD_H = 100;
const CARD_R = 8;

const SUIT_COLORS = { '♠': '#1a1a1a', '♣': '#1a1a1a', '♥': '#e53935', '♦': '#e53935' };
const SUIT_SYMBOLS = { spades: '♠', clubs: '♣', hearts: '♥', diamonds: '♦' };

function drawRoundedRect(ctx, x, y, w, h, r) {
  ctx.beginPath();
  ctx.moveTo(x + r, y);
  ctx.lineTo(x + w - r, y);
  ctx.arcTo(x + w, y, x + w, y + r, r);
  ctx.lineTo(x + w, y + h - r);
  ctx.arcTo(x + w, y + h, x + w - r, y + h, r);
  ctx.lineTo(x + r, y + h);
  ctx.arcTo(x, y + h, x, y + h - r, r);
  ctx.lineTo(x, y + r);
  ctx.arcTo(x, y, x + r, y, r);
  ctx.closePath();
}

// Масти нарисованы кривыми Безье вручную (не эмодзи-глиф из шрифта — рендер бота не может
// зависеть от того, есть ли в системе шрифт с цветными emoji, а ч/б символы ♠♥♦♣ есть не
// в каждом шрифте тоже) — сердце/пика/трилистник — по три-четыре bezierCurveTo, ромб —
// просто четыре линии.
function drawSuit(ctx, suit, cx, cy, size) {
  const color = SUIT_COLORS[suit] || '#1a1a1a';
  ctx.fillStyle = color;
  if (suit === '♥') {
    ctx.beginPath();
    ctx.moveTo(cx, cy + size * 0.3);
    ctx.bezierCurveTo(cx, cy - size * 0.1, cx - size * 0.6, cy - size * 0.1, cx - size * 0.6, cy - size * 0.3);
    ctx.bezierCurveTo(cx - size * 0.6, cy - size * 0.6, cx, cy - size * 0.4, cx, cy - size * 0.15);
    ctx.bezierCurveTo(cx, cy - size * 0.4, cx + size * 0.6, cy - size * 0.6, cx + size * 0.6, cy - size * 0.3);
    ctx.bezierCurveTo(cx + size * 0.6, cy - size * 0.1, cx, cy - size * 0.1, cx, cy + size * 0.3);
    ctx.fill();
  } else if (suit === '♦') {
    ctx.beginPath();
    ctx.moveTo(cx, cy - size * 0.5);
    ctx.lineTo(cx + size * 0.4, cy);
    ctx.lineTo(cx, cy + size * 0.5);
    ctx.lineTo(cx - size * 0.4, cy);
    ctx.closePath();
    ctx.fill();
  } else if (suit === '♠') {
    ctx.beginPath();
    ctx.moveTo(cx, cy - size * 0.5);
    ctx.bezierCurveTo(cx, cy - size * 0.5, cx + size * 0.55, cy - size * 0.1, cx + size * 0.55, cy + size * 0.1);
    ctx.bezierCurveTo(cx + size * 0.55, cy + size * 0.35, cx, cy + size * 0.2, cx, cy + size * 0.2);
    ctx.bezierCurveTo(cx, cy + size * 0.2, cx - size * 0.55, cy + size * 0.35, cx - size * 0.55, cy + size * 0.1);
    ctx.bezierCurveTo(cx - size * 0.55, cy - size * 0.1, cx, cy - size * 0.5, cx, cy - size * 0.5);
    ctx.fill();
    ctx.beginPath();
    ctx.moveTo(cx - size * 0.2, cy + size * 0.5);
    ctx.quadraticCurveTo(cx, cy + size * 0.3, cx + size * 0.2, cy + size * 0.5);
    ctx.fill();
  } else if (suit === '♣') {
    const r2 = size * 0.22;
    ctx.beginPath();
    ctx.arc(cx, cy - size * 0.15, r2, 0, Math.PI * 2);
    ctx.fill();
    ctx.beginPath();
    ctx.arc(cx - size * 0.25, cy + size * 0.1, r2, 0, Math.PI * 2);
    ctx.fill();
    ctx.beginPath();
    ctx.arc(cx + size * 0.25, cy + size * 0.1, r2, 0, Math.PI * 2);
    ctx.fill();
    ctx.beginPath();
    ctx.moveTo(cx - size * 0.18, cy + size * 0.5);
    ctx.quadraticCurveTo(cx, cy + size * 0.25, cx + size * 0.18, cy + size * 0.5);
    ctx.fill();
  }
}

function drawCard(ctx, x, y, card) {
  ctx.save();
  ctx.shadowColor = 'rgba(0,0,0,0.3)';
  ctx.shadowBlur = 6;
  ctx.shadowOffsetY = 3;
  drawRoundedRect(ctx, x, y, CARD_W, CARD_H, CARD_R);
  ctx.fillStyle = '#ffffff';
  ctx.fill();
  ctx.strokeStyle = '#cccccc';
  ctx.lineWidth = 1;
  ctx.stroke();
  ctx.restore();

  const color = SUIT_COLORS[card.suit] || '#1a1a1a';
  ctx.fillStyle = color;
  ctx.font = `bold ${card.rank === '10' ? 15 : 17}px "${FONT}"`;
  ctx.textAlign = 'left';
  ctx.fillText(card.rank, x + 6, y + 20);
  drawSuit(ctx, card.suit, x + 12, y + 34, 10);
  drawSuit(ctx, card.suit, x + CARD_W / 2, y + CARD_H / 2 + 5, 20);
}

function drawBackCard(ctx, x, y) {
  ctx.save();
  ctx.shadowColor = 'rgba(0,0,0,0.3)';
  ctx.shadowBlur = 6;
  ctx.shadowOffsetY = 3;
  drawRoundedRect(ctx, x, y, CARD_W, CARD_H, CARD_R);
  ctx.fillStyle = '#1a237e';
  ctx.fill();
  ctx.restore();
  ctx.strokeStyle = 'rgba(255,255,255,0.25)';
  ctx.lineWidth = 1;
  drawRoundedRect(ctx, x + 5, y + 5, CARD_W - 10, CARD_H - 10, 4);
  ctx.stroke();
  ctx.fillStyle = 'rgba(255,255,255,0.15)';
  for (let i = 0; i < 3; i++) {
    for (let j = 0; j < 4; j++) {
      const cx = x + 14 + i * 22;
      const cy = y + 16 + j * 20;
      ctx.beginPath();
      ctx.moveTo(cx, cy - 6);
      ctx.lineTo(cx + 5, cy);
      ctx.lineTo(cx, cy + 6);
      ctx.lineTo(cx - 5, cy);
      ctx.closePath();
      ctx.fill();
    }
  }
}

// Ряд карт по центру, с сужением шага (card fan), если карт много и они не влезают с
// полным зазором — тем самым раздача с 5-6 картами после нескольких "хитов" не уезжает
// за пределы стола, а аккуратно "веером" сжимается по горизонтали.
function drawCardRow(ctx, cards, centerX, y, hideLast) {
  const n = cards.length;
  if (n === 0) return;
  const areaW = 470;
  const maxStep = CARD_W + 16;
  const step = n <= 1 ? 0 : Math.min(maxStep, (areaW - CARD_W) / (n - 1));
  const totalW = CARD_W + step * (n - 1);
  let x = centerX - totalW / 2;
  for (let i = 0; i < n; i++) {
    if (hideLast && i === n - 1) drawBackCard(ctx, x, y);
    else drawCard(ctx, x, y, cards[i]);
    x += step;
  }
}

// Переводит внутреннее представление карты игры (game/blackjack.js: {rank, suit: 'hearts'})
// в формат, который понимает рисовалка выше ({rank, suit: '♥'}).
function toDisplayCards(cards) {
  return cards.map((c) => ({ rank: c.rank, suit: SUIT_SYMBOLS[c.suit] || '♠' }));
}

const OUTCOME_STYLE = {
  win: (s) => ({ status: `✅ Победа! +${calc.formatNumber(s.win)} вирт`, accent: '#66bb6a' }),
  blackjack: (s) => ({ status: `🃏 БЛЭКДЖЕК! +${calc.formatNumber(s.win)} вирт (3:2)`, accent: '#ffd54f' }),
  push: (s) => ({ status: `🤝 Ничья — ставка ${calc.formatNumber(s.bet)} вирт возвращена`, accent: '#e0e0e0' }),
  lose: (s) => ({ status: `❌ Поражение — -${calc.formatNumber(s.bet)} вирт`, accent: '#ef5350' }),
};

// session (фаза "ход игрока"):
//   { phase: 'turn', bet, playerCards, dealerCards, dealerHidden: true, playerTotal, playerName? }
// session (фаза "итог"):
//   { phase: 'finished', bet, win, outcome, playerCards, dealerCards, playerTotal, dealerTotal, playerName? }
async function renderTable(session) {
  const dealer = toDisplayCards(session.dealerCards);
  const player = toDisplayCards(session.playerCards);
  const finished = session.phase === 'finished';
  const dealerHideHole = !finished && !!session.dealerHidden;
  const playerBust = session.playerTotal > 21;

  const dealerText = dealerHideHole ? '' : `очки: ${session.dealerTotal != null ? session.dealerTotal : ''}`;
  const playerText = `очки: ${session.playerTotal}${playerBust ? ' (перебор!)' : ''}`;

  let status = '';
  let accent = '#ffeb3b';
  if (finished) {
    const style = (OUTCOME_STYLE[session.outcome] || OUTCOME_STYLE.lose)(session);
    status = style.status;
    accent = style.accent;
  } else {
    status = '🃏 Ваш ход: хит или стенд';
  }

  const W = 560;
  const H = 430;
  const canvas = createCanvas(W, H);
  const ctx = canvas.getContext('2d');

  // Фон-сукно — тройная рамка (тёмно-зелёный борт → зелёное сукно → тонкий внутренний
  // обвод), тот же приём "корпуса", что и у слотов (game/casinoRender.js), но в
  // зелёно-казино-столовой палитре, а не в золоте игрового автомата — блэкджек это стол,
  // а не автомат.
  ctx.fillStyle = '#0b3d1e';
  drawRoundedRect(ctx, 0, 0, W, H, 20);
  ctx.fill();
  ctx.fillStyle = '#15602f';
  drawRoundedRect(ctx, 14, 14, W - 28, H - 28, 16);
  ctx.fill();
  ctx.strokeStyle = '#0b3d1e';
  ctx.lineWidth = 3;
  drawRoundedRect(ctx, 30, 30, W - 60, H - 60, 12);
  ctx.stroke();

  // Заголовок и ставка
  ctx.fillStyle = 'rgba(255,255,255,0.7)';
  ctx.font = `bold 20px "${FONT}"`;
  ctx.textAlign = 'center';
  ctx.fillText('🃏 Блэкджек', W / 2, 52);
  if (session.bet > 0) {
    ctx.fillStyle = '#fff9c4';
    ctx.font = `bold 14px "${FONT}"`;
    ctx.fillText(`Ставка: ${calc.formatNumber(session.bet)}`, W / 2, 72);
  }

  // Дилер
  ctx.fillStyle = '#c8e6c9';
  ctx.font = `bold 15px "${FONT}"`;
  ctx.textAlign = 'left';
  ctx.fillText(`Дилер${dealerText ? ' — ' + dealerText : ''}`, 40, 96);
  drawCardRow(ctx, dealer, W / 2, 106, dealerHideHole);

  // Игрок
  const py = 250;
  ctx.fillStyle = '#c8e6c9';
  ctx.font = `bold 15px "${FONT}"`;
  ctx.textAlign = 'left';
  const nm = session.playerName ? session.playerName.split(' ')[0] : 'Вы';
  ctx.fillText(`${nm}${playerText ? ' — ' + playerText : ''}`, 40, py - 8);
  drawCardRow(ctx, player, W / 2, py, false);

  // Статус-бар снизу
  if (status) {
    ctx.fillStyle = 'rgba(0,0,0,0.35)';
    drawRoundedRect(ctx, 30, H - 52, W - 60, 34, 8);
    ctx.fill();
    ctx.fillStyle = accent;
    ctx.font = `bold 15px "${FONT}"`;
    ctx.textAlign = 'center';
    ctx.fillText(status, W / 2, H - 30);
  }

  return canvas.toBuffer('image/png');
}

module.exports = { renderTable };
