'use strict';

const C = require('./constants');
const calc = require('./calc');
const players = require('../db/players');

// Жетоны/час с учётом прокачки уровня майнера (0-15, см. MINER_MAX_LEVEL) — каждый уровень
// прибавляет MINER_LEVEL_TOKEN_BONUS_PER_LEVEL (сейчас 8.22%) к базовой ставке
// MINER_HOURLY_TOKENS. На максимуме (15 ур.) это 150 * (1 + 0.0822*15) ≈ 335 жетонов/час.
// Вирты с майнера прокачкой НЕ затрагиваются, остаются фиксированными.
function tokensForLevel(level) {
  const lvl = Math.max(0, Math.min(level || 0, C.MINER_MAX_LEVEL));
  return Math.round(C.MINER_HOURLY_TOKENS * (1 + C.MINER_LEVEL_TOKEN_BONUS_PER_LEVEL * lvl));
}

// Вызывается раз в час общим планировщиком (см. game/scheduler.js). Начисляет всем игрокам
// с активным майнером фиксированную сумму вирт и жетонов каждый час — гарантированно, без шанса.
// Работает молча (без личных уведомлений каждый час) — статус можно проверить командой "майнер".
async function hourlyMinerTick() {
  const all = await players.getAllActivePlayers();

  for (const player of all) {
    if (!calc.isMinerActive(player)) continue;

    const virts = calc.randomInt(C.MINER_HOURLY_VIRTS_MIN, C.MINER_HOURLY_VIRTS_MAX);
    await players.updateBalance(player.vk_id, virts);
    await players.addTokens(player.vk_id, tokensForLevel(player.miner_level));
  }
}

// ===================== ПРОКАЧКА МАЙНЕРА (донат, за рубли, см. !админ майнерур) =====================

async function setLevel(vkId, level) {
  const player = await players.getPlayer(vkId);
  if (!player) return { ok: false, reason: 'not_registered' };
  if (!calc.isMinerActive(player)) return { ok: false, reason: 'miner_required' };

  const clamped = Math.max(0, Math.min(level, C.MINER_MAX_LEVEL));
  await players.setMinerLevel(vkId, clamped);
  return { ok: true, level: clamped };
}

async function adjustLevel(vkId, delta) {
  const player = await players.getPlayer(vkId);
  if (!player) return { ok: false, reason: 'not_registered' };
  if (!calc.isMinerActive(player)) return { ok: false, reason: 'miner_required' };

  const clamped = Math.max(0, Math.min((player.miner_level || 0) + delta, C.MINER_MAX_LEVEL));
  await players.setMinerLevel(vkId, clamped);
  return { ok: true, level: clamped };
}

module.exports = { hourlyMinerTick, tokensForLevel, setLevel, adjustLevel };
