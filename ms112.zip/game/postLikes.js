'use strict';

const { VK } = require('vk-io');
const postLikesDb = require('../db/postLikes');
const shopDb = require('../db/shop');
const C = require('./constants');
const { withLock } = require('./asyncLock');

// Лок, которым сериализуем "!админ лайки выкл/вкл" и фоновый cron-тик syncAndRecompute
// между собой (см. пояснение у setSystemEnabled/syncAndRecompute ниже) — без него возможна
// гонка: тик уже прошёл проверку isSystemEnabled()===true и продолжает висеть на запросах
// к VK API, админ в этот момент выключает систему и чистит штрафы, а тик после этого
// доходит до recomputePenalties и снова проставляет штраф — который потом уже никто не
// снимет, т.к. следующие тики видят enabled=false и сразу выходят.
const POST_LIKE_LOCK_KEY = 'post-likes-sync';

// Вкл/выкл всей системы штрафа за нелайкнутые посты + окно (интервал), за какой период
// назад учитывать посты — настраивается админом на лету через "!админ лайки" (см.
// handlers/adminHandlers.js) и хранится в общей key-value таблице meta (db/shop.js:
// getMeta/setMeta — тот же приём, что и у game/globalBoost.js), чтобы значение переживало
// перезапуск процесса и было общим для всех воркеров.
const POST_LIKE_ENABLED_META_KEY = 'post_like_system_enabled';
const POST_LIKE_WINDOW_META_KEY = 'post_like_window_ms';

// Пресеты интервала — "за какой период считать посты для штрафа" (не путать с грейс-периодом
// C.POST_LIKE_GRACE_PERIOD_MS — тем, сколько времени даётся на лайк ПОСЛЕ публикации).
// null у 'all' означает "без ограничения по времени — все посты сообщества".
const HOUR_MS = 60 * 60 * 1000;
const DAY_MS = 24 * HOUR_MS;
const POST_LIKE_WINDOW_PRESETS = {
  '5ч': 5 * HOUR_MS,
  день: 1 * DAY_MS,
  '3дня': 3 * DAY_MS,
  '5дней': 5 * DAY_MS,
  '30дней': 30 * DAY_MS,
  '60дней': 60 * DAY_MS,
  все: null,
};

async function isSystemEnabled() {
  const raw = await shopDb.getMeta(POST_LIKE_ENABLED_META_KEY);
  // По умолчанию (пока админ не выключил явно) система включена — сохраняем прежнее поведение.
  return raw === null || raw === undefined ? true : raw === '1';
}

async function setSystemEnabled(enabled) {
  // Тот же лок, что и у syncAndRecompute — гарантирует, что переключение и фоновый тик не
  // выполняются "вперемешку" (см. комментарий у POST_LIKE_LOCK_KEY выше). Иначе уже
  // запущенный тик может пересчитать и заново проставить штраф ПОСЛЕ того, как мы его
  // здесь сняли — и тот так и останется висеть, потому что следующие тики уже пропустят
  // пересчёт из-за enabled=false.
  return withLock(POST_LIKE_LOCK_KEY, async () => {
    await shopDb.setMeta(POST_LIKE_ENABLED_META_KEY, enabled ? '1' : '0');
    if (!enabled) {
      // При выключении сразу снимаем штраф со всех игроков, чтобы не "зависал" до следующего тика.
      await postLikesDb.clearAllPenalties();
    }
    return enabled;
  });
}

async function getWindowMs() {
  const raw = await shopDb.getMeta(POST_LIKE_WINDOW_META_KEY);
  if (raw === null || raw === undefined || raw === '') return null; // по умолчанию — без ограничения
  const parsed = Number(raw);
  return Number.isFinite(parsed) && parsed > 0 ? parsed : null;
}

async function setWindowPreset(presetKey) {
  if (!Object.prototype.hasOwnProperty.call(POST_LIKE_WINDOW_PRESETS, presetKey)) return null;
  const ms = POST_LIKE_WINDOW_PRESETS[presetKey];
  await shopDb.setMeta(POST_LIKE_WINDOW_META_KEY, ms === null ? '' : String(ms));
  return ms;
}

// ВАЖНО про ошибку "Code №27 — Group authorization failed: method is unavailable with
// group auth": это не про недостающий чекбокс прав у токена сообщества, а про
// фундаментальное ограничение VK API — токен СООБЩЕСТВА (community/group token) вообще
// поддерживает только ограниченный список разделов API (messages, wall, photos, docs,
// manage, stories и т.п.). "likes" в этот список не входит никогда, ни при каких правах —
// поэтому likes.getList в принципе не вызвать с групповым токеном, только с обычным
// пользовательским. wall.get формально в списке есть, но у токена в .env, судя по логу,
// не включено право "Стена" при создании ключа в настройках сообщества.
//
// Поэтому для wall.get/likes.getList используем ОТДЕЛЬНЫЙ клиент на пользовательском
// токене (VK_USER_TOKEN в .env — токен обычного аккаунта, состоящего в сообществе, с
// правами wall,offline), а токен сообщества (VK_TOKEN) оставляем только для отправки
// сообщений ботом. Если VK_USER_TOKEN не задан — пробуем токен сообщества как раньше
// (для wall.get это может сработать, если у него включено право "Стена"; для
// likes.getList не сработает никогда — см. пояснение выше), но громко предупреждаем в
// логе один раз, чтобы это не терялось среди повторяющихся ошибок каждую минуту.
let userVkClient = null;
let warnedNoUserToken = false;

function getWallApiClient(bot) {
  if (process.env.VK_USER_TOKEN) {
    if (!userVkClient) {
      userVkClient = new VK({ token: process.env.VK_USER_TOKEN });
    }
    return userVkClient;
  }
  if (!warnedNoUserToken) {
    warnedNoUserToken = true;
    console.error(
      '[PostLikes] Не задан VK_USER_TOKEN в .env — используется токен сообщества для wall.get/likes.getList. ' +
        'likes.getList с токеном сообщества гарантированно не работает (VK API не поддерживает раздел "likes" ' +
        'для групповых токенов, см. комментарий в game/postLikes.js) — штраф за нелайкнутые посты работать не будет, ' +
        'пока не добавите VK_USER_TOKEN (токен обычного аккаунта с правами wall,offline).'
    );
  }
  return bot.vk;
}

// owner_id для VK-методов — отрицательный ID сообщества. Берём из VK_GROUP_ID (.env), а не
// вычисляем откуда-то ещё, т.к. это единственное официальное сообщество, посты которого
// нужно лайкать (см. README: "Данные для подключения уже прописаны в .env").
function getGroupOwnerId() {
  const raw = process.env.VK_GROUP_ID;
  const groupId = Number(raw);
  if (!raw || !groupId || Number.isNaN(groupId)) return null;
  return -Math.abs(groupId);
}

// Подтягивает последние посты со стены сообщества (filter: 'owner' — только официальные
// посты от лица самого сообщества, а не чужие записи, если у группы включена открытая стена)
// и заносит новые в отслеживание. Работает независимо от события wall_post_new — так надёжнее:
// не зависит от того, включена ли галочка в настройках Long Poll и дошёл ли конкретный апдейт.
async function syncPosts(vk, ownerId) {
  const res = await vk.api.wall.get({
    owner_id: ownerId,
    count: 30,
    filter: 'owner',
  });
  const items = (res && res.items) || [];
  const posts = items
    .filter((post) => post && post.id && post.date)
    .map((post) => ({
      postId: post.id,
      publishedAt: new Date(post.date * 1000).toISOString(),
    }));
  await postLikesDb.upsertPosts(ownerId, posts);
}

// Опрашивает likes.getList для постов, которых ещё не все активные игроки лайкнули, и
// записывает актуальный список лайкнувших (постранично — VK отдаёт максимум 1000 за раз).
// Как только по посту лайкнули все активные игроки, getPendingPosts перестаёт его отдавать —
// повторных запросов к VK по "закрытым" постам больше не будет.
async function syncLikes(vk, ownerId) {
  const pending = await postLikesDb.getPendingPosts(
    ownerId,
    C.POST_LIKE_GRACE_PERIOD_MS,
    C.POST_LIKE_MAX_POSTS_PER_SYNC
  );

  for (const post of pending) {
    const likerIds = [];
    let offset = 0;
    const pageSize = 1000;
    for (;;) {
      const res = await vk.api.likes.getList({
        type: 'post',
        owner_id: ownerId,
        item_id: post.post_id,
        count: pageSize,
        offset,
      });
      // Разные версии VK API отдают список то в items, то в users — проверяем оба.
      const users = (res && res.items) || (res && res.users) || [];
      likerIds.push(...users);
      if (users.length < pageSize) break;
      offset += pageSize;
      if (offset > 50000) break; // защитный предел от бесконечного цикла
    }
    if (likerIds.length) {
      await postLikesDb.bulkInsertLikes(ownerId, post.post_id, likerIds);
    }
  }
}

// Полный цикл: подтягиваем новые посты → опрашиваем лайки по "хвостам" → пересчитываем
// штрафной флаг у всех активных игроков. Каждый шаг обёрнут в свой try/catch: сбой VK API на
// одном шаге (например, временная 502-ошибка при wall.get) не должен ронять весь цикл и
// мешать пересчитать штраф по уже накопленным данным.
async function syncAndRecompute(bot) {
  const ownerId = getGroupOwnerId();
  if (!ownerId) {
    console.error('[PostLikes] Не задан VK_GROUP_ID в .env — штраф за нелайкнутые посты выключен.');
    return;
  }
  if (!bot || !bot.vk) return;

  // Тот же лок, что и у setSystemEnabled — не даёт тику и переключению "вкл/выкл" выполняться
  // одновременно (см. POST_LIKE_LOCK_KEY). Сама проверка isSystemEnabled() тоже сделана ВНУТРИ
  // лока и повторена ещё раз прямо перед recomputePenalties — на случай, если систему выключили
  // (и сняли штраф) пока этот же тик ждал в очереди на лок; без повторной проверки тик мог бы
  // выполниться следующим и заново проставить штраф, который потом уже никто не снимет.
  await withLock(POST_LIKE_LOCK_KEY, async () => {
    const enabled = await isSystemEnabled();
    if (!enabled) return;

    const vk = getWallApiClient(bot);

    try {
      await syncPosts(vk, ownerId);
    } catch (err) {
      console.error('[PostLikes] Не удалось опросить wall.get:', err.message);
    }

    try {
      await syncLikes(vk, ownerId);
    } catch (err) {
      console.error('[PostLikes] Не удалось опросить likes.getList:', err.message);
    }

    // Повторная проверка — систему могли выключить, пока мы висели на syncPosts/syncLikes
    // (это запросы к внешнему VK API, могут идти секунды). Без этой проверки ниже мы бы
    // снова проставили штраф уже после того, как админ его снял.
    const stillEnabled = await isSystemEnabled();
    if (!stillEnabled) return;

    try {
      const windowMs = await getWindowMs();
      await postLikesDb.recomputePenalties(ownerId, C.POST_LIKE_GRACE_PERIOD_MS, windowMs);
    } catch (err) {
      console.error('[PostLikes] Не удалось пересчитать штрафы за лайки:', err.message);
    }
  });
}

// Для команды "!лайки" — список непролайканных игроком постов с прямыми ссылками на них.
async function getUnlikedPostsForPlayer(vkId) {
  const ownerId = getGroupOwnerId();
  if (!ownerId) return [];
  const enabled = await isSystemEnabled();
  if (!enabled) return [];
  const windowMs = await getWindowMs();
  const rows = await postLikesDb.getUnlikedPostsForPlayer(ownerId, vkId, C.POST_LIKE_GRACE_PERIOD_MS, windowMs);
  const groupId = Math.abs(ownerId);
  return rows.map((row) => ({
    postId: row.post_id,
    publishedAt: row.published_at,
    url: `https://vk.com/wall-${groupId}_${row.post_id}`,
  }));
}

module.exports = {
  getGroupOwnerId,
  getWallApiClient,
  syncAndRecompute,
  getUnlikedPostsForPlayer,
  isSystemEnabled,
  setSystemEnabled,
  getWindowMs,
  setWindowPreset,
  POST_LIKE_WINDOW_PRESETS,
};
