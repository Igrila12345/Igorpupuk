'use strict';

// ===================== ОБЩАЯ ПАЛИТРА ДЛЯ ГИФКИ (устранение главного тормоза рендера) =====================
// gifencoder@2.0.1 (game/casinoRender.js) на каждый encoder.addFrame() заново вызывает
// analyzePixels(), который создаёт НОВУЮ NeuQuant-сеть и честно обучает её (100 циклов
// обучения, см. node_modules/gifencoder/lib/TypedNeuQuant.js: ncycles=100) на пикселях
// именно этого кадра — а затем результат тут же выбрасывается на следующем кадре. Один
// спин слотов — это ~75 кадров (CASINO_SPIN_MS / FRAME_DELAY_MS), т.е. полное обучение
// нейросети прогонялось 75 раз подряд на картинке ~600x360px. Именно это — а не рисование
// самих кадров через Jimp — было основным источником тормозов ("бот зависает на 3-4
// минуты после игр"): рендер казино и блэкджека делит один пул воркеров (game/renderPool.js)
// с другими мини-играми, и когда несколько игроков подряд крутят слоты, тяжёлые спины
// выстраиваются в очередь и упираются в TASK_TIMEOUT_MS.
//
// Фон и вся "рамка автомата" идентичны на КАЖДОМ кадре одного спина (см. buildStaticTemplate
// в casinoRender.js) — то есть NeuQuant каждый раз переобучался практически на одних и тех же
// цветах. Решение: обучаем сеть ОДИН раз на паре синтетических "калибровочных" кадров,
// которые специально содержат все цвета, что могут встретиться в реальной анимации (фон,
// все 6 иконок символов, золотую/зелёную подсветку выигрыша, конфетти), и переиспользуем
// эту одну обученную сеть для всех кадров конкретного спина через lookupRGB (быстрый поиск
// ближайшего цвета в уже готовой палитре — без переобучения). Внешний вид кадров не
// меняется: это тот же алгоритм квантования (NeuQuant), просто обученный один раз вместо 75.
//
// ВАЖНО: используются приватные внутренности пакета gifencoder (require('gifencoder/lib/...'),
// GIFEncoder.prototype.getImagePixels/writeLSD/writePalette/writeGraphicCtrlExt/writeImageDesc/
// writePixels) — в package.json версия закреплена БЕЗ "^" (см. package.json), чтобы случайное
// minor-обновление не сломало эти внутренние поля тихой ошибкой.
const NeuQuant = require('gifencoder/lib/TypedNeuQuant.js');

// Обучает одну NeuQuant-сеть на пикселях калибровочных кадров (см. buildCalibrationFrames
// в casinoRender.js) и возвращает уже готовый объект с lookupRGB(r,g,b) и колормапом.
// sample=1 — самое точное (и самое медленное) качество квантования, но здесь это не имеет
// значения: обучение идёт РОВНО ОДИН РАЗ за весь спин, а не 75 раз, так что можем позволить
// себе точность выше, чем была у отдельных кадров раньше (там ради скорости стояло sample=12).
function buildSharedQuantizer(calibrationFrames, sample) {
  let totalPixels = 0;
  const rgbBuffers = calibrationFrames.map((frame) => {
    const rgba = frame.bitmap.data;
    const nPix = rgba.length / 4;
    const rgb = new Uint8Array(nPix * 3);
    let k = 0;
    for (let i = 0; i < rgba.length; i += 4) {
      rgb[k++] = rgba[i];
      rgb[k++] = rgba[i + 1];
      rgb[k++] = rgba[i + 2];
    }
    totalPixels += nPix;
    return rgb;
  });

  const merged = new Uint8Array(totalPixels * 3);
  let offset = 0;
  for (const buf of rgbBuffers) {
    merged.set(buf, offset);
    offset += buf.length;
  }

  const imgq = new NeuQuant(merged, sample || 1);
  imgq.buildColormap();
  return imgq;
}

// imgq.lookupRGB() (NeuQuant inxsearch) не бесплатен — ходит по отсортированной сети из
// (до) 256 нейронов на КАЖДЫЙ пиксель. Наши кадры почти целиком состоят из повторяющихся
// точных цветов: фон — вертикальный градиент, где ВСЯ строка одного y — один и тот же
// цвет (см. renderUtils.js: buildBackground), плюс десяток-другой плоских цветов иконок/
// рамок — т.е. реально на кадр ~600x360px приходится лишь несколько сотен РАЗНЫХ точных
// RGB-значений, повторяющихся многие тысячи раз. Кешируем результат lookupRGB по точному
// (r,g,b) — точно так же, как symbolIconCache в этом файле кеширует готовые иконки:
// без потери точности (это просто мемоизация чистой функции), но с кардинально меньшим
// числом реальных обращений к NeuQuant. Кеш живёт на весь спин (общий для всех 75 кадров),
// поэтому эффект накапливается от кадра к кадру.
function makeCachedLookup(imgq) {
  const cache = new Map();
  return function lookup(r, g, b) {
    const key = (r << 16) | (g << 8) | b;
    let idx = cache.get(key);
    if (idx === undefined) {
      idx = imgq.lookupRGB(r, g, b);
      cache.set(key, idx);
    }
    return idx;
  };
}

// Кодирует один кадр в encoder, используя УЖЕ обученную сеть imgq (через кешированный
// lookup, см. makeCachedLookup выше) вместо encoder.analyzePixels() (который заново
// обучил бы сеть с нуля — см. комментарий выше). Повторяет один в один остальную часть
// GIFEncoder.prototype.addFrame из node_modules/gifencoder/lib/GIFEncoder.js — меняется
// только способ получения палитры и индексов пикселей, порядок записи GIF-блоков
// (LSD/палитра/graphic control/image descriptor/пиксели) не тронут, поэтому итоговый
// файл читается любым GIF-декодером так же, как и раньше.
//
// В отличие от штатного analyzePixels (который сначала вызывает getImagePixels(), чтобы
// сложить RGB без альфы в отдельный буфер, а ПОТОМ читает его обратно в цикле поиска по
// палитре), тут оба прохода слиты в один — читаем r/g/b сразу из исходного RGBA-буфера
// Jimp-кадра, без промежуточного выделения и повторного чтения массива.
function addFrameWithSharedPalette(encoder, lookup, colorTab, frameBuffer) {
  const nPix = encoder.width * encoder.height;
  const indexedPixels = new Uint8Array(nPix);
  let si = 0; // индекс в исходном RGBA-буфере
  for (let j = 0; j < nPix; j++) {
    indexedPixels[j] = lookup(frameBuffer[si], frameBuffer[si + 1], frameBuffer[si + 2]);
    si += 4;
  }

  encoder.indexedPixels = indexedPixels;
  encoder.colorTab = colorTab;
  encoder.colorDepth = 8;
  encoder.palSize = 7;

  if (encoder.firstFrame) {
    encoder.writeLSD(); // logical screen descriptor
    encoder.writePalette(); // общая (глобальная) палитра
    if (encoder.repeat >= 0) encoder.writeNetscapeExt();
  }
  encoder.writeGraphicCtrlExt();
  encoder.writeImageDesc();
  // Как и в оригинальном addFrame, для не-первого кадра пишем ту же палитру ещё раз как
  // "локальную" — не меняем эту часть формата, чтобы не рисковать совместимостью с
  // существующими декодерами; раньше здесь была РАЗНАЯ обученная с нуля палитра на каждый
  // кадр, теперь везде одна и та же, так что цвета между кадрами стали ещё и стабильнее.
  if (!encoder.firstFrame) encoder.writePalette();
  encoder.writePixels();
  encoder.firstFrame = false;
  encoder.emit();
}

module.exports = { buildSharedQuantizer, makeCachedLookup, addFrameWithSharedPalette };
