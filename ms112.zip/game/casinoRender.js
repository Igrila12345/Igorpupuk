'use strict';

const Jimp = require('jimp');
const GIFEncoder = require('gifencoder');
const C = require('./constants');
const R = require('./renderUtils');
const calc = require('./calc');
const gifPalette = require('./gifPalette');

// ===================== АНИМАЦИЯ (гифка вместо статичной картинки) =====================
// Раньше renderSpin рисовал один статичный кадр с уже готовым результатом — по факту
// это была просто цифра без ощущения "казино". Теперь рендерим полноценную гифку:
// барабаны крутятся вразнобой и останавливаются один за другим слева направо (как в
// настоящих слотах), а итог показывается только на последних кадрах.
//
// Длительность гифки намеренно равна C.CASINO_SPIN_MS — game/casino.js держит игрока
// "занятым" (нельзя запустить вторую партию) ровно на этот же срок, синхронно с тем,
// сколько реально крутится анимация на экране.
const FRAME_DELAY_MS = 80; // ~12.5 кадра/сек — достаточно для ощущения вращения, гифка не разрастается
const LAST_FRAME_HOLD_MS = 1800; // последний кадр с итогом держим дольше остальных, чтобы результат успел прочитаться
// Моменты (в долях от общей длительности), когда останавливается каждый барабан —
// левый первым, правый последним, как в классических слотах.
const REEL_LOCK_FRACTIONS = [0.35, 0.6, 0.82];

// Символы рисуются простыми геометрическими фигурами (не эмодзи!) — растровый шрифт
// проекта (assets/fonts) содержит только латиницу/кириллицу и отфильтрованный набор
// символов, цветные эмодзи-глифы (🍒🍋🔔⭐💎7️⃣) он не отрисует (см. renderUtils.js:
// sanitizeText). Тот же приём, что и с иконкой завода в workRender.js — просто кружок/
// фигура нужного цвета вместо картинки.
const REEL_W = 170;
const REEL_H = 170;
const REEL_GAP = 24;
const MARGIN_SIDE = 30;
const CABINET_BORDER = 10; // золотая "рамка автомата" вокруг всей игровой зоны
const MARQUEE_HEIGHT = 14; // полоса лампочек под заголовком
const HEADER_HEIGHT = 74;
const PADDING_TOP = 20; // отступ между лампочками и барабанами
const FOOTER_HEIGHT = 80; // +12px запаса от базового текста до нижнего края — там рисуется золотая рамка корпуса (CABINET_BORDER)
const BORDER = 3;
const CORNER_RADIUS = 16;
const SYMBOL_SIZE = 96;

const MARGIN_TOP = HEADER_HEIGHT + MARQUEE_HEIGHT + PADDING_TOP;

const GOLD = 0xffc94dff;
const GOLD_DIM = 0x5a4a1fff;
const SPARKLE_COLORS = [0xffe082ff, 0xfff59dff, 0xffffffff, 0x4fc3f7ff];

const symbolIconCache = new Map();

// Рисует символ как фигуру size x size с прозрачным фоном (кешируется по ключу символа —
// фигур всего 6, дешевле нарисовать один раз и переиспользовать, как factoryIcon в
// workRender.js). Каждая фигура теперь получает тонкий контрастный ободок и небольшой
// "блик" в углу — раньше иконки были совсем плоскими одноцветными пятнами, с ободком и
// бликом они выглядят как настоящие лакированные фишки/жетоны, а не просто заливка.
function buildSymbolIcon(sym, size) {
  const icon = new Jimp(size, size, 0x00000000);
  const cx = size / 2;
  const cy = size / 2;
  const outline = darken(sym.color, 0.45);

  switch (sym.key) {
    case 'cherry': {
      // два кружка рядом — стилизованная "вишня", плюс тонкий "стебелёк" сверху
      const r = size * 0.22;
      R.drawRect(icon, cx - size * 0.03, cy - r * 1.9, size * 0.06, r * 1.1, darken(sym.color, 0.25));
      R.drawCircle(icon, cx - r * 0.9, cy + r * 0.5, r, outline);
      R.drawCircle(icon, cx + r * 0.9, cy + r * 0.5, r, outline);
      R.drawCircle(icon, cx - r * 0.9, cy + r * 0.5, r * 0.82, sym.color);
      R.drawCircle(icon, cx + r * 0.9, cy + r * 0.5, r * 0.82, sym.color);
      break;
    }
    case 'lemon': {
      R.drawEllipse(icon, cx, cy, size * 0.34, size * 0.24, outline);
      R.drawEllipse(icon, cx, cy, size * 0.29, size * 0.2, sym.color);
      break;
    }
    case 'bell': {
      R.drawCircle(icon, cx, cy - size * 0.05, size * 0.32, outline);
      R.drawRect(icon, cx - size * 0.22, cy + size * 0.18, size * 0.44, size * 0.1, outline);
      R.drawCircle(icon, cx, cy - size * 0.05, size * 0.27, sym.color);
      R.drawRect(icon, cx - size * 0.19, cy + size * 0.2, size * 0.38, size * 0.07, sym.color);
      R.drawCircle(icon, cx, cy + size * 0.32, size * 0.045, outline);
      break;
    }
    case 'star': {
      R.drawStar(icon, cx, cy, size * 0.4, size * 0.17, outline);
      R.drawStar(icon, cx, cy, size * 0.34, size * 0.14, sym.color);
      break;
    }
    case 'diamond': {
      R.drawDiamond(icon, cx, cy, size * 0.36, outline);
      R.drawDiamond(icon, cx, cy, size * 0.3, sym.color);
      R.drawDiamond(icon, cx - size * 0.06, cy - size * 0.08, size * 0.09, 0xffffffaa);
      break;
    }
    case 'seven': {
      R.drawRect(icon, cx - size * 0.3, cy - size * 0.34, size * 0.6, size * 0.14, outline);
      R.drawRect(icon, cx + size * 0.02, cy - size * 0.34, size * 0.16, size * 0.68, outline);
      R.drawRect(icon, cx - size * 0.27, cy - size * 0.31, size * 0.54, size * 0.08, sym.color);
      R.drawRect(icon, cx + 0.05 * size, cy - size * 0.31, size * 0.1, size * 0.62, sym.color);
      break;
    }
    default:
      R.drawCircle(icon, cx, cy, size * 0.3, sym.color);
  }
  return icon;
}

// Затемняет ARGB-цвет (0xRRGGBBAA) на factor (0..1) — используется, чтобы получить
// контрастный ободок того же тона, что и заливка фигуры, вместо произвольного чёрного.
function darken(colorArgb, factor) {
  const rgba = Jimp.intToRGBA(colorArgb);
  const r = Math.round(rgba.r * (1 - factor));
  const g = Math.round(rgba.g * (1 - factor));
  const b = Math.round(rgba.b * (1 - factor));
  return Jimp.rgbaToInt(r, g, b, rgba.a);
}

function getSymbolIcon(sym) {
  if (!symbolIconCache.has(sym.key)) {
    symbolIconCache.set(sym.key, buildSymbolIcon(sym, SYMBOL_SIZE));
  }
  return symbolIconCache.get(sym.key);
}

// Случайный символ для "вращающихся" (ещё не остановленных) барабанов — визуальный шум,
// никак не связанный с реальными весами исхода (тот уже посчитан в game/casino.js
// ДО рендера; рисуем только то, что игрок увидит на экране).
function randomSpinningSymbol() {
  const list = C.CASINO_SLOT_SYMBOLS;
  return list[Math.floor(Math.random() * list.length)];
}

// Заголовок и золотая рамка корпуса одинаковы на ВСЕХ кадрах анимации (не зависят ни от
// frameIndex, ни от session) — раньше они перерисовывались заново на каждом из ~75 кадров
// (текст шрифтом + 2 прямоугольные обводки), хотя результат пиксель-в-пиксель идентичен.
// Рисуем их один раз в отдельный шаблон (см. renderSpin), а каждый кадр клонирует уже
// готовый шаблон — итоговая картинка не меняется, экономится лишняя отрисовка ×74 раза.
// Рамка по-прежнему логически "поверх" содержимого (см. комментарий у border ниже) —
// порядок сохранён тем, что шаблон уже содержит и header, и border ДО того, как поверх
// него в цикле рисуются барабаны/футер/лампочки, которые в рамку и так не заходят.
function buildStaticTemplate(background, width, height, fontTitle) {
  const template = background.clone();
  R.drawHeader(template, width, HEADER_HEIGHT, '🎰 КАЗИНО — СЛОТЫ', fontTitle);

  // "Корпус автомата" — золотая рамка по периметру. Раньше рисовалась последней в
  // drawFrame (после header), чтобы перекрыть его возможный залив на кромку — здесь
  // header уже нарисован строкой выше, так что порядок и результат те же.
  R.drawFrame(template, 0, 0, width, height, CABINET_BORDER, GOLD);
  R.drawFrame(
    template,
    CABINET_BORDER - 2,
    CABINET_BORDER - 2,
    width - (CABINET_BORDER - 2) * 2,
    height - (CABINET_BORDER - 2) * 2,
    2,
    GOLD_DIM
  );
  return template;
}

// Небольшой запас по краям под "хвост" тени карточки (drawCardWithShadow рисует тень со
// смещением +6/+8 от основной заливки — см. renderUtils.js), чтобы эта тень не обрезалась
// на кешируемом холсте ниже.
const NORMAL_CELL_PAD_X = 8;
const NORMAL_CELL_PAD_Y = 10;

// Ячейка барабана в "обычном" (не выигрышном) состоянии — тень + заливка + рамка — не
// зависит НИ от конкретного барабана, ни от кадра анимации: цвет один и тот же
// (R.PALETTE.cell/cellBorder) что во время кручения, что на кадрах проигрыша. Раньше это
// рисовалось заново (drawCardWithShadow + drawFrame — 6 отдельных composite-вызовов)
// на КАЖДОМ из ~75 кадров × 3 барабана. Собираем один раз в отдельный прозрачный холст
// и дальше просто композитим готовый результат — итоговые пиксели идентичны (порядок
// alpha-компоузинга тот же, просто "предпосчитан" заранее), поэтому внешний вид кадров
// не меняется. Выигрышная (зелёная) подсветка сюда сознательно не входит — она рисуется
// по-старому "вживую" на каждом кадре, т.к. включает сияние (drawGlow), которое считывает
// уже нарисованные соседние пиксели самого кадра и потому не кешируется так же просто —
// но выигрышных кадров на порядок меньше (только последние кадры выигрышного спина), так
// что это не влияет на общую скорость.
let normalReelCellCache = null;
function getNormalReelCell() {
  if (normalReelCellCache) return normalReelCellCache;
  const canvas = new Jimp(REEL_W + NORMAL_CELL_PAD_X, REEL_H + NORMAL_CELL_PAD_Y, 0x00000000);
  R.drawCardWithShadow(canvas, 0, 0, REEL_W, REEL_H, R.PALETTE.cell, CORNER_RADIUS);
  R.drawFrame(canvas, 0, 0, REEL_W, REEL_H, BORDER, R.PALETTE.cellBorder);
  normalReelCellCache = canvas;
  return canvas;
}

// Рисует ДИНАМИЧЕСКУЮ часть одного кадра поверх уже готового шаблона (header+border,
// см. buildStaticTemplate) — барабаны, лампочки, футер. template уже склонирован
// вызывающим кодом — здесь можно мутировать его напрямую.
function drawFrame(frame, width, height, fontLabel, reelSymbols, revealing, session, frameIndex) {
  // Гирлянда лампочек под заголовком — "бегущие огни", смещаются на каждом кадре.
  R.drawMarqueeLights(frame, MARGIN_SIDE, HEADER_HEIGHT + MARQUEE_HEIGHT / 2, width - MARGIN_SIDE * 2, 18, GOLD, GOLD_DIM, frameIndex);

  for (let i = 0; i < 3; i++) {
    const x = MARGIN_SIDE + i * (REEL_W + REEL_GAP);
    const y = MARGIN_TOP;
    // Подсвечиваем зелёным только когда все барабаны уже остановлены (revealing) и есть
    // выигрыш — до этого момента цвет ячеек нейтральный, даже если конкретный барабан
    // уже "встал" на свой финальный символ (чтобы не спойлерить исход раньше времени).
    // Выигрыш теперь только при полном совпадении всех трёх (game/casino.js:
    // resolveOutcome), так что тут либо все 3 ячейки зелёные, либо ни одной — частичного
    // выигрыша/подсветки 2 из 3 больше не бывает.
    const isWinningReel = revealing && session.matchType === 'three';

    if (isWinningReel) {
      const cellColor = 0x2c3a2eff;
      const borderColor = 0x66bb6aff;
      // Мягкое золотое сияние позади ячейки — победный момент теперь виден не только по
      // смене цвета рамки, но и по "подсветке" вокруг символа.
      R.drawGlow(frame, x + REEL_W / 2, y + REEL_H / 2, REEL_W * 0.72, { r: 255, g: 215, b: 90 });
      R.drawCardWithShadow(frame, x, y, REEL_W, REEL_H, cellColor, CORNER_RADIUS);
      R.drawFrame(frame, x, y, REEL_W, REEL_H, BORDER, borderColor);
      // Второй, более тонкий золотой контур поверх зелёной рамки — делает ячейку заметно
      // "наряднее", чем просто перекраска в один цвет.
      R.drawFrame(frame, x - 2, y - 2, REEL_W + 4, REEL_H + 4, 2, GOLD);
    } else {
      // Обычное состояние — берём готовую закешированную ячейку (см. getNormalReelCell)
      // вместо того, чтобы каждый раз заново рисовать тень+заливку+рамку.
      frame.composite(getNormalReelCell(), x, y);
    }

    const icon = getSymbolIcon(reelSymbols[i]);
    const ix = x + Math.round((REEL_W - SYMBOL_SIZE) / 2);
    const iy = y + Math.round((REEL_H - SYMBOL_SIZE) / 2);
    frame.composite(icon, ix, iy);
  }

  const footerY = MARGIN_TOP + REEL_H + 12;
  if (revealing) {
    if (session.win > 0) {
      // На финальном (удержанном дольше) кадре добавляем конфетти-искры над всей игровой
      // зоной — раньше выигрыш ощущался только текстом, теперь картинка тоже "празднует".
      R.drawSparkles(frame, MARGIN_SIDE, MARGIN_TOP - 10, width - MARGIN_SIDE * 2, REEL_H + 20, 14, SPARKLE_COLORS);
    }
    const resultLine =
      session.win > 0
        ? `✅ Выигрыш: +${calc.formatNumber(session.win)} вирт (ставка ${calc.formatNumber(session.bet)})`
        : `❌ Проигрыш: -${calc.formatNumber(session.bet)} вирт`;
    R.printBoxed(frame, fontLabel, MARGIN_SIDE, footerY, width - MARGIN_SIDE * 2, 28, resultLine, Jimp.HORIZONTAL_ALIGN_CENTER);
    R.printBoxed(
      frame,
      fontLabel,
      MARGIN_SIDE,
      footerY + 28,
      width - MARGIN_SIDE * 2,
      24,
      `Баланс: ${calc.formatNumber(session.balance)} вирт`,
      Jimp.HORIZONTAL_ALIGN_CENTER
    );
  } else {
    R.printBoxed(
      frame,
      fontLabel,
      MARGIN_SIDE,
      footerY,
      width - MARGIN_SIDE * 2,
      28,
      '🎰 Крутим барабаны…',
      Jimp.HORIZONTAL_ALIGN_CENTER
    );
  }
}

// Строит 2 синтетических кадра, которые НИКОГДА не показываются игроку — они существуют
// только затем, чтобы обучить на них одну общую GIF-палитру (см. game/gifPalette.js).
// Задача — гарантированно "засветить" в обучающей выборке все цвета, которые могут
// встретиться хоть в одном реальном кадре спина:
//   1) выигрышный момент — золотая/зелёная подсветка ячейки, сияние (drawGlow) и
//      конфетти (drawSparkles), которых нет на обычном "крутящемся" кадре;
//   2) все 6 иконок символов барабанов сразу — обычный кадр показывает только 3
//      случайных из 6, и если какой-то символ ни разу не попадётся, его цвет не попал
//      бы в обучение.
// Сам кадр может выглядеть как угодно "криво" (иконки составлены встык, вне обычной
// сетки барабанов) — это не баг, т.к. эти кадры нигде не рендерятся пользователю.
function buildCalibrationFrames(template, width, height, fontLabel) {
  const symbols = C.CASINO_SLOT_SYMBOLS;

  const winSymbol = symbols[symbols.length - 1];
  const winSession = { bet: 1000, win: 1000, matchType: 'three', balance: 999999 };
  const winFrame = template.clone();
  drawFrame(winFrame, width, height, fontLabel, [winSymbol, winSymbol, winSymbol], true, winSession, 0);

  const loseSession = { bet: 1000, win: 0, matchType: 'none', balance: 999999 };
  const symbolsFrame = template.clone();
  drawFrame(
    symbolsFrame,
    width,
    height,
    fontLabel,
    [symbols[0 % symbols.length], symbols[1 % symbols.length], symbols[2 % symbols.length]],
    false,
    loseSession,
    0
  );
  // Символы сверх первых трёх (если такие есть) просто "приклеиваем" поверх в свободном
  // месте кадра — нам важны только их пиксели для обучения палитры, а не композиция.
  for (let i = 3; i < symbols.length; i++) {
    const icon = getSymbolIcon(symbols[i]);
    symbolsFrame.composite(icon, (i * (SYMBOL_SIZE + 4)) % Math.max(1, width - SYMBOL_SIZE), 4);
  }

  return [winFrame, symbolsFrame];
}

// Калибровочные кадры (см. buildCalibrationFrames) не зависят от реального результата
// спина — только от фиксированных констант (фон/рамка/иконки символов), поэтому и
// обученная на них палитра для данного размера кадра ВСЕГДА одна и та же. Обучаем её
// один раз за всё время жизни воркера (как symbolIconCache/bgCache выше), а не один раз
// на каждый спин — это убирает даже то немногое время (обучение NeuQuant), что осталось
// после перехода на общую палитру вместо переобучения на каждом кадре.
let sharedPaletteCache = null;
function getSharedPalette(template, width, height, fontLabel) {
  if (sharedPaletteCache) return sharedPaletteCache;
  const calibrationFrames = buildCalibrationFrames(template, width, height, fontLabel);
  const imgq = gifPalette.buildSharedQuantizer(calibrationFrames, 1);
  sharedPaletteCache = {
    lookup: gifPalette.makeCachedLookup(imgq),
    colorTab: imgq.getColormap(),
  };
  return sharedPaletteCache;
}

// session: { bet, win, matchType, reels: [symbol, symbol, symbol], balance }
// Возвращает Buffer с анимированным GIF: барабаны крутятся и останавливаются по очереди
// слева направо, итог (выигрыш/проигрыш + баланс) появляется только на последних кадрах.
async function renderSpin(session) {
  const width = MARGIN_SIDE * 2 + REEL_W * 3 + REEL_GAP * 2;
  const height = MARGIN_TOP + REEL_H + FOOTER_HEIGHT;

  const [background, { fontTitle, fontLabel }] = await Promise.all([R.buildBackground(width, height), R.getFonts()]);
  const template = buildStaticTemplate(background, width, height, fontTitle);

  const totalFrames = Math.max(20, Math.round(C.CASINO_SPIN_MS / FRAME_DELAY_MS));
  const lockAt = REEL_LOCK_FRACTIONS.map((frac) => Math.round(totalFrames * frac));

  const encoder = new GIFEncoder(width, height);
  encoder.start();
  encoder.setRepeat(-1); // проиграть один раз и остановиться на итоговом кадре, не зацикливать
  encoder.setDelay(FRAME_DELAY_MS);

  // Общая палитра (см. getSharedPalette выше) вместо encoder.addFrame(), который
  // переобучал бы NeuQuant-сеть с нуля на КАЖДОМ из totalFrames кадров — см. подробное
  // объяснение в game/gifPalette.js. Именно повторное обучение на каждом кадре было
  // главной причиной, по которой рендер спина раньше занимал секунды.
  const { lookup, colorTab } = getSharedPalette(template, width, height, fontLabel);

  for (let f = 0; f < totalFrames; f++) {
    const revealing = f >= lockAt[2];
    const reelSymbols = [
      f >= lockAt[0] ? session.reels[0] : randomSpinningSymbol(),
      f >= lockAt[1] ? session.reels[1] : randomSpinningSymbol(),
      f >= lockAt[2] ? session.reels[2] : randomSpinningSymbol(),
    ];

    const frame = template.clone();
    drawFrame(frame, width, height, fontLabel, reelSymbols, revealing, session, f);

    if (f === totalFrames - 1) encoder.setDelay(LAST_FRAME_HOLD_MS);
    gifPalette.addFrameWithSharedPalette(encoder, lookup, colorTab, frame.bitmap.data);
  }

  encoder.finish();
  return encoder.out.getData();
}

module.exports = { renderSpin };
