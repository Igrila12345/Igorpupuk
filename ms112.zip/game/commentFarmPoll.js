'use strict';

// ===================== ОПРОС КОММЕНТАРИЕВ БЕЗ LONG POLL =====================
// handlers/commentFarmHandlers.js (событие wall_reply_new) даёт бонус за "фарм" МГНОВЕННО,
// но только если в настройках сообщества (Управление → Работа с API → Long Poll API →
// Типы событий) включён пункт "Добавление комментария к записи". Это ручная настройка на
// стороне VK — если она выключена (или админ вообще не может её включить), Long Poll
// никогда не пришлёт это событие, и бонус за "фарм" просто не будет работать.
//
// Этот модуль решает это ТЕМ ЖЕ приёмом, что и game/postLikes.js для лайков: вместо того
// чтобы ждать событие, сами периодически (см. game/scheduler.js) опрашиваем VK API —
// wall.get за последними постами сообщества, затем wall.getComments по каждому из них —
// и прогоняем найденные комментарии через тот же commentFarm.tryClaim, что и Long Poll
// путь. Бонус НЕ теряется и НЕ зависит от настроек Long Poll'а, просто может прийти с
// задержкой до ближайшего тика вместо мгновенного начисления.

const postLikes = require('./postLikes');
const postLikesDb = require('../db/postLikes');
const shopDb = require('../db/shop');
const commentFarm = require('./commentFarm');
const { withLock } = require('./asyncLock');

const POLL_LOCK_KEY = 'comment-farm-poll';

// Сколько последних постов сообщества опрашивать. Акции "напишите фарм в комментариях"
// почти всегда стоят на свежих постах — опрашивать весь архив (может быть тысячи постов)
// было бы не только бессмысленно, но и дорого по количеству запросов к VK API.
const RECENT_POSTS_LIMIT = 15;

// Сколько комментариев запрашивать за один вызов wall.getComments (максимум у VK — 100).
const COMMENTS_PAGE_SIZE = 100;
// Защитный предел на общее количество комментариев одного поста за один тик — чтобы
// один аномально "разогретый" пост не мог зациклить опрос остальных постов.
const MAX_COMMENTS_PER_POST = 3000;

const LAST_ID_META_PREFIX = 'comment_farm_last_id_';

// "До какого id комментария под этим постом мы уже всё проверили" — храним в общей
// key-value таблице game_meta (тот же приём, что у game/globalBoost.js), чтобы при
// каждом тике не перечитывать заново ВСЕ комментарии старых постов, а смотреть только
// то, что появилось нового. Дублирующая проверка не страшна (comment_farm_claims всё
// равно не даст начислить бонус повторно), это чисто вопрос экономии запросов к VK API.
async function getLastCommentId(postId) {
  const raw = await shopDb.getMeta(`${LAST_ID_META_PREFIX}${postId}`);
  const parsed = raw ? Number(raw) : 0;
  return Number.isFinite(parsed) && parsed > 0 ? parsed : 0;
}

async function setLastCommentId(postId, commentId) {
  await shopDb.setMeta(`${LAST_ID_META_PREFIX}${postId}`, String(commentId));
}

// Разово проверяет новые комментарии одного поста и начисляет бонус там, где нашли
// триггер-слово. Отвечаем ПРЯМО В ВЕТКЕ КОММЕНТАРИЕВ — тем же способом и тем же текстом,
// что и мгновенный Long Poll путь (см. commentFarm.buildRewardReplyText/replyInComments),
// чтобы поведение не отличалось от того, срабатывает Long Poll или нет.
async function pollPostComments(bot, wallClient, ownerId, postId) {
  const lastId = await getLastCommentId(postId);
  let maxIdSeen = lastId;
  let offset = 0;
  const freshComments = [];

  for (;;) {
    const res = await wallClient.api.wall.getComments({
      owner_id: ownerId,
      post_id: postId,
      count: COMMENTS_PAGE_SIZE,
      offset,
      sort: 'asc',
      need_likes: 0,
    });
    const items = (res && res.items) || [];

    for (const comment of items) {
      if (!comment || !comment.id) continue;
      if (comment.id > maxIdSeen) maxIdSeen = comment.id;
      // Комментарии не позже lastId уже проверялись на прошлых тиках — пропускаем.
      if (comment.id > lastId) freshComments.push(comment);
    }

    if (items.length < COMMENTS_PAGE_SIZE) break;
    offset += COMMENTS_PAGE_SIZE;
    if (offset >= MAX_COMMENTS_PER_POST) break;
  }

  for (const comment of freshComments) {
    const vkId = comment.from_id;
    // Комментарии от самого сообщества (служебные) идут с отрицательным from_id — не игрок.
    if (!vkId || vkId <= 0) continue;
    if (!commentFarm.containsTrigger(comment.text)) continue;

    const result = await commentFarm.tryClaim(vkId, postId, comment.text);
    if (!result.ok) continue; // not_registered / already_claimed — молча, это не ошибка

    const replyText = commentFarm.buildRewardReplyText(result);
    await commentFarm.replyInComments(bot, ownerId, postId, comment.id, replyText);
  }

  if (maxIdSeen > lastId) {
    await setLastCommentId(postId, maxIdSeen);
  }
}

// Полный тик: подтягиваем последние посты сообщества → опрашиваем комментарии по каждому.
// Сериализуем через лок — на случай, если предыдущий тик ещё не успел закончиться (опрос
// VK API нескольких постов подряд может занять заметное время), чтобы не запускать второй
// проход параллельно первому.
async function pollComments(bot) {
  const ownerId = postLikes.getGroupOwnerId();
  if (!ownerId) return; // нет VK_GROUP_ID — то же самое ограничение, что и у лайков постов
  if (!bot || !bot.vk) return;

  await withLock(POLL_LOCK_KEY, async () => {
    // Чтение стены (wall.get/wall.getComments) — тот же клиент, что и у лайков постов:
    // либо VK_USER_TOKEN, либо (с предупреждением в лог) токен сообщества, см.
    // game/postLikes.js: getWallApiClient. Публикация же ответа в комментариях (см.
    // commentFarm.replyInComments) всегда идёт через bot.vk — она обязана быть от имени
    // самого сообщества, это отдельное ограничение VK API.
    const wallClient = postLikes.getWallApiClient(bot);

    let items = [];
    try {
      const res = await wallClient.api.wall.get({ owner_id: ownerId, count: RECENT_POSTS_LIMIT, filter: 'owner' });
      items = (res && res.items) || [];
    } catch (err) {
      console.error('[CommentFarmPoll] Не удалось опросить wall.get:', err.message);
      return;
    }

    const posts = items
      .filter((post) => post && post.id && post.date)
      .map((post) => ({ postId: post.id, publishedAt: new Date(post.date * 1000).toISOString() }));

    // Складываем в ту же таблицу отслеживаемых постов, что и у лайков (community_posts) —
    // она уже ведёт учёт независимо от Long Poll, отдельная таблица под комментарии не нужна.
    await postLikesDb.upsertPosts(ownerId, posts).catch((err) => {
      console.error('[CommentFarmPoll] Не удалось сохранить список постов:', err.message);
    });

    for (const post of posts) {
      try {
        await pollPostComments(bot, wallClient, ownerId, post.postId);
      } catch (err) {
        console.error(`[CommentFarmPoll] Ошибка опроса комментариев поста ${post.postId}:`, err.message);
      }
    }
  });
}

module.exports = { pollComments };
