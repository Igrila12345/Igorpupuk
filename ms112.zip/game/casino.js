'use strict';

const C = require('./constants');
const players = require('../db/players');
const casinoDb = require('../db/casino');
const asyncLock = require('./asyncLock');

// Игроки, у которых прямо сейчас "крутится" партия — пока vkId в этом Set, новую партию
// запустить нельзя (ни первую, ни вторую, ни третью — см. ТЗ). Живёт в памяти процесса,
// как и остальные короткоживущие геймплейные локи в проекте (см. asyncLock.js).
// Держим его именно на весь CASINO_SPIN_MS — но теперь НЕ через await sleep() внутри
// spin() (это заставляло бы игрока ждать CASINO_SPIN_MS молча ДО получения ответа, а
// потом ещё раз столько же — пока проигрывается сама гифка с анимацией барабанов, см.
// game/casinoRender.js). Вместо этого результат считается и отправляется сразу, а слот
// освобождается фоновым setTimeout ровно к моменту, когда на экране игрока должна
// закончиться анимация — так суммарное ожидание не удваивается.
const spinningPlayers = new Set();

function isSpinning(vkId) {
  return spinningPlayers.has(vkId);
}

// Кулдаун на ЗАПУСК новой партии (см. C.CASINO_SLOT_COOLDOWN_MS) — отдельно от
// spinningPlayers выше: тот блокирует только на время самой анимации (CASINO_SPIN_MS),
// этот — ещё некоторое время сверху, чтобы нельзя было спамить рендер сразу же, как
// анимация закончилась. В памяти процесса, как и spinningPlayers — тот же трейд-офф
// (переживать перезапуск бота смысла нет, это просто анти-спам защита, а не игровое
// состояние).
const lastSlotStartAt = new Map();

function getSlotCooldownRemainingMs(vkId) {
  const last = lastSlotStartAt.get(vkId);
  if (!last) return 0;
  const remaining = C.CASINO_SLOT_COOLDOWN_MS - (Date.now() - last);
  return remaining > 0 ? remaining : 0;
}

function totalWeight() {
  return C.CASINO_SLOT_SYMBOLS.reduce((sum, s) => sum + s.weight, 0);
}

function rollSymbol() {
  const total = totalWeight();
  let r = Math.random() * total;
  for (const sym of C.CASINO_SLOT_SYMBOLS) {
    if (r < sym.weight) return sym;
    r -= sym.weight;
  }
  return C.CASINO_SLOT_SYMBOLS[C.CASINO_SLOT_SYMBOLS.length - 1]; // страховка от ошибок округления
}

// Обычный бросок — 3 независимых барабана по весам символов.
// Если у игрока стоит админский буст (boostPercent > 0, см. !админ казиношанс, db/players.js:
// casino_win_boost_percent) — с вероятностью boostPercent% ВСЕ ТРИ барабана принудительно
// становятся одним и тем же (случайно выбранным по тем же весам) символом, т.е. это
// гарантированный выигрыш на этом спине. В остальных случаях (или всегда, если буста нет) —
// обычный независимый бросок, который тоже может случайно дать 3oak.
function rollReels(boostPercent) {
  if (boostPercent > 0 && Math.random() * 100 < boostPercent) {
    const sym = rollSymbol();
    return [sym, sym, sym];
  }
  return [rollSymbol(), rollSymbol(), rollSymbol()];
}

// Считает выплату по трём выпавшим символам (см. constants.js: CASINO_SLOT_SYMBOLS —
// матрица весов/множителей и объяснение итогового RTP).
// Выигрыш только если ВСЕ ТРИ барабана совпали — любое расхождение хотя бы на одном
// барабане (в т.ч. 2 из 3) считается проигрышем всей ставки. Раньше 2 совпавших тоже
// давали небольшую выплату (twoMult) — это убрано, т.к. путало игроков: на анимации
// видно, что не все символы одинаковые, а бот всё равно пишет "выигрыш".
function resolveOutcome(reels, bet) {
  if (reels[0].key === reels[1].key && reels[1].key === reels[2].key) {
    const sym = reels[0];
    return { win: Math.round(bet * sym.threeMult), matchType: 'three', symbol: sym };
  }
  return { win: 0, matchType: 'none', symbol: null };
}

// Публичная точка входа: проверяет регистрацию/ставку/баланс, списывает ставку, крутит,
// начисляет выигрыш, пишет лог в БД — и сразу возвращает готовый для рендера расклад
// (без ожидания). Слот на повторный спин освобождается в фоне спустя CASINO_SPIN_MS —
// на экране игрока в это время как раз проигрывается гифка с анимацией (см. выше).
// preloadedPlayer — необязательный параметр: хендлер (handlers/casinoHandlers.js) уже
// сходил в БД за игроком в requireRegistered() ДО вызова spin(), и без этого параметра
// мы бы сходили за тем же самым игроком в БД ещё раз — лишний round-trip на пути,
// который по ТЗ должен укладываться в ~1 секунду. Если параметр не передан (вызов не из
// текущего хендлера, а откуда-то ещё), функция как и раньше сходит в БД сама.
async function spin(vkId, betRaw, preloadedPlayer) {
  if (isSpinning(vkId)) {
    return { ok: false, reason: 'already_spinning' };
  }

  const cooldownRemainingMs = getSlotCooldownRemainingMs(vkId);
  if (cooldownRemainingMs > 0) {
    return { ok: false, reason: 'cooldown', cooldownMs: cooldownRemainingMs };
  }

  const player = preloadedPlayer || (await players.getPlayer(vkId));
  if (!player || player.registration_step !== 'done') {
    return { ok: false, reason: 'not_registered' };
  }

  const bet = Math.floor(Number(betRaw));
  if (!Number.isFinite(bet) || bet <= 0) {
    return { ok: false, reason: 'bad_bet' };
  }
  if (bet < C.CASINO_MIN_BET) {
    return { ok: false, reason: 'bet_too_small' };
  }
  if (bet > C.CASINO_MAX_BET) {
    return { ok: false, reason: 'bet_too_big' };
  }
  if (Number(player.balance) < bet) {
    return { ok: false, reason: 'not_enough_balance', balance: Number(player.balance) };
  }

  spinningPlayers.add(vkId);
  // Отмечаем момент старта СРАЗУ, а не после resolve — кулдаун должен отсчитываться от
  // факта запуска партии (что и нагружает рендер), а не от того, успешно ли досчитались
  // деньги (если баланс вдруг не сойдётся в spinLocked — редкий гоночный случай, см.
  // комментарий у asyncLock.withLock ниже — партия всё равно уже "стоила" слот в очереди
  // рендера следующему спину этого игрока, это ожидаемо).
  lastSlotStartAt.set(vkId, Date.now());

  try {
    // withLock — тот же приём, что и в game/work.js: страхует от гонки, если по какой-то
    // причине вызов spin() для одного vkId всё же случится дважды параллельно (например,
    // повтор недоставленного апдейта от VK) ДО того, как spinningPlayers.add() выше успеет
    // сработать во втором вызове — двойного списания одной и той же ставки быть не должно.
    const boostPercent = Number(player.casino_win_boost_percent) || 0;
    const result = await asyncLock.withLock(`casino:${vkId}`, () => spinLocked(vkId, bet, boostPercent));

    if (result.ok) {
      // Не await'им — освобождаем слот в фоне, ровно к моменту, когда должна закончиться
      // гифка с анимацией на экране игрока (см. game/casinoRender.js: тот же CASINO_SPIN_MS).
      setTimeout(() => spinningPlayers.delete(vkId), C.CASINO_SPIN_MS);
    } else {
      spinningPlayers.delete(vkId);
    }

    return result;
  } catch (err) {
    spinningPlayers.delete(vkId);
    throw err;
  }
}

async function spinLocked(vkId, bet, boostPercent) {
  // Списываем ставку СРАЗУ (и одной атомарной SQL-операцией) — иначе накрутка двух
  // партий впритык друг к другу могла бы прочитать один и тот же баланс дважды.
  const balanceAfterBet = await players.updateBalance(vkId, -bet);
  if (balanceAfterBet === null || balanceAfterBet < 0) {
    // Не хватило денег в момент реального списания (баланс утёк между проверкой выше и
    // этим моментом) — откатываем и сообщаем как обычную нехватку средств.
    if (balanceAfterBet !== null) await players.updateBalance(vkId, bet);
    return { ok: false, reason: 'not_enough_balance' };
  }

  const reels = rollReels(boostPercent);
  const { win, matchType, symbol } = resolveOutcome(reels, bet);

  let balanceAfter = balanceAfterBet;
  if (win > 0) {
    balanceAfter = await players.updateBalance(vkId, win);
  }

  await casinoDb.insertSpin(vkId, bet, win, reels.map((s) => s.key));

  return {
    ok: true,
    bet,
    win,
    net: win - bet,
    matchType,
    symbol,
    reels,
    balance: balanceAfter,
  };
}

// Ежедневная награда топ-3 казино (по SUM(win) за прошедшие сутки МСК) — вызывается из
// game/scheduler.js в той же полуночной крон-джобе, что и ratings.distributeDailyRewards
// (топ заводов/кланов). Топ-1/2/3 получают C.CASINO_DAILY_REWARDS напрямую на баланс.
// Если за сутки никто не выигрывал вообще (win=0 у всех/не играли) — награды просто не
// выдаются никому, это ожидаемо, а не баг.
async function distributeDailyRewards(bot) {
  const top = await casinoDb.getTopWinnersForPreviousDay(3);
  for (let i = 0; i < top.length; i++) {
    const reward = C.CASINO_DAILY_REWARDS[i];
    if (!reward) break;
    const row = top[i];
    await players.updateBalance(row.vk_id, reward.virts);
    if (bot) {
      await bot
        .notifyUser(
          row.vk_id,
          `🎰 Ежедневная награда за ${reward.place} место в топе казино (выигрыш за сутки: ${Number(
            row.total_win
          )} вирт)!\n💰 +${reward.virts} вирт`
        )
        .catch(() => {});
    }
  }
}

module.exports = { spin, isSpinning, distributeDailyRewards };
