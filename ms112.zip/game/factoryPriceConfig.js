'use strict';

const shopDb = require('../db/shop');
const C = require('./constants');

// Позволяет админу временно/постоянно переопределить стартовую цену завода
// (C.FACTORY_BASE_PRICE), не трогая код — например, если экономику надо "сбросить"
// после того как игроки разогнали цену слишком сильно, или наоборот устроить
// распродажу с конкретной ценой. Хранится в game_meta (см. db/shop.js: getMeta/setMeta),
// как и другие переопределяемые админом настройки (курс фермы, глобальный буст и т.д.).
// Пустая строка/отсутствие значения = override не задан, используется дефолт из constants.js.
const META_KEY = 'factory_base_price_override';

// Возвращает override как число, либо null если он не задан (используется дефолт).
async function getOverride() {
  const raw = await shopDb.getMeta(META_KEY);
  if (raw === null || raw === undefined || raw === '') return null;
  const val = parseInt(raw, 10);
  return Number.isFinite(val) && val > 0 ? val : null;
}

// Реальная цена, по которой сейчас считается кривая (override, либо дефолт из constants.js).
async function getEffectiveBasePrice() {
  const override = await getOverride();
  return override != null ? override : C.FACTORY_BASE_PRICE;
}

// Задать конкретную стартовую цену завода (цену за 1-й завод; дальше кривая считается
// от неё так же, как раньше считалась от C.FACTORY_BASE_PRICE — см. calc.nextFactoryPrice).
async function setOverride(price) {
  const clean = Math.max(1, Math.floor(price));
  await shopDb.setMeta(META_KEY, String(clean));
  return clean;
}

// Сброс — возврат к дефолтной цене из constants.js (C.FACTORY_BASE_PRICE).
async function resetOverride() {
  await shopDb.setMeta(META_KEY, '');
  return C.FACTORY_BASE_PRICE;
}

module.exports = { getOverride, getEffectiveBasePrice, setOverride, resetOverride, DEFAULT_PRICE: C.FACTORY_BASE_PRICE };
