'use strict';

// Простой асинхронный лок по ключу (в памяти процесса). Гарантирует, что все вызовы
// withLock() с одинаковым key выполняются строго по очереди — даже если пришли почти
// одновременно (например, игрок спамит одну и ту же команду несколько раз подряд, пока
// бот ещё обрабатывает предыдущую).
//
// Зачем это нужно: без лока действия вроде "построить завод" читают баланс/лимиты игрока,
// а затем пишут их — несколько ПАРАЛЛЕЛЬНЫХ вызовов (10 сообщений "построить" подряд вместо
// одного "построить 10") могут все прочитать одно и то же стартовое состояние ДО того, как
// первая запись успеет сохраниться, и таким образом обойти часовой лимит построек или
// получить несколько заводов по цене одного и того же (более раннего, более дешёвого) шага
// цены. Один и тот же результат в единицах — либо через один командой на N штук, либо через
// N команд по 1 — не должен быть выгоднее по цене/лимиту, чем предполагает игровой баланс.
const queues = new Map();

function withLock(key, fn) {
  const previous = queues.get(key) || Promise.resolve();
  const run = previous.then(fn, fn); // выполняем fn после previous независимо от её исхода
  const chained = run.catch(() => {}); // гасим ошибку в цепочке, чтобы очередь не "залипла"
  queues.set(key, chained);
  chained.finally(() => {
    if (queues.get(key) === chained) queues.delete(key);
  });
  return run;
}

// Как withLock, но с "хвостовой" паузой ПОСЛЕ fn, которая держит очередь ключа занятой
// для СЛЕДУЮЩЕГО вызова, не заставляя ждать ЭТОТ вызов. withLock() в чистом виде тут не
// подходит: если положить sleep(delayMs) внутрь самой fn (как раньше делал
// utils/uploadImage.js), вызывающий код получит результат ТОЛЬКО после этой паузы —
// хотя сама полезная работа (загрузка в VK) уже давно завершилась. Здесь же вызывающий
// получает результат сразу по готовности fn, а очередь для этого key остаётся занятой
// ещё delayMs после этого — ровно как и раньше, просто не за счёт задержки ответа игроку.
function withLockAndTrailingDelay(key, fn, delayMs) {
  const previous = queues.get(key) || Promise.resolve();
  const run = previous.then(fn, fn);
  const settled = run.catch(() => {});
  const extended = delayMs > 0 ? settled.then(() => new Promise((resolve) => setTimeout(resolve, delayMs))) : settled;
  queues.set(key, extended);
  extended.finally(() => {
    if (queues.get(key) === extended) queues.delete(key);
  });
  return run;
}

module.exports = { withLock, withLockAndTrailingDelay };
