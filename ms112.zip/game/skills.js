'use strict';

const C = require('./constants');

// Кумулятивный порог попыток, открывающий уровень L (1..SKILL_MAX_LEVEL).
// См. объяснение формулы в constants.js: SKILL_MAX_LEVEL / SKILL_BONUS_PER_LEVEL_PERCENT.
function thresholdFor(level) {
  return Math.round(2.5 * level * level + 7.5 * level);
}

// Уровень навыка по общему счётчику попыток (0, если не хватает даже на 1 уровень).
function levelFromCount(count) {
  let level = 0;
  for (let l = 1; l <= C.SKILL_MAX_LEVEL; l++) {
    if (count >= thresholdFor(l)) level = l;
    else break;
  }
  return level;
}

// Множитель к награде: 1.0 на уровне 0, +3% за каждый уровень (2.5x на максимуме — 50 ур.).
function rewardMultiplier(level) {
  return 1 + (level * C.SKILL_BONUS_PER_LEVEL_PERCENT) / 100;
}

// Прогресс до следующего уровня — для отображения в "!дозор статистика" / "!кража статистика".
function progressInfo(count) {
  const level = levelFromCount(count);
  const isMax = level >= C.SKILL_MAX_LEVEL;
  const nextThreshold = isMax ? null : thresholdFor(level + 1);
  const remaining = isMax ? 0 : nextThreshold - count;
  return {
    level,
    count,
    isMax,
    nextThreshold,
    remaining,
    multiplier: rewardMultiplier(level),
    bonusPercent: level * C.SKILL_BONUS_PER_LEVEL_PERCENT,
  };
}

module.exports = { thresholdFor, levelFromCount, rewardMultiplier, progressInfo };
