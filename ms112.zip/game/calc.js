'use strict';

const C = require('./constants');

function distanceKm(x1, y1, x2, y2) {
  return Math.sqrt((x1 - x2) ** 2 + (y1 - y2) ** 2);
}

// Цена n-го завода. До FACTORY_PRICE_LINEAR_THRESHOLD — экспонента (как раньше, там она ещё
// разумна). После порога — линейный рост на FACTORY_PRICE_LINEAR_STEP за завод, чтобы цена не
// улетала в бесконечность на больших количествах (см. комментарий в constants.js).
//
// basePriceOverride — необязательное число: если задано (и > 0), используется ВМЕСТО
// константы C.FACTORY_BASE_PRICE как стартовая цена завода. Так админ может временно
// поменять "с какой цены начинается" вся кривая (см. game/factoryPriceConfig.js и команду
// "!админ ценазаводов" в handlers/adminHandlers.js), не трогая сам код/константы.
//
// ВАЖНО: масштабируем ОБЕ части кривой (и экспоненту, и линейный участок) одним и тем же
// коэффициентом scale = basePrice / C.FACTORY_BASE_PRICE. Раньше scale применялся только к
// экспоненциальной части (currentCount <= threshold), а FACTORY_PRICE_LINEAR_STEP оставался
// ФИКСИРОВАННОЙ константой — из-за этого у игроков с большим числом заводов (за порогом
// FACTORY_PRICE_LINEAR_THRESHOLD, а это все активные/давние игроки) итоговая цена почти не
// менялась от админского оверрайда: линейное слагаемое (currentCount - threshold) * STEP
// на таких масштабах доминирует и полностью "съедает" эффект от изменения базовой цены.
// Итог был как "команда сброса цен на заводы не сбрасывает цены всем игрокам" — оверрайд/сброс
// технически применялся, но заметного эффекта не давал никому, кроме новичков с малым
// числом заводов. Масштабирование линейного шага тем же коэффициентом устраняет это: теперь
// изменение базовой цены пропорционально меняет цену для ВСЕХ игроков, независимо от того,
// сколько заводов у них уже построено.
function nextFactoryPrice(currentCount, basePriceOverride) {
  const basePrice =
    Number.isFinite(basePriceOverride) && basePriceOverride > 0 ? basePriceOverride : C.FACTORY_BASE_PRICE;
  const scale = basePrice / C.FACTORY_BASE_PRICE;
  const threshold = C.FACTORY_PRICE_LINEAR_THRESHOLD;
  if (currentCount <= threshold) {
    return Math.round(basePrice * Math.pow(C.FACTORY_PRICE_GROWTH, currentCount));
  }
  const priceAtThreshold = basePrice * Math.pow(C.FACTORY_PRICE_GROWTH, threshold);
  const linearStep = C.FACTORY_PRICE_LINEAR_STEP * scale;
  return Math.round(priceAtThreshold + (currentCount - threshold) * linearStep);
}

// Активные (не заблокированные) заводы = всего заводов - сумма заблокированных - заводы в производстве (учитывается отдельно вызывающим кодом)
function sumBlocked(blockedFactories) {
  if (!blockedFactories || !Array.isArray(blockedFactories)) return 0;
  const now = Date.now();
  return blockedFactories
    .filter((b) => new Date(b.unblock_at).getTime() > now)
    .reduce((sum, b) => sum + b.count, 0);
}

function isVipActive(player) {
  return !!(player && player.vip_until && new Date(player.vip_until) > new Date());
}

// Отдельная от VIP подписка (см. game/steal.js: attemptSteal) — защищает баланс от кражи.
function isStealProtectionActive(player) {
  return !!(player && player.steal_protection_until && new Date(player.steal_protection_until) > new Date());
}

function isMinerActive(player) {
  return !!(player && player.miner_until && new Date(player.miner_until) > new Date());
}

// Майнер, выданный командой "!админ майнер @юзер навсегда", ставит miner_until на
// MINER_FOREVER_YEARS лет вперёд — считаем такой майнер "вечным" для отображения (вместо
// конкретной далёкой даты показываем игроку просто "навсегда").
function isMinerForever(player) {
  if (!isMinerActive(player)) return false;
  const yearsLeft = (new Date(player.miner_until).getTime() - Date.now()) / (365.25 * 24 * 60 * 60 * 1000);
  return yearsLeft > C.MINER_FOREVER_DISPLAY_THRESHOLD_YEARS;
}

// ===================== РАСХОДУЕМЫЕ ДОНАТ-БАФФЫ (см. game/donateBuffs.js, game/constants.js) =====================

function isIncomeBoostActive(player) {
  return !!(player && player.income_boost_until && new Date(player.income_boost_until) > new Date());
}

// Щит: защита заводов от НЕядерного оружия (см. game/combat.js, game/robot.js, game/superRobot.js —
// ядерное оружие (nuke_strike) щит намеренно НЕ проверяет и наносит урон как обычно).
function isShieldActive(player) {
  return !!(player && player.shield_until && new Date(player.shield_until) > new Date());
}

function isWorkDoubleActive(player) {
  return !!(player && player.work_double_until && new Date(player.work_double_until) > new Date());
}

function isFarmBoostActive(player) {
  return !!(player && player.farm_boost_until && new Date(player.farm_boost_until) > new Date());
}

// ⚡ Турбоферма — донат-подписка x${FARM_PRO_MULTIPLIER} к добыче фермы (см. game/farm.js)
function isFarmProActive(player) {
  return !!(player && player.farm_pro_until && new Date(player.farm_pro_until) > new Date());
}

// Донат-бафф x2 к награде за попадание по мировому боссу (см. game/boss.js, DONATE_BOSS_DOUBLE_*)
function isBossDoubleActive(player) {
  return !!(player && player.boss_double_until && new Date(player.boss_double_until) > new Date());
}

// ===================== НОВЫЕ ВРЕМЕННЫЕ ДОНАТ-БАФФЫ (см. game/constants.js: DONATE_*_BOOST_*) =====================

function isEmojiTagActive(player) {
  return !!(player && player.emoji_tag && player.emoji_tag_until && new Date(player.emoji_tag_until) > new Date());
}

function isScienceBoostActive(player) {
  return !!(player && player.science_boost_until && new Date(player.science_boost_until) > new Date());
}

function isStealBoostActive(player) {
  return !!(player && player.steal_boost_until && new Date(player.steal_boost_until) > new Date());
}

function isPatrolBoostActive(player) {
  return !!(player && player.patrol_boost_until && new Date(player.patrol_boost_until) > new Date());
}

function isInspectionBoostActive(player) {
  return !!(player && player.inspection_boost_until && new Date(player.inspection_boost_until) > new Date());
}

// ===================== БОНУС НОВИЧКА (catch-up) =====================
// «Вес» игрока для порога бонуса: заводы + наука в пересчёте на заводы (1 наука = 10
// заводов, см. NEWBIE_BOOST_SCIENCE_FACTORY_EQUIV). Наука приносит 80 вирт/ч против 8 у
// завода, поэтому игрок, вложившийся в науку, перестаёт быть новичком так же, как если бы
// настроил заводов.
function newbieEquivalentFactories(player) {
  return (
    (player.factories || 0) + (player.science_centers || 0) * C.NEWBIE_BOOST_SCIENCE_FACTORY_EQUIV
  );
}

// Бонус ОДНОРАЗОВЫЙ: как только игрок хоть раз дошёл до порога, флаг newbie_boost_ended
// ставится в БД навсегда (см. game/economy.js: syncNewbieBoostFlag), и бонус больше не
// возвращается — даже если заводы снесли в войне или игрок продал науку. Раньше бонус
// считался только по текущему числу заводов, поэтому топовый игрок, потерявший заводы,
// снова получал +50% к доходу как новичок.
function isNewbieBoostActive(player) {
  if (!player || player.newbie_boost_ended) return false;
  return newbieEquivalentFactories(player) < C.NEWBIE_BOOST_FACTORY_THRESHOLD;
}

// Множитель дохода С ЗАВОДОВ: полный +NEWBIE_BOOST_INCOME_BONUS в самом начале, линейно
// убывает до 0 к порогу. Возвращает 1 (без бонуса), если бонус уже отработан.
function newbieBoostMultiplier(player) {
  if (!isNewbieBoostActive(player)) return 1;
  const progress =
    Math.max(0, newbieEquivalentFactories(player) - 1) / (C.NEWBIE_BOOST_FACTORY_THRESHOLD - 1);
  return 1 + C.NEWBIE_BOOST_INCOME_BONUS * (1 - progress);
}

// ===================== ПРОКАЧКА ЗАВОДОВ (см. game/constants.js: FACTORY_UPGRADE_*) =====================
// НЕ путать с бонусом новичка выше — это отдельная, постоянная (не убывающая, не разовая)
// прокачка: чем выше уровень, тем БОЛЬШЕ бонус, и он не пропадает с ростом остальных
// показателей. Как и бонус новичка, множит только доход С ЗАВОДОВ, не науку.
function factoryUpgradeLevel(player) {
  return (player && player.factory_upgrade_level) || 0;
}

function factoryUpgradeMultiplier(player) {
  return 1 + factoryUpgradeLevel(player) * C.FACTORY_UPGRADE_INCOME_BONUS_PER_LEVEL;
}

// Цена перехода С уровня currentLevel НА currentLevel+1 (уровень 1 стоит 150к, каждый
// следующий на 150к дороже — т.е. цена перехода на уровень N это N × FACTORY_UPGRADE_COST_STEP).
function factoryUpgradeCost(currentLevel) {
  return (currentLevel + 1) * C.FACTORY_UPGRADE_COST_STEP;
}

function incomePerHour(player, factoriesInProduction = 0) {
  const blocked = sumBlocked(player.blocked_factories);
  const normalFactories = player.factories - player.gold_mine_count;
  const goldFactories = player.gold_mine_count;
  // Считаем усреднённо: доход пропорционален доле активных заводов
  const totalActive = Math.max(player.factories - blocked - factoriesInProduction, 0);
  const activeRatio = player.factories > 0 ? totalActive / player.factories : 0;
  let factoryIncome =
    normalFactories * C.FACTORY_INCOME_PER_HOUR * activeRatio +
    goldFactories * C.FACTORY_INCOME_PER_HOUR * C.GOLD_MINE_MULTIPLIER * activeRatio;

  // Бонус для новых/маленьких игроков (catch-up) — см. newbieBoostMultiplier ниже:
  // одноразовый (после достижения порога не возвращается) и считает науку как заводы.
  //
  // ВАЖНО: бонус умножает ТОЛЬКО доход с заводов, а не науку. Раньше он применялся ко ВСЕМУ
  // доходу (заводы + научные центры) уже ПОСЛЕ их сложения — и, поскольку сам бонус убывает
  // с ростом числа заводов, постройка нового завода УМЕНЬШАЛА множитель у всего научного
  // дохода. Прибавка от самого завода (8 вирт/ч) этого не перекрывала, если центров было
  // много, и суммарный доход после постройки реально ПАДАЛ: например, при 55 научных центрах
  // каждый построенный завод отнимал ~4-11 вирт/ч. Наука к «бонусу новичка» отношения не
  // имеет, поэтому и множиться на него не должна.
  factoryIncome *= newbieBoostMultiplier(player);
  // Постоянная прокачка заводов (см. выше) — так же только на доход с заводов, по той же
  // причине, и складывается с бонусом новичка (оба множителя применяются последовательно,
  // а не выбирается один из двух).
  factoryIncome *= factoryUpgradeMultiplier(player);

  // Научные центры — не подвержены блокировке/производству, доход стабильный
  const scienceCenters = player.science_centers || 0;
  let income = factoryIncome + scienceCenters * C.SCIENCE_INCOME_PER_HOUR;

  const radiationActive = player.radiation_until && new Date(player.radiation_until) > new Date();
  if (radiationActive) income *= 1 - C.RADIATION_INCOME_PENALTY;

  // Штраф за нелайкнутые посты сообщества (см. game/postLikes.js). like_penalty_active —
  // кэш-флаг на самом игроке, пересчитывается фоновой задачей, т.к. эта функция синхронная
  // и не может сама ходить в БД на каждый вызов.
  if (player.like_penalty_active) income *= 1 - C.POST_LIKE_INCOME_PENALTY;

  // VIP: +25% к пассивному доходу
  if (isVipActive(player)) income *= 1 + C.VIP_INCOME_BONUS;

  // Донат-бафф "буст дохода" (x1.5 или x2 на ограниченное время) — множитель хранится
  // персонально в income_boost_mult, т.к. цена/множитель отличаются (см. !админ доход).
  if (isIncomeBoostActive(player) && player.income_boost_mult) {
    income *= Number(player.income_boost_mult);
  }

  if (player.factories <= 0 && scienceCenters <= 0) return 0;
  return Math.round(income);
}

// Штраф на трофеи при атаке значительно более слабого игрока (по числу заводов) — чтобы топы
// не farm-или мелких игроков как основной источник дохода. Если у защитника меньше
// WEAK_TARGET_RATIO_THRESHOLD от заводов атакующего — трофеи снижаются пропорционально
// разрыву, вплоть до WEAK_TARGET_MIN_LOOT_MULTIPLIER на совсем беззащитных новичках.
// Если защитник сопоставим или сильнее атакующего — множитель всегда 1 (штрафа нет).
function weakTargetLootMultiplier(attacker, defender) {
  const attackerFactories = Math.max(attacker.factories || 0, 1);
  const defenderFactories = Math.max(defender.factories || 0, 0);
  const ratio = defenderFactories / attackerFactories;

  if (ratio >= C.WEAK_TARGET_RATIO_THRESHOLD) return 1;

  const scaled = ratio / C.WEAK_TARGET_RATIO_THRESHOLD; // 0..1
  return C.WEAK_TARGET_MIN_LOOT_MULTIPLIER + (1 - C.WEAK_TARGET_MIN_LOOT_MULTIPLIER) * scaled;
}

function formatNumber(n) {
  return Math.round(n).toLocaleString('ru-RU');
}

function formatDuration(ms) {
  if (ms <= 0) return '0 сек';
  // Меньше минуты — показываем секунды, а не округлённые "0 мин" (это вводило в заблуждение:
  // бот писал "ждите" и тут же "осталось 0 мин", будто ждать не нужно).
  if (ms < 60000) {
    const totalSeconds = Math.max(1, Math.round(ms / 1000));
    return `${totalSeconds} сек`;
  }
  const totalMinutes = Math.round(ms / 60000);
  const hours = Math.floor(totalMinutes / 60);
  const minutes = totalMinutes % 60;
  const parts = [];
  if (hours > 0) parts.push(`${hours} ч`);
  if (minutes > 0 || hours === 0) parts.push(`${minutes} мин`);
  return parts.join(' ');
}

function formatHours(hoursFloat) {
  if (Number.isInteger(hoursFloat)) return `${hoursFloat} ч`;
  return `${hoursFloat} ч`;
}

function randomInt(min, max) {
  return Math.floor(Math.random() * (max - min + 1)) + min;
}

// Взвешенная награда за "работу": сначала выбираем диапазон (тир) по весам
// C.WORK_TOKEN_TIERS, затем равномерно роллим число внутри него. Так верхние
// диапазоны (40+) остаются возможными, но выпадают заметно реже нижних.
function randomWorkTokens() {
  const tiers = C.WORK_TOKEN_TIERS;
  const totalWeight = tiers.reduce((sum, t) => sum + t.weight, 0);
  let roll = Math.random() * totalWeight;
  for (const tier of tiers) {
    if (roll < tier.weight) return randomInt(tier.min, tier.max);
    roll -= tier.weight;
  }
  // На случай ошибок округления с плавающей точкой — берём последний (самый редкий) тир.
  const last = tiers[tiers.length - 1];
  return randomInt(last.min, last.max);
}

function pickRandom(arr, count) {
  const copy = [...arr];
  const result = [];
  while (copy.length && result.length < count) {
    const idx = Math.floor(Math.random() * copy.length);
    result.push(copy.splice(idx, 1)[0]);
  }
  return result;
}

// Возвращает наивысший достигнутый скилл-тир по количеству заводов (или null, если ни один не достигнут)
function getSkillTier(factories) {
  let best = null;
  for (const tier of C.SKILL_TIERS) {
    if (factories >= tier.factories) best = tier;
  }
  return best;
}

// Текущий лимит заводов игрока с учётом купленных расширений
function currentFactoryLimit(factoryLimitLevel) {
  const level = factoryLimitLevel || 0;
  const row = C.FACTORY_LIMIT_LEVELS.find((l) => l.level === level) || C.FACTORY_LIMIT_LEVELS[0];
  return row.limit;
}

// Текущий лимит научных центров игрока с учётом купленных расширений
function currentScienceLimit(scienceLimitLevel) {
  const level = scienceLimitLevel || 1;
  const row = C.SCIENCE_LIMIT_LEVELS.find((l) => l.level === level) || C.SCIENCE_LIMIT_LEVELS[0];
  return row.limit;
}

// Цена постройки СЛЕДУЮЩЕГО научного центра с учётом уже построенных (builtCount).
// Растёт ступенчато: каждые SCIENCE_BUILD_COST_STEP_SIZE построенных центров цена
// подскакивает на SCIENCE_BUILD_COST_STEP_AMOUNT. Например, при базе 500/шаге 5/приросте 300:
// центры 1-5 -> 500, центры 6-10 -> 800, центры 11-15 -> 1100, и т.д.
function scienceBuildCost(builtCount) {
  const step = Math.floor((builtCount || 0) / C.SCIENCE_BUILD_COST_STEP_SIZE);
  return C.SCIENCE_BUILD_VIRT_COST + step * C.SCIENCE_BUILD_COST_STEP_AMOUNT;
}

module.exports = {
  distanceKm,
  nextFactoryPrice,
  sumBlocked,
  isVipActive,
  isStealProtectionActive,
  isMinerActive,
  isMinerForever,
  isIncomeBoostActive,
  isShieldActive,
  isWorkDoubleActive,
  isFarmBoostActive,
  isFarmProActive,
  isBossDoubleActive,
  isEmojiTagActive,
  isScienceBoostActive,
  isStealBoostActive,
  isPatrolBoostActive,
  isInspectionBoostActive,
  incomePerHour,
  newbieEquivalentFactories,
  isNewbieBoostActive,
  newbieBoostMultiplier,
  factoryUpgradeLevel,
  factoryUpgradeMultiplier,
  factoryUpgradeCost,
  weakTargetLootMultiplier,
  formatNumber,
  formatDuration,
  formatHours,
  randomInt,
  randomWorkTokens,
  pickRandom,
  getSkillTier,
  currentFactoryLimit,
  currentScienceLimit,
  scienceBuildCost,
};
