'use strict';

const players = require('../db/players');
const patrol = require('../game/patrol');
const quests = require('../game/quests');
const calc = require('../game/calc');
const images = require('../game/commandImages');
const skills = require('../game/skills');

async function requireRegistered(ctx) {
  const player = await players.getPlayer(ctx.senderId);
  if (!player || player.registration_step !== 'done') {
    await ctx.send('⛔ Вы ещё не зарегистрированы. Напишите старт');
    return null;
  }
  return player;
}

function resultLine(result) {
  const parts = [];
  if (result.virts > 0) parts.push(`+${calc.formatNumber(result.virts)} вирт`);
  if (result.tokens > 0) parts.push(`+${result.tokens} 🪙`);
  return parts.length ? parts.join(', ') : 'без трофеев';
}

function skillLine(skillAfter, leveledUp) {
  const levelUpNote = leveledUp ? ` 🆙 Новый уровень навыка!` : '';
  if (skillAfter.isMax) {
    return `🎓 Навык «Дозор»: ${skillAfter.level}/50 (максимум, +${skillAfter.bonusPercent}% к награде)${levelUpNote}`;
  }
  return (
    `🎓 Навык «Дозор»: ${skillAfter.level}/50 (+${skillAfter.bonusPercent}% к награде), ` +
    `до след. уровня: ${skillAfter.remaining} обход(ов)${levelUpNote}`
  );
}

async function handlePatrol(ctx) {
  const player = await requireRegistered(ctx);
  if (!player) return;

  const result = await patrol.runPatrol(ctx.senderId);
  if (!result.ok) {
    if (result.reason === 'cooldown') {
      await ctx.send(`⏳ Дозор недавно возвращался. Следующий выход через ${calc.formatDuration(result.msLeft)}.`);
    } else {
      await ctx.send('⛔ Не удалось отправить дозор.');
    }
    return;
  }

  const jackpotPrefix = result.type === 'jackpot' ? '🎉 УДАЧА! ' : '🔭 ';
  const questNotices = await quests.trackProgress(ctx.senderId, 'patrol', 1);
  let text =
    `${jackpotPrefix}${result.flavorText}\n` +
    `Итог: ${resultLine(result)}${result.patrolBoosted ? ' (🎯 донат-буст x2)' : ''}\n` +
    `⏳ Следующий дозор через ${calc.formatDuration(result.cooldownMs)}.`;
  if (result.skillLeveledUp || result.skillAfter.bonusPercent > 0) {
    text += `\n${skillLine(result.skillAfter, result.skillLeveledUp)}`;
  }
  if (questNotices.length) text += `\n\n${questNotices.join('\n')}`;
  await ctx.send(images.withImage('patrol', text));
}

async function handleStats(ctx) {
  const player = await requireRegistered(ctx);
  if (!player) return;

  const info = skills.progressInfo(player.patrol_count_total || 0);
  const text =
    `🔭 НАВЫК «ДОЗОР»\n` +
    `Уровень: ${info.level}/50 (+${info.bonusPercent}% к награде дозора)\n` +
    `Всего обходов: ${player.patrol_count_total || 0}\n` +
    (info.isMax ? `Максимальный уровень достигнут!` : `До следующего уровня: ${info.remaining} обход(ов)`);
  await ctx.send(text);
}

module.exports = { handlePatrol, handleStats };
