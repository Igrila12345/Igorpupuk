'use strict';

const economy = require('../game/economy');
const players = require('../db/players');
const calc = require('../game/calc');
const C = require('../game/constants');
const events = require('../game/events');
const quests = require('../game/quests');
const images = require('../game/commandImages');

async function handleBuild(ctx, qtyArg) {
  const vkId = ctx.senderId;
  const player = await players.getPlayer(vkId);
  if (!player || player.registration_step !== 'done') {
    await ctx.send('⛔ Вы ещё не зарегистрированы. Напишите !старт');
    return;
  }

  // VIP может построить чуть больше заводов одной командой — см. constants.js.
  const maxPerCommand = calc.isVipActive(player) ? C.FACTORY_BUILD_MAX_PER_COMMAND_VIP : C.FACTORY_BUILD_MAX_PER_COMMAND;

  let quantity = 1;
  if (qtyArg !== undefined && qtyArg !== null && String(qtyArg).trim() !== '') {
    const parsed = parseInt(qtyArg, 10);
    if (!Number.isInteger(parsed) || parsed < 1) {
      await ctx.send(`⛔ Некорректное количество. Формат: построить [количество, максимум ${maxPerCommand}]`);
      return;
    }
    quantity = parsed;
  }
  if (quantity > maxPerCommand) {
    await ctx.send(`⛔ За один раз можно построить не более ${maxPerCommand} заводов${calc.isVipActive(player) ? '' : ` (с VIP — до ${C.FACTORY_BUILD_MAX_PER_COMMAND_VIP})`}.`);
    return;
  }

  const result = await economy.buildFactory(vkId, quantity);

  if (!result.ok) {
    if (result.reason === 'max_reached') {
      await ctx.send(`⛔ У вас уже максимум заводов (${result.max}). Расширьте лимит: лимит расширить`);
    } else if (result.reason === 'build_limit') {
      await ctx.send(`⛔ Лимит постройки заводов: не более ${result.limit} в час. Попробуйте позже.`);
    } else if (result.reason === 'not_enough_money') {
      await ctx.send(
        `⛔ Недостаточно вирт. Цена завода: ${calc.formatNumber(result.price)}, не хватает ${calc.formatNumber(
          result.missing
        )}.`
      );
    } else {
      await ctx.send('⛔ Не удалось построить завод.');
    }
    return;
  }

  let text = `🏭 Построено заводов: ${result.built} за ${calc.formatNumber(result.totalSpent)} вирт!`;
  if (result.isSunday) {
    text += `\n🎉 Воскресная распродажа: -${Math.round(C.SUNDAY_FACTORY_DISCOUNT * 100)}% к цене (сэкономлено ${calc.formatNumber(
      result.totalDiscount
    )} вирт), лимит построек в час x${C.SUNDAY_FACTORY_BUILD_LIMIT_MULTIPLIER}.`;
  }
  if (result.goldMinesBuilt > 0) {
    text += `\n✨ Из них «Золотая жила» (доход x2): ${result.goldMinesBuilt}.`;
  }
  if (result.stoppedEarly) {
    const stopReasons = {
      max_reached: 'достигнут максимум заводов',
      build_limit: `лимит ${C.FACTORY_BUILD_LIMIT_PER_HOUR} построек в час`,
      not_enough_money: 'закончились вирты',
    };
    text += `\n⚠️ Построено меньше запрошенного (${result.requested}): ${stopReasons[result.stoppedEarly] || 'лимит'}.`;
  }

  // Сезонный ивент: один дроп на всю команду постройки (не за каждый завод), чтобы валюта
  // не начислялась непропорционально при постройке нескольких заводов одной командой.
  const drop = await events.awardDrop(vkId);
  text += events.dropSuffix(drop);

  const questNotices = await quests.trackProgress(vkId, 'factory_build', result.built);
  if (questNotices.length) text += `\n\n${questNotices.join('\n')}`;

  await ctx.send(images.withImage('build', text));
}

async function handleUnblock(ctx) {
  // Блокировка заводов как игровая механика отключена — атаки больше не блокируют заводы,
  // поэтому и разблокировать нечего. Команда оставлена как заглушка для старых привычек игроков.
  await ctx.send('ℹ️ Блокировка заводов отключена. Атаки теперь бьют по заводам напрямую, разблокировать нечего.');
}

async function handleDailyBonus(ctx) {
  const vkId = ctx.senderId;
  const player = await players.getPlayer(vkId);
  if (!player || player.registration_step !== 'done') {
    await ctx.send('⛔ Вы ещё не зарегистрированы. Напишите !старт');
    return;
  }

  const now = Date.now();
  if (player.last_daily_bonus) {
    const elapsed = now - new Date(player.last_daily_bonus).getTime();
    if (elapsed < C.DAILY_BONUS_COOLDOWN_MS) {
      const remaining = C.DAILY_BONUS_COOLDOWN_MS - elapsed;
      await ctx.send(`⛔ Ежедневный бонус уже получен. Следующий через: ${calc.formatDuration(remaining)}.`);
      return;
    }
  }

  await players.updateBalance(vkId, C.DAILY_BONUS_AMOUNT);
  await players.setLastDailyBonus(vkId, new Date());

  const drop = await events.awardDrop(vkId);
  await ctx.send(
    images.withImage(
      'bonus',
      `🎁 Ежедневный бонус получен: +${C.DAILY_BONUS_AMOUNT} вирт! Возвращайтесь через 24 часа.${events.dropSuffix(
        drop
      )}`
    )
  );
}

async function handleTransfer(ctx, targetId, amountArg) {
  const vkId = ctx.senderId;
  const player = await players.getPlayer(vkId);
  if (!player || player.registration_step !== 'done') {
    await ctx.send('⛔ Вы ещё не зарегистрированы. Напишите !старт');
    return;
  }

  if (!targetId) {
    await ctx.send('⛔ Формат: !перевод @юзер [сумма]');
    return;
  }

  if (targetId === vkId) {
    await ctx.send('⛔ Нельзя переводить вирты самому себе.');
    return;
  }

  const amount = parseInt(amountArg, 10);
  if (!Number.isInteger(amount) || amount < C.TRANSFER_MIN_AMOUNT) {
    await ctx.send(`⛔ Минимальная сумма перевода: ${C.TRANSFER_MIN_AMOUNT} вирт.`);
    return;
  }

  const target = await players.getPlayer(targetId);
  if (!target || target.registration_step !== 'done') {
    await ctx.send('⛔ Этот игрок не зарегистрирован.');
    return;
  }

  if (Number(player.balance) < amount) {
    await ctx.send(`⛔ Недостаточно вирт. Не хватает ${calc.formatNumber(amount - Number(player.balance))}.`);
    return;
  }

  const playersDb = require('../db/players');
  const transfersDb = require('../db/transfers');

  const lastTransfer = await transfersDb.getCooldown(vkId, targetId);
  if (lastTransfer) {
    const elapsed = Date.now() - new Date(lastTransfer).getTime();
    if (elapsed < C.TRANSFER_COOLDOWN_MS) {
      await ctx.send(
        `⛔ Этому игроку можно переводить вирты раз в 2 часа. Осталось: ${calc.formatDuration(
          C.TRANSFER_COOLDOWN_MS - elapsed
        )}.`
      );
      return;
    }
  }

  await playersDb.updateBalance(vkId, -amount);
  const commission = Math.floor((amount * C.TRANSFER_COMMISSION_PERCENT) / 100);
  const received = amount - commission;
  await playersDb.updateBalance(targetId, received);
  await transfersDb.setCooldown(vkId, targetId);

  const msg = require('../utils/messages');
  await ctx.send(
    images.withImage(
      'transfer',
      `✅ Переведено ${calc.formatNumber(amount)} вирт государству «${msg.mentionLink(targetId, target.state_name)}».\n` +
        `💸 Комиссия за перевод ${C.TRANSFER_COMMISSION_PERCENT}%: ${calc.formatNumber(commission)} вирт.\n` +
        `📥 Получатель получил: ${calc.formatNumber(received)} вирт.`
    )
  );
  if (ctx.bot) {
    await ctx.bot
      .notifyUser(
        targetId,
        `💸 «${msg.mentionLink(vkId, player.state_name)}» перевёл(а) вам ${calc.formatNumber(
          amount
        )} вирт (комиссия ${C.TRANSFER_COMMISSION_PERCENT}%), зачислено ${calc.formatNumber(received)} вирт.`
      )
      .catch(() => {});
  }
}

async function handleFactoryUpgradeStatus(ctx) {
  const vkId = ctx.senderId;
  const player = await players.getPlayer(vkId);
  if (!player || player.registration_step !== 'done') {
    await ctx.send('⛔ Вы ещё не зарегистрированы. Напишите !старт');
    return;
  }

  const level = calc.factoryUpgradeLevel(player);
  const bonusPercent = Math.round(level * C.FACTORY_UPGRADE_INCOME_BONUS_PER_LEVEL * 100);

  let text = `⚙️ ПРОКАЧКА ЗАВОДОВ\n\nТекущий уровень: ${level}/${C.FACTORY_UPGRADE_MAX_LEVEL}\nБонус к доходу с заводов: +${bonusPercent}%\n`;
  if (level >= C.FACTORY_UPGRADE_MAX_LEVEL) {
    text += '\n🏆 Максимальный уровень уже достигнут!';
  } else {
    const cost = calc.factoryUpgradeCost(level);
    const nextBonus = Math.round((level + 1) * C.FACTORY_UPGRADE_INCOME_BONUS_PER_LEVEL * 100);
    text += `\nСледующий уровень (${level + 1}): ${calc.formatNumber(cost)} вирт, бонус станет +${nextBonus}%.\nКупить: прокачка купить`;
  }

  await ctx.send(images.withImage('build', text));
}

async function handleFactoryUpgrade(ctx) {
  const vkId = ctx.senderId;
  const player = await players.getPlayer(vkId);
  if (!player || player.registration_step !== 'done') {
    await ctx.send('⛔ Вы ещё не зарегистрированы. Напишите !старт');
    return;
  }

  const result = await economy.upgradeFactory(vkId);
  if (!result.ok) {
    if (result.reason === 'max_level') {
      await ctx.send(`⛔ Уже максимальный уровень прокачки заводов (${C.FACTORY_UPGRADE_MAX_LEVEL}).`);
    } else if (result.reason === 'not_enough_money') {
      await ctx.send(
        `⛔ Недостаточно вирт. Нужно ${calc.formatNumber(result.cost)}, не хватает ${calc.formatNumber(
          result.missing
        )}.`
      );
    } else {
      await ctx.send('⛔ Не удалось прокачать. Попробуйте ещё раз.');
    }
    return;
  }

  await ctx.send(
    images.withImage(
      'build',
      `✅ Прокачка заводов: уровень ${result.newLevel}/${C.FACTORY_UPGRADE_MAX_LEVEL}! Бонус к доходу с заводов: +${Math.round(
        result.bonusPercent
      )}%. Потрачено: ${calc.formatNumber(result.cost)} вирт.`
    )
  );
}

module.exports = {
  handleBuild,
  handleUnblock,
  handleDailyBonus,
  handleTransfer,
  handleFactoryUpgradeStatus,
  handleFactoryUpgrade,
};
