'use strict';

const { Pool, types } = require('pg');
const fs = require('fs');
const path = require('path');

// ВАЖНО (исправление бага со счётчиком "работы"): по умолчанию node-postgres парсит
// колонки типа DATE в JS Date на полночь ПО ЛОКАЛЬНОМУ ВРЕМЕНИ СЕРВЕРА, а не по UTC.
// Если сервер бота работает в часовом поясе восточнее UTC (например, МСК, UTC+3),
// то `new Date(work_day).toISOString().slice(0, 10)` может вернуть ВЧЕРАШНЮЮ дату —
// из-за этого game/work.js каждый раз думал, что наступил новый день, обнулял
// work_count_today и счётчик попыток работы никогда не накапливался (игрок делал
// 10 "смен", а бот всё равно показывал 39/40, а не 30/40). Отключаем парсинг DATE
// в объект Date и возвращаем его как обычную строку 'YYYY-MM-DD' — так сравнение
// с todayStr() (тоже строка) больше не зависит от часового пояса процесса.
types.setTypeParser(1082, (value) => value);

// ВАЖНО (частая причина "всё тормозит под нагрузкой"): без явного `max` node-postgres
// открывает не больше 10 одновременных соединений к БД. Каждая команда игрока — это
// минимум один SQL-запрос, а часовой тик (game/economy.js: hourlyTick) и синхронизация
// лайков идут по ВСЕМ активным игрокам последовательно с несколькими await-запросами
// на каждого. При десятках одновременных игроков (особенно в момент, когда одна из
// фоновых cron-задач ещё не закончилась) запросы начинают ждать свободное соединение
// в очереди — снаружи это выглядит как "команда обрабатывается очень долго", хотя ни
// БД, ни бот не подвисли, просто исчерпан пул. Поднимаем лимит и делаем его настраиваемым
// через переменную окружения на случай слабого/мощного инстанса Postgres.
const POOL_MAX = Math.max(1, Number(process.env.DB_POOL_SIZE) || 20);

// ВАЖНО (исправление обрывов "Connection terminated unexpectedly" после переезда с Neon
// на свой сервер): раньше SSL был включён всегда (это было обязательно для Neon). Но
// локальный Postgres (localhost/127.0.0.1/::1), в отличие от Neon, по умолчанию SSL вообще
// не поддерживает — попытка договориться о защищённом соединении с таким сервером иногда
// проходит "наполовину" и рвётся в самый неожиданный момент под нагрузкой, что выглядело
// как случайные обрывы соединений с БД. Включаем SSL только тогда, когда БД не локальная
// (например, всё ещё Neon или другой облачный провайдер) — так один и тот же код одинаково
// корректно работает и на Neon, и после переезда на свой сервер.
function isLocalDatabaseUrl(connectionString) {
  if (!connectionString) return false;
  try {
    const { hostname } = new URL(connectionString);
    return hostname === 'localhost' || hostname === '127.0.0.1' || hostname === '::1';
  } catch (_err) {
    return false;
  }
}

const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: isLocalDatabaseUrl(process.env.DATABASE_URL) ? false : { rejectUnauthorized: false },
  max: POOL_MAX,
  idleTimeoutMillis: 30000,
  connectionTimeoutMillis: 10000,
});

pool.on('error', (err) => {
  console.error('[DB] Неожиданная ошибка пула соединений:', err);
});

async function initSchema() {
  const schemaPath = path.join(__dirname, 'schema.sql');
  const sql = fs.readFileSync(schemaPath, 'utf8');
  await pool.query(sql);
  console.log('[DB] Схема базы данных инициализирована.');
}

async function query(text, params) {
  return pool.query(text, params);
}

module.exports = { pool, query, initSchema };
