'use strict';

const { query } = require('./pool');

// Лог каждой завершённой раздачи блэкджека — тот же приём, что и casino_spins в
// db/casino.js: и дебаг-лог, и источник для топа/статистики. outcome — одно из
// 'win' | 'blackjack' | 'push' | 'lose' (см. game/blackjack.js: finishHand).
async function insertBlackjackHand(vkId, bet, win, outcome, playerCards, dealerCards) {
  const net = win - bet;
  await query(
    'INSERT INTO blackjack_hands (vk_id, bet, win, net, outcome, player_cards, dealer_cards) VALUES ($1, $2, $3, $4, $5, $6, $7)',
    [vkId, bet, win, net, outcome, playerCards, dealerCards]
  );
}

// day/week/month — те же календарные периоды по МСК, что и в db/casino.js: getTopWinners
// (см. комментарий там про date_trunc + 'Europe/Moscow'). Топ считается по SUM(win) —
// проигрыши на него не влияют, ровно как и у слотов, чтобы оба топа казино вели себя
// одинаково предсказуемо.
const PERIOD_UNITS = { day: 'day', week: 'week', month: 'month' };

async function getTopWinners(period, limit = 10) {
  if (period === 'all') {
    const res = await query(
      `SELECT bh.vk_id, p.state_name, SUM(bh.win)::BIGINT AS total_win
       FROM blackjack_hands bh
       JOIN players p ON p.vk_id = bh.vk_id
       WHERE bh.win > 0
       GROUP BY bh.vk_id, p.state_name
       ORDER BY total_win DESC
       LIMIT $1`,
      [limit]
    );
    return res.rows;
  }

  const unit = PERIOD_UNITS[period];
  if (!unit) throw new Error(`Unknown blackjack top period: ${period}`);

  const res = await query(
    `SELECT bh.vk_id, p.state_name, SUM(bh.win)::BIGINT AS total_win
     FROM blackjack_hands bh
     JOIN players p ON p.vk_id = bh.vk_id
     WHERE bh.win > 0
       AND bh.created_at >= (date_trunc($1, now() AT TIME ZONE 'Europe/Moscow') AT TIME ZONE 'Europe/Moscow')
     GROUP BY bh.vk_id, p.state_name
     ORDER BY total_win DESC
     LIMIT $2`,
    [unit, limit]
  );
  return res.rows;
}

// Личная статистика игрока по блэкджеку (для "!казино блекджек статус") — сколько
// раздано раздач всего/сегодня, сколько поставлено/выиграно, чистый итог.
async function getPlayerStats(vkId) {
  const totalRes = await query(
    `SELECT COUNT(*)::INT AS hands,
            COALESCE(SUM(bet), 0)::BIGINT AS total_bet,
            COALESCE(SUM(win), 0)::BIGINT AS total_win,
            COALESCE(SUM(net), 0)::BIGINT AS total_net
     FROM blackjack_hands
     WHERE vk_id = $1`,
    [vkId]
  );
  const todayRes = await query(
    `SELECT COALESCE(SUM(win), 0)::BIGINT AS today_win,
            COALESCE(SUM(bet), 0)::BIGINT AS today_bet
     FROM blackjack_hands
     WHERE vk_id = $1
       AND created_at >= (date_trunc('day', now() AT TIME ZONE 'Europe/Moscow') AT TIME ZONE 'Europe/Moscow')`,
    [vkId]
  );
  return { ...totalRes.rows[0], ...todayRes.rows[0] };
}

module.exports = { insertBlackjackHand, getTopWinners, getPlayerStats };
