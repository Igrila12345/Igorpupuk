'use strict';

// Скрипт для Termux: начисляет игрокам по 125 заводов и 125 научных центров.
// Запуск из корня проекта (там, где index.js и .env):
//   node scripts/give-resources.js

require('dotenv').config();
const { pool } = require('../db/pool');

// ⚠️ Впиши сюда VK ID игроков, которым нужно выдать ресурсы
const PLAYER_IDS = [
  636650478,   // Саша Семёнов
  593044752,   // Stas Stas
  1117375544,  // Шадоу Fiend
  1091398294,  // Gret Kito
  804638109,   // Эвелина Савицкая
  563044208,   // Vlad Fiestov
  1124122258,  // Zefir Zefir
  1121606427,  // Pol Lop
  200001908920, // Zefir Zefir
];

const FACTORIES_TO_GIVE = 125;
const SCIENCE_TO_GIVE = 125;

async function main() {
  if (!PLAYER_IDS.length) {
    console.log('Список PLAYER_IDS пуст — нечего выдавать.');
    return;
  }

  const { rows } = await pool.query(
    `UPDATE players
        SET factories = factories + $2,
            science_centers = COALESCE(science_centers, 0) + $3
      WHERE vk_id = ANY($1::bigint[])
      RETURNING vk_id, factories, science_centers`,
    [PLAYER_IDS, FACTORIES_TO_GIVE, SCIENCE_TO_GIVE]
  );

  const found = new Set(rows.map((r) => Number(r.vk_id)));
  const missing = PLAYER_IDS.filter((id) => !found.has(Number(id)));

  console.log(`Обновлено игроков: ${rows.length} из ${PLAYER_IDS.length}`);
  for (const r of rows) {
    console.log(`  vk_id=${r.vk_id} -> заводы: ${r.factories}, наука: ${r.science_centers}`);
  }

  if (missing.length) {
    console.log('Не найдены в базе (проверь ID):', missing.join(', '));
  }
}

main()
  .catch((err) => {
    console.error('Ошибка при выдаче ресурсов:', err);
    process.exitCode = 1;
  })
  .finally(() => {
    pool.end();
  });
