'use strict';
/* Собирает public/index.html из src/: стили, иконки, ядро игры и интерфейс в одном файле.
   node tools/build.js         обычная сборка (читаемый код, для разработки)
   node tools/build.js --prod  боевая сборка: код клиента обфусцирован и сжат (tools/obfuscate.js) */
const fs=require('node:fs'),path=require('node:path');
const root=path.join(__dirname,'..');
const prod=process.argv.includes('--prod');
const {obfuscate}=require('./obfuscate.js');
const r=f=>{
  const s=fs.readFileSync(path.join(root,'src',f),'utf8');
  return prod&&f.endsWith('.js')?obfuscate(s,{seed:process.env.OBF_SEED||''}):s;
};
const body=`<div id="sky"></div>
<div id="app">
  <header class="hud" id="hdr"></header>
  <main id="page"></main>
</div>
<nav id="tabs"><div class="in" id="tabin"></div></nav>
<div id="back" data-act="close"></div>
<div id="sheet" role="dialog" aria-modal="true"></div>
<div id="toasts" aria-live="polite"></div>
`;
const out=r('head.html')+r('icons.svg.html')+'\n'+body+
`\n<script>window.STELLAR_API=window.STELLAR_API||"";</script>
<script src="https://cdn.jsdelivr.net/npm/@vkontakte/vk-bridge@2/dist/browser.min.js"></script>
<script id="sign">
/* Content-Sign: HMAC-SHA256 на чистом JS. */
${r('sign.js')}
</script>
<script id="core">
/* Ядро игры: формулы и правила. Тот же файл (src/core.js) выполняется на сервере. */
${r('core.js')}
</script>
<script id="ui">
${r('ui.js')}
</script>
</body>
</html>
`;
fs.mkdirSync(path.join(root,'public'),{recursive:true});
fs.writeFileSync(path.join(root,'public','index.html'),out);
console.log('public/index.html',out.length,'bytes',prod?'(obfuscated)':'(readable)');
