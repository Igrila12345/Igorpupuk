/* Content-Sign: подпись запросов HMAC-SHA256 на чистом JS (без WebCrypto, работает и по http).
   Тот же файл проверяется тестами на совпадение с криптографией Node.js, сервер считает подпись независимо. */
const Sign=(function(){
'use strict';
const K=new Uint32Array(64),H0=new Uint32Array(8);
(function init(){
  const primes=[];for(let n=2;primes.length<64;n++){let ok=true;for(const p of primes){if(p*p>n)break;if(n%p===0){ok=false;break;}}if(ok)primes.push(n);}
  const frac=x=>Math.floor((x-Math.floor(x))*4294967296)>>>0;
  for(let i=0;i<64;i++)K[i]=frac(Math.cbrt(primes[i]));
  for(let i=0;i<8;i++)H0[i]=frac(Math.sqrt(primes[i]));
})();
const rotr=(x,n)=>(x>>>n)|(x<<(32-n));
function sha256(data){
  const l=data.length,bits=l*8,padLen=((l+9+63)>>6)<<6,buf=new Uint8Array(padLen);
  buf.set(data);buf[l]=0x80;
  const dv=new DataView(buf.buffer);
  dv.setUint32(padLen-8,Math.floor(bits/4294967296));dv.setUint32(padLen-4,bits>>>0);
  const h=Uint32Array.from(H0),w=new Uint32Array(64);
  for(let off=0;off<padLen;off+=64){
    for(let i=0;i<16;i++)w[i]=dv.getUint32(off+i*4);
    for(let i=16;i<64;i++){
      const a=w[i-15],b=w[i-2];
      const s0=rotr(a,7)^rotr(a,18)^(a>>>3),s1=rotr(b,17)^rotr(b,19)^(b>>>10);
      w[i]=(w[i-16]+s0+w[i-7]+s1)>>>0;
    }
    let a=h[0],b=h[1],c=h[2],d=h[3],e=h[4],f=h[5],g=h[6],hh=h[7];
    for(let i=0;i<64;i++){
      const S1=rotr(e,6)^rotr(e,11)^rotr(e,25),ch=(e&f)^(~e&g),t1=(hh+S1+ch+K[i]+w[i])>>>0;
      const S0=rotr(a,2)^rotr(a,13)^rotr(a,22),maj=(a&b)^(a&c)^(b&c),t2=(S0+maj)>>>0;
      hh=g;g=f;f=e;e=(d+t1)>>>0;d=c;c=b;b=a;a=(t1+t2)>>>0;
    }
    h[0]=(h[0]+a)>>>0;h[1]=(h[1]+b)>>>0;h[2]=(h[2]+c)>>>0;h[3]=(h[3]+d)>>>0;
    h[4]=(h[4]+e)>>>0;h[5]=(h[5]+f)>>>0;h[6]=(h[6]+g)>>>0;h[7]=(h[7]+hh)>>>0;
  }
  const out=new Uint8Array(32),ov=new DataView(out.buffer);
  for(let i=0;i<8;i++)ov.setUint32(i*4,h[i]);
  return out;
}
function hmac(key,msg){
  if(key.length>64)key=sha256(key);
  const ip=new Uint8Array(64+msg.length),op=new Uint8Array(96);
  for(let i=0;i<64;i++){const k=i<key.length?key[i]:0;ip[i]=k^0x36;op[i]=k^0x5c;}
  ip.set(msg,64);op.set(sha256(ip),64);
  return sha256(op);
}
const utf8=s=>new TextEncoder().encode(s);
const hex=b=>Array.from(b,x=>x.toString(16).padStart(2,'0')).join('');
const ALPHA='ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_';
function b64url(b){
  let o='',i=0;
  for(;i+2<b.length;i+=3){const n=(b[i]<<16)|(b[i+1]<<8)|b[i+2];o+=ALPHA[n>>18]+ALPHA[(n>>12)&63]+ALPHA[(n>>6)&63]+ALPHA[n&63];}
  if(i+1===b.length){const n=b[i]<<16;o+=ALPHA[n>>18]+ALPHA[(n>>12)&63];}
  else if(i+2===b.length){const n=(b[i]<<16)|(b[i+1]<<8);o+=ALPHA[n>>18]+ALPHA[(n>>12)&63]+ALPHA[(n>>6)&63];}
  return o;
}
function fromB64url(s){
  const out=[];let acc=0,bits=0;
  for(const ch of s){const v=ALPHA.indexOf(ch);if(v<0)continue;acc=(acc<<6)|v;bits+=6;if(bits>=8){bits-=8;out.push((acc>>bits)&255);}}
  return new Uint8Array(out);
}
/* Что именно подписывается: метод, путь, время, одноразовое число и SHA-256 тела запроса */
function canonical(method,path,ts,nonce,body){return method+'\n'+path+'\n'+ts+'\n'+nonce+'\n'+hex(sha256(utf8(body)));}
function sign(keyB64,method,path,ts,nonce,body){return b64url(hmac(fromB64url(keyB64),utf8(canonical(method,path,ts,nonce,body))));}
function nonce(){const a=new Uint8Array(16);(globalThis.crypto||{getRandomValues(x){for(let i=0;i<x.length;i++)x[i]=Math.floor(Math.random()*256);return x;}}).getRandomValues(a);return hex(a);}
return {sha256,hmac,utf8,hex,b64url,fromB64url,canonical,sign,nonce};
})();
if(typeof module!=='undefined'&&module.exports)module.exports=Sign;
