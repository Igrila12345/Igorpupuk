const fs=require('fs'),f='/opt/server.js';let s=fs.readFileSync(f,'utf8');
if(s.includes('  setPrice(a)')){console.log('уже применён');process.exit(0)}
fs.writeFileSync(f+'.bak_setprice',s);
const k="  setBalance(a) {";
if(!s.includes(k)){console.log('НЕ НАЙДЕНО');process.exit(1)}
s=s.replace(k,"  setPrice(a) { const u = getUser(a.id); if (!u) return ERR('Игрок не найден'); u.price = num(a.value, 1, MAX, 100); touch(); return { ok: true, value: u.price }; },\n"+k);
fs.writeFileSync(f,s);console.log('применён');
