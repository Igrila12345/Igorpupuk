'use strict';

const players = require('../db/players');
const production = require('../db/production');
const calc = require('../game/calc');
const msg = require('../utils/messages');
const C = require('../game/constants');
const images = require('../game/commandImages');
const economy = require('../game/economy');
const globalBoost = require('../game/globalBoost');
const business = require('../game/business');
const donateBusiness = require('../game/donateBusiness');

const NAME_REGEX = /^[a-zA-Zа-яА-ЯёЁ0-9 ]{2,30}$/;

async function handleStart(ctx) {
  const vkId = ctx.senderId;
  let player = await players.getPlayer(vkId);

  if (!player) {
    player = await players.createPlayerStub(vkId);
    await ctx.send(
      images.withImage('start', {
        message:
          `🏛️ Добро пожаловать, Командир!\n` +
          `Ваш народ ждёт великих свершений. Дайте название вашему государству (городу/империи):\n` +
          `- От 2 до 30 символов\n` +
          `- Только буквы, цифры и пробелы`,
      })
    );
    return;
  }

  if (player.registration_step === 'awaiting_name') {
    await ctx.send('✅ Вы уже начали регистрацию. Напишите название вашего государства сообщением.');
    return;
  }

  await ctx.send(
    images.withImage('start', `👋 С возвращением, «${player.state_name}»! Введите !помощь для списка команд.`)
  );
}

async function handleNameInput(ctx) {
  const vkId = ctx.senderId;
  const player = await players.getPlayer(vkId);
  if (!player || player.registration_step !== 'awaiting_name') return false;

  const name = ctx.text.trim();

  if (!NAME_REGEX.test(name)) {
    await ctx.send(
      '⛔ Название должно быть от 2 до 30 символов и содержать только буквы, цифры и пробелы. Попробуйте снова.'
    );
    return true;
  }

  const existing = await players.getPlayerByName(name);
  if (existing) {
    await ctx.send('⛔ Это название уже занято. Придумайте другое.');
    return true;
  }

  const updated = await players.finalizeRegistration(vkId, name);

  await ctx.send(
    `✅ Отлично! Государство «${updated.state_name}» основано!\n` +
      `📍 Ваши координаты на карте: (${updated.x}, ${updated.y})\n` +
      `🎁 Вам выдано ${C.START_BALANCE} вирт и ${C.STARTER_FREE_FACTORIES} заводов в подарок!\n` +
      `🚀 Пока «вес» (заводы + наука×${C.NEWBIE_BOOST_SCIENCE_FACTORY_EQUIV}) меньше ${C.NEWBIE_BOOST_FACTORY_THRESHOLD} — у вас повышенный доход с заводов, чтобы легче догнать остальных. Бонус пропадает НАВСЕГДА при достижении порога (это НЕ защита от атак — см. !помощь → «Бой»).\n` +
      `\n📚 КРАТКАЯ ИНСТРУКЦИЯ:\n` +
      `🏭 !построить — построить завод (стоимость зависит от количества)\n` +
      `🏪 !магазин — купить оружие и ПВО\n` +
      `⚔️ !атака @юзер [оружие] [количество] — атаковать игрока\n` +
      `🏭 !произвести [оружие] [количество] [заводов] — производить оружие\n` +
      `👷 !работа — мини-игра на жетоны (можно 40 раз в день)\n` +
      `💰 !профиль — посмотреть свою статистику\n` +
      `👥 !клан создать [название] — создать клан\n\n` +
      `Удачи в бою, Командир!`
  );
  return true;
}

async function handleProfile(ctx, targetId) {
  const vkId = targetId || ctx.senderId;
  const player = await players.getPlayer(vkId);

  if (!player || player.registration_step !== 'done') {
    await ctx.send(targetId ? '⛔ Этот игрок ещё не зарегистрирован.' : '⛔ Вы ещё не зарегистрированы. Напишите !старт');
    return;
  }

  const factoriesInProd = await production.getFactoriesInUse(vkId);

  // Полная цепочка бонусов дохода (глобальный буст / индустриализация клана / зоны клана) —
  // ТА ЖЕ функция, что использует реальное почасовое начисление (game/economy.js:
  // hourlyTick), чтобы показанная цифра дохода гарантированно совпадала с тем, что
  // реально капает на баланс, и чтобы был виден именно бонус зон (изначальный запрос).
  const boost = await globalBoost.getBoost();
  const globalMult = boost ? Number(boost.multiplier) : 1;
  const incomeBreakdown = await economy.computeIncomeBreakdown(player, factoriesInProd, globalMult);
  const income = incomeBreakdown.total;

  // Доход с бизнесов — отдельная система накопления (см. game/business.js), не входит в
  // почасовое начисление выше. Считаем только по бизнесам, у которых сейчас не кончилось
  // сырьё (live.stockActive) — простаивающий бизнес не приносит дохода прямо сейчас.
  const myBusinesses = await business.listMy(vkId);
  const businessFactoryMult = business.getFactoryMultiplier(player.factories);
  const businessIncomePerHour = myBusinesses.reduce(
    (sum, entry) => sum + (entry.live.stockActive ? entry.live.rate * businessFactoryMult : 0),
    0
  );

  // Доход с донат-бизнесов (game/donateBusiness.js) — отдельная от почасового начисления
  // выше система (тоже капает на баланс каждый час, но своим тиком), раньше нигде не
  // попадала в "Итого доход" в профиле. Оценка — среднее по диапазону тира * уровень слота.
  const donateBusinessIncomePerHour = await donateBusiness.estimateHourlyIncome(vkId);

  const factoryRank = await players.getFactoryRank(vkId);

  // incomeBreakdown.clanRow уже содержит клан игрока (см. economy.computeIncomeBreakdown
  // выше) — переиспользуем вместо повторного похода в БД за тем же кланом.
  let clanName = null;
  let clanVaultContribution = 0;
  if (player.clan_id) {
    clanName = incomeBreakdown.clanRow ? incomeBreakdown.clanRow.name : null;
    clanVaultContribution = Math.round(income * C.CLAN_VAULT_INCOME_RATE);
  }

  const text = msg.profileMessage(player, income, clanName, factoryRank, clanVaultContribution, {
    globalMult: incomeBreakdown.globalMult,
    industrializationActive: incomeBreakdown.industrializationActive,
    zoneBonusPct: incomeBreakdown.zoneBonusPct,
    businessIncomePerHour: Math.round(businessIncomePerHour),
    donateBusinessIncomePerHour,
  });

  // Кастомное фото/видео профиля, выданное админом (см. !админ фото / !админ видео).
  // Если заданы оба — показываем фото (приоритетнее видео).
  const profileAttachment = player.profile_photo || player.profile_video || null;

  if (profileAttachment) {
    await ctx.send({ message: text, attachment: profileAttachment });
  } else {
    await ctx.send(text);
  }
}

async function handleRename(ctx, newName) {
  const vkId = ctx.senderId;
  const player = await players.getPlayer(vkId);
  if (!player || player.registration_step !== 'done') {
    await ctx.send('⛔ Вы ещё не зарегистрированы. Напишите !старт');
    return;
  }

  if (!newName || !NAME_REGEX.test(newName)) {
    await ctx.send('⛔ Название должно быть от 2 до 30 символов (буквы, цифры, пробелы).');
    return;
  }

  if (Number(player.balance) < C.RENAME_COST) {
    await ctx.send(`⛔ Недостаточно вирт. Нужно ${C.RENAME_COST}, у вас ${calc.formatNumber(player.balance)}.`);
    return;
  }

  const existing = await players.getPlayerByName(newName);
  if (existing) {
    await ctx.send('⛔ Это название уже занято.');
    return;
  }

  await players.updateBalance(vkId, -C.RENAME_COST);
  await players.renamePlayer(vkId, newName);
  await ctx.send(images.withImage('rename', `✅ Государство переименовано в «${newName}»!`));
}

// Красиво показывает VK ID игрока: сам ID, его имя-фамилию из VK и прямую ссылку
// на профиль. Если targetId не передан — показывает данные отправителя команды.
async function handleId(ctx, targetId) {
  const vkId = targetId || ctx.senderId;

  if (!vkId || !Number.isFinite(Number(vkId))) {
    await ctx.send('⛔ Не удалось определить пользователя. Укажите упоминание, ссылку или ID: !ид @юзер');
    return;
  }

  let fullName = null;
  if (ctx.bot && ctx.bot.vk) {
    try {
      const res = await ctx.bot.vk.api.users.get({ user_ids: [vkId] });
      if (res && res[0] && !res[0].deactivated) {
        fullName = `${res[0].first_name} ${res[0].last_name}`.trim();
      } else if (res && res[0] && res[0].deactivated) {
        fullName = '💤 страница удалена/заблокирована';
      }
    } catch (err) {
      console.error('[Profile] Не удалось получить имя пользователя VK:', err.message);
    }
  }

  const lines = [
    '┏━━━━━━━━━━━━━━┓',
    `🆔 ID: ${vkId}`,
    `👤 ${fullName || 'Не удалось получить имя'}`,
    `🔗 Ссылка: vk.com/id${vkId}`,
    '┗━━━━━━━━━━━━━━┛',
  ];

  await ctx.send(lines.join('\n'));
}

module.exports = { handleStart, handleNameInput, handleProfile, handleRename, handleId, NAME_REGEX };
