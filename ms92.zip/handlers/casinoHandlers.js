'use strict';

const players = require('../db/players');
const casinoDb = require('../db/casino');
const casino = require('../game/casino');
const renderPool = require('../game/renderPool');
const calc = require('../game/calc');
const C = require('../game/constants');
const msg = require('../utils/messages');
const { uploadGifAsMessageDoc } = require('../utils/uploadImage');

async function requireRegistered(ctx) {
  const player = await players.getPlayer(ctx.senderId);
  if (!player || player.registration_step !== 'done') {
    await ctx.send('⛔ Вы ещё не зарегистрированы. Напишите !старт');
    return null;
  }
  return player;
}

function reasonMessage(reason, extra) {
  switch (reason) {
    case 'already_spinning':
      return '⏳ Барабаны ещё крутятся — дождитесь итога текущей партии, прежде чем запускать следующую.';
    case 'bad_bet':
      return `⛔ Укажите ставку числом. Например: !казино слот ${C.CASINO_MIN_BET}`;
    case 'bet_too_small':
      return `⛔ Минимальная ставка — ${calc.formatNumber(C.CASINO_MIN_BET)} вирт.`;
    case 'bet_too_big':
      return `⛔ Максимальная ставка — ${calc.formatNumber(C.CASINO_MAX_BET)} вирт.`;
    case 'not_enough_balance': {
      const balancePart = typeof extra === 'number' ? ` (у вас ${calc.formatNumber(extra)} вирт)` : '';
      return `⛔ Недостаточно вирт для такой ставки${balancePart}.`;
    }
    default:
      return '⛔ Не удалось запустить казино. Попробуйте ещё раз.';
  }
}

async function handleSlot(ctx, betArg) {
  const player = await requireRegistered(ctx);
  if (!player) return;

  if (!betArg) {
    await ctx.send(
      `🎰 КАЗИНО — СЛОТЫ\n` +
        `Ставка: от ${calc.formatNumber(C.CASINO_MIN_BET)} до ${calc.formatNumber(C.CASINO_MAX_BET)} вирт.\n` +
        `Команда: !казино слот <ставка>\n` +
        `Например: !казино слот 1000`
    );
    return;
  }

  const vkId = ctx.senderId;

  // Мгновенная проверка "уже крутится" — до похода в БД, чтобы спам той же командой не
  // создавал лишнюю нагрузку и не путал порядок сообщений (реальная защита — Set внутри
  // game/casino.js, эта проверка тут просто даёт мгновенный ответ без похода в БД).
  if (casino.isSpinning(vkId)) {
    await ctx.send(reasonMessage('already_spinning'));
    return;
  }

  // Результат считается сразу (без искусственного ожидания — см. game/casino.js), но
  // ТЕКСТ с итогом (выиграл/проиграл) отправляется ОТДЕЛЬНЫМ сообщением с задержкой
  // C.CASINO_SPIN_MS — ровно пока крутится гифка. Раньше caption уходил ВМЕСТЕ с
  // гифкой одним сообщением, а VK показывает текст сразу по приходу сообщения, не
  // дожидаясь конца анимации — то есть игрок видел "Выигрыш/Проигрыш" ДО того, как
  // барабаны на экране успевали остановиться. Теперь гифка уходит без подписи, а итог —
  // отдельным сообщением спустя время её реальной длительности.
  const result = await casino.spin(vkId, betArg);
  if (!result.ok) {
    await ctx.send(reasonMessage(result.reason, result.balance));
    return;
  }

  try {
    const buffer = await renderPool.renderCasino(result);
    const doc = await uploadGifAsMessageDoc(ctx.bot.vk, buffer, ctx.peerId);
    await ctx.send({ attachment: doc });
    await sleep(C.CASINO_SPIN_MS);
    await ctx.send(renderResultCaption(result));
  } catch (err) {
    console.error('[Casino] Не удалось отрисовать/загрузить анимацию, отправляю текстом:', err);
    await ctx.send(renderResultCaption(result, true));
  }
}

function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

function renderResultCaption(result, withReels) {
  const reelsLine = withReels ? `${result.reels.map((s) => s.label).join(' | ')}\n` : '';
  if (result.win > 0) {
    return (
      `${reelsLine}✅ Выигрыш ${calc.formatNumber(result.win)} вирт (ставка ${calc.formatNumber(result.bet)})!\n` +
      `💰 Баланс: ${calc.formatNumber(result.balance)} вирт`
    );
  }
  return (
    `${reelsLine}❌ Проигрыш ${calc.formatNumber(result.bet)} вирт.\n` + `💰 Баланс: ${calc.formatNumber(result.balance)} вирт`
  );
}

const PERIOD_LABELS = {
  day: 'ЗА ДЕНЬ',
  week: 'ЗА НЕДЕЛЮ',
  month: 'ЗА МЕСЯЦ',
  all: 'ЗА ВСЁ ВРЕМЯ',
};

const PERIOD_ALIASES = {
  день: 'day',
  сегодня: 'day',
  неделя: 'week',
  месяц: 'month',
  всё: 'all',
  все: 'all',
  всего: 'all',
};

async function handleTop(ctx, periodArg) {
  const period = PERIOD_ALIASES[(periodArg || 'all').toLowerCase()] || 'all';
  const list = await casinoDb.getTopWinners(period, 15);

  let text = `🎰 ТОП КАЗИНО — ${PERIOD_LABELS[period]}\n${msg.TOP_DIVIDER}\n\n`;
  if (list.length === 0) {
    text += 'Пока никто ничего не выиграл за этот период.\n';
  } else {
    list.forEach((row, i) => {
      const place = ['🥇', '🥈', '🥉'][i] || `${i + 1}.`;
      text += `${place} ${msg.mentionLink(row.vk_id, row.state_name)}\n     💰 ${calc.formatNumber(Number(row.total_win))} вирт\n\n`;
    });
  }
  text += `${msg.TOP_DIVIDER}\n`;
  if (period === 'day') {
    text += `🏆 В 00:00 МСК топ-3 этого дня получат награду: 30 000 / 20 000 / 10 000 вирт.\n`;
  }
  text += `Другие периоды: !казино топ день / неделя / месяц / всего`;
  await ctx.send(text.trim());
}

async function handleStatus(ctx) {
  const player = await requireRegistered(ctx);
  if (!player) return;
  const stats = await casinoDb.getPlayerStats(ctx.senderId);
  const threshold = await casinoDb.getTop15Threshold();

  const myWin = Number(stats.total_win);
  let top15Line;
  if (threshold === null) {
    // Топ ещё не заполнен 15 игроками с win>0 — свободное место уже есть, достаточно
    // любого ненулевого выигрыша (если он уже есть — игрок и так в топе).
    top15Line = myWin > 0 ? '🏅 Вы уже в топ-15 (места ещё свободны).' : '🏅 До топ-15: любой выигрыш — места ещё свободны.';
  } else if (myWin >= threshold) {
    top15Line = '🏅 Вы уже в топ-15 по выигрышам!';
  } else {
    top15Line = `🏅 До топ-15 не хватает: ${calc.formatNumber(threshold - myWin)} вирт выигрыша.`;
  }

  const text =
    `🎰 КАЗИНО\n` +
    `Ставка: от ${calc.formatNumber(C.CASINO_MIN_BET)} до ${calc.formatNumber(C.CASINO_MAX_BET)} вирт.\n\n` +
    `Сыграно партий всего: ${stats.spins}\n` +
    `Поставлено всего: ${calc.formatNumber(Number(stats.total_bet))} вирт\n` +
    `Выиграно всего: ${calc.formatNumber(myWin)} вирт\n` +
    `Итог с казино: ${Number(stats.total_net) >= 0 ? '+' : ''}${calc.formatNumber(Number(stats.total_net))} вирт\n\n` +
    `Сегодня: ставок на ${calc.formatNumber(Number(stats.today_bet))}, выиграно ${calc.formatNumber(Number(stats.today_win))}\n\n` +
    `${top15Line}\n\n` +
    `Команды:\n` +
    `!казино слот <ставка> — крутить (короткая форма: !слот <ставка>)\n` +
    `!казино топ [день/неделя/месяц/всего] — таблица лидеров по выигрышам\n\n` +
    `🃏 Также доступен блэкджек: !бж <ставка>`;
  await ctx.send(text);
}

module.exports = { handleSlot, handleTop, handleStatus };
