'use strict';

const players = require('../db/players');
const blackjackDb = require('../db/blackjack');
const blackjack = require('../game/blackjack');
const renderPool = require('../game/renderPool');
const calc = require('../game/calc');
const C = require('../game/constants');
const msg = require('../utils/messages');
const { uploadPngAsMessagePhoto } = require('../utils/uploadImage');

async function requireRegistered(ctx) {
  const player = await players.getPlayer(ctx.senderId);
  if (!player || player.registration_step !== 'done') {
    await ctx.send('⛔ Вы ещё не зарегистрированы. Напишите !старт');
    return null;
  }
  return player;
}

function reasonMessage(reason, extra) {
  switch (reason) {
    case 'already_playing':
      return '⏳ У вас уже есть незакрытая раздача — сначала возьмите карту (!хит) или остановитесь (!стенд).';
    case 'no_active_hand':
      return '⛔ У вас нет активной раздачи блэкджека. Начните новую: !бж <ставка>';
    case 'bad_bet':
      return `⛔ Укажите ставку числом. Например: !бж ${C.BLACKJACK_MIN_BET}`;
    case 'bet_too_small':
      return `⛔ Минимальная ставка — ${calc.formatNumber(C.BLACKJACK_MIN_BET)} вирт.`;
    case 'bet_too_big':
      return `⛔ Максимальная ставка — ${calc.formatNumber(C.BLACKJACK_MAX_BET)} вирт.`;
    case 'not_enough_balance': {
      const balancePart = typeof extra === 'number' ? ` (у вас ${calc.formatNumber(extra)} вирт)` : '';
      return `⛔ Недостаточно вирт для такой ставки${balancePart}.`;
    }
    default:
      return '⛔ Не удалось выполнить действие в блэкджеке. Попробуйте ещё раз.';
  }
}

// Общий хвост для старт/хит/стенд — рендерит стол и отправляет его НОВЫМ сообщением
// с фото (см. game/blackjackRender.js: renderTable). Именно это "фото меняется после
// ставки/хода" — каждое действие игрока даёт новую картинку стола, а не редактирует
// старую (VK API не позволяет менять уже отправленное фото в сообщении).
async function sendTable(ctx, result) {
  try {
    const buffer = await renderPool.renderBlackjack(result);
    const photo = await uploadPngAsMessagePhoto(ctx.bot.vk, buffer, ctx.peerId);
    await ctx.send({ attachment: photo, message: captionFor(result) });
  } catch (err) {
    console.error('[Blackjack] Не удалось отрисовать/загрузить фото стола, отправляю текстом:', err);
    await ctx.send(captionFor(result, true));
  }
}

function cardsToText(cards) {
  const suitLabel = { spades: '♠', hearts: '♥', diamonds: '♦', clubs: '♣' };
  return cards.map((c) => `${c.rank}${suitLabel[c.suit] || ''}`).join(' ');
}

function captionFor(result, withCards) {
  if (result.phase === 'turn') {
    const cardsPart = withCards ? `Ваши карты: ${cardsToText(result.playerCards)} (${result.playerTotal})\n` : '';
    return (
      `🃏 БЛЭКДЖЕК — раздача, ставка ${calc.formatNumber(result.bet)} вирт.\n` +
      cardsPart +
      `Дилер: одна карта в закрытую.\n` +
      `Ваш ход: !хит (взять карту) или !стенд (остановиться).`
    );
  }

  const OUTCOME_TEXT = {
    win: `✅ Победа! +${calc.formatNumber(result.win)} вирт`,
    blackjack: `🃏 БЛЭКДЖЕК! +${calc.formatNumber(result.win)} вирт (выплата 2:1)`,
    push: `🤝 Ничья (двойной блэкджек) — ставка ${calc.formatNumber(result.bet)} вирт возвращена`,
    lose: `❌ Поражение — -${calc.formatNumber(result.bet)} вирт`,
  };
  const cardsPart = withCards
    ? `Ваши карты: ${cardsToText(result.playerCards)} (${result.playerTotal})\n` +
      `Карты дилера: ${cardsToText(result.dealerCards)} (${result.dealerTotal})\n`
    : '';
  return `${cardsPart}${OUTCOME_TEXT[result.outcome] || OUTCOME_TEXT.lose}\n💰 Баланс: ${calc.formatNumber(result.balance)} вирт`;
}

async function handleStart(ctx, betArg) {
  const player = await requireRegistered(ctx);
  if (!player) return;

  if (!betArg) {
    await ctx.send(
      `🃏 КАЗИНО — БЛЭКДЖЕК\n` +
        `Ставка: от ${calc.formatNumber(C.BLACKJACK_MIN_BET)} до ${calc.formatNumber(C.BLACKJACK_MAX_BET)} вирт.\n` +
        `Блэкджек (21 с двух карт) платит 2:1, обычная победа — 1:1, ничья — тоже победа!\n` +
        `Команда: !бж <ставка>\n` +
        `Например: !бж 1000`
    );
    return;
  }

  if (blackjack.isBusy(ctx.senderId)) {
    await ctx.send(reasonMessage('already_playing'));
    return;
  }

  const result = await blackjack.start(ctx.senderId, betArg);
  if (!result.ok) {
    await ctx.send(reasonMessage(result.reason, result.balance));
    return;
  }

  result.playerName = player.state_name;
  await sendTable(ctx, result);
}

async function handleHit(ctx) {
  const player = await requireRegistered(ctx);
  if (!player) return;

  const result = await blackjack.hit(ctx.senderId);
  if (!result.ok) {
    await ctx.send(reasonMessage(result.reason));
    return;
  }

  result.playerName = player.state_name;
  await sendTable(ctx, result);
}

async function handleStand(ctx) {
  const player = await requireRegistered(ctx);
  if (!player) return;

  const result = await blackjack.stand(ctx.senderId);
  if (!result.ok) {
    await ctx.send(reasonMessage(result.reason));
    return;
  }

  result.playerName = player.state_name;
  await sendTable(ctx, result);
}

const PERIOD_LABELS = {
  day: 'ЗА ДЕНЬ',
  week: 'ЗА НЕДЕЛЮ',
  month: 'ЗА МЕСЯЦ',
  all: 'ЗА ВСЁ ВРЕМЯ',
};

const PERIOD_ALIASES = {
  день: 'day',
  сегодня: 'day',
  неделя: 'week',
  месяц: 'month',
  всё: 'all',
  все: 'all',
  всего: 'all',
};

async function handleTop(ctx, periodArg) {
  const period = PERIOD_ALIASES[(periodArg || 'all').toLowerCase()] || 'all';
  const list = await blackjackDb.getTopWinners(period, 10);

  let text = `🃏 ТОП БЛЭКДЖЕКА — ${PERIOD_LABELS[period]}\n${msg.TOP_DIVIDER}\n\n`;
  if (list.length === 0) {
    text += 'Пока никто ничего не выиграл за этот период.\n';
  } else {
    list.forEach((row, i) => {
      const place = ['🥇', '🥈', '🥉'][i] || `${i + 1}.`;
      text += `${place} ${msg.mentionLink(row.vk_id, row.state_name)}\n     💰 ${calc.formatNumber(Number(row.total_win))} вирт\n\n`;
    });
  }
  text += `${msg.TOP_DIVIDER}\nДругие периоды: !бж топ день / неделя / месяц / всего`;
  await ctx.send(text.trim());
}

async function handleStatus(ctx) {
  const player = await requireRegistered(ctx);
  if (!player) return;
  const stats = await blackjackDb.getPlayerStats(ctx.senderId);

  const text =
    `🃏 БЛЭКДЖЕК\n` +
    `Ставка: от ${calc.formatNumber(C.BLACKJACK_MIN_BET)} до ${calc.formatNumber(C.BLACKJACK_MAX_BET)} вирт.\n\n` +
    `Сыграно раздач всего: ${stats.hands}\n` +
    `Поставлено всего: ${calc.formatNumber(Number(stats.total_bet))} вирт\n` +
    `Выиграно всего: ${calc.formatNumber(Number(stats.total_win))} вирт\n` +
    `Итог: ${Number(stats.total_net) >= 0 ? '+' : ''}${calc.formatNumber(Number(stats.total_net))} вирт\n\n` +
    `Команды:\n` +
    `!бж <ставка> — начать раздачу\n` +
    `!хит — взять карту\n` +
    `!стенд — остановиться\n` +
    `!бж топ [день/неделя/месяц/всего] — таблица лидеров`;
  await ctx.send(text);
}

module.exports = { handleStart, handleHit, handleStand, handleTop, handleStatus };
