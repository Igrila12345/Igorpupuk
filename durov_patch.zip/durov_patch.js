const fs = require('fs'), path = require('path');
const dir = process.argv[2] || '/opt', f = path.join(dir, 'server.js');
let s = fs.readFileSync(f, 'utf8');
if (s.includes('const FIXED =')) { console.log('уже применён'); process.exit(0); }
const R = [
  ["const PUP_ID = 416999966, PUP_NAME = 'Василий Перун', PUP_IMG = '/assets/u/p1.jpg';\n",
   "const PUP_ID = 416999966, PUP_NAME = 'Василий Перун', PUP_IMG = '/assets/u/p1.jpg';\nconst FIXED = [{ id: 1, name: 'Павел Дуров', img: '/assets/u/d1.jpg' }];\nFIXED.forEach(f => { const ph = 'https://rab.89-23-115-251.sslip.io' + f.img; let u = getUser(f.id) || createUser(f.id, f.name, ph); u.pup = 1; u.name = f.name; u.photo = ph; });\n"],
  ["    if (p === PUP_IMG) {\n      try { const h = Object.assign({}, SEC, { 'Content-Type': 'image/jpeg', 'Cache-Control': 'public, max-age=86400' }); delete h['X-Frame-Options']; const d = fs.readFileSync(path.join(__dirname, 'assets', 'u', 'p1.jpg'));",
   "    const fx = p === PUP_IMG ? 'p1.jpg' : (FIXED.find(f => f.img === p) || {}).img && path.basename(p);\n    if (fx) {\n      try { const h = Object.assign({}, SEC, { 'Content-Type': 'image/jpeg', 'Cache-Control': 'public, max-age=86400' }); delete h['X-Frame-Options']; const d = fs.readFileSync(path.join(__dirname, 'assets', 'u', fx));"],
  ["const u = U[p.id]; if (u) { u.name", "const u = U[p.id]; if (u && !u.pup) { u.name"],
  ["const aid = me ? (+b.as === 1 ? CFG.admin : +b.as) : PUP_ID;\n  if (me && +b.as !== 1 && !A.includes(aid))",
   "const dur = b.as === 'durov', aid = me ? (dur ? 1 : +b.as === 1 ? CFG.admin : +b.as) : PUP_ID;\n  if (me && !dur && +b.as !== 1 && !A.includes(aid))"]
];
for (const [a, b] of R) { if (s.split(a).length !== 2) { console.log('НЕ НАЙДЕН фрагмент, ничего не изменено:\n' + a.slice(0, 90)); process.exit(1); } s = s.replace(a, () => b); }
fs.mkdirSync(path.join(dir, 'assets', 'u'), { recursive: true });
fs.copyFileSync(path.join(__dirname, 'd1.jpg'), path.join(dir, 'assets', 'u', 'd1.jpg'));
fs.copyFileSync(f, f + '.bak_durov'); fs.writeFileSync(f, s);
console.log('ok, бэкап ' + f + '.bak_durov');
