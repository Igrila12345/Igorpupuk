'use strict';

// Кража у топ-5 игроков (по заводам — тот же рейтинг, что и в "!топ заводы").
// Специально сбалансирована, чтобы не сносить топеров: см. комментарий к константам
// STEAL_* в game/constants.js.

const C = require('./constants');
const players = require('../db/players');
const gameDate = require('./gameDate');

function msLeft(lastAt, cooldownMs) {
  if (!lastAt) return 0;
  const left = cooldownMs - (Date.now() - new Date(lastAt).getTime());
  return left > 0 ? left : 0;
}

function clamp(value, min, max) {
  return Math.max(min, Math.min(max, value));
}

// Случайно применяет бонусный дроп (наука или заводы) с жертвы на вора.
// Если у жертвы не хватает выбранного ресурса — пробуем второй вариант.
// Если и его нет — бонус пропускается (возвращаем null).
async function tryBonusDrop(attackerVkId, target) {
  const options = Math.random() < 0.5 ? ['science', 'factories'] : ['factories', 'science'];
  for (const type of options) {
    if (type === 'science' && (target.science_centers || 0) >= C.STEAL_BONUS_SCIENCE) {
      await players.decrementScienceCenters(target.vk_id, C.STEAL_BONUS_SCIENCE);
      await players.addScienceCenters(attackerVkId, C.STEAL_BONUS_SCIENCE);
      return { type: 'science', amount: C.STEAL_BONUS_SCIENCE };
    }
    if (type === 'factories' && (target.factories || 0) >= C.STEAL_BONUS_FACTORIES) {
      await players.decrementFactories(target.vk_id, C.STEAL_BONUS_FACTORIES);
      await players.addFactories(attackerVkId, C.STEAL_BONUS_FACTORIES, false);
      return { type: 'factories', amount: C.STEAL_BONUS_FACTORIES };
    }
  }
  return null;
}

async function attemptSteal(attackerVkId, targetVkId) {
  if (String(attackerVkId) === String(targetVkId)) {
    return { ok: false, reason: 'self' };
  }

  const attacker = await players.getPlayer(attackerVkId);
  if (!attacker || attacker.registration_step !== 'done') {
    return { ok: false, reason: 'not_registered' };
  }

  const target = await players.getPlayer(targetVkId);
  if (!target || target.registration_step !== 'done') {
    return { ok: false, reason: 'target_not_registered' };
  }

  const rank = await players.getFactoryRank(targetVkId);
  if (!rank || rank > C.STEAL_TOP_N) {
    return { ok: false, reason: 'not_top', topN: C.STEAL_TOP_N };
  }

  const today = gameDate.todayStr();
  let dayCount = attacker.steal_count_today || 0;
  if (attacker.steal_day && String(attacker.steal_day).slice(0, 10) !== today) {
    dayCount = 0;
  }

  const left = msLeft(attacker.last_steal_at, C.STEAL_COOLDOWN_MS);
  if (left > 0) {
    return { ok: false, reason: 'cooldown', msLeft: left };
  }

  if (dayCount >= C.STEAL_DAILY_LIMIT) {
    return { ok: false, reason: 'daily_limit', limit: C.STEAL_DAILY_LIMIT };
  }

  const targetBalance = Number(target.balance) || 0;
  const rawAmount = targetBalance * C.STEAL_PERCENT_OF_BALANCE;
  const stolen = Math.min(
    targetBalance,
    Math.round(clamp(rawAmount, C.STEAL_MIN_AMOUNT, C.STEAL_MAX_AMOUNT))
  );

  if (stolen <= 0) {
    return { ok: false, reason: 'target_broke' };
  }

  const attackerGain = Math.round(stolen * C.STEAL_ATTACKER_SHARE);

  await players.updateBalance(targetVkId, -stolen);
  if (attackerGain > 0) {
    await players.updateBalance(attackerVkId, attackerGain);
  }

  const newCount = await players.incrementStealCount(attackerVkId, today);

  let bonus = null;
  if (newCount % C.STEAL_BONUS_EVERY === 0) {
    const freshTarget = await players.getPlayer(targetVkId);
    bonus = await tryBonusDrop(attackerVkId, freshTarget);
  }

  return {
    ok: true,
    stolen,
    attackerGain,
    bonus,
    stealsToday: newCount,
    dailyLimit: C.STEAL_DAILY_LIMIT,
    targetId: target.vk_id,
    targetName: target.state_name,
    attackerId: attacker.vk_id,
    attackerName: attacker.state_name,
  };
}

module.exports = { attemptSteal };
