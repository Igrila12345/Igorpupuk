'use strict';

// Группы аккаунтов одного игрока, для которых введены отдельные ограничения:
//  - не более LINKED_MAX_ATTACKERS_PER_TARGET разных аккаунтов из группы могут
//    одновременно (в течение LINKED_ATTACK_WINDOW_MS) атаковать одну и ту же цель;
//  - не более LINKED_TRANSFER_DAILY_LIMIT суммарных переводов в сутки МЕЖДУ
//    аккаунтами внутри одной группы (переводы вовне группы не ограничены этим правилом).
//
// Решение по конкретному игроку: ранее уличён в игре с 10 аккаунтов, лимит клана/сервера — 6,
// лишние забанены. Оставшиеся 6 — ниже. Добавлено доп. ограничение на координированный снос
// новичков и перекачку виртов между своими же аккаунтами.
const LINKED_ACCOUNT_GROUPS = [
  [804638109, 1065679388, 563044208, 200001908920, 1124122258, 1117375544],
];

const LINKED_MAX_ATTACKERS_PER_TARGET = 3;
const LINKED_ATTACK_WINDOW_MS = 24 * 60 * 60 * 1000; // 24 часа

const LINKED_TRANSFER_DAILY_LIMIT = 100000;
const LINKED_TRANSFER_WINDOW_MS = 24 * 60 * 60 * 1000; // 24 часа

const GROUP_BY_ID = new Map();
for (const group of LINKED_ACCOUNT_GROUPS) {
  for (const id of group) {
    GROUP_BY_ID.set(Number(id), group);
  }
}

// Возвращает массив ID группы, к которой принадлежит vkId, или null, если игрок
// не состоит ни в одной сконфигурированной группе связанных аккаунтов.
function getLinkedGroup(vkId) {
  return GROUP_BY_ID.get(Number(vkId)) || null;
}

function isLinkedPair(vkIdA, vkIdB) {
  const group = getLinkedGroup(vkIdA);
  return !!group && group.includes(Number(vkIdB));
}

module.exports = {
  LINKED_ACCOUNT_GROUPS,
  LINKED_MAX_ATTACKERS_PER_TARGET,
  LINKED_ATTACK_WINDOW_MS,
  LINKED_TRANSFER_DAILY_LIMIT,
  LINKED_TRANSFER_WINDOW_MS,
  getLinkedGroup,
  isLinkedPair,
};
