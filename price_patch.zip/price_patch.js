const fs=require('fs'),f='/opt/server.js';let s=fs.readFileSync(f,'utf8');fs.writeFileSync(f+'.bak_price',s);
const R=[
["price: 8999, old: 12999, infoDays: 30","price: 5000, old: 12999, infoDays: 30"],
["const EXCL2 = { price: 6999,","const EXCL2 = { price: 1200,"],
["  exclusive2(u) {      // «Повелитель тьмы»: больше не продаётся — у тех, кто уже купил, всё остаётся как есть\n    return ERR('Этот пак больше не продаётся');\n  },",
"  exclusive2(u) {\n    if (u.excl2) return ERR('Это предложение уже получено'); if (u.gems < EXCL2.price) return ERR('Не хватает алмазов');\n    const now = Date.now(); u.gems -= EXCL2.price; u.excl2 = now;\n    u.info = Math.max(now, u.info || 0) + EXCL2.infoDays * DAY; u.bal = clamp(u.bal + EXCL2.coins);\n    u.nameColor = EXCL2.nc; u.nameUntil = Math.max(now, u.nameUntil || 0) + 3650 * DAY;\n    if (!u.ringT || typeof u.ringT !== 'object') u.ringT = {};\n    u.ringT[EXCL2.ring] = Math.max(now, u.ringT[EXCL2.ring] || 0) + 3650 * DAY; u.ring = EXCL2.ring; u.sm = 'jack'; touch(); return { ok: true };\n  },"]];
let n=0;for(const [a,b] of R){if(s.includes(a)){s=s.replace(a,b);n++}else if(s.includes(b))console.log('уже есть');else{console.log('НЕ НАЙДЕНО:',a.slice(0,50));process.exit(1)}}
fs.writeFileSync(f,s);console.log('применено',n);
