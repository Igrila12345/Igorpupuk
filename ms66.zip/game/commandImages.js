'use strict';

// Картинки-заголовки для экранов бота. Все фото лежат в одном альбоме сообщества,
// поэтому owner_id одинаковый для всех (взят из ссылок вида photo-231991465_...).
// Часть ссылок была прислана в виде "photo0_..." (VK отдаёт owner_id=0 в share-ссылке,
// когда сам аккаунт, который делится ссылкой, не является просматривающим её ботом) —
// для них подставлен тот же owner_id, что и у остальных фото альбома.
//
// ВАЖНО: "Бонус" и "Клан сейф" указывают на один и тот же photo_id (457239143) —
// это пришло так в исходном списке. Если это опечатка и должна быть отдельная
// картинка для одного из экранов, поправьте нужную строку ниже.

const OWNER_ID = -231991465;

function p(photoId) {
  return `photo${OWNER_ID}_${photoId}`;
}

const COMMAND_IMAGES = {
  start: p(457239141), // Старт
  rename: p(457239142), // Переименовать
  bonus: p(457239143), // Бонус
  transfer: p(457239144), // Перевод
  quests: p(457239145), // Задания
  career: p(457239146), // Карьера
  donate: p(457239147), // Донат
  build: p(457239148), // Построить
  weapons: p(457239149), // Оружие / Вооружение
  shop: p(457239150), // Магазин
  limit: p(457239151), // Лимит
  arsenal: p(457239152), // Арсенал
  buy: p(457239153), // Купить
  attack: p(457239154), // Атака
  farm: p(457239155), // Ферма
  science: p(457239156), // Наука
  recon: p(457239157), // Разведка
  produce: p(457239158), // Произвести
  steal: p(457239159), // Кража
  boss: p(457239160), // Босс
  superRobotAttack: p(457239161), // Супер робот (атака)
  bossNumber: p(457239162), // Босс (число)
  clanCreate: p(457239163), // Клан создать
  forsazh: p(457239164), // Форсаж
  eshelon: p(457239165), // Эшелон
  industrialization: p(457239166), // Индустриализация
  work: p(457239167), // Работа
  clanSafe: p(457239143), // Клан сейф (совпадает с "Бонус" — см. примечание выше)
  case: p(457239168), // Кейс
  patrol: p(457239169), // Дозор
  robot: p(457239170), // Робот (меню)
  robotUpgrade: p(457239171), // Робот прокачать
  robotAttack: p(457239172), // Робот атака
  superRobotMenu: p(457239173), // Суперробот меню
  superRobotUpgrade: p(457239174), // Суперробот прокачать
  miner: p(457239175), // Майнер
  auction: p(457239176), // Аукцион
  bid: p(457239177), // Ставка
  tops: p(457239178), // Топы
  help: p(457239179), // Помощь
  business: p(457239194), // Бизнес
};

// Вспомогательная функция: если у payload для ctx.send ещё нет attachment,
// подставляет картинку по ключу из COMMAND_IMAGES. Если payload — просто строка,
// оборачивает её в { message, attachment }.
function withImage(key, payload) {
  const attachment = COMMAND_IMAGES[key];
  if (!attachment) return payload;

  if (typeof payload === 'string') {
    return { message: payload, attachment };
  }
  if (payload && typeof payload === 'object' && !payload.attachment) {
    return { ...payload, attachment };
  }
  return payload;
}

module.exports = { COMMAND_IMAGES, withImage, OWNER_ID };
