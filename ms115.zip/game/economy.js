'use strict';

const C = require('./constants');
const calc = require('./calc');
const players = require('../db/players');
const production = require('../db/production');
const clans = require('../db/clans');
const clanGame = require('./clan');
const zoneWar = require('./zoneWar');
const factoryBuilds = require('../db/factoryBuilds');
const asyncLock = require('./asyncLock');
const gameDate = require('./gameDate');
const globalBoost = require('./globalBoost');
const factoryPriceConfig = require('./factoryPriceConfig');
const { query } = require('../db/pool');

// Проставляет необратимый флаг «бонус новичка отработан», как только игрок пересёк порог
// (заводы + наука*10 >= NEWBIE_BOOST_FACTORY_THRESHOLD). Вызывается и из почасового тика
// (ловит любой способ роста: трофеи, награды, админ-выдача), и сразу после постройки
// завода/науки — чтобы бонус пропадал мгновенно, а не только на следующий час.
// Идемпотентна: для уже помеченного игрока в БД ничего не пишет (см. players.markNewbieBoostEnded).
async function syncNewbieBoostFlag(player) {
  if (!player || player.newbie_boost_ended) return;
  if (calc.newbieEquivalentFactories(player) < C.NEWBIE_BOOST_FACTORY_THRESHOLD) return;
  await players.markNewbieBoostEnded(player.vk_id);
  player.newbie_boost_ended = true;
}

// Полная цепочка множителей дохода одного игрока — база (заводы+наука, см.
// calc.incomePerHour) → глобальный ивент-буст → клановая "Индустриализация" → бонус за
// зоны клана (см. game/zoneWar.js: getIncomeBonusPercentForClan). Вынесено в отдельную
// функцию, чтобы hourlyTick (реальное начисление) и профиль (handlers/profile.js —
// отображение) считали ОДИНАКОВО — раньше профиль показывал только calc.incomePerHour()
// без глобального буста/индустриализации/бонуса зон, из-за чего показанная цифра дохода
// не совпадала с тем, что реально капало на баланс, а бонус зон вообще нигде не был виден.
// globalMult передаётся снаружи (а не читается здесь) в hourlyTick, чтобы не ходить в БД
// за глобальным бустом на каждого игрока отдельно — читается один раз на весь тик.
async function computeIncomeBreakdown(player, factoriesInProd, globalMult = 1) {
  const base = calc.incomePerHour(player, factoriesInProd);
  let income = globalMult !== 1 ? Math.round(base * globalMult) : base;

  let clanRow = null;
  let industrializationActive = false;
  let zoneBonusPct = 0;
  if (player.clan_id) {
    clanRow = await clans.getClanById(player.clan_id);
    if (clanRow && clanRow.bonus_industry_until && new Date(clanRow.bonus_industry_until) > new Date()) {
      income = Math.round(income * 1.2);
      industrializationActive = true;
    }
    // Бонус за зоны, захваченные кланом игрока (см. game/zoneWar.js) — суммируется по
    // всем зонам, которыми клан владеет (по умолчанию +25% за зону).
    zoneBonusPct = await zoneWar.getIncomeBonusPercentForClan(player.clan_id);
    if (zoneBonusPct > 0) {
      income = Math.round(income * (1 + zoneBonusPct));
    }
  }

  return { total: income, base, globalMult, industrializationActive, zoneBonusPct, clanRow };
}

// Начисление часового дохода всем игрокам + перевод в клан-сейф
async function hourlyTick(bot) {
  const all = await players.getAllActivePlayers();
  // Глобальный ивент-буст (запускает админ, см. !админ буст) — читаем ОДИН раз за весь
  // тик, а не на каждого игрока, т.к. это не персональный, а общий множитель для всех.
  const boost = await globalBoost.getBoost();
  const globalMult = boost ? Number(boost.multiplier) : 1;

  for (const player of all) {
    if (player.factories <= 0 && (player.science_centers || 0) <= 0) continue;

    const factoriesInProd = await production.getFactoriesInUse(player.vk_id);
    // Ловим пересечение порога до расчёта дохода — если игрок дорос за прошедший час любым
    // путём (трофеи, награды, админ-выдача), бонус новичка отключается уже в этом тике.
    await syncNewbieBoostFlag(player);
    const breakdown = await computeIncomeBreakdown(player, factoriesInProd, globalMult);
    const income = breakdown.total;
    const clanRow = breakdown.clanRow;

    if (income > 0) {
      // По просьбе владельца: клановый взнос больше НЕ вычитается из дохода игрока — игрок
      // получает доход целиком, а в сейф клана ДОПОЛНИТЕЛЬНО (сверху, не в ущерб игроку)
      // капает CLAN_VAULT_INCOME_RATE (15%) от его дохода. Это осознанное решение, а не
      // прежний баг с "деньгами из воздуха" — теперь это сделано намеренно.
      await players.updateBalance(player.vk_id, income);

      if (player.clan_id) {
        const clanShare = Math.round(income * C.CLAN_VAULT_INCOME_RATE);
        if (clanShare > 0) {
          const info = await clanGame.getClanVaultInfo(player.clan_id, clanRow);
          if (info && info.effectiveMaxVault > 0) {
            const res = await clans.addVault(player.clan_id, clanShare, info.effectiveMaxVault);
            const { leveledUp, level } = await clans.syncVaultLevel(player.clan_id, res.totalCollected);
            if (leveledUp && bot) {
              bot.notifyUser(
                info.clan.leader_id,
                `🏦 Сейф клана «${info.clan.name}» повысил уровень: ${level}/${C.CLAN_VAULT_MAX_LEVEL}! Вместимость сейфа выросла.`
              ).catch(() => {});
            }
          }
        }
      }
    }

    // Налог на богатство убран по просьбе — раньше здесь списывалось 5% от всего баланса
    // выше 10 000 каждый час (см. историю game/constants.js: WEALTH_TAX_*).
  }
}

// Постройка завода (можно сразу несколько штук одной командой, максимум см. C.FACTORY_BUILD_MAX_PER_COMMAND).
// Обёрнуто в withLock по vkId (см. game/asyncLock.js): без этого несколько ПАРАЛЛЕЛЬНЫХ вызовов
// (игрок спамит "построить" много раз подряд вместо одной команды "построить 10") могли бы
// каждый прочитать одно и то же стартовое состояние баланса/лимита до того, как предыдущий
// вызов сохранит свою запись — и таким образом обойти часовой лимит построек или получить
// несколько заводов по цене одного и того же (более раннего) шага цены. С локом результат
// не зависит от того, прислали ли одну команду на N заводов или N команд по одному.
async function buildFactory(vkId, count = 1) {
  return asyncLock.withLock(`build-factory:${vkId}`, () => buildFactoryLocked(vkId, count));
}

async function buildFactoryLocked(vkId, count = 1) {
  const player0 = await players.getPlayer(vkId);
  if (!player0) return { ok: false, reason: 'not_registered' };

  // VIP может купить чуть больше заводов одной командой, чем обычный игрок —
  // см. FACTORY_BUILD_MAX_PER_COMMAND / FACTORY_BUILD_MAX_PER_COMMAND_VIP в constants.js.
  const maxPerCommand = calc.isVipActive(player0)
    ? C.FACTORY_BUILD_MAX_PER_COMMAND_VIP
    : C.FACTORY_BUILD_MAX_PER_COMMAND;
  const requested = Math.max(1, Math.min(Math.floor(count) || 1, maxPerCommand));

  // Воскресная распродажа (по московскому времени): заводы дешевле, а часовой лимит построек
  // выше — см. SUNDAY_FACTORY_DISCOUNT / SUNDAY_FACTORY_BUILD_LIMIT_MULTIPLIER в constants.js.
  const isSunday = gameDate.isSundayMsk();

  // Стартовая цена завода может быть переопределена админом (см. game/factoryPriceConfig.js
  // и "!админ ценазаводов") — читаем ОДИН раз на всю пачку построек, а не на каждый завод.
  const priceOverride = await factoryPriceConfig.getOverride();

  let built = 0;
  let totalSpent = 0;
  let totalDiscount = 0;
  let goldMinesBuilt = 0;
  let lastReason = null;
  let lastExtra = null;

  for (let i = 0; i < requested; i++) {
    const player = await players.getPlayer(vkId);
    const maxFactories = calc.currentFactoryLimit(player.factory_limit_level);
    if (player.factories >= maxFactories) {
      lastReason = 'max_reached';
      lastExtra = { max: maxFactories };
      break;
    }

    // Лимит построек в час: 20 всем, x2 (40) для VIP (см. FACTORY_BUILD_LIMIT_PER_HOUR /
    // VIP_FACTORY_BUILD_LIMIT_MULTIPLIER в constants.js) — раньше VIP давал плоскую
    // надбавку +2 к лимиту, теперь удваивает его целиком.
    let buildLimit = calc.isVipActive(player)
      ? C.FACTORY_BUILD_LIMIT_PER_HOUR * C.VIP_FACTORY_BUILD_LIMIT_MULTIPLIER
      : C.FACTORY_BUILD_LIMIT_PER_HOUR;
    if (isSunday) buildLimit = Math.round(buildLimit * C.SUNDAY_FACTORY_BUILD_LIMIT_MULTIPLIER);
    const recentBuilds = await factoryBuilds.countRecentBuilds(vkId, 60 * 60 * 1000);
    if (recentBuilds >= buildLimit) {
      lastReason = 'build_limit';
      lastExtra = { limit: buildLimit };
      break;
    }

    const basePrice = calc.nextFactoryPrice(player.factories, priceOverride);
    const price = isSunday ? Math.round(basePrice * (1 - C.SUNDAY_FACTORY_DISCOUNT)) : basePrice;
    if (Number(player.balance) < price) {
      lastReason = 'not_enough_money';
      lastExtra = { price, missing: price - Number(player.balance) };
      break;
    }

    const isGoldMine = Math.random() < C.GOLD_MINE_CHANCE;
    await players.updateBalance(vkId, -price);
    await players.addFactories(vkId, 1, isGoldMine);
    await factoryBuilds.logBuild(vkId);

    built += 1;
    totalSpent += price;
    totalDiscount += basePrice - price;
    if (isGoldMine) goldMinesBuilt += 1;
  }

  if (built === 0) {
    return { ok: false, reason: lastReason || 'unknown', isSunday, ...lastExtra };
  }

  // Игрок мог этой пачкой построек пересечь порог «уже не новичок» — отключаем бонус сразу,
  // не дожидаясь следующего часового тика. Перечитываем игрока: player выше — это снимок ДО
  // построек, в нём старое число заводов.
  const afterBuild = await players.getPlayer(vkId);
  await syncNewbieBoostFlag(afterBuild);

  return {
    ok: true,
    built,
    requested,
    totalSpent,
    totalDiscount,
    goldMinesBuilt,
    isSunday,
    stoppedEarly: built < requested ? lastReason : null,
  };
}

// Прокачка заводов — ОБЩИЙ множитель дохода со всех заводов игрока, НЕ количество заводов
// (см. подробный комментарий у FACTORY_UPGRADE_* в constants.js). Один уровень за вызов —
// команда "прокачка" покупает следующий уровень, а не сразу N.
async function upgradeFactory(vkId) {
  return asyncLock.withLock(`factory-upgrade:${vkId}`, () => upgradeFactoryLocked(vkId));
}

async function upgradeFactoryLocked(vkId) {
  const player = await players.getPlayer(vkId);
  if (!player) return { ok: false, reason: 'not_registered' };

  const level = calc.factoryUpgradeLevel(player);
  if (level >= C.FACTORY_UPGRADE_MAX_LEVEL) {
    return { ok: false, reason: 'max_level' };
  }

  const cost = calc.factoryUpgradeCost(level);
  if (Number(player.balance) < cost) {
    return { ok: false, reason: 'not_enough_money', cost, missing: cost - Number(player.balance) };
  }

  // Атомарный инкремент с проверкой "уровень не изменился с момента чтения игрока выше" —
  // см. db/players.js: incrementFactoryUpgradeLevel. При гонке (два параллельных запроса на
  // прокачку одного игрока) один из них получит null и должен просто повториться — здесь
  // ретраим один раз, этого достаточно, т.к. второй конкурент за это время уже завершится
  // (сам механизм это тот же паттерн, что и оптимистичная блокировка в withdrawVault).
  await players.updateBalance(vkId, -cost);
  const newLevel = await players.incrementFactoryUpgradeLevel(vkId, level);
  if (newLevel === null) {
    // Кто-то другой успел прокачать между чтением и записью — возвращаем деньги, это тот
    // редкий случай гонки, для которого withLock как раз и существует, но перестраховка
    // не помешает (см. комментарий выше в buildFactoryLocked про подобные редкие гонки).
    await players.updateBalance(vkId, cost);
    return { ok: false, reason: 'race_retry' };
  }

  return { ok: true, cost, newLevel, bonusPercent: newLevel * C.FACTORY_UPGRADE_INCOME_BONUS_PER_LEVEL * 100 };
}

// Досрочная разблокировка завода
async function earlyUnblock(vkId, factoryIndex) {
  const player = await players.getPlayer(vkId);
  if (!player) return { ok: false, reason: 'not_registered' };

  const blocked = player.blocked_factories || [];
  if (!blocked.length || factoryIndex < 0 || factoryIndex >= blocked.length) {
    return { ok: false, reason: 'invalid_index' };
  }

  const entry = blocked[factoryIndex];
  const now = Date.now();
  const unblockAt = new Date(entry.unblock_at).getTime();
  if (unblockAt <= now) return { ok: false, reason: 'already_unblocked' };

  const hoursLeft = Math.ceil((unblockAt - now) / (60 * 60 * 1000));
  const cost = C.EARLY_UNBLOCK_COST_PER_HOUR * hoursLeft;

  if (Number(player.balance) < cost) {
    return { ok: false, reason: 'not_enough_money', cost, missing: cost - Number(player.balance) };
  }

  await players.updateBalance(vkId, -cost);
  blocked.splice(factoryIndex, 1);
  await players.setBlockedFactories(vkId, blocked);

  return { ok: true, cost };
}

// Обработка разблокировки заводов по истечении времени (очистка списка blocked_factories)
async function processFactoryUnblocks() {
  const all = await players.getPlayersWithBlockedFactories();
  const now = Date.now();
  for (const player of all) {
    const blocked = player.blocked_factories || [];
    if (!blocked.length) continue;
    const stillBlocked = blocked.filter((b) => new Date(b.unblock_at).getTime() > now);
    if (stillBlocked.length !== blocked.length) {
      await players.setBlockedFactories(player.vk_id, stillBlocked);
    }
  }
}

// Обработка снятия радиации
async function processRadiationExpiry() {
  await query(
    `UPDATE players SET radiation_until = NULL WHERE radiation_until IS NOT NULL AND radiation_until <= NOW()`
  );
}

module.exports = {
  hourlyTick,
  syncNewbieBoostFlag,
  computeIncomeBreakdown,
  buildFactory,
  upgradeFactory,
  earlyUnblock,
  processFactoryUnblocks,
  processRadiationExpiry,
};
