'use strict';

const { Keyboard } = require('vk-io');
const players = require('../db/players');
const inspection = require('../game/inspection');
const quests = require('../game/quests');
const inspectionRender = require('../game/inspectionRender');
const calc = require('../game/calc');
const C = require('../game/constants');
const { uploadPngAsMessagePhoto } = require('../utils/uploadImage');

function buildKeyboard(session) {
  const cols = Math.ceil(Math.sqrt(session.size));
  const rows = [];
  for (let r = 0; r < Math.ceil(session.size / cols); r++) {
    const row = [];
    for (let c = 0; c < cols; c++) {
      const i = r * cols + c;
      if (i >= session.size) continue;
      row.push(
        Keyboard.textButton({
          label: `${i + 1}`,
          payload: { cmd: 'inspection_pick', cell: i, round: session.round },
          color: Keyboard.PRIMARY_COLOR,
        })
      );
    }
    rows.push(row);
  }
  return Keyboard.keyboard(rows).inline();
}

function buildMenuKeyboard() {
  return Keyboard.keyboard([
    [
      Keyboard.textButton({
        label: `▶️ Начать инспекцию`,
        payload: { cmd: 'inspection_start' },
        color: Keyboard.POSITIVE_COLOR,
      }),
    ],
  ]).inline();
}

// Текстовый запасной вариант, если рендер/загрузка фото не сработали.
function renderRoundText(session) {
  const lines = [];
  for (let i = 0; i < session.size; i++) {
    lines.push(`${i + 1}: ${i === session.anomalyIndex ? '🏭↗️(развёрнут)' : '🏭'}`);
  }
  return lines.join('\n');
}

async function sendRound(ctx, session, resumed, attemptsLeft, dailyLimitToday) {
  const keyboard = buildKeyboard(session);
  const prefix = resumed ? '↩️ Продолжаем незавершённую попытку.\n' : '';
  const limitDenom = dailyLimitToday || C.INSPECTION_MAX_PER_DAY;
  const attemptsLine = typeof attemptsLeft === 'number' ? ` (осталось попыток сегодня: ${attemptsLeft}/${limitDenom})` : '';
  const caption =
    `${prefix}🔍 ИНСПЕКЦИЯ — раунд ${session.round}/${C.INSPECTION_ROUNDS}${attemptsLine}\n` +
    `Все значки 🏭 одинаковые, кроме ОДНОГО — он развёрнут под углом. Найдите его и нажмите номер ячейки.`;

  try {
    const buffer = await inspectionRender.renderRound(session);
    const photo = await uploadPngAsMessagePhoto(ctx.bot.vk, buffer, ctx.peerId);

    await ctx.send({
      message: `${caption}`,
      attachment: photo,
      keyboard,
    });
  } catch (err) {
    console.error('[Inspection] Не удалось отрисовать/загрузить раунд картинкой, отправляю текстом:', err);
    await ctx.send({
      message: `${caption}\n\n${renderRoundText(session)}`,
      keyboard,
    });
  }
}

async function handleInspectionMenu(ctx) {
  const vkId = ctx.senderId;
  const player = await players.getPlayer(vkId);
  if (!player || player.registration_step !== 'done') {
    await ctx.send('⛔ Вы ещё не зарегистрированы. Напишите старт');
    return;
  }

  const status = await inspection.getStatus(vkId);
  if (!status.ok) {
    await ctx.send('⛔ Не удалось получить статус инспекции.');
    return;
  }

  const progressLine =
    status.activeRound !== null
      ? `▶️ Есть незавершённая попытка: раунд ${status.activeRound}/${C.INSPECTION_ROUNDS} (жмите «Начать инспекцию», чтобы продолжить)\n`
      : '';

  await ctx.send({
    message:
      `🔍 ИНСПЕКЦИЯ ЦЕХА\n\n` +
      `Второй вид заработка помимо "работы" — свой отдельный дневной лимит, награда сразу виртами.\n\n` +
      `Попыток использовано сегодня: ${status.attemptsUsed}/${status.dailyLimitToday}\n` +
      `Осталось попыток: ${status.attemptsLeft}\n` +
      `💰 Баланс: ${calc.formatNumber(status.balance)} вирт\n\n` +
      `За полное прохождение (${C.INSPECTION_ROUNDS} раунда) — ${C.INSPECTION_VIRTS_MIN}-${C.INSPECTION_VIRTS_MAX} вирт.\n` +
      progressLine,
    keyboard: buildMenuKeyboard(),
  });
}

async function handleInspection(ctx) {
  const vkId = ctx.senderId;
  const player = await players.getPlayer(vkId);
  if (!player || player.registration_step !== 'done') {
    await ctx.send('⛔ Вы ещё не зарегистрированы. Напишите старт');
    return;
  }

  const result = await inspection.startInspection(vkId);

  if (!result.ok) {
    if (result.reason === 'daily_limit') {
      await ctx.send(`⛔ На сегодня лимит инспекций исчерпан (${result.dailyLimitToday || C.INSPECTION_MAX_PER_DAY}/день). Попробуйте завтра.`);
    } else if (result.reason === 'cooldown') {
      await ctx.send(`⏳ Между попытками нужно подождать. Осталось: ${calc.formatDuration(result.remainingMs)}.`);
    } else {
      await ctx.send('⛔ Не удалось начать инспекцию.');
    }
    return;
  }

  await sendRound(ctx, result.session, result.resumed, result.attemptsLeft, result.dailyLimitToday);
}

async function handleInspectionPick(ctx, cellIndexRaw, roundRaw) {
  const vkId = ctx.senderId;
  const cellIndex = Number(cellIndexRaw);
  const round = Number(roundRaw);

  const result = await inspection.pickCell(vkId, cellIndex, round);

  if (!result.ok) {
    if (result.reason === 'not_registered') {
      await ctx.send('⛔ Вы ещё не зарегистрированы. Напишите старт');
    } else if (result.reason === 'wrong') {
      await ctx.send(
        `❌ Мимо! Это была не аномальная ячейка. Попытка засчитана как использованная.\n` +
          `Осталось попыток сегодня: ${result.attemptsLeft}/${result.dailyLimitToday || C.INSPECTION_MAX_PER_DAY}.\n` +
          `Попробовать снова: инспекция`
      );
    } else if (result.reason === 'timeout') {
      await ctx.send(
        `⌛ Время на раунд вышло. Попытка засчитана как использованная.\n` +
          `Осталось попыток сегодня: ${result.attemptsLeft}/${result.dailyLimitToday || C.INSPECTION_MAX_PER_DAY}.\n` +
          `Попробовать снова: инспекция`
      );
    } else if (result.reason === 'no_session' || result.reason === 'invalid_cell') {
      return;
    } else {
      await ctx.send('⛔ Не удалось обработать выбор.');
    }
    return;
  }

  if (result.status === 'completed') {
    const questNotices = await quests.trackProgress(vkId, 'inspection', 1);
    let text =
      `✅ Все ${C.INSPECTION_ROUNDS} раунда пройдены! Получено: ${result.virts} вирт 💰\n` +
      `Осталось попыток сегодня: ${result.attemptsLeft}.\n` +
      `💰 Баланс: ${calc.formatNumber(result.totalBalance)} вирт`;
    if (questNotices.length) text += `\n\n${questNotices.join('\n')}`;
    await ctx.send(text);
    return;
  }

  await sendRound(ctx, result.session, false, result.attemptsLeft);
}

module.exports = { handleInspectionMenu, handleInspection, handleInspectionPick };
