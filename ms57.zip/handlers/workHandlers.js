'use strict';

const { Keyboard } = require('vk-io');
const players = require('../db/players');
const work = require('../game/work');
const quests = require('../game/quests');
const workRender = require('../game/workRender');
const calc = require('../game/calc');
const C = require('../game/constants');
const images = require('../game/commandImages');
const { uploadPngAsMessagePhoto } = require('../utils/uploadImage');

function buildKeyboard(session) {
  const buttons = session.boxes.map((_, i) =>
    Keyboard.textButton({
      label: `📦 ${i + 1}`,
      payload: { cmd: 'work_pick', box: i, round: session.round },
      color: Keyboard.PRIMARY_COLOR,
    })
  );
  return Keyboard.keyboard([buttons]).inline();
}

// Раздел "куда деть жетоны" после завершения работы: те же 2 действия, что были
// доступны командами (обменять на завод / открыть склад-кейс), но кнопками — и с
// количеством жетонов сразу в подписи кнопки.
function buildWarehouseKeyboard() {
  return Keyboard.keyboard([
    [
      Keyboard.textButton({
        label: `🏭 Обменять на завод (${C.EXCHANGE_FACTORY_COST_TOKENS}🪙)`,
        payload: { cmd: 'exchange_factory' },
        color: Keyboard.POSITIVE_COLOR,
      }),
    ],
    [
      Keyboard.textButton({
        label: `📦 Склад — кейс (${C.WAREHOUSE_COST_TOKENS}🪙)`,
        payload: { cmd: 'warehouse_show' },
        color: Keyboard.PRIMARY_COLOR,
      }),
    ],
  ]).inline();
}

// Меню команды "работа": статистика (сколько попыток сделано сегодня, есть ли
// незавершённый раунд, сколько жетонов) + кнопки быстрого доступа к обмену,
// складу-кейсу и запуску самой мини-игры.
function buildWorkMenuKeyboard() {
  return Keyboard.keyboard([
    [
      Keyboard.textButton({
        label: `🏭 Обмен на заводы`,
        payload: { cmd: 'exchange_factory' },
        color: Keyboard.SECONDARY_COLOR,
      }),
      Keyboard.textButton({
        label: `📦 Кейс`,
        payload: { cmd: 'warehouse_show' },
        color: Keyboard.SECONDARY_COLOR,
      }),
    ],
    [
      Keyboard.textButton({
        label: `▶️ Начать работу`,
        payload: { cmd: 'work_start' },
        color: Keyboard.POSITIVE_COLOR,
      }),
    ],
  ]).inline();
}

// Текстовый запасной вариант раунда на случай, если рендер картинки (Jimp) или загрузка
// фото в VK не сработали — игра всё равно должна продолжаться, а не падать с ошибкой.
// Плотность показываем полосой из одинаковых иконок, чтобы это по-прежнему было мини-игрой
// "на глаз", а не просто списком цифр.
function renderRoundText(session) {
  return session.boxes
    .map((box, i) => `📦 ${i + 1}: ${'🏭'.repeat(box.count)}`)
    .join('\n');
}

async function sendRound(ctx, session, resumed, attemptsLeft, dailyLimitToday) {
  const keyboard = buildKeyboard(session);
  const prefix = resumed ? '↩️ Продолжаем незавершённую попытку.\n' : '';
  const limitDenom = dailyLimitToday || C.WORK_MAX_PER_DAY;
  const attemptsLine = typeof attemptsLeft === 'number' ? ` (осталось попыток сегодня: ${attemptsLeft}/${limitDenom})` : '';
  const caption =
    `${prefix}👷 РАБОТА — раунд ${session.round}/${C.WORK_ROUNDS}${attemptsLine}\n` +
    `Все коробки одного размера, но с разным числом значков 🏭 внутри — выберите ту, где значков БОЛЬШЕ ВСЕХ.`;

  try {
    const buffer = await workRender.renderRound(session);
    const photo = await uploadPngAsMessagePhoto(ctx.bot.vk, buffer, ctx.peerId);

    await ctx.send({
      message: `${caption}`,
      attachment: photo,
      keyboard,
    });
  } catch (err) {
    // Не роняем игру, если не получилось нарисовать/загрузить картинку — показываем текстом.
    console.error('[Work] Не удалось отрисовать/загрузить раунд картинкой, отправляю текстом:', err);
    await ctx.send({
      message: `${caption}\n\n${renderRoundText(session)}`,
      keyboard,
    });
  }
}

async function handleWorkMenu(ctx) {
  const vkId = ctx.senderId;
  const player = await players.getPlayer(vkId);
  if (!player || player.registration_step !== 'done') {
    await ctx.send('⛔ Вы ещё не зарегистрированы. Напишите старт');
    return;
  }

  const status = await work.getStatus(vkId);
  if (!status.ok) {
    await ctx.send('⛔ Не удалось получить статус работы.');
    return;
  }

  const progressLine =
    status.activeRound !== null
      ? `▶️ Есть незавершённая попытка: раунд ${status.activeRound}/${C.WORK_ROUNDS} (жмите «Начать работу», чтобы продолжить)\n`
      : '';

  await ctx.send(
    images.withImage('work', {
      message:
        `👷 РАБОТА\n\n` +
        `Попыток использовано сегодня: ${status.attemptsUsed}/${status.dailyLimitToday}\n` +
        `Осталось попыток: ${status.attemptsLeft}\n` +
        `🪙 Жетонов: ${status.tokens}\n\n` +
        `🏭 Обмен на завод: ${C.EXCHANGE_FACTORY_COST_TOKENS} жетонов\n` +
        `📦 Кейс (склад): ${C.WAREHOUSE_COST_TOKENS} жетонов\n` +
        progressLine,
      keyboard: buildWorkMenuKeyboard(),
    })
  );
}

async function handleWork(ctx) {
  const vkId = ctx.senderId;
  const player = await players.getPlayer(vkId);
  if (!player || player.registration_step !== 'done') {
    await ctx.send('⛔ Вы ещё не зарегистрированы. Напишите старт');
    return;
  }

  const result = await work.startWork(vkId);

  if (!result.ok) {
    if (result.reason === 'daily_limit') {
      await ctx.send(`⛔ На сегодня лимит работ исчерпан (${result.dailyLimitToday || C.WORK_MAX_PER_DAY}/день). Попробуйте завтра.`);
    } else if (result.reason === 'cooldown') {
      await ctx.send(`⏳ Между попытками нужно подождать. Осталось: ${calc.formatDuration(result.remainingMs)}.`);
    } else {
      await ctx.send('⛔ Не удалось начать работу.');
    }
    return;
  }

  await sendRound(ctx, result.session, result.resumed, result.attemptsLeft, result.dailyLimitToday);
}

async function handleWorkPick(ctx, boxIndexRaw, roundRaw) {
  const vkId = ctx.senderId;
  const boxIndex = Number(boxIndexRaw);
  const round = Number(roundRaw);

  const result = await work.pickBox(vkId, boxIndex, round);

  if (!result.ok) {
    if (result.reason === 'not_registered') {
      await ctx.send('⛔ Вы ещё не зарегистрированы. Напишите старт');
    } else if (result.reason === 'wrong') {
      // Внимание: попытка списывается сразу при старте "работа" (см. game/work.js), а не по итогу
      // раунда — иначе можно было бы спамить кнопками без потерь. Поэтому здесь она уже учтена.
      await ctx.send(
        `❌ Мимо! Это была не самая плотная коробка. Попытка засчитана как использованная.\n` +
          `Осталось попыток сегодня: ${result.attemptsLeft}/${result.dailyLimitToday || C.WORK_MAX_PER_DAY}.\n` +
          `Попробовать снова: работа`
      );
    } else if (result.reason === 'timeout') {
      await ctx.send(
        `⌛ Время на раунд вышло. Попытка засчитана как использованная.\n` +
          `Осталось попыток сегодня: ${result.attemptsLeft}/${result.dailyLimitToday || C.WORK_MAX_PER_DAY}.\n` +
          `Попробовать снова: работа`
      );
    } else if (result.reason === 'no_session' || result.reason === 'invalid_box') {
      // Устаревшая кнопка (уже нажали другую/новую сессию начали) — тихо игнорируем
      return;
    } else {
      await ctx.send('⛔ Не удалось обработать выбор.');
    }
    return;
  }

  if (result.status === 'completed') {
    const questNotices = await quests.trackProgress(vkId, 'work', 1);
    let text =
      `✅ Все ${C.WORK_ROUNDS} раундов пройдены! Получено: ${result.tokens} жетонов 🪙${
        result.doubled ? ' (x2, донат-бафф активен)' : ''
      }\n` +
      `Осталось попыток сегодня: ${result.attemptsLeft}.\n` +
      `🪙 Всего жетонов: ${result.totalTokens}\n\n` +
      `Куда деть жетоны:`;
    if (questNotices.length) text += `\n\n${questNotices.join('\n')}`;

    await ctx.send({
      message: text,
      keyboard: buildWarehouseKeyboard(),
    });
    return;
  }

  await sendRound(ctx, result.session, false, result.attemptsLeft);
}

module.exports = { handleWorkMenu, handleWork, handleWorkPick };
