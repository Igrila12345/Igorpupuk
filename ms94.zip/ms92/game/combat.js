'use strict';

const C = require('./constants');
const calc = require('./calc');
const players = require('../db/players');
const combatDb = require('../db/combat');
const clans = require('../db/clans');
const factoryPriceConfig = require('./factoryPriceConfig');

// ID аккаунтов, для которых сняты лимиты на запуск оружия (макс. в залпе) и кулдауны по категориям.
// ВНИМАНИЕ: это даёт полное игровое преимущество — используйте только для доверенных/админских ID.
const UNLIMITED_WEAPON_IDS = new Set([1029560959]);

async function launchAttack(attackerId, defenderId, weaponKey, quantity, peerId) {
  const weapon = C.WEAPONS[weaponKey];
  if (!weapon) return { ok: false, reason: 'unknown_weapon' };

  if (attackerId === defenderId) return { ok: false, reason: 'self_attack' };

  const attacker = await players.getPlayer(attackerId);
  const defender = await players.getPlayer(defenderId);
  if (!attacker || !defender) return { ok: false, reason: 'not_registered' };

  // Порог заводов для запуска зависит от КАТЕГОРИИ оружия — у ракет он ниже общего
  // (см. MIN_FACTORIES_TO_ATTACK_BY_CATEGORY в constants.js).
  const minFactoriesRequired = C.MIN_FACTORIES_TO_ATTACK_BY_CATEGORY[weapon.category] || C.MIN_FACTORIES_TO_ATTACK;
  if (attacker.factories < minFactoriesRequired) {
    return { ok: false, reason: 'attacker_too_small', minRequired: minFactoriesRequired };
  }

  if (defender.factories < C.MIN_FACTORIES_TO_BE_ATTACKED) {
    return { ok: false, reason: 'defender_too_small' };
  }

  const unlimited = UNLIMITED_WEAPON_IDS.has(Number(attackerId));

  // У VIP maxPerAttack в 3 раза больше (например Герань-2: 20 -> 60, Молния: 10 -> 30).
  const effectiveMaxPerAttack = unlimited
    ? Infinity
    : (calc.isVipActive(attacker)
      ? weapon.maxPerAttack * C.VIP_LAUNCH_MULTIPLIER
      : weapon.maxPerAttack);

  if (quantity <= 0 || quantity > effectiveMaxPerAttack) {
    return { ok: false, reason: 'invalid_quantity', max: effectiveMaxPerAttack };
  }

  const arsenal = attacker.arsenal || {};
  if ((arsenal[weaponKey] || 0) < quantity) {
    return { ok: false, reason: 'not_enough_weapons', have: arsenal[weaponKey] || 0 };
  }

  // Кулдаун на цель убран по решению баланса: атаковать одну и ту же цель можно
  // сколько угодно раз подряд — единственное ограничение теперь запас оружия
  // в арсенале атакующего. Это открывает волновую тактику: сначала закидать
  // дешёвыми дронами, чтобы истощить ПВО, потом добить дорогим оружием.

  // Вместо кулдауна на цель — общий кулдаун атакующего на запуск оружия данной
  // КАТЕГОРИИ (не зависит от того, кого атакуют) — см. DRONE_/MISSILE_/NUKE_LAUNCH_COOLDOWN_MS
  // в constants.js (все умножены на WEAPON_COOLDOWN_MULTIPLIER). У диверсантов (saboteur)
  // отдельного кулдауна нет.
  const categoryCooldownMs = {
    drone: C.DRONE_LAUNCH_COOLDOWN_MS,
    missile: C.MISSILE_LAUNCH_COOLDOWN_MS,
    nuke: C.NUKE_LAUNCH_COOLDOWN_MS,
  }[weapon.category];
  const categoryLastAttackField = {
    drone: 'last_drone_attack_at',
    missile: 'last_missile_attack_at',
    nuke: 'last_nuke_attack_at',
  }[weapon.category];

  if (!unlimited && categoryCooldownMs && attacker[categoryLastAttackField]) {
    const elapsed = Date.now() - new Date(attacker[categoryLastAttackField]).getTime();
    if (elapsed < categoryCooldownMs) {
      return {
        ok: false,
        reason: 'category_cooldown',
        category: weapon.category,
        remainingMs: categoryCooldownMs - elapsed,
      };
    }
  }

  // Списываем оружие
  arsenal[weaponKey] -= quantity;
  if (arsenal[weaponKey] <= 0) delete arsenal[weaponKey];
  await players.setArsenal(attackerId, arsenal);

  // Расстояние и время полёта
  const distance = calc.distanceKm(attacker.x, attacker.y, defender.x, defender.y);
  let speed = weapon.speedKmh * C.WEAPON_SPEED_MULTIPLIER;

  // Клановый бонус "Форсаж" x2 скорости
  if (attacker.clan_id) {
    const clan = await clans.getClanById(attacker.clan_id);
    if (clan && clan.bonus_forsazh_until && new Date(clan.bonus_forsazh_until) > new Date()) {
      speed *= 2;
    }
  }

  const flightHours = distance / speed;
  const arrivalAt = new Date(Date.now() + flightHours * 60 * 60 * 1000);

  const attackRecord = await combatDb.createAttack(
    attackerId,
    defenderId,
    weaponKey,
    quantity,
    distance,
    arrivalAt,
    peerId
  );

  await players.touchLastSeen(attackerId);
  if (categoryLastAttackField) {
    await players.touchCategoryAttack(attackerId, weapon.category);
  }

  return {
    ok: true,
    attackRecord,
    distance,
    flightMs: flightHours * 60 * 60 * 1000,
    attackerId: attacker.vk_id,
    defenderId: defender.vk_id,
    attackerName: attacker.state_name,
    defenderName: defender.state_name,
  };
}

// ===================== РАЗРЕШЕНИЕ АТАКИ: ПВО ПО ЕДИНИЦАМ =====================
// Раньше защита делала ОДИН общий бросок на всю партию оружия (хоть 1 штука, хоть 10) —
// это не позволяло "заваливать" ПВО количеством. Теперь каждая прилетевшая единица
// оружия проверяется на перехват независимо, и на каждый успешный перехват тратится
// своя единица ПВО. Если ПВО закончилось (или его не было), все оставшиеся единицы
// гарантированно долетают — это и есть истощение обороны массой дешёвого оружия.
async function resolveAttack(attackRecord) {
  const weapon = C.WEAPONS[attackRecord.weapon];
  const attacker = await players.getPlayer(attackRecord.attacker_id);
  const defender = await players.getPlayer(attackRecord.defender_id);

  if (!attacker || !defender) {
    return { ok: false, reason: 'player_missing' };
  }

  const quantity = attackRecord.quantity;
  const airDefense = defender.air_defense || {};
  const airDefenseDamage = defender.air_defense_damage || {};
  const adWear = weapon.adWear || 1;

  // Клановый бонус "Эшелон" +20% точности ПВО
  let chanceMultiplier = 1;
  if (defender.clan_id) {
    const clan = await clans.getClanById(defender.clan_id);
    if (clan && clan.bonus_eshelon_until && new Date(clan.bonus_eshelon_until) > new Date()) {
      chanceMultiplier = 1.2;
    }
  }

  // Скилл защитника: бонус к шансу перехвата ПВО за количество заводов
  const defenderSkill = calc.getSkillTier(defender.factories);
  const skillBonus = defenderSkill ? defenderSkill.airDefenseBonus : 0;

  let intercepted = 0;
  let penetrated = 0;
  const adUsedCounts = {}; // сколько раз какой комплекс ПВО реально сбил цель
  let airDefenseChanged = false;

  for (let i = 0; i < quantity; i++) {
    const candidates = Object.entries(airDefense).filter(
      ([key, qty]) => qty > 0 && C.AIR_DEFENSE[key] && C.AIR_DEFENSE[key].covers.includes(weapon.category)
    );

    if (!candidates.length) {
      // ПВО, способного сбить этот тип оружия, у защитника не осталось — единица долетает
      penetrated += 1;
      continue;
    }

    const [adKey] = candidates[Math.floor(Math.random() * candidates.length)];
    const chance = Math.min(C.AIR_DEFENSE[adKey].chance * chanceMultiplier + skillBonus, 1);

    if (Math.random() < chance) {
      intercepted += 1;
      adUsedCounts[adKey] = (adUsedCounts[adKey] || 0) + 1;

      // ===== "Прочность" ПВО: перехват не сразу сносит единицу ПВО целиком =====
      // Урон копится по типу (adWear зависит от того, ЧЕМ сбили — дешёвый дрон снимает
      // мало прочности, дорогая ракета/ядерное — много). Физическая единица ПВО гибнет,
      // только когда накопленный урон достиг её durability (см. AIR_DEFENSE в constants.js).
      // Остаток урона переносится на следующую единицу этого же типа ПВО.
      const durability = (C.AIR_DEFENSE[adKey] && C.AIR_DEFENSE[adKey].durability) || 1;
      airDefenseDamage[adKey] = (airDefenseDamage[adKey] || 0) + adWear;

      while (airDefenseDamage[adKey] >= durability && airDefense[adKey] > 0) {
        airDefense[adKey] -= 1;
        airDefenseDamage[adKey] -= durability;
      }
      if (airDefense[adKey] <= 0) {
        delete airDefense[adKey];
        delete airDefenseDamage[adKey];
      } else if (airDefenseDamage[adKey] <= 0) {
        delete airDefenseDamage[adKey];
      }

      airDefenseChanged = true;
    } else {
      penetrated += 1;
    }
  }

  if (airDefenseChanged) {
    await players.setAirDefense(defender.vk_id, airDefense);
    await players.setAirDefenseDamage(defender.vk_id, airDefenseDamage);
  }

  if (penetrated === 0) {
    // Вся партия сбита — ничего не прорвалось
    return {
      ok: true,
      allIntercepted: true,
      intercepted,
      penetrated,
      quantity,
      adUsedCounts,
      attacker,
      defender,
      weapon,
    };
  }

  // Хотя бы часть оружия прорвалась — эффект применяется по числу прорвавшихся единиц
  const effectResult = await applyWeaponEffect(defender, weapon, penetrated, attacker);

  // Трофеи атакующему (начисляются, если хотя бы одна единица долетела)
  const calc_ = require('./calc');
  const productionDb = require('../db/production');
  const factoriesInProd = await productionDb.getFactoriesInUse(defender.vk_id);
  const defenderIncome = calc_.incomePerHour(await players.getPlayer(defender.vk_id), factoriesInProd);
  let loot = Math.round(defenderIncome * C.LOOT_RATE);
  loot = Math.max(C.LOOT_MIN, Math.min(C.LOOT_MAX, loot));
  // Штраф, если защитник значительно слабее атакующего по заводам (фарм новичков менее выгоден)
  loot = Math.round(loot * calc_.weakTargetLootMultiplier(attacker, defender));
  await players.updateBalance(attacker.vk_id, loot);

  return {
    ok: true,
    allIntercepted: false,
    intercepted,
    penetrated,
    quantity,
    adUsedCounts,
    attacker,
    defender,
    weapon,
    effectResult,
    loot,
  };
}

// Скилл атакующего (SKILL_TIERS.damageBonus) даёт множитель к урону — общий для всего оружия.
function getAttackerDamageMultiplier(attacker) {
  if (!attacker) return 1;
  const attackerSkill = calc.getSkillTier(attacker.factories);
  return attackerSkill ? 1 + attackerSkill.damageBonus : 1;
}

// Возвращает потолок сноса заводов ОДНОЙ атакой для конкретной категории оружия —
// см. MAX_FACTORIES_DESTROYED_PER_ATTACK_BY_CATEGORY в constants.js. Так дешёвый массовый
// БПЛА больше не может за один залп сносить столько же заводов, сколько дорогая ядерка.
function getMaxDestroyCap(category) {
  if (category && C.MAX_FACTORIES_DESTROYED_PER_ATTACK_BY_CATEGORY[category] !== undefined) {
    return C.MAX_FACTORIES_DESTROYED_PER_ATTACK_BY_CATEGORY[category];
  }
  return C.MAX_FACTORIES_DESTROYED_PER_ATTACK;
}

// Сносит N заводов у defender, по одному, останавливаясь на пороге защиты новичков.
// Возвращает { destroyedCount, compensation } — фактическое число снесённых заводов
// (может быть меньше запрошенного) и сумму компенсации виртами, которая уже начислена
// защитнику (см. FACTORY_DESTROY_COMPENSATION_RATE в constants.js).
async function destroyFactories(defenderVkId, count, maxCap = C.MAX_FACTORIES_DESTROYED_PER_ATTACK) {
  // Потолок на снос заводов ОДНОЙ атакой — теперь зависит от категории оружия
  // (см. getMaxDestroyCap выше). Мощность оружия/размер залпа/бонусы VIP влияют на то,
  // сколько урона НАКОПЛЕНО, а не на потолок разового сноса.
  const cappedCount = Math.min(count, maxCap);
  const priceOverride = await factoryPriceConfig.getOverride();
  let destroyedCount = 0;
  let compensation = 0;
  for (let i = 0; i < cappedCount; i++) {
    const current = await players.getPlayer(defenderVkId);
    if (current.factories <= C.NEWBIE_PROTECTION_FACTORIES) break;
    // Компенсация считается от цены завода, который сейчас будет снесён (последнего
    // построенного, приблизительно — игра не хранит цену каждого завода отдельно).
    // Номер завода клампим потолком FACTORY_MAX_COUNT: без этого у игроков с сотнями
    // заводов (сверх задуманного потолка) 1.03^N улетает экспоненциально и компенсация
    // становится абсурдно огромной (десятки миллионов за один завод).
    const priceIndex = Math.min(Math.max(current.factories - 1, 0), C.FACTORY_MAX_COUNT - 1);
    const price = calc.nextFactoryPrice(priceIndex, priceOverride);
    compensation += Math.round(price * C.FACTORY_DESTROY_COMPENSATION_RATE);
    await players.destroyOneFactory(defenderVkId);
    destroyedCount += 1;
  }
  if (compensation > 0) {
    await players.updateBalance(defenderVkId, compensation);
  }
  return { destroyedCount, compensation };
}

async function applyWeaponEffect(defender, weapon, quantity, attacker) {
  const player = await players.getPlayer(defender.vk_id);
  const damageMultiplier = getAttackerDamageMultiplier(attacker);

  if (weapon.effect === 'block_random') {
    // ===== Донат-щит: блокирует снос заводов ЛЮБЫМ НЕядерным оружием целиком =====
    // (nuke_strike ниже щит намеренно не проверяет — по щиту ядерное оружие бьёт как обычно).
    if (calc.isShieldActive(player)) {
      return { type: 'shielded', count: quantity, destroyedCount: 0, compensation: 0, totalDestroyed: null };
    }

    // ===== Урон по заводам противника (окончательный снос, без временной блокировки) =====
    let destroyedCount = 0;
    let compensation = 0;

    const categoryCap = getMaxDestroyCap(weapon.category);

    if (weapon.factoriesPerHit) {
      // Сильное оружие: КАЖДОЕ попадание сразу сносит несколько заводов (без накопления урона).
      const perHit = Math.max(1, Math.round(weapon.factoriesPerHit * damageMultiplier));
      ({ destroyedCount, compensation } = await destroyFactories(defender.vk_id, perHit * quantity, categoryCap));
    } else if (weapon.hitsToDestroy) {
      // Слабое/среднее оружие: нужно накопить несколько попаданий, чтобы снести 1 завод.
      // Каждое попадание даёт (FACTORY_HP_UNIT / hitsToDestroy) единиц урона.
      const baseDamagePerHit = Math.floor(C.FACTORY_HP_UNIT / weapon.hitsToDestroy);
      const damagePerHit = Math.round(baseDamagePerHit * damageMultiplier);

      // Потолок для категории этого оружия и здесь: излишек накопленного урона
      // НЕ теряется, а сохраняется в factory_damage и сработает при следующей атаке.
      let accumulated = (player.factory_damage || 0) + damagePerHit * quantity;
      const priceOverride = await factoryPriceConfig.getOverride();
      while (accumulated >= C.FACTORY_HP_UNIT && destroyedCount < categoryCap) {
        const current = await players.getPlayer(defender.vk_id);
        if (current.factories <= C.NEWBIE_PROTECTION_FACTORIES) break;
        const priceIndex = Math.min(Math.max(current.factories - 1, 0), C.FACTORY_MAX_COUNT - 1);
        const price = calc.nextFactoryPrice(priceIndex, priceOverride);
        compensation += Math.round(price * C.FACTORY_DESTROY_COMPENSATION_RATE);
        await players.destroyOneFactory(defender.vk_id);
        destroyedCount += 1;
        accumulated -= C.FACTORY_HP_UNIT;
      }
      await players.setFactoryDamage(defender.vk_id, accumulated);
      if (compensation > 0) {
        await players.updateBalance(defender.vk_id, compensation);
      }
    }

    let totalDestroyed = null;
    if (destroyedCount > 0 && attacker) {
      totalDestroyed = await players.incrementEnemyFactoriesDestroyed(attacker.vk_id, destroyedCount);
    }

    return { type: 'block', count: quantity, destroyedCount, compensation, totalDestroyed };
  }

  if (weapon.effect === 'nuke_strike') {
    // ===== Ядерное оружие: всегда сносит несколько заводов за удар (мощнее любой ракеты), =====
    // ===== плюс у каждого вида — свой уникальный побочный эффект.                          =====
    const perHit = Math.max(1, Math.round((weapon.factoriesPerHit || 1) * damageMultiplier));
    const { destroyedCount, compensation } = await destroyFactories(
      defender.vk_id,
      perHit * quantity,
      getMaxDestroyCap(weapon.category)
    );

    let totalDestroyed = null;
    if (destroyedCount > 0 && attacker) {
      totalDestroyed = await players.incrementEnemyFactoriesDestroyed(attacker.vk_id, destroyedCount);
    }

    let radiation = false;
    if (weapon.radiation) {
      const radiationUntil = new Date(Date.now() + C.RADIATION_DURATION_MS);
      await players.setRadiationUntil(defender.vk_id, radiationUntil);
      radiation = true;
    }

    let wipedAirDefense = false;
    if (weapon.wipeAirDefense) {
      await players.setAirDefense(defender.vk_id, {});
      await players.setAirDefenseDamage(defender.vk_id, {});
      wipedAirDefense = true;
    }

    return { type: 'nuke_strike', destroyedCount, compensation, totalDestroyed, radiation, wipedAirDefense };
  }

  return { type: 'none' };
}

module.exports = {
  launchAttack,
  resolveAttack,
  applyWeaponEffect,
};
