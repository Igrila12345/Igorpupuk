'use strict';

const C = require('./constants');
const calc = require('./calc');
const players = require('../db/players');
const production = require('../db/production');
const clans = require('../db/clans');
const clanGame = require('./clan');
const zoneWar = require('./zoneWar');
const factoryBuilds = require('../db/factoryBuilds');
const asyncLock = require('./asyncLock');
const gameDate = require('./gameDate');
const globalBoost = require('./globalBoost');
const factoryPriceConfig = require('./factoryPriceConfig');
const { query } = require('../db/pool');

// Начисление часового дохода всем игрокам + налоги + перевод в клан-сейф
async function hourlyTick(bot) {
  const all = await players.getAllActivePlayers();
  // Глобальный ивент-буст (запускает админ, см. !админ буст) — читаем ОДИН раз за весь
  // тик, а не на каждого игрока, т.к. это не персональный, а общий множитель для всех.
  const boost = await globalBoost.getBoost();
  const globalMult = boost ? Number(boost.multiplier) : 1;

  for (const player of all) {
    if (player.factories <= 0 && (player.science_centers || 0) <= 0) continue;

    const factoriesInProd = await production.getFactoriesInUse(player.vk_id);
    let income = calc.incomePerHour(player, factoriesInProd);
    if (globalMult !== 1) income = Math.round(income * globalMult);

    // Клановый бонус "Индустриализация" (читаем клан один раз и переиспользуем ниже для
    // сейфа — раньше клан вычитывался из БД дважды подряд за одну и ту же итерацию:
    // здесь и повторно внутри getClanVaultInfo. Между этими двумя чтениями ничего не
    // меняет состояние клана, так что результат идентичен прежнему, просто без лишнего
    // запроса к БД на каждого игрока в клане каждый час.
    let clanRow = null;
    if (player.clan_id) {
      clanRow = await clans.getClanById(player.clan_id);
      if (clanRow && clanRow.bonus_industry_until && new Date(clanRow.bonus_industry_until) > new Date()) {
        income = Math.round(income * 1.2);
      }
      // Бонус за зоны, захваченные кланом игрока (см. game/zoneWar.js) — суммируется по
      // всем зонам, которыми клан владеет (по умолчанию +25% за зону).
      const zoneBonusPct = await zoneWar.getIncomeBonusPercentForClan(player.clan_id);
      if (zoneBonusPct > 0) {
        income = Math.round(income * (1 + zoneBonusPct));
      }
    }

    if (income > 0) {
      // По просьбе владельца: клановый взнос больше НЕ вычитается из дохода игрока — игрок
      // получает доход целиком, а в сейф клана ДОПОЛНИТЕЛЬНО (сверху, не в ущерб игроку)
      // капает CLAN_VAULT_INCOME_RATE (15%) от его дохода. Это осознанное решение, а не
      // прежний баг с "деньгами из воздуха" — теперь это сделано намеренно.
      await players.updateBalance(player.vk_id, income);

      if (player.clan_id) {
        const clanShare = Math.round(income * C.CLAN_VAULT_INCOME_RATE);
        if (clanShare > 0) {
          const info = await clanGame.getClanVaultInfo(player.clan_id, clanRow);
          if (info && info.effectiveMaxVault > 0) {
            const res = await clans.addVault(player.clan_id, clanShare, info.effectiveMaxVault);
            const { leveledUp, level } = await clans.syncVaultLevel(player.clan_id, res.totalCollected);
            if (leveledUp && bot) {
              bot.notifyUser(
                info.clan.leader_id,
                `🏦 Сейф клана «${info.clan.name}» повысил уровень: ${level}/${C.CLAN_VAULT_MAX_LEVEL}! Вместимость сейфа выросла.`
              ).catch(() => {});
            }
          }
        }
      }
    }

    // Налог на богатство
    const updated = await players.getPlayer(player.vk_id);
    let balance = Number(updated.balance);
    if (balance > C.WEALTH_TAX_THRESHOLD) {
      const excess = balance - C.WEALTH_TAX_THRESHOLD;
      const tax = Math.round(excess * C.WEALTH_TAX_RATE);
      if (tax > 0) await players.updateBalance(player.vk_id, -tax);
    }
  }
}

// Постройка завода (можно сразу несколько штук одной командой, максимум см. C.FACTORY_BUILD_MAX_PER_COMMAND).
// Обёрнуто в withLock по vkId (см. game/asyncLock.js): без этого несколько ПАРАЛЛЕЛЬНЫХ вызовов
// (игрок спамит "построить" много раз подряд вместо одной команды "построить 10") могли бы
// каждый прочитать одно и то же стартовое состояние баланса/лимита до того, как предыдущий
// вызов сохранит свою запись — и таким образом обойти часовой лимит построек или получить
// несколько заводов по цене одного и того же (более раннего) шага цены. С локом результат
// не зависит от того, прислали ли одну команду на N заводов или N команд по одному.
async function buildFactory(vkId, count = 1) {
  return asyncLock.withLock(`build-factory:${vkId}`, () => buildFactoryLocked(vkId, count));
}

async function buildFactoryLocked(vkId, count = 1) {
  const player0 = await players.getPlayer(vkId);
  if (!player0) return { ok: false, reason: 'not_registered' };

  // VIP может купить чуть больше заводов одной командой, чем обычный игрок —
  // см. FACTORY_BUILD_MAX_PER_COMMAND / FACTORY_BUILD_MAX_PER_COMMAND_VIP в constants.js.
  const maxPerCommand = calc.isVipActive(player0)
    ? C.FACTORY_BUILD_MAX_PER_COMMAND_VIP
    : C.FACTORY_BUILD_MAX_PER_COMMAND;
  const requested = Math.max(1, Math.min(Math.floor(count) || 1, maxPerCommand));

  // Воскресная распродажа (по московскому времени): заводы дешевле, а часовой лимит построек
  // выше — см. SUNDAY_FACTORY_DISCOUNT / SUNDAY_FACTORY_BUILD_LIMIT_MULTIPLIER в constants.js.
  const isSunday = gameDate.isSundayMsk();

  // Стартовая цена завода может быть переопределена админом (см. game/factoryPriceConfig.js
  // и "!админ ценазаводов") — читаем ОДИН раз на всю пачку построек, а не на каждый завод.
  const priceOverride = await factoryPriceConfig.getOverride();

  let built = 0;
  let totalSpent = 0;
  let totalDiscount = 0;
  let goldMinesBuilt = 0;
  let lastReason = null;
  let lastExtra = null;

  for (let i = 0; i < requested; i++) {
    const player = await players.getPlayer(vkId);
    const maxFactories = calc.currentFactoryLimit(player.factory_limit_level);
    if (player.factories >= maxFactories) {
      lastReason = 'max_reached';
      lastExtra = { max: maxFactories };
      break;
    }

    let buildLimit = C.FACTORY_BUILD_LIMIT_PER_HOUR + (calc.isVipActive(player) ? C.VIP_BUILD_LIMIT_BONUS : 0);
    if (isSunday) buildLimit = Math.round(buildLimit * C.SUNDAY_FACTORY_BUILD_LIMIT_MULTIPLIER);
    const recentBuilds = await factoryBuilds.countRecentBuilds(vkId, 60 * 60 * 1000);
    if (recentBuilds >= buildLimit) {
      lastReason = 'build_limit';
      lastExtra = { limit: buildLimit };
      break;
    }

    const basePrice = calc.nextFactoryPrice(player.factories, priceOverride);
    const price = isSunday ? Math.round(basePrice * (1 - C.SUNDAY_FACTORY_DISCOUNT)) : basePrice;
    if (Number(player.balance) < price) {
      lastReason = 'not_enough_money';
      lastExtra = { price, missing: price - Number(player.balance) };
      break;
    }

    const isGoldMine = Math.random() < C.GOLD_MINE_CHANCE;
    await players.updateBalance(vkId, -price);
    await players.addFactories(vkId, 1, isGoldMine);
    await factoryBuilds.logBuild(vkId);

    built += 1;
    totalSpent += price;
    totalDiscount += basePrice - price;
    if (isGoldMine) goldMinesBuilt += 1;
  }

  if (built === 0) {
    return { ok: false, reason: lastReason || 'unknown', isSunday, ...lastExtra };
  }

  return {
    ok: true,
    built,
    requested,
    totalSpent,
    totalDiscount,
    goldMinesBuilt,
    isSunday,
    stoppedEarly: built < requested ? lastReason : null,
  };
}

// Досрочная разблокировка завода
async function earlyUnblock(vkId, factoryIndex) {
  const player = await players.getPlayer(vkId);
  if (!player) return { ok: false, reason: 'not_registered' };

  const blocked = player.blocked_factories || [];
  if (!blocked.length || factoryIndex < 0 || factoryIndex >= blocked.length) {
    return { ok: false, reason: 'invalid_index' };
  }

  const entry = blocked[factoryIndex];
  const now = Date.now();
  const unblockAt = new Date(entry.unblock_at).getTime();
  if (unblockAt <= now) return { ok: false, reason: 'already_unblocked' };

  const hoursLeft = Math.ceil((unblockAt - now) / (60 * 60 * 1000));
  const cost = C.EARLY_UNBLOCK_COST_PER_HOUR * hoursLeft;

  if (Number(player.balance) < cost) {
    return { ok: false, reason: 'not_enough_money', cost, missing: cost - Number(player.balance) };
  }

  await players.updateBalance(vkId, -cost);
  blocked.splice(factoryIndex, 1);
  await players.setBlockedFactories(vkId, blocked);

  return { ok: true, cost };
}

// Обработка разблокировки заводов по истечении времени (очистка списка blocked_factories)
async function processFactoryUnblocks() {
  const all = await players.getPlayersWithBlockedFactories();
  const now = Date.now();
  for (const player of all) {
    const blocked = player.blocked_factories || [];
    if (!blocked.length) continue;
    const stillBlocked = blocked.filter((b) => new Date(b.unblock_at).getTime() > now);
    if (stillBlocked.length !== blocked.length) {
      await players.setBlockedFactories(player.vk_id, stillBlocked);
    }
  }
}

// Обработка снятия радиации
async function processRadiationExpiry() {
  await query(
    `UPDATE players SET radiation_until = NULL WHERE radiation_until IS NOT NULL AND radiation_until <= NOW()`
  );
}

module.exports = {
  hourlyTick,
  buildFactory,
  earlyUnblock,
  processFactoryUnblocks,
  processRadiationExpiry,
};
