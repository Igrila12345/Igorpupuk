'use strict';

const calc = require('../game/calc');
const C = require('../game/constants');

// ===== Форматирование времени в МСК (Europe/Moscow), независимо от таймзоны сервера =====
// Сервер работает в UTC — toLocaleTimeString/toLocaleString без явной timeZone показывали
// СЕРВЕРНОЕ (UTC) время под видом обычных часов, из-за чего игроки путали его с московским
// (разница 3 часа) и решали, что кулдаун/таймер уже истёк, хотя на деле ещё нет.
const GAME_TIMEZONE = 'Europe/Moscow';

function formatTimeMsk(date) {
  return new Date(date).toLocaleTimeString('ru-RU', { timeZone: GAME_TIMEZONE });
}

function formatDateTimeMsk(date) {
  return new Date(date).toLocaleString('ru-RU', { timeZone: GAME_TIMEZONE });
}

function formatDateMsk(date) {
  return new Date(date).toLocaleDateString('ru-RU', { timeZone: GAME_TIMEZONE });
}

function arsenalToText(obj) {
  const entries = Object.entries(obj || {}).filter(([, qty]) => qty > 0);
  if (!entries.length) return 'пусто';
  return entries.map(([k, v]) => `${k} (${v})`).join(', ');
}

function profileMessage(player, income, clanName, factoryRank, clanVaultContribution = 0) {
  const clanLine = player.clan_id
    ? `👥 Клан: 【${clanName}】 (${player.clan_role === 'leader' ? 'глава' : player.clan_role === 'deputy' ? 'зам' : 'участник'})`
    : '👥 Клан: нет';

  const skillTier = calc.getSkillTier(player.factories);
  const skillLine = skillTier
    ? `🎖️ Скилл: ${skillTier.name} (+${Math.round(skillTier.damageBonus * 100)}% урон, +${Math.round(
        skillTier.airDefenseBonus * 100
      )} п.п. ПВО)`
    : `🎖️ Скилл: нет (откроется от ${C.SKILL_TIERS[0].factories} заводов)`;

  const careerRankInfo = C.CAREER_RANKS.find((r) => r.level === (player.career_rank || 1)) || C.CAREER_RANKS[0];
  const careerLine = `🎗️ Звание: ${careerRankInfo.title} (см. !карьера)`;

  const vipLine = calc.isVipActive(player)
    ? `👑 VIP до ${formatDateMsk(player.vip_until)} (+${Math.round(
        C.VIP_INCOME_BONUS * 100
      )}% к доходу)\n`
    : '';

  const minerLine = calc.isMinerActive(player)
    ? `⛏️ Майнер ${
        calc.isMinerForever(player) ? 'НАВСЕГДА' : `до ${formatDateMsk(player.miner_until)}`
      } (пассивно приносит вирты и жетоны)\n`
    : '';

  // ===== Расходуемые донат-баффы (см. game/donateBuffs.js, game/constants.js: DONATE_*) =====
  const incomeBoostLine = calc.isIncomeBoostActive(player)
    ? `💰 Буст дохода x${player.income_boost_mult} до ${formatDateTimeMsk(player.income_boost_until)}\n`
    : '';
  const shieldLine = calc.isShieldActive(player)
    ? `🛡️ Щит до ${formatDateTimeMsk(player.shield_until)} (защита от НЕядерного оружия)\n`
    : '';
  const workDoubleLine = calc.isWorkDoubleActive(player)
    ? `🪙 Двойные жетоны за "работу" до ${formatDateTimeMsk(player.work_double_until)}\n`
    : '';
  const farmBoostLine = calc.isFarmBoostActive(player)
    ? `⛏️ Ускорение фермы до ${formatDateTimeMsk(player.farm_boost_until)}\n`
    : '';
  const donateStreakLine =
    player.donate_streak > 1 ? `🔥 Стрик донат-баффов: ${player.donate_streak} дн. подряд\n` : '';

  const superRobotLevel = player.super_robot_level || 0;
  const superRobotLine = superRobotLevel > 0 ? `🤖 Суперробот: ур. ${superRobotLevel}/${C.SUPER_ROBOT_MAX_LEVEL}\n` : '';

  let newbieBoostLine = '';
  if (player.factories < C.NEWBIE_BOOST_FACTORY_THRESHOLD) {
    const progress = Math.max(0, player.factories - 1) / (C.NEWBIE_BOOST_FACTORY_THRESHOLD - 1);
    const boostPercent = Math.round(C.NEWBIE_BOOST_INCOME_BONUS * (1 - progress) * 100);
    newbieBoostLine = `🚀 Бонус старта: +${boostPercent}% к доходу (исчезает к ${C.NEWBIE_BOOST_FACTORY_THRESHOLD} заводам)\n`;
  }

  const rankLine = factoryRank ? `🏆 Место в топе заводов: #${factoryRank}\n` : '';

  const likePenaltyLine = player.like_penalty_active
    ? `⚠️ Доход снижен на ${Math.round(
        C.POST_LIKE_INCOME_PENALTY * 100
      )}%: не лайкнуты посты сообщества (см. !лайки)\n`
    : '';

  const enemyDestroyed = player.enemy_factories_destroyed || 0;
  const destroyedLine = `💥 Уничтожено вражеских заводов: ${calc.formatNumber(enemyDestroyed)}\n`;

  const scienceCenters = player.science_centers || 0;
  const scienceLimit = calc.currentScienceLimit(player.science_limit_level);
  const scienceLine = `🔬 Научных центров: ${scienceCenters}/${scienceLimit}\n`;

  const arsenalLine = `⚔️ Арсенал: ${arsenalToText(player.arsenal)}\n`;
  const airDefenseLine = `🛅 ПВО: ${arsenalToText(player.air_defense)}\n`;

  // Доход в строке "Заводов: ... | Доход: ..." — это ПОЛНЫЙ доход игрока, ничего из него не
  // вычитается. Если игрок состоит в клане, в сейф клана ДОПОЛНИТЕЛЬНО (сверху, игроку это
  // ничего не стоит) капает CLAN_VAULT_INCOME_RATE от его дохода — показываем это отдельной
  // строкой, чтобы было понятно, что это не вычет.
  const incomeBreakdownLine =
    player.clan_id && clanVaultContribution > 0
      ? ` (в сейф клана дополнительно: +${clanVaultContribution}, вам ничего не вычитается)`
      : '';

  return (
    `🏙️ ГОСУДАРСТВО: ${mentionLink(player.vk_id, player.state_name)}\n` +
    `${vipLine}` +
    `${minerLine}` +
    `${incomeBoostLine}` +
    `${shieldLine}` +
    `${workDoubleLine}` +
    `${farmBoostLine}` +
    `${donateStreakLine}` +
    `${superRobotLine}` +
    `${newbieBoostLine}` +
    `${rankLine}` +
    `${likePenaltyLine}` +
    `🏭 Заводов: ${player.factories} | Доход: ${income} вирт/час${incomeBreakdownLine}\n` +
    `💰 Баланс: ${calc.formatNumber(player.balance)} вирт\n` +
    `${destroyedLine}` +
    `${scienceLine}` +
    `${skillLine}\n` +
    `${careerLine}\n` +
    `${arsenalLine}` +
    `${airDefenseLine}` +
    `${clanLine}`
  );
}

const CATEGORY_LABELS = {
  drone: '\ud83d\udee9\ufe0f БПЛА (слабее ракет)',
  missile: '\ud83d\ude80 Ракеты (сильнее БПЛА)',
  nuke: '\u2622\ufe0f Ядерное (сильнее всех ракет)',
  saboteur: '\ud83d\udd76\ufe0f Диверсанты',
};

const CATEGORY_ORDER = ['drone', 'missile', 'nuke', 'saboteur'];

// Русское склонение "завод/завода/заводов" по числу
function pluralFactories(n) {
  const mod10 = n % 10;
  const mod100 = n % 100;
  if (mod10 === 1 && mod100 !== 11) return 'завод';
  if ([2, 3, 4].includes(mod10) && ![12, 13, 14].includes(mod100)) return 'завода';
  return 'заводов';
}

// "Сколько заводов сносит" одним попаданием этого оружия — короткая и понятная фраза.
// Единая логика для ЛЮБОГО оружия с effect 'block_random' или 'nuke_strike':
//   • factoriesPerHit — сильное оружие, сносит несколько заводов за 1 попадание
//   • hitsToDestroy    — слабое оружие, нужно несколько попаданий на 1 завод
function destroyDescription(w) {
  if (w.factoriesPerHit) {
    return w.factoriesPerHit === 1
      ? `💀 Сносит 1 завод с ОДНОГО попадания`
      : `💀 Сносит ${w.factoriesPerHit} ${pluralFactories(w.factoriesPerHit)} с ОДНОГО попадания`;
  }
  if (w.hitsToDestroy) {
    return w.hitsToDestroy === 1
      ? `💀 Сносит 1 завод с ОДНОГО попадания`
      : `💀 Сносит 1 завод за ${w.hitsToDestroy} попадания`;
  }
  return '';
}

// Доп. эффекты у ядерного оружия (помимо сноса заводов)
function extraEffectDescription(w) {
  const parts = [];
  if (w.radiation) parts.push('☢️ + радиация: -20% дохода на 2 ч всем оставшимся заводам');
  if (w.wipeAirDefense) parts.push('🌊 + уничтожает ВСЁ ПВО противника');
  return parts;
}

// Короткое описание эффекта одного запуска — используется в сообщении об атаке (команда "атака")
function weaponEffectSummary(w) {
  const lines = [destroyDescription(w), ...extraEffectDescription(w)].filter(Boolean);
  return lines.join('\n');
}

// Полный список оружия и ПВО с характеристиками и ценами (команда "оружие")
function weaponsInfoMessage() {
  let text = `📋 ОРУЖИЕ — ХАРАКТЕРИСТИКИ И ЦЕНЫ\n`;

  for (const category of CATEGORY_ORDER) {
    const entries = Object.values(C.WEAPONS)
      .filter((w) => w.category === category)
      .sort((a, b) => (a.tier || 0) - (b.tier || 0));
    if (!entries.length) continue;
    text += `\n${CATEGORY_LABELS[category] || category}:\n`;
    for (const w of entries) {
      const effectiveSpeed = w.speedKmh * C.WEAPON_SPEED_MULTIPLIER;
      const flightPer100km = w.speedKmh ? `${Math.round((100 / effectiveSpeed) * 3600)} сек/100км` : 'н/д';
      text += `\n${w.tier ? `Ур.${w.tier} ` : ''}${w.key}\n`;
      text += `💰 Цена: ${w.price} вирт\n`;
      text += `🚀 Скорость: ${flightPer100km}\n`;
      text += `🔫 За 1 атаку: до ${w.maxPerAttack} шт.\n`;
      text += `${destroyDescription(w)}\n`;
      for (const extra of extraEffectDescription(w)) text += `${extra}\n`;
      text += w.notProducible
        ? `🏭 Произвести самому: недоступно — только покупка в магазине\n`
        : `🏭 Произвести самому: ${w.productionCost} вирт, ${w.productionMinutes} мин (ускорено в ${C.PRODUCTION_SPEED_MULTIPLIER} раза)\n`;
    }
  }

  text += `\n🛡️ ПВО:\n`;
  for (const a of Object.values(C.AIR_DEFENSE)) {
    const coverage = a.covers.length >= 4 ? 'всё' : a.covers.join(', ');
    text += `• ${a.key} — цена: ${a.price} вирт | сбивает: ${coverage} | шанс: ${Math.round(a.chance * 100)}%\n`;
  }

  text += `\n🛍️ Купить в магазине: магазин → купить [название] [количество]`;

  return text.trim();
}

// Команда "вооружение": подробный гайд "как произвести оружие самому" — синтаксис команды,
// откуда берётся стоимость и время, какие бонусы ускоряют производство, и живой пример.
function productionGuideMessage() {
  let text = `🏭 КАК ПРОИЗВЕСТИ ОРУЖИЕ САМОМУ\n\n`;

  text += `Синтаксис:\n`;
  text += `произвести [оружие] [количество] [заводов]\n`;
  text += `Пример: произвести Калибр 5 10\n`;
  text += `(запустить производство 5 шт. «Калибр», выделив под это 10 своих заводов)\n\n`;

  text += `📋 Как это работает:\n`;
  text += `1️⃣ Указываете название оружия (как в списке команды «оружие»), сколько штук хотите\n` +
    `   и сколько СВОБОДНЫХ заводов выделяете под производство.\n`;
  text += `2️⃣ Пока заводы заняты производством, они НЕ приносят обычный доход — деньги вместо\n` +
    `   этого идут в производимое оружие.\n`;
  text += `3️⃣ Итоговая стоимость = цена производства оружия (см. «оружие») × количество.\n` +
    `   Это ДЕШЕВЛЕ, чем купить в магазине, но нужно подождать.\n`;
  text += `4️⃣ Время изготовления зависит от количества выделенных заводов: чем больше заводов —\n` +
    `   тем быстрее. Базовое время производства уже ускорено в ${C.PRODUCTION_SPEED_MULTIPLIER} раза.\n`;
  text += `5️⃣ Если выделяете ${C.MASS_PRODUCTION_FACTORY_THRESHOLD}+ заводов сразу — дополнительный бонус:\n` +
    `   ещё −${Math.round(C.MASS_PRODUCTION_TIME_BONUS * 100)}% ко времени производства.\n\n`;

  text += `📦 Когда оружие готово:\n`;
  text += `забрать [оружие] [количество] — забрать готовое оружие в арсенал (иначе оно просто ждёт)\n` +
    `производство — посмотреть статус всех своих очередей и когда что будет готово\n\n`;

  text += `💰 Цены на производство и время для каждого вида оружия — в команде «оружие».\n`;
  text += `🛒 Купить готовое оружие без ожидания — в команде «магазин».`;

  return text.trim();
}

// Описание содержимого кейса и шансов выпадения (команда "склад" / "кейс шансы")
function warehouseRewardLabel(reward) {
  const qtyPart = reward.min === reward.max ? `${reward.min}` : `${reward.min}–${reward.max}`;
  switch (reward.type) {
    case 'virts':
      return `💰 Вирты: ${qtyPart}`;
    case 'tokens':
      return `🪙 Жетоны: ${qtyPart}`;
    case 'factory':
      return `🏭 Бесплатный завод: ${qtyPart} шт.`;
    case 'gold_mine':
      return `✨ Золотая жила (доход x2)`;
    case 'weapon':
      return `⚔️ ${reward.key}: ${qtyPart} шт.`;
    case 'air_defense':
      return `🛡️ ${reward.key}: ${qtyPart} шт.`;
    default:
      return `${reward.key || reward.type}: ${qtyPart}`;
  }
}

function warehouseRewardsMessage() {
  let text = `📦 СОДЕРЖИМОЕ КЕЙСА И ШАНСЫ (цена кейса: ${C.WAREHOUSE_COST_TOKENS} жетонов)\n\n`;
  const sorted = [...C.WAREHOUSE_REWARDS].sort((a, b) => b.chance - a.chance);
  for (const reward of sorted) {
    text += `${reward.chance}% — ${warehouseRewardLabel(reward)}\n`;
  }
  return text.trim();
}

function shopMessage(items, player, msUntilRefresh) {
  const shopGame = require('../game/shop');
  const calcMod = require('../game/calc');
  const ordered = shopGame.orderedShopItems(items);
  const weapons = ordered.filter((i) => i.type === 'weapon' && C.WEAPONS[i.key].category !== 'nuke');
  const nukes = ordered.filter((i) => i.type === 'weapon' && C.WEAPONS[i.key].category === 'nuke');
  const ad = ordered.filter((i) => i.type === 'air_defense');

  let text = `🛒 ВОЕННЫЙ МАГАЗИН (обновление через ${calc.formatDuration(msUntilRefresh)})\n💰 Ваш баланс: ${calc.formatNumber(player.balance)} вирт\n\n`;

  let index = 1;

  if (weapons.length) {
    text += `🔹 Вооружение:\n`;
    for (const item of weapons) {
      const w = C.WEAPONS[item.key];
      text += `${index}. ${item.key} ⭐ ${item.qty} шт. | Цена: ${w.price}\n`;
      index++;
    }
    text += '\n';
  }

  if (ad.length) {
    text += `🔹 ПВО:\n`;
    for (const item of ad) {
      const a = C.AIR_DEFENSE[item.key];
      const coverage = a.covers.length >= 4 ? 'всё' : a.covers.join(', ');
      text += `${index}. ${item.key} ⭐ ${item.qty} шт. | Сбивает: ${coverage} | Шанс: ${Math.round(a.chance * 100)}% | Цена: ${a.price}\n`;
      index++;
    }
    text += '\n';
  }

  if (nukes.length) {
    text += `☢️ Ядерное:\n`;
    for (const item of nukes) {
      const w = C.WEAPONS[item.key];
      text += `${index}. ${item.key} ⭐ ${item.qty} шт. | Цена: ${w.price}\n`;
      index++;
    }
  }

  if (!items.length) {
    text += 'Магазин пуст. Ждите обновления.';
  }

  text += `\n🛍️ Купить: купить [номер или название] [количество]\nПример: купить 3 2  (или: купить Молния 2)`;

  // Расширение лимита заводов — тоже часть магазина, показываем прямо тут
  const level = player.factory_limit_level || 0;
  const currentLimit = calcMod.currentFactoryLimit(level);
  const nextRow = C.FACTORY_LIMIT_LEVELS.find((l) => l.level === level + 1);
  text += `\n\n🏭 Лимит заводов: ${currentLimit}`;
  if (nextRow) {
    text += ` (расширить до ${nextRow.limit} за ${calc.formatNumber(nextRow.cost)} вирт — лимит расширить)`;
  } else {
    text += ` (максимум достигнут)`;
  }

  return text.trim();
}

// Кликабельная ссылка на страницу игрока ВКонтакте вида [id123|Название].
// Обратите внимание: такая ссылка отправляет пользователю уведомление-упоминание
// (пинг) в VK — это ожидаемо и используется в том числе в топах по явному запросу,
// чтобы имена в топах были кликабельными.
function mentionLink(vkId, label) {
  return `[id${vkId}|${label}]`;
}

// Обычное имя без ссылки/пинга — доступно на случай, если где-то понадобится
// показать имя без уведомления адресата.
function plainName(vkId, label) {
  return label;
}

const TOP_DIVIDER = '➖➖➖➖➖➖➖➖➖➖';

function topPlaceLabel(i) {
  const medals = ['🥇', '🥈', '🥉'];
  return medals[i] || `${i + 1}.`;
}

function topFactoriesMessage(list, viewerCoords) {
  let text = `🏭 ТОП ИГРОКОВ ПО ЗАВОДАМ\n${TOP_DIVIDER}\n\n`;
  list.forEach((p, i) => {
    let distancePart = '';
    if (viewerCoords) {
      const d = Math.round(calc.distanceKm(viewerCoords.x, viewerCoords.y, p.x, p.y));
      distancePart = `\n     📍 расстояние: ${d} км`;
    }
    const crown = i === 0 ? ' 👑' : '';
    text += `${topPlaceLabel(i)} ${mentionLink(p.vk_id, p.state_name)}${crown}\n     🏭 ${p.factories} заводов${distancePart}\n\n`;
  });
  text += `${TOP_DIVIDER}\n💰 Ежедневный бонус за 1-3 места!`;
  return text;
}

function topBalanceMessage(list) {
  let text = `💰 ТОП ИГРОКОВ ПО ВИРТАМ\n${TOP_DIVIDER}\n\n`;
  list.forEach((p, i) => {
    text += `${topPlaceLabel(i)} ${mentionLink(p.vk_id, p.state_name)}\n     💰 ${calc.formatNumber(p.balance)} вирт\n\n`;
  });
  text += `${TOP_DIVIDER}\n⚠️ Топ-3 платят дополнительный налог: 10% / 7% / 5% в час от суммы сверх 5 000 вирт.`;
  return text;
}

function topRobotMessage(list) {
  const robotGame = require('../game/robot');
  let text = `🤖 ТОП ИГРОКОВ ПО УРОВНЮ РОБОТА\n${TOP_DIVIDER}\n\n`;
  list.forEach((p, i) => {
    const level = p.robot_level || 1;
    text += `${topPlaceLabel(i)} ${mentionLink(p.vk_id, p.state_name)}\n     ур. ${level} (${robotGame.levelName(level)})\n\n`;
  });
  return text.trim();
}

function topSuperRobotMessage(list) {
  const superRobotGame = require('../game/superRobot');
  if (!list.length) {
    return `🤖 ТОП ИГРОКОВ ПО УРОВНЮ СУПЕРРОБОТА\n\nПока никто не построил суперробота. Постройка: суперробот прокачать`;
  }
  let text = `🤖 ТОП ИГРОКОВ ПО УРОВНЮ СУПЕРРОБОТА\n${TOP_DIVIDER}\n\n`;
  list.forEach((p, i) => {
    const level = p.super_robot_level || 0;
    text += `${topPlaceLabel(i)} ${mentionLink(p.vk_id, p.state_name)}\n     ур. ${level} (${superRobotGame.levelName(level)})\n\n`;
  });
  return text.trim();
}

function topClansMessage(list) {
  let text = `👥 ТОП КЛАНОВ ПО ДОХОДУ В ЧАС\n${TOP_DIVIDER}\n\n`;
  list.forEach((c, i) => {
    const leaderLine = c.leader_id ? `\n     👑 глава: ${mentionLink(c.leader_id, 'профиль')}` : '';
    text +=
      `${topPlaceLabel(i)} ${c.name}\n` +
      `     💰 ${calc.formatNumber(c.total_income)} вирт/час · 🏭 ${c.total_factories} заводов · 🔒 сейф ${calc.formatNumber(c.vault)}${leaderLine}\n\n`;
  });
  text += `${TOP_DIVIDER}\n🏆 Ежедневный бонус в сейф за 1-3 места!`;
  return text;
}

function topIncomeMessage(list) {
  if (!list.length) {
    return `💵 ТОП ИГРОКОВ ПО ДОХОДУ В ЧАС\n\nПока ни у кого нет активного дохода.`;
  }
  let text = `💵 ТОП ИГРОКОВ ПО ДОХОДУ В ЧАС\n${TOP_DIVIDER}\n\n`;
  list.forEach((entry, i) => {
    const { player, income } = entry;
    text += `${topPlaceLabel(i)} ${mentionLink(player.vk_id, player.state_name)}\n     💰 ${calc.formatNumber(
      income
    )} вирт/час\n\n`;
  });
  return text.trim();
}

function topFarmLevelMessage(list) {
  if (!list.length) {
    return `⛏️ ТОП ИГРОКОВ ПО УРОВНЮ МАЙНИНГ-ФЕРМЫ\n\nПока никто не построил ферму. Постройка: ферма прокачать`;
  }
  let text = `⛏️ ТОП ИГРОКОВ ПО УРОВНЮ МАЙНИНГ-ФЕРМЫ\n${TOP_DIVIDER}\n\n`;
  list.forEach((p, i) => {
    text += `${topPlaceLabel(i)} ${mentionLink(p.vk_id, p.state_name)}\n     ур. ${p.farm_level}/999\n\n`;
  });
  return text.trim();
}

function topFarmIncomeMessage(list, rate) {
  const farmGame = require('../game/farm');
  if (!list.length) {
    return `⛏️ ТОП ИГРОКОВ ПО ДОХОДУ МАЙНИНГ-ФЕРМЫ В ЧАС\n\nПока никто не построил ферму. Постройка: ферма прокачать`;
  }
  let text = `⛏️ ТОП ИГРОКОВ ПО ДОХОДУ МАЙНИНГ-ФЕРМЫ В ЧАС\n${TOP_DIVIDER}\n\n`;
  list.forEach((p, i) => {
    const avgCoins = farmGame.avgYieldPerHour(p.farm_level);
    const virtsEquivalent = Math.round(avgCoins * rate);
    text += `${topPlaceLabel(i)} ${mentionLink(p.vk_id, p.state_name)}\n     ур. ${p.farm_level} · ~${calc.formatNumber(
      avgCoins
    )} ₿/час (≈${calc.formatNumber(virtsEquivalent)} вирт по текущему курсу)\n\n`;
  });
  return text.trim();
}

const HELP_INTRO =
  `📚 ПОМОЩЬ\n` +
  `Команды работают и с «!», и без него (например: старт или !старт). Работает и в ЛС, и в беседах.\n` +
  `Новичок? Нажмите «🧭 С чего начать» ниже или напишите гайд.\n\n` +
  `Выберите раздел кнопкой под этим сообщением 👇`;

// Разделы помощи по кнопкам. Ключ — короткий код для payload кнопки.
const HELP_SECTIONS = {
  guide: {
    label: '🧭 С чего начать',
    text:
      `🧭 С ЧЕГО НАЧАТЬ (пошаговый гайд)\n\n` +
      `1️⃣ старт — регистрация, придумайте название своего государства\n` +
      `2️⃣ построить — стройте заводы, они приносят доход каждый час (в профиль → «Доход»)\n` +
      `3️⃣ профиль — проверяйте баланс, доход и место в топе в любой момент\n` +
      `4️⃣ магазин → купить [номер] [количество] — покупайте оружие и ПВО, пока копите на заводы\n` +
      `5️⃣ атака @юзер [оружие] [количество] — атакуйте других игроков, чтобы получить трофеи вирт\n` +
      `6️⃣ произвести [оружие] [количество] [заводов] — производите оружие сами на своих заводах, дешевле магазина\n` +
      `7️⃣ работа — бесплатная мини-игра на жетоны (до 40 раз в день), жетоны меняются на заводы и призы через склад\n` +
      `8️⃣ клан создать [название] (или клан вступить [название]) — вступайте в клан, чтобы получать бонусы из общего сейфа\n\n` +
      `💡 Совет: сначала стройте заводы (это основа дохода), затем покупайте ПВО для защиты, и только потом — оружие для атак.\n` +
      `📖 Остальные разделы помощи ниже раскрывают каждую механику подробнее.`,
  },
  main: {
    label: '🏛️ Основное',
    text:
      `🏛️ ОСНОВНОЕ\n\n` +
      `старт (или: начать) — регистрация\n` +
      `профиль (@юзер) — статистика\n` +
      `я — то же самое, что «профиль», но только для себя (короткий вариант, работает в ЛС)\n` +
      `переименовать [новое_название] — сменить название (200 вирт)\n` +
      `бонус — забрать ежедневный бонус (раз в 24 ч)\n` +
      `задания — ежедневные задания (обновляются в 00:00 МСК), награда: вирты + очки карьеры\n` +
      `карьера — ваше звание и прогресс до следующего (звания дают разовую награду виртами)\n` +
      `перевод @юзер [сумма] — перевести вирты игроку (раз в 2 ч одному игроку)\n` +
      `донат — прайс-лист VIP / майнера / суперробота\n\n` +
      `🎖️ Скиллы (пассивные бонусы за количество заводов):\n` +
      `50 заводов — +15% урон по вражеским заводам, +5 п.п. к перехвату ПВО\n` +
      `150 заводов — +35% урон по вражеским заводам, +10 п.п. к перехвату ПВО`,
  },
  economy: {
    label: '💰 Экономика',
    text:
      `💰 ЭКОНОМИКА\n\n` +
      `построить [количество] — построить завод(ы), максимум ${C.FACTORY_BUILD_MAX_PER_COMMAND} за раз, не более 10 в час\n` +
      `оружие — характеристики, эффекты и цены всего оружия и ПВО (с производством)\n` +
      `вооружение — гайд «как произвести оружие самому» (синтаксис, стоимость, бонусы, пример)\n` +
      `магазин — ассортимент магазина\n` +
      `купить [название или номер] [количество] — купить оружие/ПВО\n` +
      `арсенал — ваше оружие\n` +
      `лимит — статус лимита заводов (100 → 1000)\n` +
      `лимит расширить — увеличить лимит\n\n` +
      `🔬 Научные центры:\n` +
      `наука — статус (доход ${C.SCIENCE_INCOME_PER_HOUR} вирт/час за центр)\n` +
      `наука построить — построить центр (${C.SCIENCE_BUILD_FACTORY_COST} заводов + вирты, цена растёт каждые ${C.SCIENCE_BUILD_COST_STEP_SIZE} центров)\n` +
      `наука расширить — увеличить лимит центров\n` +
      `наука обменять [количество] — обменять центры ОБРАТНО на заводы (курс: 1 центр = ${Math.max(1, Math.floor(C.SCIENCE_BUILD_FACTORY_COST * C.SCIENCE_TO_FACTORY_RATE))} завода, вирты за постройку не возвращаются, лимит: ${C.SCIENCE_TO_FACTORY_MAX_PER_DAY} центра в день, нельзя опускаться ниже ${C.NEWBIE_PROTECTION_SCIENCE_CENTERS} центров)\n\n` +
      `🔥 Глобальный буст: администратор может временно поднять доход ВСЕМ игрокам сразу (множитель применяется автоматически к почасовому доходу — отдельной команды нет, только уведомление в чате).\n\n` +
      `⛏️ Майнинг-ферма (добывает отдельную валюту — нанокоины ₿, кнопки под сообщением «ферма»):\n` +
      `ферма — статус (уровень, мощность, баланс, автономность)\n` +
      `ферма прокачать — построить (${calc.formatNumber(C.FARM_BUILD_COST)} вирт) или повысить уровень (максимум ${C.FARM_MAX_LEVEL}, качать тяжело)\n` +
      `ферма включить / ферма выключить — вкл./выкл. непрерывную добычу (копит до ${C.FARM_AUTONOMY_HOURS} ч. без присмотра)\n` +
      `ферма снять — перенести накопленное на личный кошелёк (и перезапустить автономность)\n` +
      `ферма продать [число|всё] — продать нанокоины за вирты по плавающему курсу\\n\\n` +
      `🏢 Бизнес (2 слота, +1 за донат до ${C.BUSINESS_MAX_EXTRA_SLOTS}, кнопки под сообщением «бизнес»):\\n` +
      `бизнес — список ваших бизнесов\\n` +
      `бизнес магазин — каталог из 25 видов бизнеса (цены и доход)\\n` +
      `бизнес купить [номер] — купить по номеру из магазина\\n` +
      `бизнес [id] — карточка своего бизнеса (уровень, доход, остаток сырья)\\n` +
      `бизнес собрать [id] — собрать доход (без id — собрать со всех сразу)\\n` +
      `бизнес прокачать [id] — повысить уровень (максимум ${C.BUSINESS_MAX_LEVEL})\\n` +
      `бизнес сырьё [id] — пополнить запас сырья на ${C.BUSINESS_STOCK_HOURS}ч (без пополнения бизнес сгорает через ${C.BUSINESS_GRACE_HOURS}ч после того как сырьё кончилось)\\n` +
      `бизнес продать [id] — продать государству за ${Math.round(C.BUSINESS_SELL_RATE * 100)}% от цены покупки`,
  },
  combat: {
    label: '⚔️ Бой',
    text:
      `⚔️ БОЙ И ПРОИЗВОДСТВО\n\n` +
      `атака @юзер [оружие] [количество] — атаковать\n` +
      `разведка @юзер — узнать расстояние (50 вирт)\n\n` +
      `📏 Пороги по заводам (не путать с бонусом дохода новичкам до 150 заводов — см. раздел «Основное»):\n` +
      `Атаковать можно от ${C.MIN_FACTORIES_TO_ATTACK} заводов${C.MIN_FACTORIES_TO_ATTACK_MISSILE !== C.MIN_FACTORIES_TO_ATTACK ? ` (ракетами — от ${C.MIN_FACTORIES_TO_ATTACK_MISSILE})` : ''}\n` +
      `Атаковать МОЖНО игрока минимум с ${C.MIN_FACTORIES_TO_BE_ATTACKED} заводами\n` +
      `Сносить заводы нельзя ниже ${C.NEWBIE_PROTECTION_FACTORIES} заводов у защитника (полная защита новичков)\n\n` +
      `🌊 Волновая тактика: кулдауна на цель больше нет — атаковать одного и того же игрока можно ` +
      `сколько угодно раз подряд, ограничивает только запас оружия в вашем арсенале. Каждая единица ` +
      `оружия теперь пробивается через ПВО отдельно, поэтому можно сначала закидать дешёвыми дронами, ` +
      `чтобы истощить ПВО противника, а затем добить дорогим оружием по ослабленной обороне.\n\n` +
      `произвести [оружие] [количество] [заводов] — запустить производство\n` +
      `производство — статус очередей\n` +
      `забрать [оружие] [количество] — забрать готовое оружие\n\n` +
      `💥 Снос заводов: потолок разовой атаки зависит от категории оружия — ` +
      `БПЛА до ${C.MAX_FACTORIES_DESTROYED_PER_ATTACK_BY_CATEGORY.drone}, ракеты до ${C.MAX_FACTORIES_DESTROYED_PER_ATTACK_BY_CATEGORY.missile}, ` +
      `диверсанты до ${C.MAX_FACTORIES_DESTROYED_PER_ATTACK_BY_CATEGORY.saboteur}, ядерное оружие до ${C.MAX_FACTORIES_DESTROYED_PER_ATTACK_BY_CATEGORY.nuke} заводов за одну атаку.\n\n` +
      `🦾 Суперробот — отдельный боевой юнит (см. раздел «Работа»): суперробот атака @юзер\n\n` +
      `🕵️ кража @юзер — красть у топ-${C.STEAL_TOP_N} игроков по виртам (см. !топ вирты). ` +
      `Кулдаун ${Math.round(C.STEAL_COOLDOWN_MS / 60000)} мин., лимит ${C.STEAL_DAILY_LIMIT} краж в день. ` +
      `Вору достаётся лишь часть похищенного (${Math.round(C.STEAL_ATTACKER_SHARE * 100)}%) — топеров кража сильно не сносит. ` +
      `Раз в ${C.STEAL_BONUS_EVERY} успешных краж — доп. бонус: ${C.STEAL_BONUS_SCIENCE} научный центр или ${C.STEAL_BONUS_FACTORIES} заводов случайно.\n\n` +
      `👹 Мировой босс — отдельный раздел помощи, кнопка «Босс» ниже.`,
  },
  boss: {
    label: '👹 Босс',
    text:
      `👹 МИРОВОЙ БОСС\n\n` +
      `Кооп-ивент на весь сервер сразу: администрация объявляет о появлении босса, и все игроки ` +
      `стреляют по нему ракетами из общего баланса вирт. У босса нет «здоровья» — событие идёт, ` +
      `пока администратор не завершит его вручную, после чего всем участникам выдаются награды.\n\n` +
      `📌 Команды:\n` +
      `босс — статус: активен ли сейчас босс, ваш личный вклад, топ-5 по попаданиям\n` +
      `босс [количество] — купить и запустить столько ракет «${C.BOSS_ROCKET_NAME}», например «босс 10»\n\n` +
      `⚙️ Как это работает:\n` +
      `Каждая ракета «${C.BOSS_ROCKET_NAME}» стоит ${C.BOSS_ROCKET_PRICE} вирт и запускается сразу при покупке.\n` +
      `🎯 Шанс попадания — ${Math.round(C.BOSS_HIT_CHANCE * 100)}% на каждую ракету.\n` +
      `✅ При попадании — случайная награда ${C.BOSS_HIT_REWARD_MIN}–${C.BOSS_HIT_REWARD_MAX} вирт (донат-бафф x2 может удвоить).\n` +
      `❌ При промахе — босс забирает у вас 1 завод или 1 научный центр (если есть что забирать; ниже порога защиты новичков ничего не списывается).\n` +
      `📅 Лимит ${C.BOSS_MAX_ROCKETS_PER_DAY} ракет в сутки на игрока — считается по попыткам выстрела, а не по попаданиям.\n\n` +
      `🏆 Когда администратор завершает ивент, каждый участник (кто выпустил хотя бы 1 ракету) получает ` +
      `${C.BOSS_FINISH_PARTICIPATION_BONUS} вирт за участие, плюс топ-3 по числу попаданий получают дополнительный бонус: ` +
      `1 место +${calc.formatNumber(C.BOSS_FINISH_TOP_BONUS[0])}, 2 место +${calc.formatNumber(C.BOSS_FINISH_TOP_BONUS[1])}, ` +
      `3 место +${calc.formatNumber(C.BOSS_FINISH_TOP_BONUS[2])} вирт.\n\n` +
      `💡 Совет: стреляйте пачками через «босс [число]» — так меньше кликов, а награды/штрафы считаются честно за каждую ракету отдельно.`,
  },
  clan: {
    label: '👥 Кланы',
    text:
      `👥 КЛАНЫ\n\n` +
      `клан — характеристики своего клана (то же самое, что клан инфо)\n` +
      `клан создать [название] — бесплатно\n` +
      `клан пригласить @юзер — только глава\n` +
      `клан вступить [название]\n` +
      `клан кик @юзер — только глава\n` +
      `клан зам @юзер — назначить зама (только глава)\n` +
      `клан снять_зама @юзер — снять зама (только глава)\n` +
      `клан бонус [форсаж/эшелон/индустриализация] — только глава, тратит сейф\n` +
      `  • Форсаж: скорость полёта оружия x2 на 1 ч (цена: ${Math.round(C.CLAN_BONUSES['форсаж'].costRateOfMaxVault * 100)}% от макс. сейфа, кулдаун ${C.CLAN_BONUSES['форсаж'].cooldownHours} ч)\n` +
      `  • Эшелон: ПВО точнее на 20% на 1 ч (цена: ${Math.round(C.CLAN_BONUSES['эшелон'].costRateOfMaxVault * 100)}% от макс. сейфа, кулдаун ${C.CLAN_BONUSES['эшелон'].cooldownHours} ч)\n` +
      `  • Индустриализация: +20% дохода всем на 1 ч (цена: ${Math.round(C.CLAN_BONUSES['индустриализация'].costRateOfMaxVault * 100)}% от макс. сейфа, кулдаун ${C.CLAN_BONUSES['индустриализация'].cooldownHours} ч)\n` +
      `клан инфо — список участников и уровень сейфа\n` +
      `клан покинуть — если вы глава, главенство автоматически передаётся другому участнику (заму, если есть)\n` +
      `клан удалить [название] — распустить клан безвозвратно (только глава, нужно повторить название, сейф должен быть пуст)\n\n` +
      `🏦 Сейф клана (казна):\n` +
      `клан сейф — баланс, вместимость, уровень и прогресс\n` +
      `клан сейф пополнить [сумма] — пополнить может любой участник из своего баланса (короткий алиас: +сейф [сумма])\n` +
      `клан сейф забрать [сумма] — снять на свой баланс может глава или зам\n` +
      `клан сейф лог — журнал всех снятий из сейфа (кто, сколько, когда) — видят глава и зам\n\n` +
      `📈 Уровень сейфа растёт от ВСЕХ поступлений за всё время (15% от дохода участников — сверху, не в ущерб им — + ручные взносы) — ` +
      `10 000 собранных вирт = 1 уровень, до 100 уровней. Каждый уровень даёт +1% к вместимости сейфа. ` +
      `Траты и снятие главой уровень не понижают.`,
  },
  work: {
    label: '👷 Работа',
    text:
      `👷 РАБОТА И ЖЕТОНЫ\n\n` +
      `работа — меню статистики (сколько попыток сделано, жетоны) с кнопками: обмен на заводы, кейс, начать работу\n` +
      `инспекция (или: осмотр) — вторая бесплатная мини-игра на жетоны, отдельный лимит попыток от «работы»\n` +
      `склад — открыть кейс за 100 жетонов + показывает содержимое и шансы выпадения (лимит: ${C.EXCHANGE_CASE_MAX_PER_DAY} в день)\n` +
      `склад шансы — только шансы и содержимое кейса, без открытия\n` +
      `выбрать [номер] — выбрать коробку в открытом кейсе\n` +
      `обменять — обменять 50 жетонов на 1 завод напрямую, без рандома (лимит: ${C.EXCHANGE_FACTORY_MAX_PER_DAY} в день)\n` +
      `обменять наука — обменять ${C.EXCHANGE_SCIENCE_COST_TOKENS} жетонов на 1 научный центр, только с VIP-статусом (лимит: ${C.EXCHANGE_SCIENCE_MAX_PER_DAY} в день)\n\n` +
      `🔭 Дозор (короткий кулдаун — чем заняться, пока копится доход/тикают часовые кулдауны):\n` +
      `дозор — быстрый обход, доступно раз в ${Math.round(C.PATROL_COOLDOWN_MS / 60000)} минут, случайная награда: вирты, жетоны или ничего\n\n` +
      `🤖 Робот (мгновенная прибыль без ожидания; с уровня ${C.ROBOT_FACTORY_DESTROY_UNLOCK_LEVEL} умеет и атаковать):\n` +
      `робот — мгновенно собрать доход виртами (доступно раз в час)\n` +
      `мой робот — статистика: уровень, доход, кулдауны\n` +
      `робот прокачать — повысить уровень (до ${C.ROBOT_MAX_LEVEL}, каждый уровень дороже предыдущего, цена в виртах)\n` +
      `роботы — список уровней робота: имена, цена прокачки, доход, жетоны\n` +
      `отправить — мгновенно получить жетоны от робота (доступно раз в час, чем выше уровень — тем больше)\n` +
      `робот атака @юзер — с уровня ${C.ROBOT_FACTORY_DESTROY_UNLOCK_LEVEL}: атаковать игрока и снести заводы, если прорвётся ` +
      `(1 завод на ${C.ROBOT_FACTORY_DESTROY_UNLOCK_LEVEL} ур., дальше +1 каждые ${C.ROBOT_FACTORY_DESTROY_LEVELS_PER_STEP} ур., максимум ${C.ROBOT_FACTORY_DESTROY_MAX} — слабее суперробота) ` +
      `(перехватить может только ПВО С-400 Триумф противника, кулдаун ${Math.round(C.ROBOT_ATTACK_COOLDOWN_MS / 3600000)} ч)\n` +
      `топ робот — рейтинг игроков по уровню робота\n\n` +
      `🦾 Суперробот (боевой юнит, качается ВИРТАМИ, качать тяжело):\n` +
      `суперробот — статус: уровень, сила атаки, кулдаун\n` +
      `суперробот прокачать — повысить уровень за вирты (до ${C.SUPER_ROBOT_MAX_LEVEL}, цена растёт очень быстро)\n` +
      `суперробот атака @юзер — атаковать игрока: сносит заводы напрямую (1 ур. = 1 завод, дальше сильнее), ` +
      `перехватить может только ПВО С-400 Триумф противника (если получится — защитник получает крупную награду виртами, робот не теряется)\n` +
      `суперроботы — список всех ${C.SUPER_ROBOT_MAX_LEVEL} уровней суперробота\n` +
      `топ суперробот — рейтинг игроков по уровню суперробота\n\n` +
      `⛏️ Майнер (донат-предмет, выдаётся администратором):\n` +
      `майнер — проверить статус (активен ли, до какого числа)\n` +
      `Пока активен — каждый час пассивно (без ваших действий) приносит немного вирт и с шансом жетон.`,
  },
  style: {
    label: '🎨 Стили',
    text:
      `🎨 СТИЛИ ПРОФИЛЯ\n\n` +
      `стиль (или: скины) — ваш инвентарь стилей\n` +
      `стиль выбрать [номер] — экипировать стиль из инвентаря\n` +
      `стиль снять — снять текущий стиль\n` +
      `стиль продать [номер] [цена] — выставить свой стиль на витрину для продажи другим игрокам\n\n` +
      `🛍️ Витрина (торговля стилями между игроками):\n` +
      `витрина — список лотов, выставленных игроками\n` +
      `витрина купить [номер] — купить лот с витрины\n` +
      `витрина снять [номер] — снять свой лот с продажи\n\n` +
      `🏛️ Редкие стили также иногда появляются на общем аукционе (см. раздел «Аукцион и промо») — ` +
      `следите за !аукцион. Администратор может выдать редкий стиль напрямую или закрепить его игроку принудительно.`,
  },
  market: {
    label: '🛎️ Аукцион и промо',
    text:
      `🛎️ АУКЦИОН\n\n` +
      `аукцион — список активных лотов\n` +
      `аукцион [номер] — подробности лота\n` +
      `продать [товар] [кол-во] [старт_цена] [шаг] [часов] — выставить лот (только администратор)\n` +
      `ставка [номер] [сумма] — сделать ставку\n` +
      `отмена [номер] — отменить свой лот (если ставок ещё нет)\n` +
      `лоты — ваши лоты\n\n` +
      `🎟️ Промокоды:\n` +
      `промо [код] — активировать промокод`,
  },
  social: {
    label: '📊 Рейтинги',
    text:
      `📊 РЕЙТИНГИ\n\n` +
      `топ заводы\n` +
      `топ вирты\n` +
      `топ кланы`,
  },
};

const HELP_SECTION_ORDER = ['guide', 'main', 'economy', 'combat', 'boss', 'clan', 'work', 'style', 'market', 'social'];

module.exports = {
  arsenalToText,
  mentionLink,
  plainName,
  formatTimeMsk,
  formatDateTimeMsk,
  formatDateMsk,
  profileMessage,
  shopMessage,
  weaponsInfoMessage,
  productionGuideMessage,
  weaponEffectSummary,
  pluralFactories,
  warehouseRewardsMessage,
  topFactoriesMessage,
  topBalanceMessage,
  topRobotMessage,
  topSuperRobotMessage,
  topClansMessage,
  topIncomeMessage,
  topFarmLevelMessage,
  topFarmIncomeMessage,
  HELP_INTRO,
  HELP_SECTIONS,
  HELP_SECTION_ORDER,
};
