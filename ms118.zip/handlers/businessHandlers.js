'use strict';

const { Keyboard } = require('vk-io');
const players = require('../db/players');
const business = require('../game/business');
const calc = require('../game/calc');
const C = require('../game/constants');
const images = require('../game/commandImages');

// ===== Мастер "собрать свою сумму" с бизнеса (в памяти процесса, живёт максимум
// COLLECT_WIZARD_TTL_MS — тот же приём, что и у мастера создания депозита, см.
// handlers/depositHandlers.js: pending/getPending/clearPending). vkId -> { businessId, expiresAt }.
const COLLECT_WIZARD_TTL_MS = 5 * 60 * 1000;
const pendingCollect = new Map();

function clearPendingCollect(vkId) {
  pendingCollect.delete(vkId);
}

function getPendingCollect(vkId) {
  const state = pendingCollect.get(vkId);
  if (!state) return null;
  if (Date.now() > state.expiresAt) {
    pendingCollect.delete(vkId);
    return null;
  }
  return state;
}

async function requireRegistered(ctx) {
  const player = await players.getPlayer(ctx.senderId);
  if (!player || player.registration_step !== 'done') {
    await ctx.send('⛔ Вы ещё не зарегистрированы. Напишите старт');
    return null;
  }
  return player;
}

function formatDuration(ms) {
  if (ms <= 0) return '0ч';
  const totalMinutes = Math.floor(ms / 60000);
  const hours = Math.floor(totalMinutes / 60);
  const minutes = totalMinutes % 60;
  if (hours <= 0) return `${minutes}мин.`;
  return `${hours}ч. ${minutes}мин.`;
}

async function send(ctx, text, keyboard) {
  await ctx.send(images.withImage('business', { message: text, keyboard }));
}

function homeKeyboard(mine) {
  const rows = mine.map((entry) => [
    Keyboard.textButton({
      label: `🏢 #${entry.business.id} ${entry.type.name} (ур.${entry.business.level})`,
      payload: { cmd: 'business_view', id: entry.business.id },
      color: Keyboard.SECONDARY_COLOR,
    }),
  ]);

  // ВАЖНО: у инлайн-клавиатур ВК помимо лимита кнопок есть ОТДЕЛЬНЫЙ жёсткий лимит —
  // не более 6 РЯДОВ на клавиатуру (RangeError: Max count of keyboard rows 6 в vk-io,
  // это происходит при сериализации запроса, т.е. падает вся отправка сообщения).
  // При максимуме бизнесов (2 базовых + 3 доп. = 5, см. BUSINESS_BASE_SLOTS/
  // BUSINESS_MAX_EXTRA_SLOTS) это 5 рядов под бизнесы, поэтому нижние кнопки навигации
  // должны занимать не больше 1 ряда суммарно — иначе 5 (бизнесы) + 2 (нав. в два ряда) = 7.
  rows.push([
    Keyboard.textButton({ label: '🛒 Магазин', payload: { cmd: 'business_shop' }, color: Keyboard.PRIMARY_COLOR }),
    Keyboard.textButton({
      label: '💰 Собрать всё',
      payload: { cmd: 'business_collect_all' },
      color: Keyboard.POSITIVE_COLOR,
    }),
    Keyboard.textButton({ label: '🏠', payload: { cmd: 'business_home' }, color: Keyboard.SECONDARY_COLOR }),
  ]);

  return Keyboard.keyboard(rows).inline();
}

// ВАЖНО: у INLINE-клавиатур ВК жёсткий лимит — не более 10 кнопок в сообщении СУММАРНО
// (это не то же самое, что лимит обычной клавиатуры в 10 рядов/40 кнопок!). При 9 товарах
// на странице (3x3) + кнопка "След. страница" + кнопка "◀️ Мои бизнесы" получается 11 кнопок,
// и ВК возвращает 911 "Keyboard format is invalid: keyboard contains too much buttons".
// 6 товаров на странице + до 2 кнопок навигации (◀️/▶️) + 1 кнопка "Мои бизнесы" = максимум 9 —
// с запасом укладывается в лимит.
const SHOP_PAGE_SIZE = 6;

// Магазин листается страницами по 9 видов бизнеса (3 в ряд), чтобы не упираться в лимит
// ВК на инлайн-клавиатуру (максимум 10 рядов и 40 кнопок в одной клавиатуре). Нажатие на
// бизнес сразу его покупает.
function shopKeyboard(page) {
  const types = business.getCatalog();
  const totalPages = Math.max(1, Math.ceil(types.length / SHOP_PAGE_SIZE));
  const safePage = Math.min(Math.max(page, 0), totalPages - 1);
  const pageTypes = types.slice(safePage * SHOP_PAGE_SIZE, safePage * SHOP_PAGE_SIZE + SHOP_PAGE_SIZE);

  const rows = [];
  for (let i = 0; i < pageTypes.length; i += 3) {
    const chunk = pageTypes.slice(i, i + 3);
    rows.push(
      chunk.map((type) =>
        Keyboard.textButton({
          label: `#${type.id} ${type.name}`,
          payload: { cmd: 'business_buy', id: type.id, page: safePage },
          color: Keyboard.PRIMARY_COLOR,
        })
      )
    );
  }

  const nav = [];
  if (safePage > 0) {
    nav.push(
      Keyboard.textButton({ label: '◀️ Пред. страница', payload: { cmd: 'business_shop', page: safePage - 1 }, color: Keyboard.SECONDARY_COLOR })
    );
  }
  if (safePage < totalPages - 1) {
    nav.push(
      Keyboard.textButton({ label: 'След. страница ▶️', payload: { cmd: 'business_shop', page: safePage + 1 }, color: Keyboard.SECONDARY_COLOR })
    );
  }
  if (nav.length) rows.push(nav);

  rows.push([Keyboard.textButton({ label: '◀️ Мои бизнесы', payload: { cmd: 'business_home' }, color: Keyboard.SECONDARY_COLOR })]);
  return { keyboard: Keyboard.keyboard(rows).inline(), totalPages, safePage };
}

function businessCardKeyboard(id) {
  return Keyboard.keyboard([
    [
      Keyboard.textButton({ label: '💰 25%', payload: { cmd: 'business_collect_pct', id, pct: 25 }, color: Keyboard.POSITIVE_COLOR }),
      Keyboard.textButton({ label: '💰 50%', payload: { cmd: 'business_collect_pct', id, pct: 50 }, color: Keyboard.POSITIVE_COLOR }),
      Keyboard.textButton({ label: '💰 Всё', payload: { cmd: 'business_collect_pct', id, pct: 100 }, color: Keyboard.POSITIVE_COLOR }),
    ],
    [
      // Своя сумма: кнопка не собирает сразу, а запускает мастер (см. handleCollectCustomPrompt/
      // handlePendingCollectAmount ниже) — бот спрашивает сумму, следующее голое число от игрока
      // и есть команда "бизнес собрать <id> <сумма>", просто без необходимости печатать её руками.
      Keyboard.textButton({ label: '✏️ Своя сумма', payload: { cmd: 'business_collect_custom', id }, color: Keyboard.SECONDARY_COLOR }),
    ],
    [
      Keyboard.textButton({ label: '⬆️ Прокачать', payload: { cmd: 'business_upgrade', id }, color: Keyboard.PRIMARY_COLOR }),
      Keyboard.textButton({ label: '⛽ Пополнить сырьё', payload: { cmd: 'business_refill', id }, color: Keyboard.SECONDARY_COLOR }),
    ],
    [
      Keyboard.textButton({ label: '💵 Продать', payload: { cmd: 'business_sell', id }, color: Keyboard.NEGATIVE_COLOR }),
    ],
    [
      Keyboard.textButton({ label: '◀️ Мои бизнесы', payload: { cmd: 'business_home' }, color: Keyboard.SECONDARY_COLOR }),
    ],
  ]).inline();
}

function collectCustomCancelKeyboard(id) {
  return Keyboard.keyboard([
    [Keyboard.textButton({ label: '❌ Отмена', payload: { cmd: 'business_collect_custom_cancel', id }, color: Keyboard.SECONDARY_COLOR })],
  ]).inline();
}

async function handleHome(ctx) {
  const player = await requireRegistered(ctx);
  if (!player) return;

  const mine = await business.listMy(ctx.senderId);
  const limit = business.getSlotLimit(player);

  if (!mine.length) {
    await send(
      ctx,
      `🏢 Бизнес\n\nУ вас пока нет ни одного бизнеса (доступно слотов: ${mine.length}/${limit}).\n` +
        `Загляните в 🛒 Магазин, чтобы купить первый.`,
      homeKeyboard(mine)
    );
    return;
  }

  const lines = [`🏢 Ваши бизнесы (${mine.length}/${limit}):`, ''];
  for (const entry of mine) {
    const { business: b, live, type } = entry;
    lines.push(
      `#${b.id} ${type.name} — ур.${b.level}/${C.BUSINESS_MAX_LEVEL}, накоплено ${calc.formatNumber(
        Math.floor(live.accrued)
      )} вирт${live.stockActive ? '' : ' ⚠️ сырьё кончилось'}`
    );
  }
  lines.push('');
  lines.push('Нажмите на бизнес ниже, чтобы открыть карточку с действиями.');

  await send(ctx, lines.join('\n'), homeKeyboard(mine));
}

async function handleShop(ctx, pageArg) {
  const player = await requireRegistered(ctx);
  if (!player) return;

  const owned = await business.listMy(ctx.senderId);
  const limit = business.getSlotLimit(player);

  const requestedPage = Number.isInteger(pageArg) ? pageArg : 0;
  const { keyboard, totalPages, safePage } = shopKeyboard(requestedPage);
  const types = business.getCatalog();
  const pageTypes = types.slice(safePage * SHOP_PAGE_SIZE, safePage * SHOP_PAGE_SIZE + SHOP_PAGE_SIZE);

  const lines = [
    `🛒 Магазин бизнесов (слотов занято: ${owned.length}/${limit})`,
    `Страница ${safePage + 1}/${totalPages}`,
    '',
  ];
  for (const type of pageTypes) {
    lines.push(
      `#${type.id} ${type.name} — ${calc.formatNumber(type.price)} вирт, доход ${calc.formatNumber(
        type.incomePerHour
      )}/ч (ур.1)`
    );
  }
  lines.push('');
  lines.push('Нажмите на нужный бизнес ниже, чтобы купить (или: бизнес купить <номер>).');
  lines.push(`Продажа гос-ву — ${Math.round(C.BUSINESS_SELL_RATE * 100)}% от цены покупки.`);

  await send(ctx, lines.join('\n'), keyboard);
}

async function handleBuy(ctx, idToken, page) {
  const player = await requireRegistered(ctx);
  if (!player) return;

  const typeId = parseInt(idToken, 10);
  if (!Number.isInteger(typeId)) {
    await ctx.send('⛔ Формат: бизнес купить <номер из магазина>');
    return;
  }

  const result = await business.buy(ctx.senderId, typeId);
  if (!result.ok) {
    if (result.reason === 'invalid_type') {
      await ctx.send('⛔ Нет бизнеса с таким номером. Смотрите 🛒 Магазин.');
    } else if (result.reason === 'slots_full') {
      await ctx.send(
        `⛔ Все слоты заняты (${result.limit}). Продайте бизнес или купите доп. слот за донат (см. !донат).`
      );
    } else if (result.reason === 'not_enough_money') {
      await ctx.send(
        `⛔ Недостаточно вирт. Нужно ${calc.formatNumber(result.price)}, не хватает ${calc.formatNumber(
          result.missing
        )}.`
      );
    } else {
      await ctx.send('⛔ Не удалось купить бизнес.');
    }
    return;
  }

  await send(
    ctx,
    `✅ Куплен бизнес «${result.type.name}» за ${calc.formatNumber(result.type.price)} вирт!\n` +
      `Сырья хватит на ${C.BUSINESS_STOCK_HOURS} ч.`,
    Keyboard.keyboard([
      [Keyboard.textButton({ label: '🏢 Мои бизнесы', payload: { cmd: 'business_home' }, color: Keyboard.PRIMARY_COLOR })],
      [Keyboard.textButton({ label: '🛒 Магазин', payload: { cmd: 'business_shop', page: Number.isInteger(page) ? page : 0 }, color: Keyboard.SECONDARY_COLOR })],
    ]).inline()
  );
}

async function handleView(ctx, id) {
  const player = await requireRegistered(ctx);
  if (!player) return;

  const mine = await business.listMy(ctx.senderId);
  const entry = mine.find((e) => e.business.id === Number(id));
  if (!entry) {
    await ctx.send('⛔ Бизнес не найден (возможно, уже продан или слетел).');
    return;
  }

  const { business: b, live, type } = entry;
  const factoryMult = business.getFactoryMultiplier(player.factories);
  const effectiveRate = live.rate * factoryMult;

  const lines = [`🏢 #${b.id} ${type.name}`, ''];
  lines.push(`⚔️ Уровень: ${b.level}/${C.BUSINESS_MAX_LEVEL}`);
  lines.push(
    `⚡ Доход: ${calc.formatNumber(live.rate)}/ч${
      factoryMult !== 1 ? ` × ${factoryMult} (бонус за заводы) = ${calc.formatNumber(effectiveRate)}/ч` : ''
    }`
  );
  lines.push(`🔢 Накоплено: ${calc.formatNumber(Math.floor(live.accrued * factoryMult))} вирт`);
  lines.push(`   ▸ кнопки ниже соберут 25%/50%/100%; для точной суммы введите: бизнес собрать ${b.id} <сумма>`);

  if (live.stockActive) {
    lines.push(`⛽ Сырья хватит ещё: ${formatDuration(live.stockUntilMs - Date.now())}`);
  } else {
    lines.push(
      `⚠️ Сырьё кончилось! Пополните до ${
        live.graceUntilMs ? formatDuration(live.graceUntilMs - Date.now()) : '?'
      } — иначе бизнес будет потерян безвозвратно.`
    );
  }

  if (b.level < C.BUSINESS_MAX_LEVEL) {
    const cost = C.BUSINESS_UPGRADE_COSTS[b.level];
    let costText = `${calc.formatNumber(cost.virts)} вирт`;
    if (cost.tokens) costText += ` + ${cost.tokens} жетонов`;
    if (cost.holdHours) costText += ` (и ${cost.holdHours}ч непрерывно на 4 ур.)`;
    lines.push(`📈 Прокачка до ур. ${b.level + 1}: ${costText}`);
  } else {
    lines.push('🏆 Максимальный уровень!');
  }

  lines.push(`⛽ Пополнить сырьё (+${C.BUSINESS_STOCK_HOURS}ч): ${calc.formatNumber(business.refillCostFor(type))} вирт`);
  lines.push(`💵 Продажа гос-ву: ${calc.formatNumber(business.sellPriceFor(type))} вирт`);

  await send(ctx, lines.join('\n'), businessCardKeyboard(b.id));
}

async function handleCollect(ctx, id, amountArg) {
  const player = await requireRegistered(ctx);
  if (!player) return;

  let amount; // undefined = собрать всё
  if (amountArg !== undefined) {
    amount = parseInt(amountArg, 10);
    if (!Number.isInteger(amount) || amount <= 0) {
      await ctx.send('⛔ Формат: бизнес собрать <id> [сумма] — сумма должна быть целым положительным числом.');
      return;
    }
  }

  const result = await business.collect(ctx.senderId, Number(id), amount);
  if (!result.ok) {
    if (result.reason === 'not_found') {
      await ctx.send('⛔ Бизнес не найден.');
    } else if (result.reason === 'nothing_to_collect') {
      await ctx.send('⛔ Пока нечего собирать.');
    } else if (result.reason === 'amount_too_high') {
      await ctx.send(`⛔ Столько не накопилось. Доступно: ${calc.formatNumber(result.available)} вирт.`);
    } else {
      await ctx.send('⛔ Формат: бизнес собрать <id> [сумма].');
    }
    return;
  }
  const remainingLine = result.partial ? ` Осталось накопленным: ${calc.formatNumber(result.remaining)} вирт.` : '';
  await ctx.send(`✅ Собрано ${calc.formatNumber(result.amount)} вирт.${remainingLine}`);
}

async function handleCollectPercent(ctx, id, pct) {
  const player = await requireRegistered(ctx);
  if (!player) return;

  const result = await business.collectPercent(ctx.senderId, Number(id), pct);
  if (!result.ok) {
    if (result.reason === 'not_found') {
      await ctx.send('⛔ Бизнес не найден.');
    } else if (result.reason === 'nothing_to_collect') {
      await ctx.send('⛔ Пока нечего собирать.');
    } else {
      await ctx.send('⛔ Не удалось собрать.');
    }
    return;
  }
  const remainingLine = result.partial ? ` Осталось накопленным: ${calc.formatNumber(result.remaining)} вирт.` : '';
  await ctx.send(`✅ Собрано ${calc.formatNumber(result.amount)} вирт.${remainingLine}`);
}

// Кнопка "✏️ Своя сумма" — не собирает сразу, а спрашивает точную сумму (см.
// handlePendingCollectAmount ниже, перехватывает следующее голое число от игрока).
async function handleCollectCustomPrompt(ctx, id) {
  const player = await requireRegistered(ctx);
  if (!player) return;

  const businessId = Number(id);
  const mine = await business.listMy(ctx.senderId);
  const entry = mine.find((e) => e.business.id === businessId);
  if (!entry) {
    await ctx.send('⛔ Бизнес не найден (возможно, уже продан или слетел).');
    return;
  }

  // Тот же приём, что и в handleView (см. выше): доход умножается на бонус за заводы.
  const factoryMult = business.getFactoryMultiplier(player.factories);
  const available = Math.floor(entry.live.accrued * factoryMult);

  // Очищаем возможный "чужой" мастер (создание депозита) у того же игрока — иначе
  // следующее голое число мог бы перехватить не тот мастер (см. depositHandlers.clearPending).
  const depositHandlers = require('./depositHandlers');
  depositHandlers.clearPending(ctx.senderId);

  pendingCollect.set(ctx.senderId, { businessId, expiresAt: Date.now() + COLLECT_WIZARD_TTL_MS });

  await ctx.send({
    message:
      `✏️ Введите сумму, которую хотите собрать с бизнеса #${businessId}.\n` +
      `Доступно сейчас: ${calc.formatNumber(available)} вирт.`,
    keyboard: collectCustomCancelKeyboard(businessId),
  });
}

async function handleCollectCustomCancel(ctx) {
  clearPendingCollect(ctx.senderId);
  await ctx.send('❌ Отменено.');
}

// Перехватывает голое число, отправленное в ответ на приглашение ввести сумму (см.
// handleCollectCustomPrompt выше). Возвращает true, если сообщение было обработано как
// часть мастера — тот же контракт, что и у depositHandlers.handlePendingAmount, дальше
// диспетчер не должен пытаться разобрать его как обычную команду.
async function handlePendingCollectAmount(ctx) {
  const vkId = ctx.senderId;
  const state = getPendingCollect(vkId);
  if (!state) return false;

  const text = (ctx.text || '').trim();
  const cleaned = text.replace(/[\s.]/g, '');
  // Не голое число — не наш случай (игрок передумал/написал другое) — пусть идёт по
  // обычному пути диспетчера, мастер остаётся открытым до TTL.
  if (!/^\d+$/.test(cleaned)) return false;

  const amount = parseInt(cleaned, 10);
  clearPendingCollect(vkId);

  if (!Number.isInteger(amount) || amount <= 0) {
    await ctx.send('⛔ Сумма должна быть целым положительным числом.');
    return true;
  }

  const result = await business.collect(vkId, state.businessId, amount);
  if (!result.ok) {
    if (result.reason === 'not_found') {
      await ctx.send('⛔ Бизнес не найден.');
    } else if (result.reason === 'nothing_to_collect') {
      await ctx.send('⛔ Пока нечего собирать.');
    } else if (result.reason === 'amount_too_high') {
      await ctx.send(`⛔ Столько не накопилось. Доступно: ${calc.formatNumber(result.available)} вирт.`);
    } else {
      await ctx.send('⛔ Не удалось собрать.');
    }
    return true;
  }

  const remainingLine = result.partial ? ` Осталось накопленным: ${calc.formatNumber(result.remaining)} вирт.` : '';
  await ctx.send(`✅ Собрано ${calc.formatNumber(result.amount)} вирт.${remainingLine}`);
  return true;
}

async function handleCollectAll(ctx) {
  const player = await requireRegistered(ctx);
  if (!player) return;

  const result = await business.collectAll(ctx.senderId);
  if (!result.ok) {
    await ctx.send('⛔ Пока нечего собирать.');
    return;
  }
  await ctx.send(`✅ Собрано ${calc.formatNumber(result.amount)} вирт со всех бизнесов (${result.count}).`);
}

async function handleUpgrade(ctx, id) {
  const player = await requireRegistered(ctx);
  if (!player) return;

  const result = await business.upgrade(ctx.senderId, Number(id));
  if (!result.ok) {
    if (result.reason === 'max_level') {
      await ctx.send('⛔ У бизнеса уже максимальный уровень.');
    } else if (result.reason === 'not_enough_money') {
      await ctx.send(
        `⛔ Недостаточно вирт. Нужно ${calc.formatNumber(result.cost)}, не хватает ${calc.formatNumber(
          result.missing
        )}.`
      );
    } else if (result.reason === 'not_enough_tokens') {
      await ctx.send(`⛔ Недостаточно жетонов. Нужно ${result.tokensNeeded}, не хватает ${result.tokensMissing}.`);
    } else if (result.reason === 'hold_not_started' || result.reason === 'hold_not_enough') {
      await ctx.send(
        `⛔ Для перехода на 5 уровень бизнес должен непрерывно проработать на 4 уровне ${C.BUSINESS_LEVEL4_HOLD_HOURS}ч.` +
          (result.hoursLeft ? ` Осталось ждать: ${result.hoursLeft}ч.` : '')
      );
    } else {
      await ctx.send('⛔ Не удалось прокачать бизнес.');
    }
    return;
  }

  await ctx.send(`✅ Бизнес прокачан до уровня ${result.newLevel}!`);
}

async function handleSell(ctx, id, confirmed) {
  const player = await requireRegistered(ctx);
  if (!player) return;

  const businessId = Number(id);

  if (!confirmed) {
    const mine = await business.listMy(ctx.senderId);
    const entry = mine.find((e) => e.business.id === businessId);
    if (!entry) {
      await send(ctx, '⛔ Бизнес не найден.');
      return;
    }
    const price = business.sellPriceFor(entry.type);
    await send(
      ctx,
      `❗ Вы точно хотите продать «${entry.type.name}» (ур. ${entry.business.level}) государству за ${calc.formatNumber(
        price
      )} вирт?\n` +
        `Апгрейды не компенсируются, действие необратимо.`,
      Keyboard.keyboard([
        [
          Keyboard.textButton({
            label: '✅ Да, продать',
            payload: { cmd: 'business_sell_confirm', id: businessId },
            color: Keyboard.NEGATIVE_COLOR,
          }),
        ],
        [
          Keyboard.textButton({
            label: '◀️ Отмена',
            payload: { cmd: 'business_view', id: businessId },
            color: Keyboard.SECONDARY_COLOR,
          }),
        ],
      ]).inline()
    );
    return;
  }

  const result = await business.sell(ctx.senderId, businessId);
  if (!result.ok) {
    await send(ctx, '⛔ Бизнес не найден.');
    return;
  }
  await send(
    ctx,
    `✅ Бизнес «${result.type.name}» продан государству за ${calc.formatNumber(result.price)} вирт.`,
    Keyboard.keyboard([
      [Keyboard.textButton({ label: '🏢 Мои бизнесы', payload: { cmd: 'business_home' }, color: Keyboard.PRIMARY_COLOR })],
    ]).inline()
  );
}

async function handleRefill(ctx, id) {
  const player = await requireRegistered(ctx);
  if (!player) return;

  const result = await business.refill(ctx.senderId, Number(id));
  if (!result.ok) {
    if (result.reason === 'not_enough_money') {
      await ctx.send(
        `⛔ Недостаточно вирт. Нужно ${calc.formatNumber(result.cost)}, не хватает ${calc.formatNumber(
          result.missing
        )}.`
      );
    } else {
      await ctx.send('⛔ Бизнес не найден.');
    }
    return;
  }
  await ctx.send(`✅ Сырьё пополнено (+${C.BUSINESS_STOCK_HOURS}ч) за ${calc.formatNumber(result.cost)} вирт.`);
}

module.exports = {
  handleHome,
  handleShop,
  handleBuy,
  handleView,
  handleCollect,
  handleCollectPercent,
  handleCollectCustomPrompt,
  handleCollectCustomCancel,
  handlePendingCollectAmount,
  clearPendingCollect,
  handleCollectAll,
  handleUpgrade,
  handleSell,
  handleRefill,
};
