'use strict';
const test=require('node:test'),assert=require('node:assert/strict');
const C=require('../src/core.js');
const mk=(uid,name)=>{const S=C.newGame({uid,name});C.spawnCompanions(S.loc);C.syncLots(S);return S;};
test('shared world: lot from A can be bought by B, A is paid through mailbox',()=>{
  const w=C.newWorld();
  const A=mk('vk1','Alice'),B=mk('vk2','Bob');
  const i=A.inv.findIndex(x=>x.k==='ore:1');
  const r=C.OPS.listLot(A,i,10,4);assert.ok(r.ok,r.err);
  assert.equal(A.lots.length,1);
  const lot=w.market.find(l=>l.owner==='vk1');assert.ok(lot);
  assert.equal(lot.tax,5);
  B.credits=1000;
  const b=C.OPS.buyLot(B,lot.id);assert.ok(b.ok,b.err);
  assert.equal(B.credits,1000-40);
  assert.ok(C.OPS.buyLot(B,lot.id).err,'lot is gone');
  const before=A.credits;C.catchUp(A,Date.now());
  assert.equal(Math.round((A.credits-before)*100)/100,38);
  assert.equal(A.lots.length,0);
});
test('cannot buy own lot',()=>{
  const w=C.newWorld();const A=mk('vk1','Alice');
  C.OPS.listLot(A,A.inv.findIndex(x=>x.k==='ore:1'),5,4);
  const lot=w.market.find(l=>l.owner==='vk1');A.credits=1e6;
  assert.match(C.OPS.buyLot(A,lot.id).err,/ваш лот/);
});
test('expired lot returns items to owner',()=>{
  const w=C.newWorld();const A=mk('vk1','Alice');
  const n0=C.countKey(A,'ore:1');
  C.OPS.listLot(A,A.inv.findIndex(x=>x.k==='ore:1'),10,4);
  assert.equal(C.countKey(A,'ore:1'),n0-10);
  w.market.find(l=>l.owner==='vk1').exp=Date.now()-1;
  C.catchUp(A,Date.now());
  assert.equal(C.countKey(A,'ore:1'),n0);assert.equal(A.lots.length,0);
});
test('world step sells player lots by bot buyers through mailbox',()=>{
  const w=C.newWorld();const A=mk('vk1','Alice');
  C.OPS.listLot(A,A.inv.findIndex(x=>x.k==='ore:1'),10,1);
  const orig=Math.random;Math.random=()=>0.0001;
  try{C.worldCatchUp(Date.now()+10*60000);}finally{Math.random=orig;}
  assert.ok((w.mailbox.vk1||[]).length>=1,'mail delivered');
  const b=A.credits;C.catchUp(A,Date.now()+10*60000);assert.ok(A.credits>b);
});
test('two players in same sector see each other only via server presence (npc crew at spawn)',()=>{
  const w=C.newWorld();const A=mk('vk1','Alice');
  assert.ok(C.crewAt(A,A.loc.t,A.loc.s).length>=3);
});
test('promo totals are global across players',()=>{
  C.newWorld();const A=mk('a','A'),B=mk('b','B');
  const g=C.PROMOS.FIRST1;g.uses_total=1;
  A.xp=B.xp=100;
  assert.ok(C.OPS.redeem(A,'FIRST1').ok);
  assert.match(C.OPS.redeem(B,'FIRST1').err,/Лимит/);
  g.uses_total=1;
});
test('ops whitelist has no dev/reset',()=>{
  assert.equal(C.OPS.dev,undefined);assert.equal(C.OPS.reset,undefined);
  assert.ok(C.OPS.doScan&&C.OPS.buyLot&&C.OPS.redeem);
});
test('top hides dev/admin (local world)',()=>{
  C.newWorld();const S=mk('a','A');S.is_dev=true;
  const t=C.top(S,'bal',50);assert.ok(!t.rows.some(p=>p.me||p.is_dev||p.is_admin));
});
