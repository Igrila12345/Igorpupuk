'use strict';
process.env.NODE_ENV='test';
const test=require('node:test'),assert=require('node:assert/strict');
const os=require('node:os'),path=require('node:path'),fs=require('node:fs');
const {createApp,readConfig,parseEnv,vkSign,paymentSig}=require('../server.js');
const Core=require('../src/core.js');
const Sign=require('../src/sign.js');
const crypto=require('node:crypto');

const dir=fs.mkdtempSync(path.join(os.tmpdir(),'stellar-'));
const cfg=readConfig({PORT:'0',DB_PATH:path.join(dir,'t.db'),VK_APP_ID:'1234',VK_SECRET:'topsecret',DEV_IDS:'777',ADMIN_IDS:'888',ALLOW_DEMO:'1',DEMO_TOPUP:'0',SIGN_KEY:'unit-test-sign-key',TRUST_PROXY:'1',ALLOW_TEST_PAYMENTS:'1',PUBLIC_DIR:path.join(__dirname,'..','public')});
let app,base;
test.before(async()=>{app=createApp(cfg);await new Promise(r=>app.server.listen(0,'127.0.0.1',r));base='http://127.0.0.1:'+app.server.address().port;});
test.after(async()=>{await app.close();});

function launch(uid,over){
  const p=Object.assign({vk_access_token_settings:'',vk_app_id:'1234',vk_are_notifications_enabled:'0',vk_is_app_user:'1',vk_language:'ru',vk_platform:'mobile_web',vk_ts:String(Math.floor(Date.now()/1000)),vk_user_id:String(uid)},over||{});
  p.sign=vkSign(p,'topsecret');
  return new URLSearchParams(p).toString();
}
const vkAuth=uid=>'VK '+launch(uid);
/* Клиент теста ведёт себя как настоящий: входит по подписи VK и подписывает каждый запрос (Content-Sign) */
const sessions=new Map();
async function rawPost(p,headers,bodyStr){
  // у каждого тестового клиента свой «IP» (через X-Forwarded-For), чтобы лимит входов не мешал другим тестам
  const h0=crypto.createHash('md5').update(String(headers.Authorization||headers['X-Sid']||'x')).digest();
  const r=await fetch(base+p,{method:'POST',headers:Object.assign({'Content-Type':'application/json','X-Forwarded-For':'10.'+h0[0]+'.'+h0[1]+'.'+h0[2]},headers),body:bodyStr});
  return {status:r.status,json:await r.json()};
}
function signedHeaders(sess,p,bodyStr,over){
  const ts=String(Date.now()),nonce=Sign.nonce();
  return Object.assign({'X-Sid':sess.sid,'X-Ts':ts,'X-Nonce':nonce,'Content-Sign':Sign.sign(sess.key,'POST',p,ts,nonce,bodyStr)},over||{});
}
async function api(p,auth,body){
  const bodyStr=JSON.stringify(body||{});
  if(p==='/api/login'){
    const r=await rawPost(p,{Authorization:auth||''},bodyStr);
    if(r.json&&r.json.session)sessions.set(auth,r.json.session);
    return r;
  }
  let sess=sessions.get(auth);
  if(!sess){const l=await rawPost('/api/login',{Authorization:auth||''},'{}');if(!l.json.session)return l;sess=l.json.session;sessions.set(auth,sess);}
  return rawPost(p,signedHeaders(sess,p,bodyStr),bodyStr);
}
const act=(auth,op,args)=>api('/api/act',auth,{op,args:args||[]});

test('ping and static page',async()=>{
  const r=await (await fetch(base+'/api/ping')).json();assert.equal(r.game,'stellar-spiral');
  const h=await fetch(base+'/');assert.equal(h.status,200);
  assert.match(h.headers.get('content-security-policy'),/frame-ancestors[^;]*vk\.com/);
});
test('rejects missing, forged and foreign-app launch params',async()=>{
  assert.equal((await api('/api/login','',{})).status,401);
  const forged=launch(1).replace(/sign=[^&]+/,'sign=AAAA');
  assert.equal((await api('/api/login','VK '+forged,{})).status,401);
  const other=new URLSearchParams(launch(1));other.set('vk_user_id','2');
  assert.equal((await api('/api/login','VK '+other.toString(),{})).status,401,'changed user id breaks the signature');
  const app2=launch(3,{vk_app_id:'999'});
  assert.equal((await api('/api/login','VK '+app2,{})).status,401,'wrong app id');
});
test('login creates a server-side player and returns state + world',async()=>{
  const r=await api('/api/login',vkAuth(100),{name:'Иван<script>',photo:'javascript:alert(1)'});
  assert.equal(r.status,200);assert.equal(r.json.created,true);
  assert.equal(r.json.state.uid,'vk100');
  assert.ok(!/[<>]/.test(r.json.state.name),'name sanitised');
  assert.equal(r.json.state.photo,'','non-https photo dropped');
  assert.equal(r.json.state.is_dev,false);
  assert.ok(r.json.world.market.length>=20&&r.json.world.prices['ore:1']>0);
  const again=await api('/api/login',vkAuth(100),{});assert.equal(again.json.created,false);
});
test('actions are executed by the server, cheating is impossible',async()=>{
  const a=vkAuth(101);await api('/api/login',a,{name:'A'});
  let r=await act(a,'build',[0,'mine']);assert.ok(r.json.result.ok,JSON.stringify(r.json.result));
  assert.equal(r.json.state.credits,15000-5000);
  r=await act(a,'buyUpg',['reactor']);assert.match(r.json.result.err,/кредит/,'cannot buy without money');
  assert.equal((await act(a,'devgive',['x'])).status,400,'unknown op');
  assert.equal((await act(a,'dev',[])).status,400,'dev is not a player op');
  assert.equal((await act(a,'buyUpg',['__proto__'])).status,400,'arg validation');
  assert.equal((await act(a,'listLot',[0,-5,1])).status,400,'negative qty');
  assert.equal((await act(a,'listLot',[0,1e30,1])).status,400,'huge qty');
  assert.equal((await act(a,'buyVip',[10])).json.result.err,'Не хватает кристаллов');
  r=await act(a,'doFight',[false]);assert.ok(r.json.result.ok);
  r=await act(a,'doFight',[false]);assert.match(r.json.result.err,/перезаряж/,'cooldown enforced by server');
});
test('client cannot make itself dev, dev endpoints are forbidden',async()=>{
  const a=vkAuth(102);await api('/api/login',a,{name:'B'});
  assert.equal((await api('/api/dev',a,{op:'give',args:{k:'ore:1',n:5}})).status,403);
  assert.equal((await api('/api/dev',a,{op:'view'})).status,403);
  const r=await api('/api/login',a,{name:'B',is_dev:true});assert.equal(r.json.state.is_dev,false);
  assert.equal((await api('/api/dev','Demo hacker123',{op:'view'})).status,403);
});
test('auction between real players: seller is paid net of tax through the mailbox',async()=>{
  const A=vkAuth(201),B=vkAuth(202);
  await api('/api/login',A,{name:'Seller'});await api('/api/login',B,{name:'Buyer'});
  const inv0=(await api('/api/sync',A,{})).json.state;
  const oreIdx=inv0.inv.findIndex(x=>x.k==='ore:1');assert.ok(oreIdx>=0);
  let r=await act(A,'listLot',[oreIdx,10,4]);
  assert.ok(r.json.result.ok,JSON.stringify(r.json.result));
  const before=r.json.state.credits;
  const view=(await api('/api/sync',B,{})).json;
  const lot=view.world.market.find(l=>l.seller==='Seller');assert.ok(lot&&lot.real&&!lot.mine);
  assert.ok(!('owner' in lot),'owner uid is not exposed');
  const buy=await act(B,'buyLot',[lot.id]);assert.ok(buy.json.result.ok,JSON.stringify(buy.json.result));
  assert.equal(buy.json.state.credits,15000-40);
  const s=(await api('/api/sync',A,{})).json;
  assert.equal(Math.round((s.state.credits-before)*100)/100,38);
  assert.ok(s.events.some(e=>/выкуплен/.test(e.text)));
  assert.equal(s.state.lots.length,0);
});
test('top hides dev and admin accounts on the server',async()=>{
  const dev=vkAuth(777),adm=vkAuth(888),usr=vkAuth(301);
  await api('/api/login',dev,{name:'DevGod'});await api('/api/login',adm,{name:'AdminGod'});await api('/api/login',usr,{name:'Regular'});
  const d=await api('/api/dev',dev,{op:'bal',args:{credits:9e15,xp:9e9}});assert.ok(d.json.result.ok);
  assert.equal(d.json.state.is_dev,true);
  // admin also gets huge money directly in DB to prove filtering is by flag
  const S=JSON.parse(app.db.prepare('SELECT data FROM players WHERE uid=?').get('vk888').data);S.credits=8e15;S.xp=8e9;
  app.db.prepare('UPDATE players SET data=?,bal=?,xp=?,inc=? WHERE uid=?').run(JSON.stringify(S),8e15,8e9,8e12,'vk888');
  for(const kind of ['bal','xp','inc']){
    const t=(await api('/api/top',usr,{kind})).json.top;
    assert.ok(t.rows.length>0);
    assert.ok(!t.rows.some(x=>/DevGod|AdminGod/.test(x.name)),'staff not in top '+kind);
    assert.equal(t.hidden,false);assert.ok(t.myRank>=1);
  }
  const mine=(await api('/api/top',dev,{kind:'bal'})).json.top;
  assert.equal(mine.hidden,true);assert.equal(mine.myRank,null);assert.ok(!mine.rows.some(x=>x.me));
  const full=(await api('/api/dev',dev,{op:'view'})).json.dev.fullTop;
  assert.ok(full.some(x=>x.is_dev)&&full.some(x=>x.is_admin),'dev panel still sees staff');
});
test('presence: real players in the same sector see each other, staff are never shown',async()=>{
  const a=vkAuth(401),b=vkAuth(402),dev=vkAuth(777);
  const A=(await api('/api/login',a,{name:'P1'})).json.state;
  await api('/api/login',b,{name:'P2'});
  // move P2 and the dev to P1's sector by DB (teleport is dev-only via API)
  for(const u of ['vk402','vk777'])app.db.prepare('UPDATE players SET loc_t=?,loc_s=?,seen=? WHERE uid=?').run(A.loc.t,A.loc.s,Date.now(),u);
  const crew=(await api('/api/crew',a,{t:A.loc.t,s:A.loc.s})).json.crew;
  assert.ok(crew.some(c=>c.name==='P2'&&c.real),'other real player visible');
  assert.ok(!crew.some(c=>c.name==='P1'),'self not listed');
  assert.ok(!crew.some(c=>/DevGod/.test(c.name)),'dev hidden from presence');
  const counts=(await api('/api/counts',a,{t:A.loc.t})).json.counts;
  assert.ok(counts[A.loc.s]>=1);
});
test('VK Payments callback: signature, get_item, idempotent crediting',async()=>{
  const u=vkAuth(501);await api('/api/login',u,{name:'Payer'});
  const post=async params=>{
    const p=Object.assign({app_id:'1234',user_id:'501',receiver_id:'501',lang:'ru',version:'1'},params);
    p.sig=paymentSig(p,'topsecret');
    return (await fetch(base+'/vk/payments',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:new URLSearchParams(p).toString()})).json();
  };
  let r=await post({notification_type:'get_item_test',item:'crystals_p2'});
  assert.equal(r.response.price,13);
  r=await post({notification_type:'get_item',item:'crystals_nope'});assert.ok(r.error);
  const bad=await (await fetch(base+'/vk/payments',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:'app_id=1234&notification_type=order_status_change&status=chargeable&order_id=1&item=crystals_p2&user_id=501&sig=deadbeef'})).json();
  assert.equal(bad.error.error_code,10);
  const before=(await api('/api/sync',u,{})).json.state.premium;
  r=await post({notification_type:'order_status_change',status:'chargeable',order_id:'9001',item:'crystals_p2'});assert.ok(r.response);
  r=await post({notification_type:'order_status_change',status:'chargeable',order_id:'9001',item:'crystals_p2'});assert.ok(r.response,'repeat ok');
  const after=(await api('/api/sync',u,{})).json.state.premium;
  assert.equal(after-before,330,'credited exactly once');
});
test('demo top-up is disabled unless enabled by config',async()=>{
  const a='Demo tester1';await api('/api/login',a,{name:'D'});
  const r=await act(a,'demoPack',['p1']);assert.match(r.json.result.err,/отключено/);
});
test('rate limit',async()=>{
  const a=vkAuth(601);let last=0;
  for(let i=0;i<70;i++)last=(await api('/api/sync',a,{})).status;
  assert.equal(last,429);
});

/* ---------- Content-Sign ---------- */
test('signing: JS implementation matches Node crypto',()=>{
  for(const m of ['','abc','привет','x'.repeat(200)]){
    assert.equal(Sign.hex(Sign.sha256(Sign.utf8(m))),crypto.createHash('sha256').update(m,'utf8').digest('hex'));
    assert.equal(Sign.b64url(Sign.hmac(Sign.utf8('key'),Sign.utf8(m))),crypto.createHmac('sha256','key').update(m).digest('base64url'));
  }
});
test('signing: login returns a session, unsigned requests are rejected',async()=>{
  const a=vkAuth(901);
  const l=await api('/api/login',a,{name:'S'});
  assert.equal(l.status,200);assert.ok(l.json.session.sid&&l.json.session.key&&l.json.session.exp>Date.now());
  // VK header alone no longer works for game endpoints
  const r=await rawPost('/api/sync',{Authorization:a},'{}');
  assert.equal(r.status,401);assert.equal(r.json.error,'sign required');
});
test('signing: tampered body, wrong key, wrong path, replay and stale timestamps fail',async()=>{
  const a=vkAuth(902);await api('/api/login',a,{name:'S2'});const sess=sessions.get(a);
  const body=JSON.stringify({op:'doScan',args:[]});
  // tampered: sign one body, send another
  let h=signedHeaders(sess,'/api/act',body);
  let r=await rawPost('/api/act',h,JSON.stringify({op:'doFight',args:[false]}));
  assert.equal(r.json.error,'bad signature');
  // wrong key
  h=signedHeaders({sid:sess.sid,key:Sign.b64url(crypto.randomBytes(32))},'/api/act',body);
  assert.equal((await rawPost('/api/act',h,body)).json.error,'bad signature');
  // signature made for another path cannot be reused
  h=signedHeaders(sess,'/api/sync',body);
  assert.equal((await rawPost('/api/act',h,body)).json.error,'bad signature');
  // valid once, then replayed
  h=signedHeaders(sess,'/api/act',body);
  r=await rawPost('/api/act',h,body);assert.equal(r.status,200);
  r=await rawPost('/api/act',h,body);assert.equal(r.status,401);assert.equal(r.json.error,'replay');
  // stale timestamp (signed correctly, but 5 minutes old)
  const ts=String(Date.now()-300000),nonce=Sign.nonce();
  h={'X-Sid':sess.sid,'X-Ts':ts,'X-Nonce':nonce,'Content-Sign':Sign.sign(sess.key,'POST','/api/act',ts,nonce,body)};
  assert.equal((await rawPost('/api/act',h,body)).json.error,'stale timestamp');
  // garbage / forged session id
  assert.equal((await rawPost('/api/act',signedHeaders({sid:'v1.x.1.y.z',key:sess.key},'/api/act',body),body)).json.error,'bad session');
  const parts=sess.sid.split('.');parts[1]=Buffer.from('vk1').toString('base64url');
  assert.equal((await rawPost('/api/act',signedHeaders({sid:parts.join('.'),key:sess.key},'/api/act',body),body)).json.error,'bad session','cannot swap the user inside a session id');
});
test('signing: a session key of one player cannot act as another',async()=>{
  const a=vkAuth(903),b=vkAuth(904);await api('/api/login',a,{name:'A'});await api('/api/login',b,{name:'B'});
  const sa=sessions.get(a),sb=sessions.get(b);
  const body='{}';
  // sid of A with key of B
  assert.equal((await rawPost('/api/sync',signedHeaders({sid:sa.sid,key:sb.key},'/api/sync',body),body)).json.error,'bad signature');
});
test('signing: expired sessions are refused',async()=>{
  const uid='vk905',iat=Math.floor(Date.now()/1000)-13*3600;
  const SKEY=crypto.createHash('sha256').update('unit-test-sign-key').digest();
  const b64=x=>Buffer.from(x).toString('base64url'),hm=(k,m)=>crypto.createHmac('sha256',k).update(m).digest();
  const body=b64(uid)+'.'+iat+'.'+b64('salt12345678');
  const sid='v1.'+body+'.'+b64(hm(SKEY,'sid|'+body)),key=b64(hm(SKEY,'key|'+sid));
  const r=await rawPost('/api/sync',signedHeaders({sid,key},'/api/sync','{}'),'{}');
  assert.equal(r.json.error,'session expired');
});
test('login: old launch params (vk_ts) are refused',async()=>{
  const old=launch(906,{vk_ts:String(Math.floor(Date.now()/1000)-48*3600)});
  const r=await rawPost('/api/login',{Authorization:'VK '+old},'{}');
  assert.equal(r.status,401);assert.equal(r.json.error,'launch expired');
});
test('login: rate limit per IP',async()=>{
  let last=0;for(let i=0;i<40;i++)last=(await rawPost('/api/login',{Authorization:'VK '+launch(950+i),'X-Forwarded-For':'203.0.113.7'},'{}')).status;
  assert.equal(last,429);
});

test('.env parser: inline comments and quotes',()=>{
  const e=parseEnv('A=1   # comment\nB="x # y"\n# C=3\nD=a#b\nTRUST_PROXY=1        # 1: брать IP\nEMPTY=\nK=  spaced  ');
  assert.equal(e.A,'1');assert.equal(e.B,'x # y');assert.equal(e.C,undefined);assert.equal(e.D,'a#b');
  assert.equal(e.TRUST_PROXY,'1');assert.equal(e.EMPTY,'');assert.equal(e.K,'spaced');
  const example=parseEnv(require('node:fs').readFileSync(path.join(__dirname,'..','.env.example'),'utf8'));
  assert.equal(example.NPC_IN_TOP,'1');assert.equal(example.LAUNCH_MAX_AGE_HOURS,'24');assert.equal(example.ALLOW_DEMO,'0');
  const c=readConfig(Object.assign({},example,{TRUST_PROXY:'1'}));
  assert.equal(c.trustProxy,true);assert.equal(c.launchMaxAgeMs,24*3600000);assert.equal(c.requireSign,true);assert.equal(c.sessionMs,12*3600000);
});

test('backup script: consistent gzip snapshot, rotation',()=>{
  const cp=require('node:child_process'),zlib=require('node:zlib'),{DatabaseSync}=require('node:sqlite');
  const bdir=path.join(dir,'bk');
  for(let i=0;i<4;i++){
    cp.execFileSync('node',[path.join(__dirname,'..','tools','backup.js')],{env:Object.assign({},process.env,{DB_PATH:cfg.dbPath,BACKUP_DIR:bdir,BACKUP_KEEP:'2'}),stdio:'pipe'});
    // имена содержат секунды, ждём смены секунды, чтобы копии не совпали
    const t0=Date.now();while(Date.now()-t0<1100){}
  }
  const files=fs.readdirSync(bdir).filter(f=>f.endsWith('.db.gz'));
  assert.equal(files.length,2,'rotation keeps only the latest 2');
  const restored=path.join(dir,'restored.db');
  fs.writeFileSync(restored,zlib.gunzipSync(fs.readFileSync(path.join(bdir,files.sort().pop()))));
  const db=new DatabaseSync(restored);
  assert.ok(db.prepare('SELECT COUNT(*) AS c FROM players').get().c>=1,'players restored from backup');
  assert.ok(db.prepare("SELECT v FROM kv WHERE k='sign_key' OR k='world'").all().length>=0);
  db.close();
});
