(function(){
'use strict';
const C=Core;
const $=s=>document.querySelector(s);
const esc=s=>String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const clamp=(x,a,b)=>Math.max(a,Math.min(b,x));
const fmt=C.fmt;

/* Флаги dev/admin в продакшене выдаёт сервер. Здесь список VK id для теста. */
const DEV_IDS=[];
const ADMIN_IDS=[];

/* ---------- иконки ---------- */
const ic=(id,cls)=>'<svg class="ic'+(cls?' '+cls:'')+'" viewBox="0 0 32 32" aria-hidden="true"><use href="#'+id+'"/></svg>';
const CRI=ic('i-credit','cg'),GEMI=ic('i-gem','cg');
const money=h=>h.replace(/₵/g,CRI).replace(/◆/g,GEMI);
const rc=q=>C.RAR_COL[q]||'#666d99';
const tile=(icon,col,lb)=>'<div class="tl" style="--rc:'+(col||'#2b3160')+'">'+ic(icon)+(lb!=null?'<span class="lb">'+lb+'</span>':'')+'</div>';
const ROM=['','I','II','III','IV','V','VI','VII','VIII','IX','X','XI','XII','XIII','XIV','XV','XVI','XVII','XVIII','XIX','XX'];
const rom=n=>ROM[n]||String(n);
const TABS=[['home','Корабль','n-ship'],['build','Строить','n-build'],['map','Карта','n-map'],['cargo','Трюм','n-cargo'],['market','Рынок','n-market'],['me','Капитан','n-me']];

let S=null,VK=null,DEMO=true,MODE='local',AUTH='',API='',CFG={demo:true,demoTopup:true},HAS_LAUNCH=false,READY=false;
let tab='home',cargoSeg='inv',mktSeg='auc',mktCat='all',mapT=0,mapS=1,topKind='bal',lastEvent=null,useAmmo=false,lotDraft=null,tapCount=0,tapTs=0,prevLevel=1;

/* =====================================================================
   Слой данных. Два режима:
   server: авторитетный сервер (VK). Клиент только просит выполнить действие.
   local:  демо без сервера, вся логика в браузере (сохранение в localStorage).
   ===================================================================== */
const realNow=Date.now.bind(Date);
let skew=0,inflight=false,nextSync=0,lastSyncAt=0;
function setSkew(serverNow){skew=serverNow-realNow();Date.now=()=>realNow()+skew;}
/* Вход подтверждается подписью VK. Дальше каждый запрос подписывается заголовком Content-Sign (HMAC-SHA256 ключом сессии). */
let SESS=null,LOGIN_INFO={name:'',photo:''},relogging=null;
async function api(path,body,retried){
  const bodyStr=JSON.stringify(body||{}),headers={'Content-Type':'application/json'};
  if(path==='/api/login')headers.Authorization=AUTH;
  else{
    if(!SESS){const e=new Error('no session');e.status=401;throw e;}
    const ts=String(Date.now()),nonce=Sign.nonce();
    headers['X-Sid']=SESS.sid;headers['X-Ts']=ts;headers['X-Nonce']=nonce;
    headers['Content-Sign']=Sign.sign(SESS.key,'POST',path,ts,nonce,bodyStr);
  }
  const ctl=new AbortController(),to=setTimeout(()=>ctl.abort(),12000);
  try{
    const r=await fetch(API+path,{method:'POST',headers,body:bodyStr,signal:ctl.signal});
    const j=await r.json().catch(()=>null);
    if(!r.ok||!j){
      const e=new Error(j&&j.error||('HTTP '+r.status));e.status=r.status;
      /* сессия истекла: один раз входим заново и повторяем запрос (сервер его не выполнял) */
      if(r.status===401&&path!=='/api/login'&&!retried&&/session|stale/.test(e.message)){
        await relogin();return api(path,body,true);
      }
      throw e;
    }
    if(j.session)SESS=j.session;
    return j;
  }finally{clearTimeout(to);}
}
async function relogin(){
  if(!relogging)relogging=api('/api/login',LOGIN_INFO).then(j=>{applyResp(j);}).finally(()=>{relogging=null;});
  return relogging;
}
const WORLD={market:[],deals:{},mkt:{},npcs:[],vol:0,econ:[],nextId:1,promoTotals:{},mailbox:{}};
function applyResp(j){
  S=j.state;
  if(MODE==='server'){
    setSkew(j.serverNow);
    WORLD.market=j.world.market;
    WORLD.deals={};for(const k in j.world.prices)WORLD.deals[k]=[j.world.prices[k]];
    C.setWorld(WORLD);
    nextSync=Math.min(realNow()+30000,S.lastTick+60000+700-skew);
  }
  if(j.dev)CACHE.dev=j.dev;
}
const Local={
  init(user){
    let st=C.load(user.uid);
    if(!st){C.newWorld();st=C.newGame(user);C.spawnCompanions(st.loc);}
    else{if(user.vk)st.name=user.name||st.name;}
    return st;
  },
  catchUp(){const now=Date.now();C.worldCatchUp(now);return C.catchUp(S,now);},
  act(op,args){
    const sum=Local.catchUp();let result;
    try{result=C.OPS[op](S,...args);}catch(e){result={err:'Ошибка выполнения'};}
    const ach=C.checkAch(S);C.syncLots(S);C.save(S);
    return {result,ach,events:sum.ev,state:S};
  },
  dev(op,a){
    const sum=Local.catchUp();let result;
    try{result=C.dev(S,op,a);}catch(e){result={err:'Ошибка выполнения'};}
    C.syncLots(S);C.save(S);
    return {result,events:sum.ev,state:S};
  }
};
/* кэши данных, которые в режиме server приходят отдельными запросами */
const CACHE={crew:{},counts:{},top:{},dev:null,busy:{}};
const CAPS={};
function fetchOnce(key,path,body,store){
  if(CACHE.busy[key])return;CACHE.busy[key]=1;
  api(path,body).then(j=>{if(store(j))render();}).catch(()=>{}).finally(()=>{delete CACHE.busy[key];});
}
function crewFor(t,s){
  if(MODE==='local'){const l=C.crewAt(S,t,s);l.forEach(c=>{CAPS[c.id]=c;});return l;}
  const key=t+':'+s,e=CACHE.crew[key];
  if(!e||realNow()-e.ts>20000)fetchOnce('crew'+key,'/api/crew',{t,s},j=>{
    const changed=!e||JSON.stringify(e.list)!==JSON.stringify(j.crew);
    CACHE.crew[key]={ts:realNow(),list:j.crew};j.crew.forEach(c=>{CAPS[c.id]=c;});return changed;});
  return e?e.list:[];
}
function countsFor(t){
  if(MODE==='local')return C.crewCounts(S,t);
  const e=CACHE.counts[t];
  if(!e||realNow()-e.ts>20000)fetchOnce('cnt'+t,'/api/counts',{t},j=>{
    const changed=!e||JSON.stringify(e.c)!==JSON.stringify(j.counts);
    CACHE.counts[t]={ts:realNow(),c:j.counts};return changed;});
  return e?e.c:{};
}
function topFor(kind){
  if(MODE==='local')return C.top(S,kind,20);
  const e=CACHE.top[kind];
  if(!e||realNow()-e.ts>30000)fetchOnce('top'+kind,'/api/top',{kind},j=>{
    const changed=!e||JSON.stringify(e.t)!==JSON.stringify(j.top);
    CACHE.top[kind]={ts:realNow(),t:j.top};return changed;});
  return e?e.t:null;
}
function devInfo(){
  if(MODE==='local'){
    const w=C.getWorld();
    return {econ:w.econ.slice(-24),fullTop:C.fullTop(S,'bal',8).map(p=>({name:p.name,bal:p.bal,is_dev:p.is_dev,is_admin:p.is_admin}))};
  }
  return CACHE.dev||{econ:[],fullTop:[]};
}
function loadDev(){if(MODE==='server')api('/api/dev',{op:'view'}).then(j=>{applyResp(j);render();}).catch(()=>{});}

/* ---------- баннер локации ---------- */
function rng(seed){let a=seed>>>0;return function(){a=(a+0x6D2B79F5)>>>0;let t=a;t=Math.imul(t^(t>>>15),t|1);t^=t+Math.imul(t^(t>>>7),t|61);return((t^(t>>>14))>>>0)/4294967296;};}
const SKY={belt:['#15132a','#2e2246'],planet:['#0b2131','#1b4a5c'],wreck:['#1e1526','#3d2434'],anomaly:['#170c38','#421c6e'],station:['#0d1b39','#20406f'],nebula:['#250b35','#5d1f5e']};
function rock(R,cx,cy,r,fill){let p='';const n=7;for(let i=0;i<n;i++){const a=i/n*Math.PI*2,k=r*(.7+R()*.5);p+=(cx+Math.cos(a)*k).toFixed(1)+','+(cy+Math.sin(a)*k*.8).toFixed(1)+' ';}return '<polygon points="'+p+'" fill="'+fill+'"/>';}
function banner(t,s,ship){
  const L=C.locInfo(t,s),R=rng(C.hash(t,s)),id='b'+t+'_'+s+(ship?'s':'x'),sk=SKY[L.type.id],tc=C.tierCol(L.tier);
  let g='<svg class="bsv" viewBox="0 0 360 176" preserveAspectRatio="xMidYMid slice" aria-hidden="true"><defs><linearGradient id="'+id+'g" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="'+sk[0]+'"/><stop offset="1" stop-color="'+sk[1]+'"/></linearGradient><filter id="'+id+'f" x="-30%" y="-30%" width="160%" height="160%"><feGaussianBlur stdDeviation="14"/></filter><radialGradient id="'+id+'p" cx=".35" cy=".3" r=".8"><stop offset="0" stop-color="#5bc0d8"/><stop offset="1" stop-color="#15506a"/></radialGradient></defs><rect width="360" height="176" fill="url(#'+id+'g)"/>';
  for(let i=0;i<48;i++)g+='<circle cx="'+(R()*360).toFixed(0)+'" cy="'+(R()*176).toFixed(0)+'" r="'+(R()*1.2+.3).toFixed(1)+'" fill="#fff" opacity="'+(R()*.6+.2).toFixed(2)+'"/>';
  switch(L.type.id){
    case 'planet':{const cx=230+R()*60,cy=150+R()*20,r=86+R()*20;
      g+='<circle cx="'+cx+'" cy="'+cy+'" r="'+r+'" fill="url(#'+id+'p)"/><ellipse cx="'+cx+'" cy="'+(cy-30)+'" rx="'+r+'" ry="10" fill="#1d6c8a" opacity=".5"/><ellipse cx="'+cx+'" cy="'+cy+'" rx="'+(r+38)+'" ry="14" fill="none" stroke="'+tc+'" stroke-width="4" opacity=".55" transform="rotate(-14 '+cx+' '+cy+')"/><circle cx="'+(60+R()*60)+'" cy="'+(30+R()*30)+'" r="10" fill="#9aa8c8"/>';break;}
    case 'belt':{const cols=['#4c4670','#6e6796','#8a83b0','#3b3658'];
      for(let i=0;i<11;i++)g+=rock(R,R()*360,40+R()*110,8+R()*24,cols[i%4]);break;}
    case 'wreck':{
      for(let i=0;i<5;i++){const cx=110+R()*180,cy=50+R()*80,a=R()*90-45;g+='<g transform="rotate('+a.toFixed(0)+' '+cx.toFixed(0)+' '+cy.toFixed(0)+')"><polygon points="'+(cx-34)+','+cy+' '+(cx+10)+','+(cy-16)+' '+(cx+38)+','+(cy+4)+' '+(cx-6)+','+(cy+20)+'" fill="'+(i%2?'#5e6684':'#7b84a4')+'"/></g>';}
      for(let i=0;i<6;i++)g+='<circle cx="'+(R()*360).toFixed(0)+'" cy="'+(40+R()*100).toFixed(0)+'" r="2.4" fill="#ffb14a"/>';break;}
    case 'anomaly':{const cx=240,cy=80;
      for(let i=1;i<=6;i++)g+='<circle cx="'+cx+'" cy="'+cy+'" r="'+(i*13)+'" fill="none" stroke="#c48bff" stroke-width="2" opacity="'+(.75-i*.1).toFixed(2)+'"/>';
      g+='<circle cx="'+cx+'" cy="'+cy+'" r="12" fill="#ff8fd0"/><circle cx="'+cx+'" cy="'+cy+'" r="30" fill="#c48bff" opacity=".25" filter="url(#'+id+'f)"/>';break;}
    case 'station':{const cx=240,cy=84;
      g+='<ellipse cx="'+cx+'" cy="'+cy+'" rx="82" ry="24" fill="none" stroke="#6fa3ff" stroke-width="7"/><ellipse cx="'+cx+'" cy="'+cy+'" rx="82" ry="24" fill="none" stroke="#0d1b39" stroke-width="1.5" stroke-dasharray="6 10"/><circle cx="'+cx+'" cy="'+cy+'" r="20" fill="#c9d8ff"/><circle cx="'+cx+'" cy="'+cy+'" r="8" fill="#20406f"/><rect x="'+(cx-3)+'" y="'+(cy-50)+'" width="6" height="30" fill="#9db7f0"/><circle cx="'+cx+'" cy="'+(cy-52)+'" r="4" fill="#ff5a6a"/>';break;}
    case 'nebula':{const cols=['#b85cf0','#ff6fae','#5c7cff','#ff9d5c'];
      for(let i=0;i<5;i++)g+='<circle cx="'+(60+R()*260).toFixed(0)+'" cy="'+(30+R()*110).toFixed(0)+'" r="'+(38+R()*26).toFixed(0)+'" fill="'+cols[i%4]+'" opacity=".55" filter="url(#'+id+'f)"/>';break;}
  }
  if(ship)g+='<g transform="translate(34 92)"><path d="M0 0L-24-8v16z" fill="#ff8a3d"/><path d="M-6 0L-16-4v8z" fill="#ffe066"/><path d="M0 -7L34 -3 46 0 34 3 0 7z" fill="#dfe6ff"/><path d="M0 -7L14 -12 22 -3z" fill="#9db0e8"/><path d="M0 7L14 12 22 3z" fill="#9db0e8"/><circle cx="34" cy="0" r="3" fill="#3fa9ff"/></g>';
  return g+'</svg>';
}
function banHtml(t,s,o){
  o=o||{};const L=C.locInfo(t,s),tc=C.tierCol(L.tier),crew=crewFor(t,s).length;
  return '<div class="ban'+(o.small?' s':'')+'">'+banner(t,s,o.ship)+'<div class="tags"><span class="tag" style="--tc:'+tc+'">Тир '+rom(L.tier)+' «'+C.tierName(L.tier)+'»</span><span class="tag">'+ic('i-users')+crew+'</span>'+(L.bias?'<span class="tag">'+ic(C.RES[L.bias].icon)+'богато: '+C.RES[L.bias].name.toLowerCase()+'</span>':'')+'</div><div class="ov"><div class="bn">'+esc(L.name)+'</div><div class="bs">Виток '+t+', сектор '+s+', '+L.type.name.toLowerCase()+'</div></div></div>';
}

/* ---------- утилиты UI ---------- */
function toast(msg,kind){
  const el=document.createElement('div');el.className='toast '+(kind||'ok');el.innerHTML=money(esc(msg));
  $('#toasts').appendChild(el);setTimeout(()=>{el.remove();},2800);
}
function openSheet(html){$('#sheet').innerHTML='<div class="grab"></div>'+money(html);$('#sheet').classList.add('on');$('#back').classList.add('on');}
function closeSheet(){$('#sheet').classList.remove('on');$('#back').classList.remove('on');}
function cd(ts){return '<span data-cd="'+ts+'">'+C.dur(ts-Date.now())+'</span>';}
function oddsChip(o){const p=Math.round(o*100),c=o>=.8?'g':o>=.5?'y':'r',l=o>=.8?'Безопасно':o>=.5?'Рискованно':'Опасно';return '<span class="chip '+c+'">Шанс победы '+p+'%, '+l.toLowerCase()+'</span>';}

/* ---------- HUD ---------- */
function gemPill(){return '<button class="cur cb" id="hp" data-act="topupwin" aria-label="Пополнить кристаллы">◆ '+S.premium+'<span class="pl">'+ic('i-plus')+'</span></button>';}
function hdr(){
  const L=C.levelOf(S.xp),a=C.xpFor(L),b=C.xpFor(L+1),p=clamp((S.xp-a)/(b-a),0,1),vl=C.vipLvl(S);
  const role=S.is_dev?'<em class="role">dev</em>':S.is_admin?'<em class="role">admin</em>':'';
  return '<div class="hrow"><div class="ava" style="--tc:'+C.VIP.col[vl]+'"><span>'+esc(S.name.slice(0,1).toUpperCase())+'</span>'+(S.photo?'<img src="'+esc(S.photo)+'" alt="" onerror="this.remove()">':'')+'<b class="lvb">'+L+'</b></div>'+
    '<div class="hm"><div class="hn" id="secret" style="color:'+C.VIP.col[vl]+'">'+esc(S.name)+role+'</div><div class="xpt"><i style="width:'+(p*100)+'%"></i></div><div class="hl">Опыт '+fmt(S.xp-a)+' из '+fmt(b-a)+'</div></div>'+
    '<div class="curs"><div class="cur" id="hc">₵ '+fmt(S.credits)+'</div>'+gemPill()+'</div></div>';
}

/* ---------- Корабль ---------- */
function crewHtml(list){
  if(!list.length)return '<div class="sub">Вы одни в этом секторе.</div>';
  return '<div class="crew">'+list.map(c=>'<button class="cp" data-act="cap" data-a="'+c.id+'"><span class="ca" style="--tc:'+C.VIP.col[c.vip]+'">'+esc(c.name.slice(0,1))+'<b>'+c.lvl+'</b></span><div class="cnm">'+esc(c.name.split(' ')[1]||c.name)+'</div></button>').join('')+'</div>';
}
function pgHome(){
  const now=Date.now(),P=C.incomeParts(S),st=C.stats(S),t=S.loc.t,s=S.loc.s,E=C.Loc.E(t),li=C.locInfo(t,s);
  const p=clamp((now-S.lastTick)/C.TICK_MS,0,1),crew=crewFor(t,s),ammoOn=useAmmo&&C.countKey(S,'ammo')>=5,odds=C.fightOdds(S,t,ammoOn);
  let h='';
  if(S.tips){
    h+='<section class="pn"><h3>С чего начать</h3><div class="sub">Откройте «Строить» и поставьте Рудник и Ферму: они приносят кредиты каждую минуту. Пока они работают, сканируйте сектор и воюйте ради опыта. На 10 уровне откроется второй тир с лучшими наградами.</div><div class="btns"><button class="btn n sm" data-act="tipsoff">Понятно</button><button class="btn y sm" data-act="tab" data-a="build">К постройкам</button></div></section>';
  }
  h+=banHtml(t,s,{ship:true});
  if(S.travel){
    const tr=S.travel,pc=clamp((now-tr.start)/(tr.end-tr.start),0,1);
    h+='<section class="pn"><h3>Корабль в пути</h3><div class="row"><div class="sp">'+esc(C.locInfo(tr.to.t,tr.to.s).name)+'</div><b>'+cd(tr.end)+'</b></div><div class="bar y" style="margin-top:10px"><i data-trav="'+tr.start+','+tr.end+'" style="width:'+(pc*100)+'%"></i></div></section>';
  }
  h+='<section class="pn"><div class="row">'+tile('u-reactor','#3a7fa0')+'<div class="sp"><div class="sub">Доход в минуту</div><div class="big">₵'+fmt(P.total)+'</div></div><div class="sub" style="text-align:right">до начисления<br><b class="gd" data-ringtxt>'+Math.max(0,Math.ceil(60-p*60))+'</b> с</div></div><div class="bar y" style="margin-top:12px"><i data-tickbar style="width:'+(p*100)+'%"></i></div>'+
    '<div class="chips"><span class="chip">База '+fmt(P.base)+'</span><span class="chip">Улучшения ×'+P.um.toFixed(2).replace('.',',')+'</span>'+(P.vm>1?'<span class="chip y">VIP ×'+P.vm.toFixed(2).replace('.',',')+'</span>':'')+'</div></section>';
  const cS=Math.max(0,S.cd.scan-now),cF=Math.max(0,S.cd.fight-now),ammo=C.countKey(S,'ammo');
  h+='<section class="pn"><h3>Действия в секторе</h3><div class="btns" style="margin-top:0"><button class="btn b act" data-act="scan"'+(cS||S.travel?' disabled':'')+'>'+ic('u-radar')+'Сканировать<small>'+(cS?cd(S.cd.scan):'шанс находки '+Math.round(st.scan*100)+'%')+'</small>'+(cS?'<i class="cdb" data-cdbar="'+(S.cd.scan-15000)+','+S.cd.scan+'"></i>':'')+'</button>'+
    '<button class="btn r act" data-act="fight"'+(cF||S.travel?' disabled':'')+'>'+ic('s-dmg')+'В бой<small>'+(cF?cd(S.cd.fight):'враг: сила '+fmt(E))+'</small>'+(cF?'<i class="cdb" data-cdbar="'+(S.cd.fight-45000)+','+S.cd.fight+'"></i>':'')+'</button></div>'+
    '<div class="chips">'+oddsChip(odds)+'</div>'+
    (ammo>=5?'<label class="tog"><input type="checkbox" data-inp="ammo"'+(useAmmo?' checked':'')+'> Патроны: +25% урона, минус 5 шт. (есть '+ammo+')</label>':'')+
    (lastEvent?lastEventHtml():'')+'</section>';
  h+='<section class="pn"><h3>Капитаны в секторе: '+crew.length+'</h3>'+crewHtml(crew)+'</section>';
  h+='<section class="pn"><h3>Корабль</h3><div class="sg">'+
    '<div class="st">'+tile('u-shield','#2a6fb0')+'<div><div class="k">Прочность</div><div class="v">'+fmt(st.hp)+'</div></div></div>'+
    '<div class="st">'+tile('s-dmg','#a8452f')+'<div><div class="k">Урон за раунд</div><div class="v">'+fmt(st.dmg)+'</div></div></div>'+
    '<div class="st">'+tile('s-speed','#2a6fb0')+'<div><div class="k">Скорость</div><div class="v">×'+st.speed.toFixed(2).replace('.',',')+'</div></div></div>'+
    '<div class="st">'+tile('u-hold','#8a5a2a')+'<div><div class="k">Трюм</div><div class="v">'+st.used+' из '+st.cap+'</div></div></div></div>'+
    '<div class="hd">Модули: '+S.equip.length+' из '+C.MOD_SLOTS+'</div><div class="mods">';
  for(let i=0;i<C.MOD_SLOTS;i++){
    const m=S.equip[i];
    h+=m?'<button class="cell f" style="--rc:'+rc(m.u.q)+'" data-act="unequip" data-a="'+i+'" aria-label="Снять модуль">'+ic(C.MOD[m.u.kind].icon)+'<span class="cn">+'+(m.u.bonus*100).toFixed(0)+'%</span></button>':'<div class="cell emp">пусто</div>';
  }
  h+='</div></section><section class="pn"><h3>Улучшения корабля</h3>';
  for(const k in C.UPG){
    const u=C.UPG[k],L=S.upg[k],cost=C.upgCost(S,k),can=S.credits>=cost;
    h+='<div class="rw">'+tile(u.icon,'#2b3160',L)+'<div class="um"><div class="t">'+u.name+'</div><div class="sub">'+u.eff(L)+' → '+u.eff(L+1)+'</div></div><button class="btn sm g" data-act="upg" data-a="'+k+'"'+(can?'':' disabled')+'>'+fmt(cost)+' ₵</button></div>';
  }
  h+='</section>';
  if(S.log.length)h+='<section class="pn"><h3>Журнал</h3>'+S.log.slice(0,6).map(l=>'<div class="sub" style="padding:3px 0">'+esc(l.text)+'</div>').join('')+'</section>';
  return h;
}
function lastEventHtml(){
  const r=lastEvent;
  if(r.type==='scan'){
    if(!r.found)return '<hr><div class="sub">Сектор пуст. Попробуйте ещё раз.</div>';
    const I=C.info(r.k);return '<hr><div class="row">'+tile(I.icon,rc(I.q))+'<div class="sp"><b>'+I.name+' ×'+r.n+'</b><div class="sub">Найдено при сканировании'+(r.lost?'. Не влезло в трюм: '+r.lost:'')+'</div></div></div>';
  }
  const hpP=r.hpMax?r.hpLeft/r.hpMax*100:0,ep=r.eMax?r.eLeft/r.eMax*100:0;
  return '<hr><div class="res-h '+(r.win?'gn':'bd')+'">'+(r.win?'Победа':'Отступление')+'</div><div class="sub">Раундов: '+r.rounds+(r.ammoUsed?', патронов потрачено: '+r.ammoUsed:'')+'</div>'+
    '<div class="row" style="margin-top:10px"><span class="sub" style="width:78px">Ваш корабль</span><div class="bar s sp"><i style="width:'+hpP+'%"></i></div></div>'+
    '<div class="row" style="margin-top:8px"><span class="sub" style="width:78px">Враг</span><div class="bar e sp"><i style="width:'+ep+'%"></i></div></div>'+
    (r.win?'<div class="chips"><span class="chip y">+'+fmt(r.cr)+' ₵</span><span class="chip b">+'+r.xp+' опыта</span>'+r.loot.map(x=>'<span class="chip">'+ic(C.info(x.k).icon)+' ×'+x.n+'</span>').join('')+'</div>':'<div class="sub" style="margin-top:10px">Усильте оружие и щиты или включите патроны. Слабее тиры ниже, там безопаснее.</div>');
}
function capSheet(id){
  const c=CAPS[id];if(!c)return;
  const L=c.loc?C.locInfo(c.loc.t,c.loc.s):null;
  openSheet('<div class="row"><div class="ca" style="--tc:'+C.VIP.col[c.vip]+';width:58px;height:58px;font-size:24px;margin:0">'+esc(c.name.slice(0,1))+'</div><div class="sp"><div class="sh-t" style="color:'+C.VIP.col[c.vip]+'">'+esc(c.name)+'</div><div class="sub">Уровень '+c.lvl+(c.vip?', VIP '+c.vip:'')+(c.real?', игрок':', бот')+'</div></div></div>'+
    '<div class="kv" style="margin-top:14px"><span>Гильдия</span><span>'+(c.guild?esc(c.guild):'нет')+'</span><span>Сейчас в секторе</span><span>'+(L?esc(L.name):'—')+'</span><span>Тир</span><span>'+(L?rom(L.tier)+' «'+C.tierName(L.tier)+'»':'—')+'</span></div><div class="btns one"><button class="btn n" data-act="close">Закрыть</button></div>');
}

/* ---------- Постройки ---------- */
function pgBuild(){
  const t=S.loc.t,s=S.loc.s,sl=C.slots(S,t,s),P=C.incomeParts(S),busy=!!S.travel,li=C.locInfo(t,s);
  let h=banHtml(t,s,{small:true});
  h+='<section class="pn"><div class="kv"><span>Слотов построек</span><span>'+sl.filter(Boolean).length+' из '+sl.length+'</span><span>Множитель дохода локации</span><span>×'+C.Loc.M(t).toFixed(2).replace('.',',')+'</span><span>Цена построек здесь</span><span>×'+C.Loc.P(t).toFixed(1).replace('.',',')+'</span><span>Сумма уровней построек</span><span>'+C.sumLevels(S)+'</span></div>'+(li.bias?'<div class="note" style="margin-top:12px">Здесь выгодно строить '+(li.bias==='ore'?'Рудник':li.bias==='food'?'Ферму':li.bias==='comp'?'Фабрику':'Лабораторию')+': ресурсы добываются на 25% быстрее.</div>':'')+(busy?'<div class="note" style="margin-top:12px">Корабль в пути. Строить можно после прибытия.</div>':'')+'</section>';
  h+='<section class="pn"><h3>Слоты</h3>';
  sl.forEach((b,i)=>{
    if(!b){
      h+='<div class="rw"><div class="tl" style="box-shadow:inset 0 0 0 2px #2b3160;color:var(--dim)">'+ic('i-plus')+'</div><div class="um"><div class="t">Свободный слот</div><div class="sub">Выберите здание для постройки</div></div><button class="btn sm b" data-act="pickbuild" data-a="'+i+'"'+(busy?' disabled':'')+'>Построить</button></div>';
      return;
    }
    const B=C.BUILD[b.type],inc=C.bldIncome(b.type,b.level,t)*P.um*P.vm,nc=C.buildCost(S,b.type,b.level+1,t),gain=(C.bldIncome(b.type,b.level+1,t)-C.bldIncome(b.type,b.level,t))*P.um*P.vm,pay=gain>0?nc/gain:Infinity,can=S.credits>=nc&&!busy;
    h+='<div class="rw">'+tile(B.icon,'#2b3160',b.level)+'<div class="um"><div class="t">'+B.name+'</div><div class="sub">+'+fmt(inc)+' ₵/мин. Окупится за '+(pay===Infinity?'—':C.dur(pay*60000))+'</div></div><button class="btn sm g" data-act="upbld" data-a="'+i+'"'+(can?'':' disabled')+'>'+fmt(nc)+' ₵</button></div>';
  });
  h+='</section>';
  const all=C.allBuildings(S);
  if(all.length){
    const by={};all.forEach(x=>{(by[x.key]=by[x.key]||[]).push(x);});
    h+='<section class="pn"><h3>Все владения</h3>';
    Object.keys(by).forEach(key=>{
      const arr=by[key],inc=arr.reduce((a,x)=>a+C.bldIncome(x.b.type,x.b.level,x.t),0)*P.um*P.vm,L=C.locInfo(arr[0].t,arr[0].s);
      h+='<div class="rw"><div class="um"><div class="t">'+esc(L.name)+'</div><div class="sub" style="display:flex;gap:10px;flex-wrap:wrap;margin-top:3px">'+arr.map(x=>'<span>'+ic(C.BUILD[x.b.type].icon)+' '+x.b.level+'</span>').join('')+'</div></div><div class="gd" style="font-weight:500">+'+fmt(inc)+' ₵</div></div>';
    });
    h+='</section>';
  }
  return h;
}
function buildSheet(i){
  const t=S.loc.t;
  let h='<div class="sh-t">Что построить</div><div class="sub" style="margin-bottom:8px">Первый уровень. Цена растёт с суммой уровней всех ваших построек.</div>';
  for(const k in C.BUILD){
    const B=C.BUILD[k],c=C.buildCost(S,k,1,t),can=S.credits>=c;
    h+='<div class="rw">'+tile(B.icon)+'<div class="um"><div class="t">'+B.name+'</div><div class="sub">'+B.desc+'. Базовый доход '+B.B+'</div></div><button class="btn sm g" data-act="dobuild" data-a="'+i+'" data-b="'+k+'"'+(can?'':' disabled')+'>'+fmt(c)+' ₵</button></div>';
  }
  openSheet(h);
}

/* ---------- Карта ---------- */
function maxCoil(){let m=0;for(const k in S.unlocked)m=Math.max(m,+k.split(':')[0]);return m;}
function pgMap(){
  const vt=mapT,ms=mapS,cx=170,cy=170,R=116,tier=C.tierOf(vt),tc=C.tierCol(tier),myL=C.levelOf(S.xp),cc=countsFor(vt);
  let h='<div class="tiers">';
  const top=Math.max(C.tierOf(maxCoil())+2,tier+1);
  for(let k=1;k<=top;k++){
    const req=C.tierReq(k),lk=myL<req;
    h+='<button class="tc'+(k===tier?' on':'')+(lk?' lk':'')+'" style="--tc:'+C.tierCol(k)+'" data-act="tier" data-a="'+k+'"><div class="rn">'+rom(k)+'</div><div class="nm">'+C.tierName(k)+'</div><div class="rq">'+(lk?ic('i-lock')+'нужен ур. '+req:'открыт')+'</div></button>';
  }
  h+='</div>';
  let svg='<svg class="dial" viewBox="0 0 340 340" role="img" aria-label="Карта витка">';
  svg+='<circle cx="170" cy="170" r="160" fill="#0f1225" stroke="'+tc+'" stroke-opacity=".35" stroke-width="2"/>';
  for(let i=0;i<72;i++){const a=i*5*Math.PI/180,long=i%6===0,r1=long?146:151,r2=158;svg+='<line x1="'+(cx+Math.cos(a)*r1).toFixed(1)+'" y1="'+(cy+Math.sin(a)*r1).toFixed(1)+'" x2="'+(cx+Math.cos(a)*r2).toFixed(1)+'" y2="'+(cy+Math.sin(a)*r2).toFixed(1)+'" stroke="'+tc+'" stroke-opacity="'+(long?.6:.25)+'" stroke-width="'+(long?2:1)+'"/>';}
  svg+='<circle cx="170" cy="170" r="'+R+'" fill="none" stroke="#2b3160" stroke-width="2" stroke-dasharray="2 6"/><circle cx="170" cy="170" r="54" fill="#1a1f38" stroke="'+tc+'" stroke-width="3"/>';
  svg+='<text x="170" y="164" text-anchor="middle" fill="'+tc+'" font-size="26">'+rom(tier)+'</text><text x="170" y="184" text-anchor="middle" fill="#9aa1cc" font-size="11">виток '+vt+'</text><text x="170" y="200" text-anchor="middle" fill="#666d99" font-size="10">×'+C.Loc.M(vt).toFixed(2).replace('.',',')+'</text>';
  for(let sct=1;sct<=C.SECTORS;sct++){
    const a=(sct-1)*30*Math.PI/180-Math.PI/2,x=cx+Math.cos(a)*R,y=cy+Math.sin(a)*R,key=vt+':'+sct;
    const cur=S.loc.t===vt&&S.loc.s===sct,open=!!S.unlocked[key],u=C.unlockInfo(S,vt,sct),sel=ms===sct,lvlLock=myL<C.Loc.R(vt);
    let fill='#12162b',stroke='#3a4070',tcol='#666d99',dash='';
    if(open){fill='#123a2b';stroke='#3ddc84';tcol='#f1f3ff';}
    else if(u.can){stroke='#ffc83d';tcol='#ffc83d';dash=' stroke-dasharray="4 3"';fill='#1a1f38';}
    if(cur){fill='#ffc83d';stroke='#ffc83d';tcol='#251700';}
    svg+='<g data-act="msel" data-a="'+sct+'">'+(cur?'<circle class="ping" cx="'+x.toFixed(1)+'" cy="'+y.toFixed(1)+'" r="20" fill="none" stroke="#ffc83d" stroke-width="2"/>':'')+
      (sel?'<circle cx="'+x.toFixed(1)+'" cy="'+y.toFixed(1)+'" r="26" fill="none" stroke="#f1f3ff" stroke-width="2"/>':'')+
      '<circle cx="'+x.toFixed(1)+'" cy="'+y.toFixed(1)+'" r="20" fill="'+fill+'" stroke="'+stroke+'" stroke-width="2.4"'+dash+'/>'+
      (lvlLock&&!open?'<use href="#i-lock" x="'+(x-8).toFixed(1)+'" y="'+(y-8).toFixed(1)+'" width="16" height="16"/>':'<text x="'+x.toFixed(1)+'" y="'+(y+5.5).toFixed(1)+'" text-anchor="middle" fill="'+tcol+'" font-size="15">'+sct+'</text>')+
      (cc[sct]?'<circle cx="'+(x+15).toFixed(1)+'" cy="'+(y-15).toFixed(1)+'" r="9" fill="#3fa9ff"/><text x="'+(x+15).toFixed(1)+'" y="'+(y-11).toFixed(1)+'" text-anchor="middle" fill="#04182c" font-size="10.5">'+cc[sct]+'</text>':'')+'</g>';
  }
  svg+='</svg>';
  const u=C.unlockInfo(S,vt,ms),here=S.loc.t===vt&&S.loc.s===ms,li=C.locInfo(vt,ms),odds=C.fightOdds(S,vt),crew=crewFor(vt,ms);
  h+='<section class="pn"><div class="stepper"><button data-act="mcoil" data-a="-1"'+(vt<=0?' disabled':'')+' aria-label="Ближе к центру">−</button><div class="c">Виток '+vt+'</div><button data-act="mcoil" data-a="1"'+(vt>=maxCoil()+3?' disabled':'')+' aria-label="Дальше от центра">+</button></div>'+svg+
    '<div class="legend"><span><i style="background:#ffc83d"></i>вы здесь</span><span><i style="background:#3ddc84"></i>открыто</span><span><i style="background:#3fa9ff"></i>капитаны</span></div></section>';
  h+=banHtml(vt,ms,{small:true});
  h+='<section class="pn"><div class="kv"><span>Тип</span><span>'+li.type.name+'</span><span>Нужен уровень капитана</span><span class="'+(myL<C.Loc.R(vt)?'bd':'gn')+'">'+C.Loc.R(vt)+'</span><span>Множитель дохода</span><span>×'+C.Loc.M(vt).toFixed(2).replace('.',',')+'</span><span>Награды за бой</span><span>×'+C.tierRew(tier).toFixed(2).replace('.',',')+'</span><span>Сила врагов</span><span>'+fmt(C.Loc.E(vt))+'</span><span>Редкость ресурсов</span><span style="color:'+rc(C.Loc.Q(vt))+'">'+C.RARITY[C.Loc.Q(vt)]+'</span><span>Слотов построек</span><span>'+C.Loc.Sb(vt)+'</span><span>Капитанов сейчас</span><span>'+crew.length+'</span></div><div class="chips">'+oddsChip(odds)+'</div>';
  if(here)h+='<div class="note" style="margin-top:12px">Ваш корабль сейчас здесь.</div>';
  else if(u.done){
    const ms2=C.travelTime(S,{t:vt,s:ms}),lock=myL<C.Loc.R(vt);
    h+='<div class="btns one"><button class="btn g" data-act="go" data-a="'+vt+'" data-b="'+ms+'"'+(S.travel||lock?' disabled':'')+'>'+ic('n-ship')+'Лететь сюда, '+C.dur(ms2)+'</button></div>'+(lock?'<div class="sub" style="margin-top:8px;text-align:center">Нужен уровень '+C.Loc.R(vt)+'</div>':'');
  }else{
    h+=(u.reasons.length?'<div class="note" style="margin-top:12px">'+u.reasons.map(esc).join('<br>')+'</div>':'')+'<div class="btns one"><button class="btn g" data-act="unlock" data-a="'+vt+'" data-b="'+ms+'"'+(u.can&&u.afford?'':' disabled')+'>Открыть за '+fmt(u.cost)+' ₵</button></div>'+(u.can&&!u.afford?'<div class="sub" style="margin-top:8px;text-align:center">Не хватает '+fmt(u.cost-S.credits)+' ₵</div>':'');
  }
  h+='</section>';
  if(crew.length)h+='<section class="pn"><h3>Капитаны здесь</h3>'+crewHtml(crew)+'</section>';
  if(S.travel)h='<section class="pn"><div class="row"><div class="sp">Корабль летит: '+esc(C.locInfo(S.travel.to.t,S.travel.to.s).name)+'</div><b>'+cd(S.travel.end)+'</b></div></section>'+h;
  return h;
}

/* ---------- Трюм ---------- */
function pgCargo(){
  return '<div class="seg"><button class="'+(cargoSeg==='inv'?'on':'')+'" data-act="cseg" data-a="inv">Инвентарь</button><button class="'+(cargoSeg==='craft'?'on':'')+'" data-act="cseg" data-a="craft">Крафт</button></div>'+(cargoSeg==='inv'?invHtml():craftHtml());
}
function invHtml(){
  const cap=C.cap(S);
  let h='<section class="pn"><div class="row"><h3 class="sp" style="margin:0">Слоты: '+S.inv.length+' из '+cap+'</h3></div><div class="bar y" style="margin:10px 0 12px"><i style="width:'+(S.inv.length/cap*100)+'%"></i></div>'+
    '<div class="pills">'+[['type','По типу'],['rar','По редкости'],['price','По цене'],['time','По времени']].map(x=>'<button class="pill'+(S.invSort===x[0]?' on':'')+'" data-act="isort" data-a="'+x[0]+'">'+x[1]+'</button>').join('')+'</div><div class="grid">';
  for(let i=0;i<cap;i++){
    const st=S.inv[i];
    if(!st){h+='<div class="cell"></div>';continue;}
    const I=C.info(st.k,st.u);
    h+='<button class="cell f" style="--rc:'+rc(I.q)+'" data-act="inv" data-a="'+i+'" aria-label="'+esc(I.name)+'">'+ic(I.icon)+(st.n>1?'<span class="cn">'+(st.n>=1000?fmt(st.n):st.n)+'</span>':'')+'</button>';
  }
  return h+'</div></section>';
}
function itemSheet(i){
  const st=S.inv[i];if(!st)return;
  const I=C.info(st.k,st.u),avg=C.avgPrice(S,st.k,st.u),key=S.loc.t+':'+S.loc.s;
  const bot=(S.bots[key]||[]).find(b=>b.k===st.k&&b.remain>0);
  let h='<div class="row">'+tile(I.icon,rc(I.q))+'<div class="sp"><div class="sh-t">'+esc(I.name)+'</div><div class="sub" style="color:'+rc(I.q)+'">'+C.RARITY[I.q]+', '+C.CAT_NAME[I.cat].toLowerCase()+'</div></div></div>'+
    '<div class="sub" style="margin:12px 0">'+esc(I.desc)+'</div><div class="kv"><span>Количество</span><span>'+st.n+'</span><span>Средняя цена</span><span>'+(I.stop?'—':fmt(avg)+' ₵')+'</span></div><div class="btns one">';
  if(st.k==='mod')h+='<button class="btn g" data-act="equip" data-a="'+i+'">Установить на корабль</button>';
  if(st.k==='fuel')h+='<button class="btn g" data-act="useitem" data-a="'+i+'">Использовать</button>';
  if(bot)h+='<button class="btn y" data-act="botsell" data-a="'+bot.id+'" data-b="'+bot.k+'">Скупщику: '+fmt(bot.p)+' ₵ за шт., до '+Math.min(bot.remain,st.n)+' шт.</button>';
  if(!I.stop)h+='<button class="btn b" data-act="lotform" data-a="'+i+'">Выставить на аукцион</button>';
  h+='<button class="btn n" data-act="discard" data-a="'+i+'"'+(I.stop?' disabled':'')+'>Выбросить</button></div>';
  openSheet(h);
}
function craftHtml(){
  const Ll=C.bestLevel(S,'lab'),now=Date.now();
  let h='<section class="pn"><h3>'+ic('b-lab')+'Лаборатория</h3><div class="sub">'+(Ll?'Лучшая лаборатория: уровень '+Ll+'. Ускоряет сборку и повышает шанс успеха.':'Лаборатории нет. Без неё шанс успеха низкий, а сборка медленная.')+' При провале половина ресурсов теряется.</div></section>';
  if(S.craft){
    const rec=C.RECIPES.find(r=>r.id===S.craft.rid),done=now>=S.craft.end;
    h+='<section class="pn"><h3>В работе</h3><div class="rw">'+tile(rec.icon)+'<div class="um"><div class="t">'+rec.name+'</div><div class="sub">'+(done?'Готово, нужно место в трюме':'Осталось '+cd(S.craft.end))+'</div></div>'+(S.craft.done?'<button class="btn sm g" data-act="cclaim">Забрать</button>':'')+'</div></section>';
  }
  h+='<section class="pn"><h3>Рецепты</h3>';
  C.RECIPES.forEach(r=>{
    const ci=C.craftInfo(S,r);let ok=!S.craft;
    const inp=r.inp.map(([t,n])=>{const have=C.countRes(S,t);if(have<n)ok=false;return '<span class="chip '+(have>=n?'g':'r')+'">'+ic(C.RES[t].icon)+' '+fmt(have)+'/'+n+'</span>';}).join('');
    h+='<div class="rw" style="align-items:flex-start">'+tile(r.icon)+'<div class="um"><div class="t">'+r.name+'</div><div class="sub">Время '+C.dur(ci.time)+', успех '+Math.round(ci.p*100)+'%</div><div class="chips" style="margin-top:7px">'+inp+'</div></div><button class="btn sm g" data-act="craft" data-a="'+r.id+'"'+(ok?'':' disabled')+'>Создать</button></div>';
  });
  return h+'</section>';
}

/* ---------- Рынок ---------- */
function pgMarket(){
  const h='<div class="seg">'+[['auc','Аукцион'],['mine','Мои лоты'],['bots','Скупщики']].map(x=>'<button class="'+(mktSeg===x[0]?'on':'')+'" data-act="mseg" data-a="'+x[0]+'">'+x[1]+'</button>').join('')+'</div>';
  return h+(mktSeg==='auc'?aucHtml():mktSeg==='mine'?mineHtml():botsHtml());
}
function aucHtml(){
  const cats=[['all','Все'],['res','Ресурсы'],['cons','Расходники'],['mod','Модули'],['misc','Прочее']],nowT=Date.now();
  const list=C.getWorld().market.filter(l=>l.status==='active'&&l.exp>nowT&&!(l.mine||l.owner===S.uid)&&(mktCat==='all'||C.info(l.k,l.u).cat===mktCat)).sort((a,b)=>a.p*a.n-b.p*b.n);
  let h='<div class="pills">'+cats.map(c=>'<button class="pill'+(mktCat===c[0]?' on':'')+'" data-act="mcat" data-a="'+c[0]+'">'+c[1]+'</button>').join('')+'</div><section class="pn">';
  if(!list.length)h+='<div class="sub">В этой категории лотов нет.</div>';
  list.forEach(l=>{
    const I=C.info(l.k,l.u),can=S.credits>=l.p*l.n;
    h+='<div class="lot">'+tile(I.icon,rc(I.q))+'<div class="mid"><div class="nm" style="color:'+rc(I.q)+'">'+esc(I.name)+(l.n>1?' ×'+l.n:'')+'</div><div class="sub">'+fmt(l.p)+' ₵ за шт., '+esc(l.seller)+', ещё '+cd(l.exp)+'</div></div><button class="btn sm g" data-act="buylot" data-a="'+l.id+'"'+(can?'':' disabled')+'>'+fmt(l.p*l.n)+' ₵</button></div>';
  });
  return h+'</section>';
}
function mineHtml(){
  const lim=C.aucSlots(S),tax=C.taxPct(S);
  let h='<section class="pn"><div class="kv"><span>Занято слотов</span><span>'+S.lots.length+' из '+fmt(lim)+'</span><span>Налог с продажи</span><span>'+String(tax).replace('.',',')+'%</span><span>Срок лота</span><span>24 часа</span></div></section><section class="pn"><h3>Ваши лоты</h3>';
  if(!S.lots.length)h+='<div class="sub">Пока пусто. Откройте «Трюм», выберите предмет и нажмите «Выставить на аукцион».</div>';
  S.lots.forEach(l=>{
    const I=C.info(l.k,l.u),exp=l.status==='expired';
    h+='<div class="lot">'+tile(I.icon,rc(I.q))+'<div class="mid"><div class="nm">'+esc(I.name)+(l.n>1?' ×'+l.n:'')+'</div><div class="sub">'+fmt(l.p)+' ₵ за шт., '+(exp?'срок вышел, нет места в трюме':'ещё '+cd(l.exp))+'</div></div><button class="btn sm n" data-act="cancellot" data-a="'+l.id+'">'+(exp?'Забрать':'Снять')+'</button></div>';
  });
  return h+'</section>';
}
function botsHtml(){
  const bots=S.bots[S.loc.t+':'+S.loc.s]||[],now=Date.now();
  let h='<section class="pn"><h3>Скупщики: '+esc(C.locInfo(S.loc.t,S.loc.s).name)+'</h3><div class="sub" style="margin-bottom:6px">Берут ресурсы по фиксированной цене, около 70% от аукционной. Лимит и товар обновляются каждые 5–30 минут.</div>';
  bots.forEach(b=>{
    const I=C.info(b.k),have=C.countKey(S,b.k),q=Math.min(have,b.remain);
    h+='<div class="lot">'+tile(I.icon,rc(I.q))+'<div class="mid"><div class="nm" style="color:'+rc(I.q)+'">'+I.name+'</div><div class="sub">'+fmt(b.p)+' ₵ за шт., лимит '+b.remain+' из '+b.max+', у вас '+have+'</div>'+(b.dev||b.next<=now?'':'<div class="sub dim">обновится через '+cd(b.next)+'</div>')+'</div><button class="btn sm y" data-act="botsell" data-a="'+b.id+'" data-b="'+b.k+'"'+(q>0?'':' disabled')+'>Продать'+(q>0?' '+q:'')+'</button></div>';
  });
  return h+'</section>';
}
function lotSheet(i){
  const st=S.inv[i];if(!st)return;
  const I=C.info(st.k,st.u),L=C.lotLimits(S,st);
  lotDraft={i,n:st.u?1:st.n,p:Math.max(1,Math.round(L.avg))};
  let h='<div class="sh-t">Выставить лот</div><div class="row" style="margin:10px 0 14px">'+tile(I.icon,rc(I.q))+'<div class="sp"><b>'+esc(I.name)+'</b><div class="sub">Средняя цена '+fmt(L.avg)+' ₵. Допустимо от 1 до '+fmt(L.max)+' ₵ за шт.</div></div></div>';
  if(!st.u)h+='<label class="fld"><span>Количество (есть '+st.n+')</span><input class="inp" id="lotn" data-inp="lotn" type="number" inputmode="numeric" min="1" max="'+st.n+'" value="'+st.n+'"></label>';
  h+='<label class="fld"><span>Цена за штуку, ₵</span><input class="inp" id="lotp" data-inp="lotp" type="number" inputmode="numeric" min="1" value="'+lotDraft.p+'"></label><div class="note" id="lotprev"></div><div class="btns one"><button class="btn y" data-act="dolot">Выставить на 24 часа</button></div>';
  openSheet(h);lotPreview();
}
function lotPreview(){
  if(!lotDraft)return;
  const n=lotDraft.n,p=lotDraft.p,tax=C.taxPct(S),gross=n*p,el=$('#lotprev');
  if(el)el.innerHTML=money('Всего '+fmt(gross)+' ₵. Налог '+String(tax).replace('.',',')+'%, вы получите '+fmt(gross*(1-tax/100))+' ₵.');
}

/* ---------- Пополнение кристаллов ---------- */
function topupSheet(){
  const free=MODE==='local'||(CFG.demoTopup&&!HAS_LAUNCH);
  let h='<div class="sh-t">Пополнение кристаллов</div><div class="sub" style="margin-bottom:6px">Кристаллы нужны для VIP-статуса. У вас сейчас: ◆ '+S.premium+'</div>';
  C.PACKS.forEach(p=>{
    h+='<div class="rw">'+tile('i-gem','#6b4fd8')+'<div class="um"><div class="t">◆ '+fmt(p.n+p.bonus)+'</div><div class="sub">'+(p.bonus?'Бонус: +'+p.bonus+' кристаллов':'Базовый набор')+'</div></div><button class="btn sm v" data-act="buypack" data-a="'+p.id+'">'+(free?'Получить':p.price+' гол.')+'</button></div>';
  });
  h+='<div class="note" style="margin-top:12px">'+(free?'Демо-режим: кристаллы начисляются бесплатно.':'Оплата проходит через VK. Кристаллы начисляются после подтверждения платежа.')+'</div>';
  openSheet(h);
}
async function buyPack(id){
  const free=MODE==='local'||(CFG.demoTopup&&!HAS_LAUNCH);
  if(free){await act('demoPack',[id],true);topupSheet();return;}
  if(!VK){toast('Оплата доступна только внутри VK','bad');return;}
  try{
    await VK.send('VKWebAppShowOrderBox',{type:'item',item:'crystals_'+id});
    toast('Платёж принят, начисляем кристаллы','ok');
    setTimeout(()=>doSync(true),1500);setTimeout(()=>doSync(true),6000);
  }catch(e){toast('Оплата не завершена','bad');}
}

/* ---------- Капитан ---------- */
function pgMe(){
  const vl=C.vipLvl(S),st=S.stats,L=C.levelOf(S.xp),tier=C.tierForLevel(L);
  let h='<section class="pn"><div class="row"><div class="ava" style="width:60px;height:60px;font-size:24px;border-radius:18px;--tc:'+C.VIP.col[vl]+'"><span>'+esc(S.name.slice(0,1).toUpperCase())+'</span>'+(S.photo?'<img src="'+esc(S.photo)+'" alt="" onerror="this.remove()">':'')+'</div><div class="sp"><div class="sh-t" style="color:'+C.VIP.col[vl]+';margin:0">'+esc(S.name)+'</div><div class="sub">'+(S.guild?'Гильдия «'+esc(S.guild)+'»':'Без гильдии')+'</div></div></div>'+
    '<div class="chips">'+(vl?'<span class="chip y">VIP '+vl+', ещё '+C.dur(S.vipUntil-Date.now())+'</span>':'<span class="chip">без VIP</span>')+'<span class="chip" style="color:'+C.tierCol(tier)+'">Доступен тир '+rom(tier)+'</span>'+(S.is_dev?'<span class="chip g">разработчик</span>':'')+(S.is_admin?'<span class="chip g">администратор</span>':'')+'</div>'+
    '<div class="sg" style="margin-top:14px"><div class="st"><div><div class="k">Время в игре</div><div class="v">'+C.dur(st.playSec*1000)+'</div></div></div><div class="st"><div><div class="k">Побед в боях</div><div class="v">'+st.won+'</div></div></div><div class="st"><div><div class="k">Прибыль всего</div><div class="v">₵'+fmt(st.profit)+'</div></div></div><div class="st"><div><div class="k">Пройдено</div><div class="v">'+fmt(st.distance)+'</div></div></div></div></section>';
  h+=topHtml();
  h+='<section class="pn"><h3>'+ic('i-gem')+'VIP-статус</h3><div class="sub" style="margin-bottom:8px">Каждый уровень действует 30 дней. Множитель применяется к доходу после всех остальных расчётов.</div>';
  for(let N=1;N<=10;N++){
    const cur=C.vipLvl(S)===N,low=C.vipActive(S)&&N<S.vipLevel,pr=C.VIP.price(N);
    h+='<div class="rw"><div class="tl" style="--rc:'+C.VIP.col[N]+';color:'+C.VIP.col[N]+';font:400 17px var(--f-h)">'+N+'</div><div class="um"><div class="t" style="color:'+C.VIP.col[N]+'">'+C.VIP.names[N]+' ник</div><div class="sub">доход ×'+C.interp(C.VIP.mult,N).toFixed(2).replace('.',',')+', налог '+Math.max(2,5-C.interp(C.VIP.disc,N))+'%, слотов '+(N>=10?'∞':Math.round(C.interp(C.VIP.slots,N)))+'</div></div><button class="btn sm v" data-act="vip" data-a="'+N+'"'+(low?' disabled':'')+'>'+(cur?'Продлить ':'')+pr+' ◆</button></div>';
  }
  h+='</section>';
  h+='<section class="pn"><h3>Промокод</h3><div class="row"><input class="inp sp" id="promo" placeholder="Введите код" autocomplete="off" autocapitalize="characters"><button class="btn y" data-act="promo">Активировать</button></div></section>';
  h+='<section class="pn"><h3>Достижения</h3>'+C.ACH.map(a=>{const got=!!S.ach[a.id];return '<div class="rw"><div class="tl" style="'+(got?'--rc:#b98108':'')+';opacity:'+(got?1:.6)+'">'+ic(got?'i-gem':'i-lock')+'</div><div class="um"><div class="t" style="'+(got?'':'color:var(--mut)')+'">'+a.name+'</div><div class="sub">'+a.desc+'</div></div><span class="chip '+(got?'g':'')+'">'+(got?'получено':'+'+a.reward+' ◆')+'</span></div>';}).join('')+'</section>';
  h+='<section class="pn"><h3>Гильдия</h3>'+(S.guild?'<div class="row"><div class="sp">Вы состоите в «'+esc(S.guild)+'»</div><button class="btn n sm" data-act="leaveguild">Выйти</button></div>':C.GUILDS.map(g=>'<div class="rw"><div class="um"><div class="t">'+g.name+'</div><div class="sub">'+g.members+' участников</div></div><button class="btn n sm" data-act="joinguild" data-a="'+g.id+'">Вступить</button></div>').join(''))+'</section>';
  h+='<section class="pn"><h3>Команда</h3><div class="row"><input class="inp sp" id="cmd" placeholder="/help" autocomplete="off" autocapitalize="off"><button class="btn n" data-act="cmd">Отправить</button></div></section>';
  h+='<div class="sub dim" style="text-align:center;padding:8px 0">Звёздная спираль 3.0, '+(MODE==='server'?(DEMO?'демо-сервер':'сервер'):'локальный демо-режим')+'</div>';
  return h;
}
function topHtml(){
  const kinds=[['bal','Баланс'],['xp','Опыт'],['inc','Доход']],tp=topFor(topKind);
  let h='<section class="pn"><h3>Рейтинг капитанов</h3><div class="pills">'+kinds.map(k=>'<button class="pill'+(topKind===k[0]?' on':'')+'" data-act="tk" data-a="'+k[0]+'">'+k[1]+'</button>').join('')+'</div>';
  if(!tp)return h+'<div class="sub">Загрузка рейтинга…</div></section>';
  tp.rows.forEach((p,i)=>{
    const val=topKind==='xp'?'ур. '+C.levelOf(p.xp):topKind==='inc'?'₵'+fmt(p.inc)+'/мин':'₵'+fmt(p.bal);
    h+='<div class="row'+(p.me?' me':'')+'" style="padding:8px 6px"><div class="rank '+(i<3?'t'+(i+1):'')+'">'+(i+1)+'</div><div class="sp" style="color:'+C.VIP.col[p.vip]+';font-weight:500;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">'+esc(p.name)+(p.me?' (вы)':'')+'</div><div class="h" style="font-size:13px">'+val+'</div></div>';
  });
  if(tp.hidden)h+='<div class="note" style="margin-top:10px">Ваш служебный аккаунт скрыт из публичного рейтинга.</div>';
  else if(tp.myRank>20)h+='<div class="note" style="margin-top:10px">Ваше место: '+tp.myRank+' из '+tp.total+'.</div>';
  return h+'<div class="sub dim" style="margin-top:8px">Служебные аккаунты в рейтинге не показываются.</div></section>';
}

/* ---------- Панель разработчика ---------- */
function pgDev(){
  if(!S.is_dev)return '<section class="pn"><div class="note">Нет доступа.</div></section>';
  const keyOpts=C.KEYS.map(k=>'<option value="'+k+'">'+C.info(k).name+' ('+C.RARITY[C.info(k).q]+')</option>').join('')+'<option value="mod:income:4">Модуль реактора Mk-4</option><option value="mod:dmg:4">Модуль орудий Mk-4</option><option value="mod:hp:4">Модуль щита Mk-4</option>';
  const sl=C.slots(S,S.loc.t,S.loc.s),typeOpts=Object.keys(C.BUILD).map(k=>'<option value="'+k+'">'+C.BUILD[k].name+'</option>').join('');
  const DI=devInfo(),econ=DI.econ,mx=Math.max(1,...econ.map(e=>e.vol));
  let h='<section class="pn"><div class="row"><h3 class="sp" style="margin:0">Панель разработчика</h3><button class="btn n sm" data-act="tab" data-a="me">Закрыть</button></div><div class="sub" style="margin-top:8px">Доступна только аккаунтам с флагом is_dev. Проверку флага выполняет сервер.</div></section>';
  h+='<section class="pn"><h3>Выдать предмет</h3><label class="fld"><span>Предмет</span><select class="inp" id="dv-k">'+keyOpts+'</select></label><label class="fld"><span>Количество</span><input class="inp" id="dv-n" type="number" inputmode="numeric" value="100"></label><button class="btn g" data-act="dv" data-a="give">Выдать</button></section>';
  h+='<section class="pn"><h3>Телепорт</h3><div class="sg"><label class="fld"><span>Виток</span><input class="inp" id="dv-t" type="number" inputmode="numeric" value="'+S.loc.t+'"></label><label class="fld"><span>Сектор (1–12)</span><input class="inp" id="dv-s" type="number" inputmode="numeric" value="'+S.loc.s+'"></label></div><button class="btn g" data-act="dv" data-a="tp">Переместить</button></section>';
  h+='<section class="pn"><h3>Постройка на текущей локации</h3><div class="sg"><label class="fld"><span>Слот</span><select class="inp" id="dv-i">'+sl.map((b,i)=>'<option value="'+i+'">Слот '+(i+1)+(b?': '+C.BUILD[b.type].name+' '+b.level:'')+'</option>').join('')+'</select></label><label class="fld"><span>Здание</span><select class="inp" id="dv-bt">'+typeOpts+'</select></label></div><label class="fld"><span>Уровень (0 очищает слот)</span><input class="inp" id="dv-bl" type="number" inputmode="numeric" value="10"></label><button class="btn g" data-act="dv" data-a="setb">Установить</button></section>';
  h+='<section class="pn"><h3>Баланс, опыт, VIP</h3><div class="sg"><label class="fld"><span>Кредиты</span><input class="inp" id="dv-cr" type="number" inputmode="numeric" placeholder="'+Math.floor(S.credits)+'"></label><label class="fld"><span>Кристаллы</span><input class="inp" id="dv-pr" type="number" inputmode="numeric" placeholder="'+S.premium+'"></label><label class="fld"><span>Опыт</span><input class="inp" id="dv-xp" type="number" inputmode="numeric" placeholder="'+Math.floor(S.xp)+'"></label><label class="fld"><span>VIP-дни (0 снимает)</span><input class="inp" id="dv-vd" type="number" inputmode="numeric" placeholder="дни"></label></div><label class="fld"><span>Уровень VIP (1–10)</span><input class="inp" id="dv-vl" type="number" inputmode="numeric" value="'+Math.max(1,S.vipLevel)+'"></label><button class="btn g" data-act="dv" data-a="bal">Применить</button></section>';
  h+='<section class="pn"><h3>Симуляция дохода</h3><label class="fld"><span>Минут</span><input class="inp" id="dv-sim" type="number" inputmode="numeric" value="600"></label><button class="btn g" data-act="dv" data-a="sim">Начислить</button></section>';
  h+='<section class="pn"><h3>Скупщик на этой локации</h3><label class="fld"><span>Товар</span><select class="inp" id="dv-bk">'+C.KEYS.map(k=>'<option value="'+k+'">'+C.info(k).name+' ('+C.RARITY[C.info(k).q]+')</option>').join('')+'</select></label><div class="sg"><label class="fld"><span>Цена за шт., ₵</span><input class="inp" id="dv-bp" type="number" inputmode="decimal" value="10"></label><label class="fld"><span>Лимит</span><input class="inp" id="dv-bn" type="number" inputmode="numeric" value="500"></label></div><button class="btn g" data-act="dv" data-a="bot">Создать скупщика</button></section>';
  h+='<section class="pn"><h3>Экономика</h3><div class="sub" style="margin-bottom:8px">Оборот рынка по часам</div><div class="spark">'+(econ.length?econ.map(e=>'<i style="height:'+Math.max(6,e.vol/mx*100)+'%"></i>').join(''):'<span class="sub">Данные появятся через час игры</span>')+'</div>'+
    (econ.length?'<div class="kv" style="margin-top:10px"><span>Денежная масса</span><span>'+fmt(econ[econ.length-1].supply)+' ₵</span><span>Инфляция за час</span><span>'+econ[econ.length-1].infl.toFixed(2).replace('.',',')+'%</span></div>':'')+
    '<hr><div class="hd" style="margin-top:0">Полный топ балансов (включая скрытых)</div>'+DI.fullTop.map((p,i)=>'<div class="row" style="padding:4px 0"><div class="rank">'+(i+1)+'</div><div class="sp">'+esc(p.name)+(p.is_dev?' <span class="chip g">dev</span>':'')+(p.is_admin?' <span class="chip g">admin</span>':'')+'</div><div class="h" style="font-size:12.5px">'+fmt(p.bal)+'</div></div>').join('')+'</section>';
  h+='<section class="pn"><h3>Журнал действий</h3>'+(S.devLog.length?S.devLog.slice(0,8).map(l=>'<div class="sub" style="padding:2px 0">'+new Date(l.ts).toLocaleTimeString('ru-RU')+', '+esc(l.op)+' '+esc(l.args)+'</div>').join(''):'<div class="sub">Пока пусто</div>')+'</section>';
  h+='<section class="pn"><h3>Сброс</h3><div class="sub" style="margin-bottom:10px">Вернёт аккаунт к началу игры.</div><button class="btn r" data-act="resetask">Сбросить аккаунт</button></section>';
  return h;
}

/* ---------- отрисовка ---------- */
function render(){
  const keep={};let focusId=null;
  document.querySelectorAll('#page input,#page select').forEach(el=>{if(el.id)keep[el.id]=el.value;});
  const ae=document.activeElement;if(ae&&ae.id&&keep[ae.id]!==undefined)focusId=ae.id;
  $('#hdr').innerHTML=money(hdr());
  const pages={home:pgHome,build:pgBuild,map:pgMap,cargo:pgCargo,market:pgMarket,me:pgMe,dev:pgDev};
  $('#page').innerHTML=money(pages[tab]());
  for(const id in keep){const el=document.getElementById(id);if(el&&el.type!=='checkbox')el.value=keep[id];}
  if(focusId){const el=document.getElementById(focusId);if(el&&el.focus)el.focus();}
  const act=tab==='dev'?'me':tab;
  document.querySelectorAll('.tab').forEach(b=>b.classList.toggle('on',b.dataset.a===act));
}
function afterAction(){
  const L=C.levelOf(S.xp);
  if(L>prevLevel){toast('Новый уровень: '+L,'gold');const nt=C.tierForLevel(L);if(nt>C.tierForLevel(prevLevel))toast('Открыт тир '+nt+': «'+C.tierName(nt)+'»','gold');prevLevel=L;}
  render();
}
function showEvents(evs){(evs||[]).forEach(e=>toast(e.text,e.kind==='craftbad'?'bad':'ok'));}
function finishResult(r,keep){
  if(!r)return;
  if(r.err){toast(r.err,'bad');render();return;}
  if(r.msg)toast(r.msg,r.kind||'ok');
  if(r.res)lastEvent=r.res;
  if(!keep)closeSheet();
  afterAction();
}
function netError(e){toast(e&&e.status===429?'Слишком часто, подождите секунду':'Нет связи с сервером','bad');}
async function act(op,args,keep){
  if(inflight)return;
  inflight=true;
  try{
    const j=MODE==='local'?Local.act(op,args||[]):await api('/api/act',{op,args:args||[]});
    applyResp(j);showEvents(j.events);
    (j.ach||[]).forEach(a=>toast('Достижение: '+a.name+', +'+a.reward+' ◆','gold'));
    finishResult(j.result,keep);
  }catch(e){netError(e);}
  finally{inflight=false;}
}
async function devCall(op,a){
  if(inflight)return;
  inflight=true;
  try{
    const j=MODE==='local'?Local.dev(op,a||{}):await api('/api/dev',{op,args:a||{}});
    applyResp(j);showEvents(j.events);
    return j.result;
  }catch(e){netError(e);}
  finally{inflight=false;}
}
async function doSync(force){
  const now=realNow();
  if(inflight||(!force&&now-lastSyncAt<1500))return;
  lastSyncAt=now;inflight=true;
  try{
    const j=await api('/api/sync',{});
    applyResp(j);showEvents(j.events);
    const L=C.levelOf(S.xp);if(L>prevLevel)prevLevel=L;
    render();
  }catch(e){if(e&&e.status===401)fatal('Сессия недействительна. Закройте игру и откройте её заново из VK.');}
  finally{inflight=false;}
}
const A={
  tab(d){tab=d.a;closeSheet();render();window.scrollTo(0,0);},
  tipsoff(){act('tipsOff',[],true);},
  scan(){act('doScan');},
  fight(){act('doFight',[!!useAmmo]);},
  upg(d){act('buyUpg',[d.a]);},
  unequip(d){act('unequip',[+d.a]);},
  cap(d){capSheet(d.a);},
  pickbuild(d){buildSheet(+d.a);},
  dobuild(d){act('build',[+d.a,d.b]);},
  upbld(d){act('upBld',[+d.a]);},
  tier(d){mapT=(+d.a-1)*3;render();},
  mcoil(d){mapT=clamp(mapT+(+d.a),0,maxCoil()+3);render();},
  msel(d){mapS=+d.a;render();},
  go(d){act('travel',[+d.a,+d.b]);},
  unlock(d){act('unlock',[+d.a,+d.b]);},
  cseg(d){cargoSeg=d.a;render();},
  isort(d){act('sortInv',[d.a],true);},
  inv(d){itemSheet(+d.a);},
  equip(d){act('equip',[+d.a]);},
  useitem(d){act('useItem',[+d.a]);},
  discard(d){act('discard',[+d.a]);},
  lotform(d){lotSheet(+d.a);},
  dolot(){
    if(!lotDraft)return;
    if(!(lotDraft.n>=1)){toast('Укажите количество','bad');return;}
    if(!(lotDraft.p>=1)){toast('Минимальная цена: 1 кредит','bad');return;}
    act('listLot',[lotDraft.i,lotDraft.n,lotDraft.p]);
  },
  botsell(d){act('sellBot',[d.a,Math.max(1,C.countKey(S,d.b))]);},
  craft(d){act('craftStart',[d.a],true);},
  cclaim(){act('craftClaim',[],true);},
  mseg(d){mktSeg=d.a;render();},
  mcat(d){mktCat=d.a;render();},
  buylot(d){act('buyLot',[d.a],true);},
  cancellot(d){act('cancelLot',[d.a],true);},
  tk(d){topKind=d.a;render();},
  vip(d){act('buyVip',[+d.a],true);},
  topupwin(){topupSheet();},
  buypack(d){buyPack(d.a);},
  promo(){act('redeem',[String(($('#promo')||{}).value||'')],true);},
  joinguild(d){act('joinGuild',[d.a],true);},
  leaveguild(){act('leaveGuild',[],true);},
  cmd(){runCmd((($('#cmd')||{}).value||'').trim());},
  dv(d){devAction(d.a);},
  resetask(){openSheet('<div class="sh-t">Сбросить аккаунт?</div><div class="sub" style="margin:8px 0 14px">Весь прогресс будет удалён без возможности восстановления.</div><div class="btns"><button class="btn n" data-act="close">Отмена</button><button class="btn r" data-act="doreset">Сбросить</button></div>');},
  async doreset(){const r=await devCall('reset',{});if(!r)return;if(r.err){toast(r.err,'bad');return;}lastEvent=null;prevLevel=1;tab='home';mapT=S.loc.t;mapS=S.loc.s;closeSheet();toast(r.msg,'ok');render();},
  close(){closeSheet();}
};
function runCmd(c){
  if(!c)return;
  const w=c.split(/\s+/)[0].toLowerCase();
  if(w==='/devpanel'){if(S.is_dev){tab='dev';loadDev();render();window.scrollTo(0,0);}else toast('Нет доступа','bad');}
  else if(w==='/help')toast('Команды: /devpanel, /help','ok');
  else toast('Неизвестная команда. Введите /help','bad');
}
async function devAction(op){
  const v=id=>($('#'+id)||{}).value;
  let a={};
  if(op==='give')a={k:v('dv-k'),n:v('dv-n')};
  if(op==='tp')a={t:v('dv-t'),s:v('dv-s')};
  if(op==='setb')a={i:v('dv-i'),type:v('dv-bt'),level:v('dv-bl')};
  if(op==='bal')a={credits:v('dv-cr'),premium:v('dv-pr'),xp:v('dv-xp'),vipDays:v('dv-vd'),vipLevel:v('dv-vl')};
  if(op==='sim')a={n:v('dv-sim')};
  if(op==='bot')a={k:v('dv-bk'),p:v('dv-bp'),n:v('dv-bn')};
  const r=await devCall(op,a);
  if(!r)return;
  if(r.err){toast(r.err,'bad');return;}
  if(r.msg)toast(r.msg,'ok');
  afterAction();
}
const I={
  ammo(el){useAmmo=el.checked;render();},
  lotn(el){if(lotDraft){lotDraft.n=Math.max(0,Math.floor(+el.value||0));lotPreview();}},
  lotp(el){if(lotDraft){lotDraft.p=Math.max(0,Math.floor(+el.value||0));lotPreview();}}
};
document.addEventListener('click',e=>{
  const el=e.target.closest?e.target.closest('[data-act]'):null;
  if(!el||el.disabled)return;
  const f=A[el.dataset.act];if(f){e.preventDefault();f(el.dataset,el);}
});
function onInp(e){const k=e.target&&e.target.dataset&&e.target.dataset.inp;if(k&&I[k])I[k](e.target);}
document.addEventListener('input',onInp);document.addEventListener('change',onInp);
/* демо-режим: 7 нажатий на имя переключают флаг is_dev (в продакшене выдаёт сервер) */
document.addEventListener('click',e=>{
  if(MODE!=='local'||!e.target||e.target.id!=='secret')return;
  const n=Date.now();tapCount=(n-tapTs<1500)?tapCount+1:1;tapTs=n;
  if(tapCount>=7){tapCount=0;S.is_dev=!S.is_dev;toast(S.is_dev?'Демо: флаг is_dev включён, команда /devpanel':'Демо: флаг is_dev выключен','gold');C.save(S);render();}
});
document.addEventListener('keydown',e=>{if(e.key==='Enter'&&e.target&&e.target.id==='cmd')runCmd(e.target.value.trim());if(e.key==='Enter'&&e.target&&e.target.id==='promo')A.promo();});

/* ---------- живое обновление ---------- */
function tickUI(now){
  const hc=$('#hc'),hp=$('#hp');if(hc)hc.innerHTML=money('₵ '+fmt(S.credits));if(hp)hp.innerHTML=money('◆ '+S.premium)+'<span class="pl">'+ic('i-plus')+'</span>';
  const p=clamp((now-S.lastTick)/C.TICK_MS,0,1);
  const tb=document.querySelector('[data-tickbar]');if(tb)tb.style.width=(p*100)+'%';
  const rt=document.querySelector('[data-ringtxt]');if(rt)rt.textContent=Math.max(0,Math.ceil(60-p*60));
  let stale=false;
  document.querySelectorAll('[data-cd]').forEach(el=>{const rem=+el.dataset.cd-now;if(rem<=0)stale=true;else el.textContent=C.dur(rem);});
  document.querySelectorAll('[data-cdbar]').forEach(el=>{const a=el.dataset.cdbar.split(',');el.style.width=(100-clamp((now-a[0])/(a[1]-a[0]),0,1)*100)+'%';});
  const tv=document.querySelector('[data-trav]');
  if(tv){const a=tv.dataset.trav.split(',');tv.style.width=(clamp((now-a[0])/(a[1]-a[0]),0,1)*100)+'%';}
  return stale;
}
let lastLoop=realNow(),saveAt=0;
function loop(){
  if(!S||!READY)return;
  const now=Date.now(),dt=Math.min(5000,realNow()-lastLoop);lastLoop=realNow();
  if(MODE==='local'){
    if(!document.hidden)S.stats.playSec+=dt/1000;
    const r=Local.catchUp();
    showEvents(r.ev);
    const stale=tickUI(now);
    const L=C.levelOf(S.xp);if(L>prevLevel)prevLevel=L;
    if(r.changed||stale)render();
    if(realNow()-saveAt>5000){saveAt=realNow();C.syncLots(S);C.save(S);}
    return;
  }
  const stale=tickUI(now);
  if(document.hidden)return;
  if(stale||realNow()>=nextSync)doSync(false);
}
function awaySheet(sum,away){
  const parts=[];
  if(sum.credits>0)parts.push('<div class="row"><div class="sp">Доход за время отсутствия</div><b class="gd">+'+fmt(sum.credits)+' ₵</b></div>');
  const rk=Object.keys(sum.res||{});
  if(rk.length)parts.push('<div class="chips">'+rk.map(k=>'<span class="chip">'+ic(C.info(k).icon)+' ×'+fmt(sum.res[k])+'</span>').join('')+'</div>');
  if(sum.sold>0)parts.push('<div class="row" style="margin-top:10px"><div class="sp">Продано на аукционе</div><b class="gn">+'+fmt(sum.sold)+' ₵</b></div>');
  if(sum.lost>0)parts.push('<div class="note" style="margin-top:12px">Трюм был полон: не поместилось '+fmt(sum.lost)+' ед. ресурсов.</div>');
  if(away>72*3600000)parts.push('<div class="note" style="margin-top:12px">Вас не было больше 72 часов: после этого срока доход падал до 10%.</div>');
  openSheet('<div class="sh-t">Пока вас не было</div><div class="sub" style="margin-bottom:12px">Прошло '+C.dur(away)+'</div>'+parts.join('')+'<div class="btns one"><button class="btn g" data-act="close">Продолжить</button></div>');
}

/* ---------- запуск ---------- */
function withTimeout(p,ms){return Promise.race([p,new Promise((_,rej)=>setTimeout(()=>rej(new Error('timeout')),ms))]);}
function fatal(msg){
  READY=false;
  $('#hdr').innerHTML='';
  $('#page').innerHTML='<section class="pn" style="margin-top:40px"><h3>Звёздная спираль</h3><div class="sub" style="margin-bottom:14px">'+esc(msg)+'</div><div class="btns one"><button class="btn g" onclick="location.reload()">Повторить</button></div></section>';
}
async function initUser(){
  const launch=location.search;
  HAS_LAUNCH=/[?&]vk_user_id=/.test(launch)&&/[?&]sign=/.test(launch);
  const u={uid:'demo',name:'Капитан',photo:'',vk:false};
  if(window.vkBridge){
    VK=window.vkBridge;
    try{
      await withTimeout(VK.send('VKWebAppInit'),2500);
      try{VK.send('VKWebAppSetViewSettings',{status_bar_style:'light',action_bar_color:'#0b0d17',navigation_bar_color:'#0f1224'}).catch(()=>{});}catch(e){}
      try{VK.subscribe(ev=>{const d=ev&&ev.detail;if(d&&d.type==='VKWebAppUpdateConfig'&&d.data&&d.data.insets){const i=d.data.insets,r=document.documentElement.style;r.setProperty('--vk-top',(i.top||0)+'px');r.setProperty('--vk-bottom',(i.bottom||0)+'px');}});}catch(e){}
      const i=await withTimeout(VK.send('VKWebAppGetUserInfo'),2500);
      u.name=((i.first_name||'')+' '+(i.last_name||'')).trim()||u.name;u.photo=i.photo_100||'';u.vk=true;
      const m=/[?&]vk_user_id=(\d+)/.exec(launch);if(m){u.uid='vk'+m[1];u.id=+m[1];}
    }catch(e){}
  }
  return u;
}
async function connect(user){
  API=String(window.STELLAR_API||'').replace(/\/$/,'');
  let ping=null;
  if(/^https?:$/.test(location.protocol))try{
    const ctl=new AbortController(),to=setTimeout(()=>ctl.abort(),2500);
    const r=await fetch(API+'/api/ping',{signal:ctl.signal});clearTimeout(to);
    if(r.ok){const j=await r.json();if(j&&j.game==='stellar-spiral')ping=j;}
  }catch(e){}
  if(ping){
    MODE='server';
    if(HAS_LAUNCH)AUTH='VK '+location.search.replace(/^\?/,'');
    else if(ping.demo){let id=null;try{id=localStorage.getItem('stellar_demo_id');}catch(e){}if(!id){id='d'+Math.random().toString(36).slice(2,12);try{localStorage.setItem('stellar_demo_id',id);}catch(e){}}AUTH='Demo '+id;}
    else{fatal('Откройте игру из приложения VK.');return false;}
    try{
      LOGIN_INFO={name:user.name,photo:user.photo};
      const j=await api('/api/login',LOGIN_INFO);
      CFG=j.cfg||CFG;DEMO=!!ping.demo&&!HAS_LAUNCH;
      applyResp(j);
      prevLevel=C.levelOf(S.xp);mapT=S.loc.t;mapS=S.loc.s;
      READY=true;render();
      if(j.away>120000&&(j.sum.credits>0||Object.keys(j.sum.res||{}).length||j.sum.sold>0))awaySheet(j.sum,j.away);
      showEvents(j.events);
      return true;
    }catch(e){fatal(e&&e.status===401?(/expired/.test(e.message)?'Ссылка запуска устарела. Закройте игру и откройте её заново из VK.':'Не удалось проверить подпись VK. Откройте игру заново из VK.'):e&&e.status===429?'Слишком много попыток входа. Подождите минуту.':'Сервер недоступен. Попробуйте позже.');return false;}
  }
  if(HAS_LAUNCH){fatal('Нет связи с сервером игры. Попробуйте позже.');return false;}
  MODE='local';DEMO=true;
  S=Local.init(user);
  const now=Date.now(),away=now-S.lastSeen;
  prevLevel=C.levelOf(S.xp);mapT=S.loc.t;mapS=S.loc.s;
  const r=Local.catchUp();
  READY=true;render();
  if(away>120000&&(r.credits>0||Object.keys(r.res).length||r.sold>0))awaySheet(r,away);
  C.syncLots(S);C.save(S);
  return true;
}
async function boot(){
  $('#tabin').innerHTML=TABS.map(t=>'<button class="tab" data-act="tab" data-a="'+t[0]+'">'+ic(t[2])+'<span>'+t[1]+'</span></button>').join('');
  const user=await initUser();
  const ok=await connect(user);
  if(!ok)return;
  lastLoop=realNow();
  setInterval(loop,1000);
  document.addEventListener('visibilitychange',()=>{if(!S||!READY)return;if(!document.hidden){if(MODE==='server')doSync(true);else loop();}else if(MODE==='local'){C.syncLots(S);C.save(S);}});
  window.addEventListener('pagehide',()=>{if(S&&READY&&MODE==='local'){C.syncLots(S);C.save(S);}});
}
boot();
})();
