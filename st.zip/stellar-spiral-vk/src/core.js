
/* =====================================================================
   ЯДРО ИГРЫ. Вся логика без DOM. В продакшене этот слой переносится на
   сервер (cron: минутный тик, 5-минутный цикл рынка, часовой цикл).
   Клиент должен слать только команды и получать состояние.
   ===================================================================== */
const Core=(function(){
'use strict';
const TICK_MS=60000,WORLD_MS=300000,AFK_MIN=4320,STACK_MAX=9999,SECTORS=12,MOD_SLOTS=3,SAVE_PREFIX='stellar_spiral_v2:';
const clamp=(x,a,b)=>Math.max(a,Math.min(b,x));
const rnd=(a,b)=>a+Math.random()*(b-a);
const ri=(a,b)=>Math.floor(rnd(a,b+1));
const pick=a=>a[Math.floor(Math.random()*a.length)];
/* Мир: рынок, цены, капитаны-боты, почта. Общий для всех игроков (на сервере один на всех). */
let W=null;
function setWorld(w){W=w;}
function getWorld(){return W;}

/* ---------- форматирование ---------- */
function fmt(n){
  if(n===Infinity) return '∞';
  if(!isFinite(n)) return '—';
  const a=Math.abs(n);
  if(a>=1e18) return n.toExponential(2).replace('.',',').replace('e+','e');
  if(a<1000) return String(Math.round(n*10)/10).replace('.',',');
  const U=[[1e15,'квдр'],[1e12,'трлн'],[1e9,'млрд'],[1e6,'млн'],[1e3,'тыс']];
  for(const [v,u] of U){ if(a>=v){ const x=n/v; let s=Math.abs(x)>=100?x.toFixed(0):Math.abs(x)>=10?x.toFixed(1):x.toFixed(2); if(s.indexOf('.')>=0) s=s.replace(/\.?0+$/,''); return s.replace('.',',')+' '+u; } }
  return String(Math.round(n));
}
function dur(ms){
  const s=Math.max(0,Math.ceil(ms/1000));
  if(s<60) return s+' с';
  if(s<3600) return Math.floor(s/60)+' м '+(s%60)+' с';
  if(s<86400) return Math.floor(s/3600)+' ч '+Math.floor(s%3600/60)+' м';
  return Math.floor(s/86400)+' д '+Math.floor(s%86400/3600)+' ч';
}

/* ---------- справочники ---------- */
const RARITY=['','Обычный','Необычный','Редкий','Эпический','Мифический','Легендарный','Реликтовый','Космический','Запредельный','Первозданный'];
const RAR_COL=['','#9997bd','#6fdc9a','#6ab6ff','#a184ff','#ff8fd0','#ffb14a','#ff6b57','#4fe3c1','#ffe27a','#ffffff'];
const rarMult=q=>Math.pow(1.7,q-1);
const RES={ore:{name:'Руда',base:3,icon:'i-ore'},food:{name:'Провизия',base:2,icon:'i-food'},comp:{name:'Компоненты',base:8,icon:'i-gear'},art:{name:'Артефакты',base:30,icon:'i-prism'}};
const BUILD={
  mine:{name:'Рудник',B:100,res:'ore',phi:.08,icon:'b-mine',desc:'Добывает базовый ресурс'},
  farm:{name:'Ферма',B:80,res:'food',phi:.08,icon:'b-farm',desc:'Кормит экипаж, даёт пассивный доход'},
  factory:{name:'Фабрика',B:250,res:'comp',phi:.10,icon:'b-factory',desc:'Перерабатывает ресурсы в компоненты'},
  lab:{name:'Лаборатория',B:400,res:'art',phi:.12,icon:'b-lab',desc:'Редкие материалы. Ускоряет крафт и повышает шанс успеха'},
  trade:{name:'Торговая станция',B:600,res:null,icon:'b-trade',desc:'Чистый доход, дорогая'},
  beacon:{name:'Маяк',B:1000,res:null,icon:'b-beacon',desc:'Открывает новые витки спирали. Самый дорогой'}
};
function Uk(L,E){return 1+(1-1/(1+0.05*L))*E;}
const UPG={
  engines:{name:'Двигатели',icon:'u-engine',base:10000,eff:L=>'скорость ×'+Math.pow(1.05,L).toFixed(2)},
  shields:{name:'Щиты',icon:'u-shield',base:8000,eff:L=>'прочность '+fmt(500+1000*L)},
  weapons:{name:'Оружие',icon:'u-gun',base:15000,eff:L=>'урон '+fmt(60+500*L)},
  hold:{name:'Трюм',icon:'u-hold',base:20000,eff:L=>(30+5*L)+' слотов'},
  scanner:{name:'Сканер',icon:'u-radar',base:12000,eff:L=>'шанс находки '+Math.round(Math.min(.95,.35+.02*L)*100)+'%'},
  reactor:{name:'Реактор',icon:'u-reactor',base:50000,eff:L=>'доход ×'+Uk(L,10).toFixed(2)}
};
const MOD={income:{name:'Модуль реактора',icon:'m-income',unit:'к доходу',per:.012},dmg:{name:'Модуль орудий',icon:'m-dmg',unit:'к урону',per:.03},hp:{name:'Модуль щита',icon:'m-hp',unit:'к прочности',per:.03}};
/* ---------- тиры: 3 витка на тир, вход по уровню капитана ---------- */
const TIER_REQ=[0,1,10,20,30,45,60,80,100];
const tierOf=t=>Math.floor(t/3)+1;
const tierReq=k=>k<TIER_REQ.length?TIER_REQ[k]:100+25*(k-8);
const TIER_NAMES=['','Окраина','Пояс','Рубеж','Ядро','Бездна','Предел','Горизонт','Сингулярность'];
const tierName=k=>TIER_NAMES[k]||('Сектор '+k);
const TIER_COL=['','#3ddc84','#3fa9ff','#9b6dff','#ff8fd0','#ffb14a','#ff5a6a','#4fe3c1','#ffe27a'];
const tierCol=k=>TIER_COL[k]||TIER_COL[((k-1)%8)+1];
const tierRew=k=>1+.35*(k-1);
function tierForLevel(L){let k=1;while(tierReq(k+1)<=L)k++;return k;}
const Loc={M:t=>1+.15*t,E:t=>10*Math.pow(1.2,t),R:t=>tierReq(tierOf(t)),C:t=>50000*Math.pow(3,t),Q:t=>clamp(t,1,10),Sb:t=>3+t,P:t=>1+.1*t};
const STARS=['Гелиос','Вега','Лира','Ксенон','Аврора','Тайга','Орион','Кассиопея','Сириус','Альтаир','Тавр','Персей','Лебедь','Арго','Феникс','Кит','Дракон','Гидра','Пегас','Ригель','Мира','Капелла','Денеб','Антарес','Поллукс','Процион','Мицар','Альдебаран'];
const LTYPES=[
  {id:'belt',name:'Пояс астероидов',pre:'Пояс',bias:'ore',icon:'i-ore'},
  {id:'planet',name:'Аграрная планета',pre:'Планета',bias:'food',icon:'t-planet'},
  {id:'wreck',name:'Кладбище кораблей',pre:'Кладбище',bias:'comp',icon:'t-wreck'},
  {id:'anomaly',name:'Аномалия',pre:'Аномалия',bias:'art',icon:'t-anomaly'},
  {id:'station',name:'Торговая станция',pre:'Станция',bias:null,icon:'b-trade'},
  {id:'nebula',name:'Туманность',pre:'Туманность',bias:null,icon:'t-nebula'}
];
function hash(a,b){let h=(Math.imul(a+7,73856093)^Math.imul(b+13,19349663))>>>0;h=Math.imul(h^(h>>>15),2246822519)>>>0;h=Math.imul(h^(h>>>13),3266489917)>>>0;return (h^(h>>>16))>>>0;}
function locInfo(t,s){
  const h=hash(t,s),type=LTYPES[h%LTYPES.length],nm=STARS[(h>>>5)%STARS.length];
  return {t,s,tier:tierOf(t),type,bias:type.bias,name:type.pre+' '+nm+'-'+(t*12+s)};
}
const VIP={
  mult:[[1,1.10],[2,1.25],[3,1.5],[5,2],[8,3],[10,5]],
  disc:[[1,5],[2,10],[3,15],[5,25],[8,40],[10,50]],
  slots:[[1,5],[2,10],[3,20],[5,40],[8,80],[10,220]],
  col:['#ecebf7','#a3a7b8','#6fdc9a','#6ab6ff','#6ab6ff','#a184ff','#a184ff','#a184ff','#ff6b57','#ff6b57','#ffc857'],
  names:['','Серый','Зелёный','Синий','Синий','Фиолетовый','Фиолетовый','Фиолетовый','Красный','Красный','Золотой'],
  price:N=>50*N
};
function interp(pts,x){
  if(x<=pts[0][0]) return pts[0][1];
  for(let i=1;i<pts.length;i++){ if(x<=pts[i][0]){ const a=pts[i-1],b=pts[i]; return a[1]+(b[1]-a[1])*(x-a[0])/(b[0]-a[0]); } }
  return pts[pts.length-1][1];
}
const RECIPES=[
  {id:'ammo',name:'Патроны ×20',icon:'i-ammo',out:{k:'ammo',n:20},q:1,tb:15,inp:[['ore',6],['comp',2]]},
  {id:'fuel',name:'Топливные ячейки ×2',icon:'i-fuel',out:{k:'fuel',n:2},q:2,tb:25,inp:[['food',4],['comp',3]]}
];
['income','dmg','hp'].forEach(kind=>[2,4,6,8].forEach(q=>RECIPES.push({id:'mod_'+kind+'_'+q,name:MOD[kind].name+' Mk-'+q,icon:MOD[kind].icon,out:{mod:kind,q},q,tb:45*q,inp:[['art',5*q],['comp',8*q]]})));
const PROMOS={
  STELLAR2026:{type:'multi',reward:{credits:100000,item:'crystal_rare',qty:5,vip_days:7},uses_total:10000,uses_per_user:1,expires:'2026-12-31',min_level:5,max_level:null},
  WELCOME:{type:'multi',reward:{credits:20000,premium:25},uses_total:100000,uses_per_user:1,expires:'2027-06-30',min_level:1,max_level:null},
  FIRST1:{type:'single',reward:{credits:75000,premium:50},uses_total:1,uses_per_user:1,expires:'2027-01-31',min_level:1,max_level:null}
};
const GUILDS=[{id:'g1',name:'Орден Спирали',members:48},{id:'g2',name:'Пыль звёзд',members:131},{id:'g3',name:'Ржавые орлы',members:27}];
const ACH=[
  {id:'build1',name:'Первый камень',desc:'Постройте первое здание',test:S=>S.stats.built>=1,reward:5},
  {id:'win1',name:'Крещение огнём',desc:'Выиграйте бой',test:S=>S.stats.won>=1,reward:5},
  {id:'win50',name:'Ас пространства',desc:'50 побед в бою',test:S=>S.stats.won>=50,reward:20},
  {id:'mil',name:'Миллионер',desc:'1 млн кредитов на счёте',test:S=>S.credits>=1e6,reward:15},
  {id:'cart',name:'Картограф',desc:'Откройте 5 локаций',test:S=>S.stats.unlockedN>=5,reward:20},
  {id:'craft5',name:'Сборщик',desc:'Успешно создайте 5 предметов',test:S=>S.stats.crafts>=5,reward:15},
  {id:'sell10',name:'Торговец',desc:'Совершите 10 продаж',test:S=>S.stats.sold>=10,reward:10},
  {id:'lvl10',name:'Опытный капитан',desc:'Достигните 10 уровня',test:S=>levelOf(S.xp)>=10,reward:25},
  {id:'time1',name:'Живая душа',desc:'Час в игре',test:S=>S.stats.playSec>=3600,reward:10}
];

/* ---------- уровни ---------- */
const levelOf=xp=>Math.floor(Math.sqrt(Math.max(0,xp)/50))+1;
const xpFor=L=>50*(L-1)*(L-1);

/* ---------- предметы ---------- */
function roman(n){return n;}
function info(k,u){
  if(k==='mod'&&u) return {name:u.name,icon:MOD[u.kind].icon,cat:'mod',q:u.q,base:u.price,desc:'+'+(u.bonus*100).toFixed(1).replace('.',',')+'% '+MOD[u.kind].unit};
  if(k==='starter_laser') return {name:'Стартовый лазер',icon:'u-gun',cat:'misc',q:1,base:0,stop:true,desc:'Стартовый предмет. Продавать нельзя.'};
  if(k.indexOf(':')>0){ const p=k.split(':'),q=+p[1],r=RES[p[0]]; return {name:r.name,icon:r.icon,cat:'res',q,base:r.base*rarMult(q),desc:'Ресурс. Редкость: '+RARITY[q]}; }
  if(k==='ammo') return {name:'Патроны',icon:'i-ammo',cat:'cons',q:1,base:2.5,desc:'В бою: +25% урона, расходуется 5 шт.'};
  if(k==='fuel') return {name:'Топливная ячейка',icon:'i-fuel',cat:'cons',q:2,base:150,desc:'Следующий перелёт вдвое быстрее.'};
  if(k==='crystal_rare') return {name:'Редкий кристалл',icon:'i-crystal',cat:'misc',q:5,base:500,desc:'Ценный трофей. Хорошо продаётся.'};
  if(k==='debris') return {name:'Обломки',icon:'i-debris',cat:'misc',q:1,base:12,desc:'Трофей боя.'};
  return {name:k,icon:'i-debris',cat:'misc',q:1,base:1,desc:''};
}
const CAT_NAME={res:'Ресурсы',cons:'Расходники',mod:'Модули',misc:'Прочее'};
const KEYS=[];
Object.keys(RES).forEach(r=>{for(let q=1;q<=10;q++)KEYS.push(r+':'+q);});
KEYS.push('ammo','fuel','crystal_rare','debris');

function cap(S){return 30+5*S.upg.hold;}
function makeModule(kind,q){
  const per=MOD[kind].per*q,f=rnd(.8,1.2),bonus=+(per*f).toFixed(3);
  return {kind,q,bonus,name:MOD[kind].name+' Mk-'+q,price:Math.round(250*q*q*f),id:'m'+Date.now().toString(36)+Math.floor(Math.random()*1e6).toString(36)};
}
function roomFor(S,k,n,u){
  if(u) return S.inv.length<cap(S);
  let space=(cap(S)-S.inv.length)*STACK_MAX;
  for(const st of S.inv) if(st.k===k&&!st.u) space+=STACK_MAX-st.n;
  return space>=n;
}
function addItem(S,k,n,u){
  if(n<=0) return 0;
  if(u){ if(S.inv.length>=cap(S)) return n; S.inv.push({k,n:1,t:Date.now(),u}); return 0; }
  let left=n;
  for(const st of S.inv){ if(left<=0)break; if(st.k===k&&!st.u&&st.n<STACK_MAX){ const a=Math.min(STACK_MAX-st.n,left); st.n+=a; left-=a; } }
  while(left>0&&S.inv.length<cap(S)){ const a=Math.min(STACK_MAX,left); S.inv.push({k,n:a,t:Date.now()}); left-=a; }
  return left;
}
function countKey(S,k){let c=0;for(const s of S.inv)if(s.k===k&&!s.u)c+=s.n;return c;}
function takeKey(S,k,n){
  let left=n;
  for(let i=S.inv.length-1;i>=0&&left>0;i--){ const s=S.inv[i]; if(s.k!==k||s.u)continue; const a=Math.min(s.n,left); s.n-=a; left-=a; if(s.n<=0)S.inv.splice(i,1); }
  return n-left;
}
function countRes(S,type){let c=0;for(const s of S.inv)if(!s.u&&s.k.indexOf(type+':')===0)c+=s.n;return c;}
function takeRes(S,type,n){
  const used=[]; let left=n;
  const st=S.inv.filter(s=>!s.u&&s.k.indexOf(type+':')===0).sort((a,b)=>+a.k.split(':')[1]-+b.k.split(':')[1]);
  for(const s of st){ if(left<=0)break; const a=Math.min(s.n,left); s.n-=a; left-=a; used.push({k:s.k,n:a}); }
  S.inv=S.inv.filter(s=>s.n>0);
  return used;
}
function sortInv(S){
  const co={res:0,cons:1,mod:2,misc:3};
  const key=S.invSort;
  S.inv.sort((a,b)=>{
    const A=info(a.k,a.u),B=info(b.k,b.u);
    if(key==='rar') return B.q-A.q||A.name.localeCompare(B.name);
    if(key==='price') return (B.base*b.n)-(A.base*a.n);
    if(key==='time') return b.t-a.t;
    return co[A.cat]-co[B.cat]||A.name.localeCompare(B.name)||B.q-A.q;
  });
}

/* ---------- рынок ---------- */
const baseOf=k=>info(k).base;
function avgPrice(S,k,u){
  if(u) return u.price;
  const d=W.deals[k];
  if(d&&d.length) return d.reduce((a,b)=>a+b,0)/d.length;
  return baseOf(k)*(W.mkt[k]||1);
}
function marketInit(w){
  KEYS.forEach(k=>{w.mkt[k]=1;w.deals[k]=[];for(let i=0;i<6;i++)w.deals[k].push(baseOf(k)*rnd(.95,1.05));});
}
const NPC_SELLERS=['Орион-7','Кассиопея','ВегаТрейд','Пыльный Ганс','Мару Стерн','Ксенон','Дальний рейс','Лира Нова','Барон Фью','Астра'];
function genLot(w,tm){
  const r=Math.random(); let k,n,u=null;
  if(r<.72){ const type=pick(Object.keys(RES)); const q=Math.random()<.1?ri(6,10):ri(1,5); k=type+':'+q; n=ri(5,Math.max(8,Math.round(220/Math.sqrt(q)))); }
  else if(r<.84){ k=Math.random()<.6?'ammo':'fuel'; n=k==='ammo'?ri(20,120):ri(1,5); }
  else if(r<.92){ k=Math.random()<.7?'debris':'crystal_rare'; n=ri(1,10); }
  else { u=makeModule(pick(['income','dmg','hp']),pick([2,4,6,8])); k='mod'; n=1; }
  const avg=avgPrice(null,k,u);
  return {id:'l'+(w.nextId++),owner:null,seller:pick(NPC_SELLERS),k,n,p:Math.max(1,Math.round(avg*rnd(.85,1.4))),u,exp:tm+ri(4,24)*3600000,status:'active',tax:0};
}
function marketStep(w){
  for(const k of KEYS){
    let m=(w.mkt[k]==null?1:w.mkt[k]); m+=(1-m)*.06+(Math.random()-.5)*.05; m=clamp(m,.55,1.9); w.mkt[k]=m;
    const d=w.deals[k]||(w.deals[k]=[]); const p=baseOf(k)*m*rnd(.96,1.04); d.push(p); if(d.length>100)d.shift(); w.vol+=p*ri(1,20);
  }
}
function vipActive(S,now){return S.vipLevel>0&&S.vipUntil>(now||Date.now());}
function vipLvl(S,now){return vipActive(S,now)?S.vipLevel:0;}
function vipMult(S,now){const L=vipLvl(S,now);return L?interp(VIP.mult,L):1;}
function vipDisc(S,now){const L=vipLvl(S,now);return L?interp(VIP.disc,L):0;}
function aucSlots(S,now){const L=vipLvl(S,now);return L?(L>=10?Infinity:Math.round(interp(VIP.slots,L))):3;}
function taxPct(S,now){return Math.max(2,5-vipDisc(S,now));}

/* ---------- боты-скупщики ---------- */
function newBot(S,t,now){
  const q=Loc.Q(t),type=pick(Object.keys(RES)),k=type+':'+Math.max(1,q-ri(0,1)),mx=Math.round(100*Math.pow(1.1,t));
  return {id:'b'+(W.nextId++),k,p:Math.max(.1,Math.round(.7*avgPrice(S,k)*10)/10),max:mx,remain:mx,next:now+ri(5,30)*60000};
}
function ensureBots(S,t,s){
  const key=t+':'+s;
  if(!S.bots[key]){S.bots[key]=[];for(let i=0;i<3;i++)S.bots[key].push(newBot(S,t,Date.now()));}
  return S.bots[key];
}
function refreshBots(S,now){
  let ch=false;
  for(const key in S.bots){
    const t=+key.split(':')[0],arr=S.bots[key];
    for(let i=0;i<arr.length;i++){
      const b=arr[i];
      if(b.dev){ if(b.remain<=0){arr.splice(i,1);i--;ch=true;} continue; }
      if(now>=b.next){
        if(Math.random()<.5){ b.p=Math.max(.1,Math.round(.7*avgPrice(S,b.k)*10)/10); b.remain=b.max=Math.round(100*Math.pow(1.1,t)); b.next=now+ri(5,30)*60000; }
        else arr[i]=newBot(S,t,now);
        ch=true;
      }
    }
  }
  return ch;
}

/* ---------- NPC-игроки и рейтинг ---------- */
const NA=['Ржавый','Тихий','Дальний','Яростный','Белый','Чёрный','Быстрый','Старый','Одинокий','Рыжий','Лихой','Ночной'];
const NB=['Ястреб','Волк','Комета','Пилот','Странник','Орёл','Скиталец','Шершень','Барон','Лис','Стрелок','Кочевник'];
function npcPlace(n){
  const L=levelOf(npcXp(n)),mt=tierForLevel(L),tier=Math.random()<.6?mt:ri(1,mt);
  return {t:(tier-1)*3+ri(0,2),s:ri(1,SECTORS)};
}
function genNpcs(withStaff){
  const names=[];NA.forEach(a=>NB.forEach(b=>names.push(a+' '+b)));
  for(let i=names.length-1;i>0;i--){const j=ri(0,i);const x=names[i];names[i]=names[j];names[j]=x;}
  const a=[];
  for(let i=0;i<64;i++){
    const n={id:'n'+i,name:names[i],bal:Math.pow(10,rnd(3.2,10.6)),k:rnd(.6,1.4),xk:rnd(.5,1.5),vip:Math.random()<.6?ri(1,10):0,is_dev:false,is_admin:false,guild:Math.random()<.5?pick(GUILDS).name:null};
    n.loc=npcPlace(n);a.push(n);
  }
  if(withStaff===false)return a;
  a.push({id:'d1',name:'DevMaster',bal:8.8e15,k:1,xk:2,vip:10,is_dev:true,is_admin:false,guild:null,loc:null});
  a.push({id:'d2',name:'Dev_Test',bal:3.1e14,k:1,xk:2,vip:10,is_dev:true,is_admin:false,guild:null,loc:null});
  a.push({id:'a1',name:'Админ Спирали',bal:5.4e14,k:1,xk:2,vip:10,is_dev:false,is_admin:true,guild:null,loc:null});
  a.push({id:'a2',name:'Admin_Vega',bal:1.2e13,k:1,xk:2,vip:9,is_dev:false,is_admin:true,guild:null,loc:null});
  return a;
}
const npcInc=n=>.022*Math.pow(n.bal,.75)*n.k;
const npcXp=n=>Math.pow(n.bal,.62)*n.xk;
const capView=n=>({id:n.id,name:n.name,lvl:levelOf(npcXp(n)),vip:n.vip,guild:n.guild,loc:n.loc,bal:n.bal});
/* Капитаны в секторе. Служебные аккаунты (dev/admin) нигде не показываются */
function crewAt(S,t,s){return W.npcs.filter(n=>!n.is_dev&&!n.is_admin&&n.loc&&n.loc.t===t&&n.loc.s===s).map(capView);}
function crewCounts(S,t){const c={};for(const n of W.npcs){if(n.is_dev||n.is_admin||!n.loc||n.loc.t!==t)continue;c[n.loc.s]=(c[n.loc.s]||0)+1;}return c;}
function allPlayers(S,now){
  const list=W.npcs.map(n=>({id:n.id,name:n.name,bal:n.bal,xp:npcXp(n),inc:npcInc(n),vip:n.vip,is_dev:n.is_dev,is_admin:n.is_admin}));
  list.push({id:'me',me:true,name:S.name,bal:S.credits,xp:S.xp,inc:income(S,now),vip:vipLvl(S,now),is_dev:S.is_dev,is_admin:S.is_admin});
  return list;
}
/* Публичный рейтинг: аккаунты со статусом разработчика и администратора скрыты */
function top(S,kind,n,now){
  const all=allPlayers(S,now).filter(p=>!p.is_dev&&!p.is_admin);
  all.sort((a,b)=>b[kind]-a[kind]);
  const idx=all.findIndex(p=>p.me);
  return {rows:all.slice(0,n||20),myRank:idx<0?null:idx+1,total:all.length,hidden:S.is_dev||S.is_admin};
}
function fullTop(S,kind,n,now){ return allPlayers(S,now).sort((a,b)=>b[kind]-a[kind]).slice(0,n||10); }

/* ---------- состояние ---------- */
function newGame(user){
  const now=Date.now(),s0=ri(1,SECTORS),k0='0:'+s0;
  const S={v:2,uid:user.uid||'demo',name:user.name||'Капитан',photo:user.photo||'',is_dev:!!user.is_dev,is_admin:!!user.is_admin,
    created:now,lastSeen:now,lastTick:now,lastWorld:now,lastHour:now,
    xp:0,credits:15000,premium:50,vipLevel:0,vipUntil:0,
    loc:{t:0,s:s0},unlocked:{[k0]:1},bld:{[k0]:[null,null,null]},acc:{},
    upg:{engines:0,shields:0,weapons:0,hold:0,scanner:0,reactor:0},
    inv:[],equip:[],invSort:'type',
    stats:{playSec:0,won:0,lost:0,profit:0,distance:0,crafts:0,craftFail:0,scans:0,sold:0,unlockedN:1,built:0},
    ach:{},guild:null,promoUsed:{},
    lots:[],bots:{},cd:{scan:0,fight:0},travel:null,fuel:false,craft:null,
    log:[],devLog:[],tips:true};
  S.inv.push({k:'starter_laser',n:1,t:now,u:{}});
  addItem(S,'ore:1',30);addItem(S,'food:1',20);addItem(S,'ammo',10);
  ensureBots(S,0,s0);
  return S;
}
function newWorld(now,opts){
  now=now||Date.now();
  const w={v:1,market:[],deals:{},mkt:{},npcs:[],vol:0,econ:[],nextId:1,lastWorld:now,lastHour:now,promoTotals:{},mailbox:{},extraSupply:0};
  W=w;marketInit(w);w.npcs=genNpcs(!(opts&&opts.staff===false));
  for(let i=0;i<28;i++)w.market.push(genLot(w,now));
  return w;
}
/* спавн: несколько капитанов-новичков появляются рядом с новым игроком */
function spawnCompanions(loc){
  W.npcs.filter(n=>!n.is_dev&&!n.is_admin).sort((a,b)=>a.bal-b.bal).slice(0,3).forEach(n=>{n.loc={t:loc.t,s:loc.s};});
}
function save(S){try{localStorage.setItem(SAVE_PREFIX+S.uid,JSON.stringify(S));localStorage.setItem(SAVE_PREFIX+S.uid+':world',JSON.stringify(W));}catch(e){}}
function load(uid){
  try{
    const s=localStorage.getItem(SAVE_PREFIX+uid),w=localStorage.getItem(SAVE_PREFIX+uid+':world');
    if(!s||!w)return null;
    const o=JSON.parse(s),wo=JSON.parse(w);
    if(!o||o.v!==2||!wo||wo.v!==1)return null;
    W=wo;return o;
  }catch(e){return null;}
}
function logAdd(S,text){S.log.unshift({ts:Date.now(),text});if(S.log.length>30)S.log.length=30;}

/* ---------- постройки и доход ---------- */
function slots(S,t,s){const key=t+':'+s,n=Loc.Sb(t);let a=S.bld[key];if(!a)a=S.bld[key]=[];while(a.length<n)a.push(null);return a;}
function allBuildings(S){const out=[];for(const key in S.bld){const p=key.split(':'),t=+p[0],s=+p[1];S.bld[key].forEach((b,i)=>{if(b)out.push({key,t,s,i,b});});}return out;}
const sumLevels=S=>allBuildings(S).reduce((a,x)=>a+x.b.level,0);
const bestLevel=(S,type)=>allBuildings(S).reduce((m,x)=>x.b.type===type?Math.max(m,x.b.level):m,0);
const bldIncome=(type,L,t)=>BUILD[type].B*Math.pow(L,1.5)*Loc.M(t);
function buildCost(S,type,L,t){
  const fat=1+.001*Math.pow(Math.max(0,L-100),2);
  return BUILD[type].B*(50*Math.pow(L,2.7)+5*Math.pow(sumLevels(S),1.3))*Loc.P(t)*fat;
}
const modSum=(S,kind)=>S.equip.reduce((a,m)=>m.u.kind===kind?a+m.u.bonus:a,0);
function upgMult(S){return Uk(S.upg.reactor,10)*(1+modSum(S,'income'));}
/* Income/мин = (Σ B·L^1.5·M_loc · ∏U_k) · V_vip */
function incomeParts(S,now){
  let base=0;
  for(const x of allBuildings(S)) base+=bldIncome(x.b.type,x.b.level,x.t);
  const um=upgMult(S),vm=vipMult(S,now);
  return {base,um,vm,total:base*um*vm};
}
const income=(S,now)=>incomeParts(S,now).total;
function production(S){
  const p={};
  for(const x of allBuildings(S)){
    const B=BUILD[x.b.type]; if(!B.res)continue;
    const q=Loc.Q(x.t),k=B.res+':'+q;
    const bias=locInfo(x.t,x.s).bias===B.res?1.25:1;
    p[k]=(p[k]||0)+bias*B.phi*bldIncome(x.b.type,x.b.level,x.t)/(RES[B.res].base*rarMult(q));
  }
  return p;
}
function stats(S){
  const spd=Math.pow(1.05,S.upg.engines);
  return {hp:(500+1000*S.upg.shields)*(1+modSum(S,'hp')),dmg:(60+500*S.upg.weapons)*(1+modSum(S,'dmg')),speed:spd,scan:Math.min(.95,.35+.02*S.upg.scanner),cap:cap(S),used:S.inv.length};
}
const upgCost=(S,k)=>{const n=Object.values(S.upg).reduce((a,b)=>a+b,0);return UPG[k].base*Math.pow(S.upg[k]+1,2.5)*(1+.05*n);};

function applyMinutes(S,eff,sum){
  const P=incomeParts(S),earn=P.total*eff;
  S.credits+=earn;S.stats.profit+=earn;sum.credits+=earn;
  const prod=production(S);
  for(const k in prod){
    S.acc[k]=(S.acc[k]||0)+prod[k]*eff;
    const w=Math.floor(S.acc[k]);
    if(w>0){S.acc[k]-=w;const left=addItem(S,k,w),got=w-left;if(got>0)sum.res[k]=(sum.res[k]||0)+got;if(left>0)sum.lost+=left;}
  }
}

/* ---------- мировой цикл ---------- */
const lotsOf=S=>W.market.filter(l=>l.owner===S.uid);
function syncLots(S){S.lots=lotsOf(S);return S;}
function mail(uid,credits,text){(W.mailbox[uid]||(W.mailbox[uid]=[])).push({credits,text,ts:Date.now()});}
/* Один 5-минутный шаг мира: рынок, перелёты капитанов-ботов, продажи лотов игроков ботами-покупателями */
function worldStep(tm){
  marketStep(W);
  for(const n of W.npcs){
    if(n.is_dev||n.is_admin){n.bal*=1.0004;continue;}
    n.bal+=npcInc(n)*5;
    if(Math.random()<.22)n.loc=npcPlace(n);
  }
  W.market=W.market.filter(l=>l.owner||l.exp>tm);
  const npcLots=()=>W.market.filter(l=>!l.owner);
  while(npcLots().length<28)W.market.push(genLot(W,tm));
  if(Math.random()<.35){const arr=npcLots();if(arr.length){const x=arr[ri(0,arr.length-1)];W.market.splice(W.market.indexOf(x),1,genLot(W,tm));}}
  for(let i=W.market.length-1;i>=0;i--){
    const l=W.market[i]; if(!l.owner||l.status!=='active'||l.exp<=tm)continue;
    const avg=avgPrice(null,l.k,l.u),ratio=Math.max(.01,avg*1.1/l.p);
    const p1=clamp(.04*Math.pow(ratio,4),0,.35),p5=1-Math.pow(1-p1,5);
    if(Math.random()<p5){
      const gross=l.p*l.n,net=gross*(1-(l.tax||5)/100);
      W.vol+=gross;
      if(!l.u){const d=W.deals[l.k]||(W.deals[l.k]=[]);d.push(l.p);if(d.length>100)d.shift();}
      W.market.splice(i,1);
      mail(l.owner,net,'Лот продан: '+info(l.k,l.u).name+' ×'+l.n+', +'+fmt(net)+' ₵');
    }
  }
}
function worldCatchUp(now){
  if(W.lastWorld>now+WORLD_MS)W.lastWorld=now;
  const ws=Math.floor((now-W.lastWorld)/WORLD_MS);
  if(ws>0){
    const steps=Math.min(ws,288);
    for(let i=1;i<=steps;i++)worldStep(now-(steps-i)*WORLD_MS);
    W.lastWorld=ws>288?now:W.lastWorld+ws*WORLD_MS;
  }
  let hn=0;
  while(now-W.lastHour>=3600000&&hn<48){
    W.lastHour+=3600000;hn++;
    const supply=W.npcs.reduce((a,n)=>a+n.bal,0)+(W.extraSupply||0),prev=W.econ.length?W.econ[W.econ.length-1].supply:supply;
    W.econ.push({ts:W.lastHour,supply,infl:prev?(supply/prev-1)*100:0,vol:W.vol});W.vol=0;
    if(W.econ.length>48)W.econ.shift();
  }
  if(now-W.lastHour>=3600000)W.lastHour=now;
}
function applyMail(S,sum){
  const box=W.mailbox[S.uid];if(!box||!box.length)return false;
  for(const m of box){
    S.credits+=m.credits;S.stats.profit+=m.credits;S.stats.sold++;sum.sold=(sum.sold||0)+m.credits;
    sum.ev.push({kind:'sold',text:m.text});logAdd(S,m.text);
  }
  delete W.mailbox[S.uid];return true;
}
/* свои лоты: срок вышел -> предметы возвращаются в трюм (если есть место) */
function processLots(S,now,sum){
  let ch=false;
  for(let i=W.market.length-1;i>=0;i--){
    const l=W.market[i]; if(l.owner!==S.uid)continue;
    if(l.status==='active'&&l.exp<=now){l.status='expired';ch=true;}
    if(l.status==='expired'&&roomFor(S,l.k,l.n,l.u)){ addItem(S,l.k,l.n,l.u); W.market.splice(i,1); sum.ev.push({kind:'exp',text:'Лот не продан, предметы вернулись в трюм: '+info(l.k,l.u).name}); ch=true; }
  }
  return ch;
}
function tryCollectCraft(S,sum){
  const c=S.craft; if(!c||Date.now()<c.end)return false;
  const rec=RECIPES.find(r=>r.id===c.rid);
  if(!c.ok){
    c.consumed.forEach(x=>{const n=Math.floor(x.n/2);if(n>0)addItem(S,x.k,n);});
    S.craft=null;S.stats.craftFail++;
    sum.ev.push({kind:'craftbad',text:'Крафт провалился: '+rec.name+'. Половина ресурсов потеряна'});
    logAdd(S,'Провал крафта: '+rec.name);
    return true;
  }
  let left;
  if(rec.out.mod){ const u=makeModule(rec.out.mod,rec.out.q); left=addItem(S,'mod',1,u); }
  else left=addItem(S,rec.out.k,rec.out.n);
  if(left>0){ if(!c.done){c.done=true;return true;} return false; }
  S.craft=null;S.stats.crafts++;
  sum.ev.push({kind:'craft',text:'Готово: '+rec.name});
  logAdd(S,'Создано: '+rec.name);
  return true;
}
function catchUp(S,now){
  const sum={credits:0,res:{},lost:0,mins:0,sold:0,changed:false,ev:[]};
  if(S.lastTick>now+TICK_MS)S.lastTick=now;
  const m=Math.floor((now-S.lastTick)/TICK_MS);
  if(m>0){
    /* защита от афк-фарма: после 72 часов отсутствия доход падает до 10% */
    const eff=Math.min(m,AFK_MIN)+.1*Math.max(0,m-AFK_MIN);
    applyMinutes(S,eff,sum);S.lastTick+=m*TICK_MS;sum.mins=m;sum.changed=true;
  }
  if(applyMail(S,sum))sum.changed=true;
  if(refreshBots(S,now))sum.changed=true;
  if(processLots(S,now,sum))sum.changed=true;
  if(S.craft&&now>=S.craft.end){ if(tryCollectCraft(S,sum))sum.changed=true; }
  if(S.travel&&now>=S.travel.end){
    S.loc={t:S.travel.to.t,s:S.travel.to.s};S.stats.distance+=S.travel.dist;
    ensureBots(S,S.loc.t,S.loc.s);slots(S,S.loc.t,S.loc.s);
    sum.ev.push({kind:'arrive',text:'Прибытие: виток '+S.loc.t+', сектор '+S.loc.s});
    S.travel=null;sum.changed=true;
  }
  S.lastSeen=now;
  syncLots(S);
  return sum;
}

/* ---------- действия игрока ---------- */
const err=t=>({err:t});
const okm=(t,extra)=>Object.assign({ok:true,msg:t},extra||{});
function busyMsg(S){return S.travel?'Корабль в пути':null;}
function doScan(S){
  const now=Date.now();
  if(S.travel)return err('Корабль в пути');
  if(now<S.cd.scan)return err('Сканер остывает');
  const st=stats(S),t=S.loc.t,li=locInfo(t,S.loc.s);
  S.cd.scan=now+15000;S.stats.scans++;S.xp+=2;
  if(Math.random()<st.scan){
    let k,n;
    if(Math.random()<.03){k='crystal_rare';n=1;}
    else{
      const types=Object.keys(RES),w=types.map(r=>r===li.bias?3:1);let x=Math.random()*w.reduce((a,b)=>a+b,0),type=types[0];
      for(let i=0;i<types.length;i++){x-=w[i];if(x<=0){type=types[i];break;}}
      const q=Math.min(10,Loc.Q(t)+(Math.random()<.1?1:0));k=type+':'+q;
      n=Math.max(1,Math.round(ri(3,8)*(1+.2*t)*tierRew(li.tier)));
    }
    const left=addItem(S,k,n),got=n-left,I=info(k);
    return okm(got>0?'Найдено: '+I.name+' ×'+got:'Найдено: '+I.name+', но трюм полон',{res:{type:'scan',found:true,k,n:got,lost:left}});
  }
  return okm('Сектор пуст',{res:{type:'scan',found:false}});
}
function simFight(dmg,hp,E){
  let eHP=E*40,rounds=0;const eD=E*6;
  while(rounds<60){rounds++;eHP-=dmg*rnd(.85,1.15);if(eHP<=0)break;hp-=eD*rnd(.85,1.15);if(hp<=0)break;}
  return {win:eHP<=0&&hp>0,rounds,hp,eHP};
}
/* оценка шанса победы в бою на витке t (для подсказки новичкам) */
function fightOdds(S,t,ammo){
  const st=stats(S),E=Loc.E(t),d=st.dmg*(ammo?1.25:1);let w=0;
  for(let i=0;i<60;i++)if(simFight(d,st.hp,E).win)w++;
  return w/60;
}
function doFight(S,useAmmo){
  const now=Date.now();
  if(S.travel)return err('Корабль в пути');
  if(now<S.cd.fight)return err('Орудия перезаряжаются');
  const t=S.loc.t,E=Loc.E(t),st=stats(S),tier=tierOf(t);
  let dmg=st.dmg,ammoUsed=0;
  if(useAmmo&&countKey(S,'ammo')>=5){takeKey(S,'ammo',5);dmg*=1.25;ammoUsed=5;}
  const f=simFight(dmg,st.hp,E),win=f.win;
  const res={type:'fight',win,rounds:f.rounds,E,hpLeft:Math.max(0,f.hp),hpMax:st.hp,eLeft:Math.max(0,f.eHP),eMax:E*40,ammoUsed,loot:[],cr:0,xp:0};
  if(win){
    res.cr=Math.round(E*8*(1+.1*t)*tierRew(tier));res.xp=Math.round(E*4);
    S.credits+=res.cr;S.stats.profit+=res.cr;S.xp+=res.xp;S.stats.won++;
    if(Math.random()<.35){const n=ri(1,3);addItem(S,'debris',n);res.loot.push({k:'debris',n});}
    if(Math.random()<.15){const k=pick(Object.keys(RES))+':'+Loc.Q(t),n=ri(2,6);addItem(S,k,n);res.loot.push({k,n});}
    S.cd.fight=now+20000;
    logAdd(S,'Победа в бою (виток '+t+'): +'+fmt(res.cr)+' ₵, +'+res.xp+' опыта');
    return okm('Победа: +'+fmt(res.cr)+' ₵',{res});
  }
  S.stats.lost++;S.cd.fight=now+(tier===1?20000:45000);
  logAdd(S,'Отступление в бою (виток '+t+')');
  return okm('Поражение. Орудия на перезарядке',{res,kind:'bad'});
}
function buyUpg(S,k){
  const c=upgCost(S,k);
  if(S.credits<c)return err('Не хватает кредитов');
  S.credits-=c;S.upg[k]++;S.xp+=3*S.upg[k];
  return okm(UPG[k].name+': уровень '+S.upg[k]);
}
function build(S,idx,type){
  if(S.travel)return err('Корабль в пути');
  const sl=slots(S,S.loc.t,S.loc.s);
  if(idx<0||idx>=sl.length||sl[idx])return err('Слот занят');
  const c=buildCost(S,type,1,S.loc.t);
  if(S.credits<c)return err('Не хватает кредитов');
  S.credits-=c;sl[idx]={type,level:1};S.stats.built++;S.xp+=5;
  return okm(BUILD[type].name+' построен');
}
function upBld(S,idx){
  if(S.travel)return err('Корабль в пути');
  const b=slots(S,S.loc.t,S.loc.s)[idx];
  if(!b)return err('Нет здания');
  const c=buildCost(S,b.type,b.level+1,S.loc.t);
  if(S.credits<c)return err('Не хватает кредитов');
  S.credits-=c;b.level++;S.xp+=2*b.level;
  return okm(BUILD[b.type].name+': уровень '+b.level);
}
function unlockInfo(S,t,s){
  const key=t+':'+s;
  if(S.unlocked[key])return {done:true};
  const r=[];
  if(t>0&&bestLevel(S,'beacon')<t)r.push('Нужен Маяк уровня '+t);
  if(levelOf(S.xp)<Loc.R(t))r.push('Тир '+tierOf(t)+' «'+tierName(tierOf(t))+'»: нужен уровень '+Loc.R(t));
  if(t>0){let any=false;for(const k in S.unlocked)if(+k.split(':')[0]===t-1){any=true;break;}if(!any)r.push('Сначала откройте виток '+(t-1));}
  const cost=Loc.C(t);
  return {done:false,reasons:r,cost,afford:S.credits>=cost,can:r.length===0};
}
function unlock(S,t,s){
  const u=unlockInfo(S,t,s);
  if(u.done)return err('Уже открыто');
  if(!u.can)return err(u.reasons[0]);
  if(!u.afford)return err('Не хватает кредитов');
  S.credits-=u.cost;S.unlocked[t+':'+s]=1;S.stats.unlockedN++;S.xp+=20*(t+1);slots(S,t,s);
  return okm('Локация открыта: виток '+t+', сектор '+s);
}
function distance(a,b){const ds=Math.abs(a.s-b.s),sd=Math.min(ds,SECTORS-ds);return Math.abs(a.t-b.t)*8+sd*1.5;}
function travelTime(S,to){const d=distance(S.loc,to);return Math.max(3,d*4/Math.pow(1.05,S.upg.engines))*(S.fuel?.5:1)*1000;}
function travel(S,t,s){
  if(S.travel)return err('Корабль уже в пути');
  if(t===S.loc.t&&s===S.loc.s)return err('Вы уже здесь');
  if(!S.unlocked[t+':'+s])return err('Локация закрыта');
  if(levelOf(S.xp)<Loc.R(t))return err('Тир '+tierOf(t)+': нужен уровень '+Loc.R(t));
  const ms=travelTime(S,{t,s}),now=Date.now();
  S.travel={from:{t:S.loc.t,s:S.loc.s},to:{t,s},start:now,end:now+ms,dist:distance(S.loc,{t,s})};
  if(S.fuel){S.fuel=false;}
  return okm('Курс на виток '+t+', сектор '+s);
}
function useItem(S,i){
  const st=S.inv[i]; if(!st)return err('Нет предмета');
  if(st.k==='fuel'){ if(S.fuel)return err('Топливо уже активно'); takeKey(S,'fuel',1);S.fuel=true;return okm('Следующий перелёт будет вдвое быстрее'); }
  return err('Предмет нельзя использовать');
}
function equip(S,i){
  const st=S.inv[i]; if(!st||st.k!=='mod')return err('Это не модуль');
  if(S.equip.length>=MOD_SLOTS)return err('Все слоты модулей заняты');
  S.inv.splice(i,1);S.equip.push(st);return okm('Модуль установлен');
}
function unequip(S,i){
  const st=S.equip[i]; if(!st)return err('Слот пуст');
  if(S.inv.length>=cap(S))return err('В трюме нет места');
  S.equip.splice(i,1);S.inv.push(st);return okm('Модуль снят');
}
function discard(S,i){
  const st=S.inv[i]; if(!st)return err('Нет предмета');
  if(info(st.k,st.u).stop)return err('Этот предмет нельзя выбросить');
  S.inv.splice(i,1);return okm('Предмет выброшен');
}
function sellBot(S,botId,n){
  let bot=null;const key=S.loc.t+':'+S.loc.s;
  for(const b of (S.bots[key]||[]))if(b.id===botId)bot=b;
  if(!bot)return err('Скупщик улетел');
  const have=countKey(S,bot.k),q=Math.min(n,bot.remain,have);
  if(q<=0)return err(bot.remain<=0?'Скупщик набрал лимит':'Нет такого товара');
  takeKey(S,bot.k,q);bot.remain-=q;
  const cr=q*bot.p;S.credits+=cr;S.stats.profit+=cr;S.stats.sold++;W.vol+=cr;
  logAdd(S,'Скупщик: '+info(bot.k).name+' ×'+q+' за '+fmt(cr)+' ₵');
  return okm('Продано '+q+' шт. за '+fmt(cr)+' ₵');
}
function lotLimits(S,st){
  const avg=avgPrice(S,st.k,st.u);
  return {avg,min:1,max:Math.max(1,Math.floor(avg*100))};
}
function listLot(S,i,n,p){
  const st=S.inv[i]; if(!st)return err('Нет предмета');
  if(info(st.k,st.u).stop)return err('Предмет из стоп-листа: продавать нельзя');
  const active=lotsOf(S).length,lim=aucSlots(S);
  if(active>=lim)return err('Нет свободных слотов аукциона ('+active+'/'+fmt(lim)+')');
  n=st.u?1:Math.floor(n);p=Math.floor(p);
  if(!(n>=1)||n>st.n)return err('Неверное количество');
  const L=lotLimits(S,st);
  if(!(p>=L.min))return err('Минимальная цена: 1 кредит');
  if(p>L.max)return err('Слишком высокая цена. Максимум: '+fmt(L.max)+' ₵ (100× средней)');
  const lot={id:'m'+(W.nextId++),owner:S.uid,seller:S.name,k:st.k,n,p,u:st.u||null,exp:Date.now()+24*3600000,status:'active',tax:taxPct(S)};
  if(st.u)S.inv.splice(i,1);else{st.n-=n;if(st.n<=0)S.inv.splice(i,1);}
  W.market.push(lot);syncLots(S);
  return okm('Лот выставлен на 24 часа');
}
function cancelLot(S,id){
  const i=W.market.findIndex(l=>l.id===id&&l.owner===S.uid); if(i<0)return err('Лот не найден');
  const l=W.market[i];
  if(!roomFor(S,l.k,l.n,l.u))return err('В трюме нет места');
  addItem(S,l.k,l.n,l.u);W.market.splice(i,1);syncLots(S);return okm('Лот снят, предметы в трюме');
}
function buyLot(S,id){
  const i=W.market.findIndex(l=>l.id===id&&l.status==='active'&&l.exp>Date.now()); if(i<0)return err('Лот уже продан');
  const l=W.market[i],cost=l.p*l.n;
  if(l.owner===S.uid)return err('Это ваш лот');
  if(S.credits<cost)return err('Не хватает кредитов');
  if(!roomFor(S,l.k,l.n,l.u))return err('В трюме нет места');
  S.credits-=cost;addItem(S,l.k,l.n,l.u);W.market.splice(i,1);W.vol+=cost;
  if(!l.u){const d=W.deals[l.k]||(W.deals[l.k]=[]);d.push(l.p);if(d.length>100)d.shift();}
  if(l.owner)mail(l.owner,cost*(1-(l.tax||5)/100),'Лот выкуплен игроком: '+info(l.k,l.u).name+' ×'+l.n+', +'+fmt(cost*(1-(l.tax||5)/100))+' ₵');
  logAdd(S,'Куплено на аукционе: '+info(l.k,l.u).name+' ×'+l.n);
  syncLots(S);
  return okm('Куплено: '+info(l.k,l.u).name+' ×'+l.n);
}
function buyVip(S,N,now){
  now=now||Date.now();
  const price=VIP.price(N);
  if(vipActive(S,now)&&N<S.vipLevel)return err('Активен более высокий уровень VIP');
  if(S.premium<price)return err('Не хватает кристаллов');
  S.premium-=price;
  const base=vipActive(S,now)?S.vipUntil:now;
  S.vipLevel=N;S.vipUntil=base+30*86400000;
  return okm('VIP '+N+' активен ещё '+dur(S.vipUntil-now));
}
function redeem(S,raw,now){
  now=now||Date.now();
  const code=String(raw||'').trim().toUpperCase();
  if(!code)return err('Введите промокод');
  const p=PROMOS[code]; if(!p)return err('Такого промокода нет');
  if(now>new Date(p.expires+'T23:59:59').getTime())return err('Срок действия промокода истёк');
  const L=levelOf(S.xp);
  if(p.min_level&&L<p.min_level)return err('Нужен уровень капитана: '+p.min_level);
  if(p.max_level&&L>p.max_level)return err('Промокод для уровней до '+p.max_level);
  if((S.promoUsed[code]||0)>=p.uses_per_user)return err('Вы уже активировали этот промокод');
  if((W.promoTotals[code]||0)>=p.uses_total)return err('Лимит активаций исчерпан');
  const r=p.reward,parts=[];
  if(r.item&&!roomFor(S,r.item,r.qty||1))return err('В трюме нет места для награды');
  if(r.credits){S.credits+=r.credits;parts.push('+'+fmt(r.credits)+' ₵');}
  if(r.premium){S.premium+=r.premium;parts.push('+'+r.premium+' ◆');}
  if(r.item){addItem(S,r.item,r.qty||1);parts.push(info(r.item).name+' ×'+(r.qty||1));}
  if(r.vip_days){
    if(vipActive(S,now))S.vipUntil+=r.vip_days*86400000;
    else{S.vipLevel=Math.max(1,S.vipLevel);S.vipUntil=now+r.vip_days*86400000;}
    parts.push('VIP '+r.vip_days+' дн.');
  }
  S.promoUsed[code]=(S.promoUsed[code]||0)+1;W.promoTotals[code]=(W.promoTotals[code]||0)+1;
  logAdd(S,'Промокод '+code+': '+parts.join(', '));
  return okm('Промокод принят: '+parts.join(', '));
}
function joinGuild(S,id){const g=GUILDS.find(x=>x.id===id);if(!g)return err('Гильдия не найдена');S.guild=g.name;return okm('Вы вступили в гильдию «'+g.name+'»');}
function leaveGuild(S){S.guild=null;return okm('Вы покинули гильдию');}

/* ---------- крафт ---------- */
function craftInfo(S,rec){
  const Ll=bestLevel(S,'lab'),Q=rec.q;
  return {time:rec.tb*(1+.1*Q)/(1+.02*Ll)*1000,p:Math.min(.95,(.3+.05*Ll)/(1+.1*Q)),Ll};
}
function craftStart(S,rid){
  if(S.craft)return err('Сборка уже идёт');
  const rec=RECIPES.find(r=>r.id===rid); if(!rec)return err('Нет рецепта');
  for(const [t,n] of rec.inp)if(countRes(S,t)<n)return err('Не хватает ресурсов');
  const ci=craftInfo(S,rec),consumed=[];
  for(const [t,n] of rec.inp)consumed.push(...takeRes(S,t,n));
  const now=Date.now();
  S.craft={rid,start:now,end:now+ci.time,ok:Math.random()<ci.p,consumed,done:false};
  return okm('Сборка запущена: '+rec.name);
}
function craftClaim(S){
  if(!S.craft||!S.craft.done)return err('Нечего забирать');
  const sum={ev:[]};S.craft.end=0;
  tryCollectCraft(S,sum);
  if(S.craft)return err('В трюме нет места');
  return okm('Предмет получен');
}

/* ---------- достижения ---------- */
function checkAch(S){
  const got=[];
  for(const a of ACH){ if(!S.ach[a.id]&&a.test(S)){S.ach[a.id]=Date.now();S.premium+=a.reward;got.push(a);} }
  return got;
}

/* ---------- панель разработчика (серверная проверка флага is_dev) ---------- */
function dev(S,op,a){
  if(!S.is_dev)return err('Нет доступа');
  a=a||{};let msg='';
  switch(op){
    case 'give':{
      const n=Math.max(1,Math.floor(+a.n||1));
      if(!/^mod:(income|dmg|hp)/.test(String(a.k))&&KEYS.indexOf(a.k)<0)return err('Неизвестный предмет');
      if(String(a.k).indexOf('mod:')===0){const p=a.k.split(':');let l=0;for(let i=0;i<n;i++)l+=addItem(S,'mod',1,makeModule(p[1],+p[2]||2));msg='Выдано модулей: '+(n-l);}
      else{const l=addItem(S,a.k,n);msg='Выдано: '+info(a.k).name+' ×'+(n-l)+(l?' (трюм полон, потеряно '+l+')':'');}
      break;}
    case 'tp':{
      const t=Math.max(0,Math.floor(+a.t||0)),s=clamp(Math.floor(+a.s||1),1,SECTORS);
      S.travel=null;S.loc={t,s};
      if(!S.unlocked[t+':'+s]){S.unlocked[t+':'+s]=1;S.stats.unlockedN++;}
      slots(S,t,s);ensureBots(S,t,s);msg='Телепорт: виток '+t+', сектор '+s;break;}
    case 'setb':{
      const sl=slots(S,S.loc.t,S.loc.s),i=Math.floor(+a.i);
      if(!(i>=0&&i<sl.length))return err('Нет такого слота');
      const L=Math.max(0,Math.floor(+a.level||0));
      if(L>0&&!BUILD[a.type])return err('Неизвестное здание');
      if(L===0)sl[i]=null;else sl[i]={type:a.type,level:L};
      msg='Слот '+(i+1)+': '+(L?BUILD[a.type].name+' ур. '+L:'очищен');break;}
    case 'bal':{
      if(a.credits!=null&&a.credits!=='')S.credits=Math.max(0,+a.credits);
      if(a.xp!=null&&a.xp!=='')S.xp=Math.max(0,+a.xp);
      if(a.premium!=null&&a.premium!=='')S.premium=Math.max(0,Math.floor(+a.premium));
      if(a.vipDays!=null&&a.vipDays!==''){const d=Math.floor(+a.vipDays);if(d<=0){S.vipUntil=0;S.vipLevel=0;}else{S.vipLevel=clamp(Math.floor(+a.vipLevel||S.vipLevel||1),1,10);S.vipUntil=Date.now()+d*86400000;}}
      msg='Значения обновлены';break;}
    case 'sim':{
      const N=Math.max(1,Math.min(1e7,Math.floor(+a.n||1))),sum={credits:0,res:{},lost:0};
      applyMinutes(S,N,sum);msg='Симуляция '+N+' мин: +'+fmt(sum.credits)+' ₵';break;}
    case 'reset':{
      const keep={uid:S.uid,name:S.name,photo:S.photo,is_dev:S.is_dev,is_admin:S.is_admin};
      W.market=W.market.filter(l=>l.owner!==S.uid);const fresh=newGame(keep);for(const k in S)delete S[k];Object.assign(S,fresh);msg='Аккаунт сброшен к началу';break;}
    case 'bot':{
      if(KEYS.indexOf(a.k)<0)return err('Неизвестный товар');
      const key=S.loc.t+':'+S.loc.s,arr=ensureBots(S,S.loc.t,S.loc.s);
      arr.push({id:'b'+(W.nextId++),k:a.k,p:Math.max(.1,+a.p||1),max:Math.max(1,Math.floor(+a.n||100)),remain:Math.max(1,Math.floor(+a.n||100)),next:Date.now()+3600000,dev:true});
      msg='Скупщик создан на '+key;break;}
    default:return err('Неизвестная команда');
  }
  S.devLog.unshift({ts:Date.now(),op,args:JSON.stringify(a)});if(S.devLog.length>40)S.devLog.length=40;
  return okm(msg);
}

/* ---------- наборы кристаллов (id совпадают с товарами VK Payments: crystals_<id>) ---------- */
const PACKS=[{id:'p1',n:100,bonus:0,price:5},{id:'p2',n:300,bonus:30,price:13},{id:'p3',n:700,bonus:100,price:28},{id:'p4',n:1500,bonus:300,price:55},{id:'p5',n:4000,bonus:1000,price:130}];
function demoPack(S,id){const p=PACKS.find(x=>x.id===id);if(!p)return err('Нет такого набора');S.premium+=p.n+p.bonus;return okm('Начислено: +'+(p.n+p.bonus)+' ◆');}
const SORTS=['type','rar','price','time'];
/* Белый список действий игрока: сервер выполняет только их, клиент только просит */
const OPS={
  doScan,doFight,buyUpg,build,upBld,unlock,travel,useItem,equip,unequip,discard,sellBot,listLot,cancelLot,buyLot,buyVip,redeem,joinGuild,leaveGuild,craftStart,craftClaim,demoPack,
  sortInv:(S,mode)=>{if(SORTS.indexOf(mode)<0)return err('Неизвестная сортировка');S.invSort=mode;sortInv(S);return {ok:true,msg:''};},
  tipsOff:S=>{S.tips=false;return {ok:true,msg:''};}
};
return {OPS,PACKS,setWorld,getWorld,newWorld,spawnCompanions,worldCatchUp,applyMail,syncLots,lotsOf,npcXp,npcInc,npcPlace,TIER_REQ,tierOf,tierReq,tierName,tierCol,tierRew,tierForLevel,LTYPES,hash,locInfo,crewAt,crewCounts,capView,fightOdds,TICK_MS,SECTORS,MOD_SLOTS,STACK_MAX,RARITY,RAR_COL,RES,BUILD,UPG,MOD,Loc,VIP,RECIPES,PROMOS,GUILDS,ACH,CAT_NAME,KEYS,
  fmt,dur,rarMult,levelOf,xpFor,info,cap,interp,newGame,save,load,catchUp,logAdd,
  slots,allBuildings,sumLevels,bestLevel,bldIncome,buildCost,upgMult,incomeParts,income,production,stats,upgCost,
  vipActive,vipLvl,vipMult,vipDisc,aucSlots,taxPct,avgPrice,ensureBots,countKey,countRes,sortInv,roomFor,lotLimits,
  doScan,doFight,buyUpg,build,upBld,unlockInfo,unlock,distance,travelTime,travel,useItem,equip,unequip,discard,sellBot,listLot,cancelLot,buyLot,
  buyVip,redeem,joinGuild,leaveGuild,craftInfo,craftStart,craftClaim,checkAch,dev,top,fullTop,applyMinutes,makeModule,addItem};
})();

if(typeof module!=='undefined'&&module.exports)module.exports=Core;
