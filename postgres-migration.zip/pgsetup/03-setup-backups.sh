#!/usr/bin/env bash
# ═══════════════════════════════════════════════════════════════════════════
# Настраивает ежедневный автобэкап локальной БД бота — это именно то, что у
# Neon было "бесплатно" из коробки, а на своём сервере нужно включить самим.
# Без этого один битый диск на VDS = потеря всей игры (балансы, кланы, всё).
#
# Что делает:
#   - Ставит /usr/local/bin/botdb-backup.sh — снимает pg_dump и сжимает gzip.
#   - Хранит бэкапы за последние 14 дней в /var/backups/botdb/, старее — удаляет.
#   - Добавляет cron-задачу на 04:00 ночи каждый день.
#
# ЗАПУСК:
#   chmod +x 03-setup-backups.sh
#   sudo ./03-setup-backups.sh
# ═══════════════════════════════════════════════════════════════════════════
set -euo pipefail

if [ "$(id -u)" -ne 0 ]; then
  echo "⛔ Запустите с sudo: sudo ./03-setup-backups.sh"
  exit 1
fi

DEFAULT_URL=""
if [ -f /root/.botdb_new_connection_string.txt ]; then
  DEFAULT_URL="$(cat /root/.botdb_new_connection_string.txt)"
fi

read -rp "DATABASE_URL бота [$DEFAULT_URL]: " INPUT_URL
DB_URL="${INPUT_URL:-$DEFAULT_URL}"
if [ -z "$DB_URL" ]; then
  echo "⛔ Не указан DATABASE_URL."
  exit 1
fi

BACKUP_DIR="/var/backups/botdb"
mkdir -p "$BACKUP_DIR"

cat > /usr/local/bin/botdb-backup.sh <<SCRIPT
#!/usr/bin/env bash
set -euo pipefail
STAMP="\$(date +%Y%m%d_%H%M%S)"
OUT="${BACKUP_DIR}/botdb_\${STAMP}.sql.gz"
pg_dump "${DB_URL}" --no-owner --no-privileges | gzip > "\$OUT"
echo "[botdb-backup] \$(date): сохранено \$OUT (\$(du -h "\$OUT" | cut -f1))"

# Ротация: храним только бэкапы за последние 14 дней.
find "${BACKUP_DIR}" -name "botdb_*.sql.gz" -mtime +14 -delete
SCRIPT
chmod +x /usr/local/bin/botdb-backup.sh

CRON_LINE="0 4 * * * root /usr/local/bin/botdb-backup.sh >> /var/log/botdb-backup.log 2>&1"
CRON_FILE="/etc/cron.d/botdb-backup"
echo "$CRON_LINE" > "$CRON_FILE"
chmod 644 "$CRON_FILE"

echo "▶ Проверяю бэкап прямо сейчас (первый пробный запуск)..."
/usr/local/bin/botdb-backup.sh

echo ""
echo "═══════════════════════════════════════════════════════════════════"
echo "✅ Автобэкап настроен: каждую ночь в 04:00 по времени сервера."
echo "   Файлы лежат в: $BACKUP_DIR (хранятся 14 дней, старые удаляются сами)."
echo "   Лог: /var/log/botdb-backup.log"
echo ""
echo "СОВЕТ (по-хорошему обязательный): эти бэкапы лежат на ТОМ ЖЕ диске, что"
echo "и сама база — если диск целиком откажет, локальные бэкапы тоже пропадут."
echo "Раз в несколько дней скачивайте свежий файл из $BACKUP_DIR к себе на"
echo "компьютер/облако вручную, либо настройте rclone/scp по отдельному cron —"
echo "могу помочь с этим тоже, если скажете, где хотите хранить копию (Google"
echo "Drive, Telegram, свой ПК по SSH и т.п.)."
echo "═══════════════════════════════════════════════════════════════════"
