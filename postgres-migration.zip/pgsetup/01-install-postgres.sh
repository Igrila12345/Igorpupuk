#!/usr/bin/env bash
# ═══════════════════════════════════════════════════════════════════════════
# Установка локального PostgreSQL на VDS — заменяет Neon, снимает лимит по
# времени вычислений полностью (это ваш сервер, никаких облачных квот).
#
# Код бота НЕ меняется вообще — просто в конце скрипт покажет новую строку
# DATABASE_URL, которую нужно вставить в .env вместо адреса Neon.
#
# ЗАПУСК (на самом VDS, не здесь):
#   chmod +x 01-install-postgres.sh
#   sudo ./01-install-postgres.sh
# ═══════════════════════════════════════════════════════════════════════════
set -euo pipefail

if [ "$(id -u)" -ne 0 ]; then
  echo "⛔ Запустите скрипт с sudo: sudo ./01-install-postgres.sh"
  exit 1
fi

DB_NAME="botdb"
DB_USER="botuser"
DB_PASS="$(openssl rand -base64 24 | tr -dc 'a-zA-Z0-9' | head -c 32)"

echo "▶ Определяю дистрибутив..."
if [ -f /etc/os-release ]; then
  . /etc/os-release
  DISTRO_ID="$ID"
else
  echo "⛔ Не удалось определить дистрибутив (/etc/os-release отсутствует)."
  exit 1
fi

echo "▶ Обнаружено: $PRETTY_NAME"

case "$DISTRO_ID" in
  ubuntu|debian)
    echo "▶ Устанавливаю PostgreSQL через apt..."
    apt update
    apt install -y postgresql postgresql-contrib
    PG_SERVICE="postgresql"
    ;;
  centos|rhel|rocky|almalinux|fedora)
    echo "▶ Устанавливаю PostgreSQL через dnf/yum..."
    if command -v dnf >/dev/null 2>&1; then
      dnf install -y postgresql-server postgresql-contrib
    else
      yum install -y postgresql-server postgresql-contrib
    fi
    if [ ! -d /var/lib/pgsql/data ] || [ -z "$(ls -A /var/lib/pgsql/data 2>/dev/null)" ]; then
      postgresql-setup --initdb
    fi
    PG_SERVICE="postgresql"
    ;;
  *)
    echo "⛔ Дистрибутив '$DISTRO_ID' скрипт не знает. Установите PostgreSQL вручную по"
    echo "   документации вашего дистрибутива, затем запустите 02-create-db.sh отдельно"
    echo "   (в нём только SQL-команды, без установки пакетов)."
    exit 1
    ;;
esac

echo "▶ Включаю и запускаю службу PostgreSQL..."
systemctl enable "$PG_SERVICE"
systemctl start "$PG_SERVICE"
sleep 2

echo "▶ Создаю базу данных и пользователя для бота..."
sudo -u postgres psql -v ON_ERROR_STOP=1 <<SQL
DO \$\$
BEGIN
  IF NOT EXISTS (SELECT FROM pg_catalog.pg_roles WHERE rolname = '${DB_USER}') THEN
    CREATE USER ${DB_USER} WITH PASSWORD '${DB_PASS}';
  ELSE
    ALTER USER ${DB_USER} WITH PASSWORD '${DB_PASS}';
  END IF;
END
\$\$;
SQL

sudo -u postgres psql -v ON_ERROR_STOP=1 -tc "SELECT 1 FROM pg_database WHERE datname = '${DB_NAME}'" | grep -q 1 || \
  sudo -u postgres createdb -O "$DB_USER" "$DB_NAME"

sudo -u postgres psql -v ON_ERROR_STOP=1 -d "$DB_NAME" -c "GRANT ALL PRIVILEGES ON DATABASE ${DB_NAME} TO ${DB_USER};"
sudo -u postgres psql -v ON_ERROR_STOP=1 -d "$DB_NAME" -c "GRANT ALL ON SCHEMA public TO ${DB_USER};"

NEW_DATABASE_URL="postgresql://${DB_USER}:${DB_PASS}@localhost:5432/${DB_NAME}"

echo ""
echo "═══════════════════════════════════════════════════════════════════"
echo "✅ PostgreSQL установлен и настроен локально."
echo ""
echo "Новая строка для .env (замените старую DATABASE_URL целиком):"
echo ""
echo "DATABASE_URL=${NEW_DATABASE_URL}"
echo ""
echo "⚠️  Сохраните эту строку в надёжном месте — пароль сгенерирован один раз"
echo "    и больше нигде не показывается."
echo ""
echo "Дальше:"
echo "  1) Если нужно перенести старые данные из Neon — запустите 02-migrate-data.sh"
echo "     (нужен ваш СТАРЫЙ DATABASE_URL от Neon, скрипт спросит его сам)."
echo "  2) Если старая база не нужна (начинаете с нуля) — просто впишите строку"
echo "     выше в .env и перезапустите бота, схема создастся сама при старте"
echo "     (см. db/pool.js: initSchema())."
echo "  3) Настройте автобэкап: 03-setup-backups.sh"
echo "═══════════════════════════════════════════════════════════════════"

echo "$NEW_DATABASE_URL" > /root/.botdb_new_connection_string.txt
chmod 600 /root/.botdb_new_connection_string.txt
echo "(строка подключения также сохранена в /root/.botdb_new_connection_string.txt)"
