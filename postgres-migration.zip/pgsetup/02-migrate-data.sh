#!/usr/bin/env bash
# ═══════════════════════════════════════════════════════════════════════════
# Переносит данные (все таблицы: игроков, кланы, балансы, историю казино и
# т.д.) со старой БД на Neon в новую локальную БД на этом VDS.
#
# Запускайте ПОСЛЕ 01-install-postgres.sh, когда у вас уже есть новая строка
# подключения (показана в конце того скрипта / в /root/.botdb_new_connection_string.txt).
#
# ВАЖНО: перед запуском ОСТАНОВИТЕ бота (чтобы никто не играл и баланс не
# менялся во время переноса) — иначе данные, изменённые в Neon уже ПОСЛЕ
# снятия дампа, потеряются.
#
# ЗАПУСК:
#   chmod +x 02-migrate-data.sh
#   ./02-migrate-data.sh
# ═══════════════════════════════════════════════════════════════════════════
set -euo pipefail

if ! command -v pg_dump >/dev/null 2>&1; then
  echo "⛔ pg_dump не найден. Установите postgresql-client (обычно ставится вместе с"
  echo "   postgresql-contrib в 01-install-postgres.sh) или запустите этот скрипт после него."
  exit 1
fi

echo "Остановили бота перед переносом? Во время дампа никто не должен играть,"
echo "иначе изменения в старой БД после снятия дампа потеряются."
read -rp "Продолжить? (yes/нет): " CONFIRM
if [ "$CONFIRM" != "yes" ]; then
  echo "Отменено. Остановите бота и запустите скрипт снова."
  exit 0
fi

read -rp "Вставьте СТАРЫЙ DATABASE_URL (от Neon, из текущего .env): " OLD_URL
if [ -z "$OLD_URL" ]; then
  echo "⛔ Пустая строка подключения."
  exit 1
fi

NEW_URL=""
if [ -f /root/.botdb_new_connection_string.txt ]; then
  NEW_URL="$(cat /root/.botdb_new_connection_string.txt)"
  echo "Найдена новая строка подключения из 01-install-postgres.sh:"
  echo "  $NEW_URL"
  read -rp "Использовать её? (yes/нет, тогда введу вручную): " USE_FOUND
  if [ "$USE_FOUND" != "yes" ]; then
    NEW_URL=""
  fi
fi
if [ -z "$NEW_URL" ]; then
  read -rp "Вставьте НОВЫЙ DATABASE_URL (локальный, из 01-install-postgres.sh): " NEW_URL
fi

DUMP_FILE="/root/botdb_migration_$(date +%Y%m%d_%H%M%S).sql"

echo "▶ Снимаю дамп со старой базы (Neon) в $DUMP_FILE ..."
pg_dump "$OLD_URL" --no-owner --no-privileges -f "$DUMP_FILE"

echo "▶ Дамп снят ($(du -h "$DUMP_FILE" | cut -f1)). Загружаю в новую локальную базу..."
psql "$NEW_URL" -v ON_ERROR_STOP=1 -f "$DUMP_FILE"

echo ""
echo "═══════════════════════════════════════════════════════════════════"
echo "✅ Перенос завершён."
echo ""
echo "Проверка — количество игроков в новой базе:"
psql "$NEW_URL" -tc "SELECT COUNT(*) FROM players;"
echo ""
echo "Сверьте это число с тем, что было на старой (Neon) базе — они должны совпадать."
echo ""
echo "Дальше:"
echo "  1) Впишите NEW_URL в .env бота вместо старого DATABASE_URL."
echo "  2) Запустите бота, убедитесь что команды вроде !профиль работают и видят"
echo "     старые данные (баланс, название государства и т.д.) — не выдуманные заново."
echo "  3) Только после проверки — можно отключать/удалять старый проект на Neon."
echo ""
echo "Дамп сохранён на всякий случай тут: $DUMP_FILE (удалите вручную, когда"
echo "убедитесь, что всё перенеслось верно)."
echo "═══════════════════════════════════════════════════════════════════"
