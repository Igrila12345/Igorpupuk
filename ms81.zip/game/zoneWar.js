'use strict';

// ===================== ВОЙНА КЛАНОВ ЗА ЗОНЫ =====================
// Механика (см. C.ZONE_WAR_* в game/constants.js): клан вкладывает вирты из сейфа в зону,
// кто вложил больше за цикл — тот и владеет. Раз в ZONE_WAR_CYCLE_DAYS дней бот подводит
// итог по всем НЕ защищённым зонам и открывает новый цикл. Захваченная зона под защитой
// ZONE_WAR_PROTECTION_DAYS дней — отобрать её раньше нельзя, даже если у неё есть владелец.
// Владение зоной даёт участникам клана + к часовому доходу (см. game/economy.js: hourlyTick).

const C = require('./constants');
const zonesDb = require('../db/zones');
const clansDb = require('../db/clans');
const players = require('../db/players');
const gameMeta = require('../db/shop');

const META_CYCLE_STARTED_AT = 'zone_war_cycle_started_at';
const META_ENABLED = 'zone_war_enabled';
const META_MAP_CACHE_KEY = 'zone_war_map_png_b64'; // кэш последнего СГЕНЕРИРОВАННОГО PNG (base64),
// НЕ vk-attachment'а — см. комментарий у getCachedMapBuffer ниже.

function findZoneByName(arg) {
  const lower = (arg || '').trim().toLowerCase();
  return C.ZONE_WAR_ZONES.find((z) => z.name.toLowerCase() === lower) || null;
}

// Сколько зон клан держит ПРЯМО СЕЙЧАС под защитой (см. ZONE_WAR_MAX_ZONES_PER_CLAN).
// Зоны, чья защита уже истекла, не считаются — они по факту уже "в игре" для всех.
async function countActiveOwnedZones(clanId) {
  const owned = await zonesDb.getZonesOwnedByClan(clanId);
  const now = new Date();
  return owned.filter((row) => row.protected_until && new Date(row.protected_until) > now).length;
}

async function isEnabled() {
  const v = await gameMeta.getMeta(META_ENABLED);
  return v === '1';
}

async function setEnabled(on) {
  await gameMeta.setMeta(META_ENABLED, on ? '1' : '0');
  if (on) {
    // Если войну включают впервые (или снова после паузы) и цикл ещё не отмечен — стартуем сейчас
    const started = await gameMeta.getMeta(META_CYCLE_STARTED_AT);
    if (!started) await gameMeta.setMeta(META_CYCLE_STARTED_AT, new Date().toISOString());
  }
}

async function getCycleInfo() {
  const startedRaw = await gameMeta.getMeta(META_CYCLE_STARTED_AT);
  const startedAt = startedRaw ? new Date(startedRaw) : new Date();
  const endsAt = new Date(startedAt.getTime() + C.ZONE_WAR_CYCLE_DAYS * 24 * 60 * 60 * 1000);
  return { startedAt, endsAt };
}

// ===================== СТАТУС ДЛЯ ИГРОКОВ =====================

// Полное состояние всех 9 зон: владелец, защита, текущие ставки (если зона оспаривается)
async function getFullStatus() {
  for (const z of C.ZONE_WAR_ZONES) {
    await zonesDb.ensureZoneRow(z.id);
  }
  const states = await zonesDb.getAllZoneStates();
  const stakes = await zonesDb.getAllStakes();
  const clanCache = {};

  const result = [];
  for (const zoneDef of C.ZONE_WAR_ZONES) {
    const state = states.find((s) => s.zone_id === zoneDef.id) || {};
    const now = new Date();
    const protectedUntil = state.protected_until ? new Date(state.protected_until) : null;
    const isProtected = protectedUntil && protectedUntil > now;

    let ownerName = null;
    if (state.owner_clan_id) {
      if (!clanCache[state.owner_clan_id]) {
        clanCache[state.owner_clan_id] = await clansDb.getClanById(state.owner_clan_id);
      }
      ownerName = clanCache[state.owner_clan_id] ? clanCache[state.owner_clan_id].name : null;
    }

    const zoneStakes = stakes.filter((s) => s.zone_id === zoneDef.id);

    // Текущий лидер по ставкам в этой зоне (клан, вложивший больше всех в НЕЗАЩИЩЁННУЮ
    // зону за текущий цикл) — показываем его на карте пунктиром/иначе, чтобы игроки видели,
    // кто выигрывает прямо сейчас, а не только по факту в конце цикла (когда назначается
    // ownerName). НЕ путать с ownerName: leadingClanName может смениться в любой момент,
    // пока цикл не закрылся, а ownerName — это уже подтверждённый победитель прошлого цикла.
    let leadingClanName = null;
    let leadingAmount = 0;
    if (!isProtected && zoneStakes.length) {
      const top = [...zoneStakes].sort((a, b) => Number(b.amount) - Number(a.amount))[0];
      leadingClanName = top.clan_name;
      leadingAmount = Number(top.amount);
    }

    result.push({
      ...zoneDef,
      ownerClanId: state.owner_clan_id || null,
      ownerName,
      protectedUntil,
      isProtected,
      leadingClanName,
      leadingAmount,
      bonusPercent:
        state.bonus_override !== null && state.bonus_override !== undefined
          ? Number(state.bonus_override)
          : C.ZONE_WAR_INCOME_BONUS_DEFAULT,
      stakes: isProtected ? [] : zoneStakes.map((s) => ({ clanId: s.clan_id, clanName: s.clan_name, amount: Number(s.amount) })),
    });
  }
  return result;
}

// ===================== СТАВКА =====================

// actorVkId — тот, кто вводит команду; должен быть главой или замом клана.
// Деньги списываются из СЕЙФА КЛАНА (не с личного баланса), это коллективная казна на войну.
async function stake(actorVkId, zoneArg, rawAmount) {
  const player = await players.getPlayer(actorVkId);
  if (!player || !player.clan_id) return { ok: false, reason: 'not_in_clan' };
  if (player.clan_role !== 'leader' && player.clan_role !== 'deputy') {
    return { ok: false, reason: 'not_leader' };
  }

  const zoneDef = findZoneByName(zoneArg);
  if (!zoneDef) return { ok: false, reason: 'unknown_zone' };

  const amount = Math.floor(Number(rawAmount));
  if (!Number.isFinite(amount) || amount <= 0) return { ok: false, reason: 'invalid_amount' };

  if (!(await isEnabled())) return { ok: false, reason: 'war_disabled' };

  await zonesDb.ensureZoneRow(zoneDef.id);
  const state = await zonesDb.getZoneState(zoneDef.id);
  const now = new Date();
  if (state && state.protected_until && new Date(state.protected_until) > now) {
    return { ok: false, reason: 'zone_protected', protectedUntil: new Date(state.protected_until) };
  }

  // Лимит одновременного владения (ZONE_WAR_MAX_ZONES_PER_CLAN): не даём клану ставить в
  // ЕЩЁ ОДНУ зону, если он уже держит максимум — иначе клан либо зря сожжёт вирты из сейфа
  // на ставку, которая не сможет выиграть, либо (если бы мы это не проверяли на входе)
  // выиграл бы её в обход лимита. Ставки в зону, которой клан уже владеет (продление/защита
  // не даст здесь ничего, но это не тот случай — владеемые зоны и так под protected_until),
  // не задеваются этой проверкой.
  const activeOwned = await countActiveOwnedZones(player.clan_id);
  if (activeOwned >= C.ZONE_WAR_MAX_ZONES_PER_CLAN) {
    return { ok: false, reason: 'zone_cap_reached', max: C.ZONE_WAR_MAX_ZONES_PER_CLAN };
  }

  const clan = await clansDb.getClanById(player.clan_id);
  if (!clan || Number(clan.vault) < amount) {
    return { ok: false, reason: 'not_enough_vault', have: clan ? Number(clan.vault) : 0, need: amount };
  }

  const newVault = await clansDb.withdrawVault(player.clan_id, amount);
  if (newVault === null) {
    return { ok: false, reason: 'not_enough_vault', have: Number(clan.vault), need: amount };
  }

  const boost = await zonesDb.getBoost(player.clan_id);
  const multiplier =
    boost && boost.boost_until && new Date(boost.boost_until) > now ? Number(boost.multiplier) : 1;
  const effective = Math.round(amount * multiplier);

  const total = await zonesDb.addStake(zoneDef.id, player.clan_id, effective);
  await gameMeta.setMeta(META_MAP_CACHE_KEY, ''); // лидер по ставкам сменился — сбрасываем кэш карты

  return {
    ok: true,
    zone: zoneDef,
    spent: amount,
    effective,
    boosted: multiplier > 1,
    totalStake: Number(total),
    clanName: clan.name,
  };
}

// ===================== ПОДВЕДЕНИЕ ИТОГОВ ЦИКЛА =====================
// Вызывается из scheduler.js раз в сутки; сама решает, прошло ли ZONE_WAR_CYCLE_DAYS.
async function maybeResolveCycle(bot) {
  if (!(await isEnabled())) return { resolved: false };

  const { endsAt } = await getCycleInfo();
  if (new Date() < endsAt) return { resolved: false };

  const now = new Date();

  // Стартовый учёт зон "уже под защитой" на клан — это то, что реально ограничивает лимит
  // ZONE_WAR_MAX_ZONES_PER_CLAN. Зоны с истёкшей защитой в счёт не идут: они в этом же
  // проходе разыгрываются заново и могут сменить владельца. Счётчик растёт по ходу цикла,
  // когда мы тут же присуждаем очередную зону тому же клану — так лимит соблюдается и
  // внутри одного подведения итогов, а не только между циклами.
  const zoneCountByClan = new Map();
  const stateByZoneId = new Map();
  for (const zoneDef of C.ZONE_WAR_ZONES) {
    await zonesDb.ensureZoneRow(zoneDef.id);
    const state = await zonesDb.getZoneState(zoneDef.id);
    stateByZoneId.set(zoneDef.id, state);
    const isProtected = state && state.protected_until && new Date(state.protected_until) > now;
    if (isProtected && state.owner_clan_id) {
      zoneCountByClan.set(state.owner_clan_id, (zoneCountByClan.get(state.owner_clan_id) || 0) + 1);
    }
  }

  const captures = [];
  const capBlocked = []; // {zone, clanName, amount} — крупнейшая ставка, отклонённая из-за лимита

  for (const zoneDef of C.ZONE_WAR_ZONES) {
    const state = stateByZoneId.get(zoneDef.id);
    const isProtected = state && state.protected_until && new Date(state.protected_until) > now;
    if (isProtected) continue; // защищённые зоны в этом подведении итогов не участвуют

    const stakes = await zonesDb.getStakesForZone(zoneDef.id);
    if (!stakes.length) continue; // никто не ставил — зона остаётся как есть (или нейтральной)

    // Идём от крупнейшей ставки вниз, пропуская кланы, которые уже держат
    // ZONE_WAR_MAX_ZONES_PER_CLAN зон — им эта зона не достанется, даже если их ставка
    // была самой большой.
    let winner = null;
    for (const s of stakes) {
      const held = zoneCountByClan.get(s.clan_id) || 0;
      if (held >= C.ZONE_WAR_MAX_ZONES_PER_CLAN) {
        if (s === stakes[0]) capBlocked.push({ zone: zoneDef, clanId: s.clan_id, clanName: s.clan_name, amount: Number(s.amount) });
        continue;
      }
      winner = s;
      break;
    }

    await zonesDb.clearStakesForZone(zoneDef.id);
    if (!winner) continue; // все ставившие уже в лимите — зона остаётся ничьей до следующего цикла

    const protectedUntil = new Date(now.getTime() + C.ZONE_WAR_PROTECTION_DAYS * 24 * 60 * 60 * 1000);
    await zonesDb.setZoneOwner(zoneDef.id, winner.clan_id, protectedUntil);
    await zonesDb.logCapture(zoneDef.id, winner.clan_id, Number(winner.amount));

    zoneCountByClan.set(winner.clan_id, (zoneCountByClan.get(winner.clan_id) || 0) + 1);
    captures.push({ zone: zoneDef, clanId: winner.clan_id, clanName: winner.clan_name, amount: Number(winner.amount) });
  }

  await gameMeta.setMeta(META_CYCLE_STARTED_AT, new Date().toISOString());
  await gameMeta.setMeta(META_MAP_CACHE_KEY, ''); // сброс кэша карты — состав владельцев изменился

  if (bot) {
    for (const cap of captures) {
      try {
        const members = await clansDb.getClanMembers(cap.clanId);
        for (const m of members) {
          await bot
            .notifyUser(
              m.vk_id,
              `🚩 Клан «${cap.clanName}» захватил зону «${cap.zone.name}»! Вложено: ${cap.amount} вирт.\n` +
                `Защита от захвата: ${C.ZONE_WAR_PROTECTION_DAYS} дней. Бонус к доходу: +${Math.round(
                  C.ZONE_WAR_INCOME_BONUS_DEFAULT * 100
                )}% участникам клана.`
            )
            .catch(() => {});
        }
      } catch {
        // не роняем весь цикл из-за ошибки уведомления одного клана
      }
    }
    for (const blocked of capBlocked) {
      try {
        const members = await clansDb.getClanMembers(blocked.clanId);
        for (const m of members) {
          await bot
            .notifyUser(
              m.vk_id,
              `⚠️ Клан «${blocked.clanName}» вложил больше всех в зону «${blocked.zone.name}» (${blocked.amount} вирт), ` +
                `но клан уже владеет максимумом зон (${C.ZONE_WAR_MAX_ZONES_PER_CLAN}) — зона досталась другому клану или осталась ничьей.`
            )
            .catch(() => {});
        }
      } catch {
        // не критично, если не удалось уведомить
      }
    }
  }

  return { resolved: true, captures, capBlocked };
}

// ===================== БОНУС К ДОХОДУ (вызывается из economy.js: hourlyTick) =====================

async function getIncomeBonusPercentForClan(clanId) {
  if (!clanId) return 0;
  if (!(await isEnabled())) return 0;
  const owned = await zonesDb.getZonesOwnedByClan(clanId);
  const now = new Date();
  let total = 0;
  for (const row of owned) {
    if (row.protected_until && new Date(row.protected_until) <= now && !row.owner_clan_id) continue;
    const bonus =
      row.bonus_override !== null && row.bonus_override !== undefined
        ? Number(row.bonus_override)
        : C.ZONE_WAR_INCOME_BONUS_DEFAULT;
    total += bonus;
  }
  return total;
}

// ===================== АДМИН: БОНУС ЗОНЫ / ДОНАТ-БУСТ =====================

async function setZoneBonus(zoneArg, percentOrNull) {
  const zoneDef = findZoneByName(zoneArg);
  if (!zoneDef) return { ok: false, reason: 'unknown_zone' };
  await zonesDb.setZoneBonusOverride(zoneDef.id, percentOrNull);
  return { ok: true, zone: zoneDef };
}

// Донат: даёт клану временный множитель веса ставок в текущей войне. Сгорает сам —
// см. комментарий у C.ZONE_WAR_BOOST_DEFAULT_* в constants.js (это намеренная механика).
async function grantBoost(clanId, multiplier = C.ZONE_WAR_BOOST_DEFAULT_MULTIPLIER, days = C.ZONE_WAR_BOOST_DEFAULT_DAYS) {
  const boostUntil = new Date(Date.now() + days * 24 * 60 * 60 * 1000);
  await zonesDb.setBoost(clanId, multiplier, boostUntil);
  return { ok: true, multiplier, boostUntil };
}

// ВАЖНО: раньше здесь кэшировался сам vk-attachment ("photo-231991465_457239148") и
// переиспользовался для ВСЕХ последующих вызовов "зона", кем бы они ни были вызваны.
// Это баг: фото, полученное через photos.getMessagesUploadServer/saveMessagesPhoto,
// привязано к тому peer_id, для которого был выдан upload-тикет — VK не разрешает
// прицепить его к сообщению для ДРУГОГО peer_id и отвечает "Access denied"/"photo is
// undefined". На практике это значило: у игрока/чата, который первым вызвал "зона"
// после сброса кэша (см. setZoneOwner-подобные места ниже, где кэш обнуляется), карта
// показывалась; у всех остальных peer_id она молча падала в текстовый fallback — именно
// это и наблюдалось в проде.
//
// Чиним, кэшируя не attachment, а сам PNG (base64) — рендер (game/zoneMapRender.js через
// воркер-пул) стоит CPU и его правда не нужно повторять, пока состояние зон не менялось,
// а вот photos.getMessagesUploadServer/saveMessagesPhoto делаем КАЖДЫЙ раз заново, под
// актуальный peer_id вызывающего — это дешёвый сетевой вызов и другого пути с учётом
// peer-scoping у VK просто нет.
async function getCachedMapBuffer() {
  const v = await gameMeta.getMeta(META_MAP_CACHE_KEY);
  return v ? Buffer.from(v, 'base64') : null;
}

async function setCachedMapBuffer(buffer) {
  await gameMeta.setMeta(META_MAP_CACHE_KEY, buffer ? buffer.toString('base64') : '');
}

module.exports = {
  findZoneByName,
  isEnabled,
  setEnabled,
  getCycleInfo,
  getFullStatus,
  stake,
  maybeResolveCycle,
  getIncomeBonusPercentForClan,
  setZoneBonus,
  grantBoost,
  getCachedMapBuffer,
  setCachedMapBuffer,
};
