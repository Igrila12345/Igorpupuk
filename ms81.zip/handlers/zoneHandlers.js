'use strict';

const C = require('../game/constants');
const calc = require('../game/calc');
const zoneWar = require('../game/zoneWar');
const zonesDb = require('../db/zones');
const renderPool = require('../game/renderPool');
const { uploadPngAsMessagePhoto } = require('../utils/uploadImage');

function formatTimeLeft(untilDate) {
  const ms = new Date(untilDate).getTime() - Date.now();
  if (ms <= 0) return 'сейчас';
  const days = Math.floor(ms / (24 * 60 * 60 * 1000));
  const hours = Math.floor((ms % (24 * 60 * 60 * 1000)) / (60 * 60 * 1000));
  if (days > 0) return `${days} дн. ${hours} ч.`;
  return `${hours} ч.`;
}

function buildStatusText(zones, cycleInfo, enabled) {
  if (!enabled) {
    return '🗺️ Война кланов за зоны сейчас ВЫКЛЮЧЕНА администрацией.';
  }

  let text = `🗺️ ВОЙНА КЛАНОВ ЗА ЗОНЫ\nТекущий цикл ставок закроется через: ${formatTimeLeft(cycleInfo.endsAt)}\n\n`;

  for (const z of zones) {
    text += `📍 ${z.name} (+${Math.round(z.bonusPercent * 100)}% к доходу владельцу)\n`;
    if (z.ownerName) {
      text += `   👑 Владелец: «${z.ownerName}»`;
      text += z.isProtected ? ` (защита ещё ${formatTimeLeft(z.protectedUntil)})\n` : ` (защита истекла — зона в игре!)\n`;
    } else {
      text += `   ⚪ Ничья зона\n`;
    }
    if (!z.isProtected) {
      if (z.stakes.length) {
        const top = z.stakes.slice(0, 3);
        text += `   💰 Ставки сейчас: ${top.map((s) => `«${s.clanName}» ${calc.formatNumber(s.amount)}`).join(', ')}\n`;
      } else {
        text += `   💰 Ставок пока нет — !клан зона ${z.name} <сумма>\n`;
      }
    }
    text += '\n';
  }

  text += `🛑 Один клан не может владеть больше ${C.ZONE_WAR_MAX_ZONES_PER_CLAN} зонами из 9 одновременно. Подробнее: !помощь → «Война за зоны».`;

  return text.trim();
}

async function handleStatus(ctx) {
  const enabled = await zoneWar.isEnabled();
  const zones = await zoneWar.getFullStatus();
  const cycleInfo = await zoneWar.getCycleInfo();
  const text = buildStatusText(zones, cycleInfo, enabled);

  try {
    // Кэшируем только сам PNG (рендер не бесплатный), а не vk-attachment — фото,
    // загруженное для peer_id одного пользователя/чата, VK не даёт прицепить к
    // сообщению для другого peer_id (см. комментарий в game/zoneWar.js). Поэтому
    // upload делаем каждый раз заново, под ТЕКУЩИЙ ctx.peerId.
    let buffer = await zoneWar.getCachedMapBuffer();
    if (!buffer) {
      buffer = await renderPool.renderZoneMap(zones, cycleInfo);
      await zoneWar.setCachedMapBuffer(buffer);
    }
    const attachment = await uploadPngAsMessagePhoto(ctx.bot.vk, buffer, ctx.peerId);
    await ctx.send({ message: text, attachment });
  } catch (err) {
    console.error('[Zones] Не удалось отрисовать/загрузить карту, отправляю текстом:', err);
    await ctx.send(text);
  }
}

async function handleHistory(ctx) {
  const rows = await zonesDb.getRecentHistory(15);
  if (!rows.length) {
    await ctx.send('🗺️ Пока ни одна зона не была захвачена.');
    return;
  }
  const zoneNameById = new Map(C.ZONE_WAR_ZONES.map((z) => [z.id, z.name]));
  let text = '🗺️ ИСТОРИЯ ЗАХВАТОВ ЗОН\n\n';
  for (const r of rows) {
    const dateStr = new Date(r.captured_at).toLocaleString('ru-RU', { timeZone: 'Europe/Moscow' });
    text += `${dateStr} — «${r.clan_name || 'неизвестный клан'}» захватил «${zoneNameById.get(r.zone_id) || r.zone_id}» (${calc.formatNumber(
      Number(r.amount)
    )} вирт)\n`;
  }
  await ctx.send(text.trim());
}

module.exports = { handleStatus, handleHistory };
