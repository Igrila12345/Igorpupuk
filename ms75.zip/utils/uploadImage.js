'use strict';

const fs = require('fs');
const os = require('os');
const path = require('path');
const crypto = require('crypto');
const asyncLock = require('../game/asyncLock');

const PNG_SIGNATURE = Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]);

// Сколько раз пробовать загрузку и с какой паузой между попытками. VK периодически
// отвечает "Bad Gateway"/502 на upload-сервере — это временный сбой на стороне VK,
// не ошибка данных, поэтому просто повторяем запрос ещё несколько раз перед тем,
// как окончательно откатиться на текстовый вариант раунда.
const UPLOAD_RETRIES = 3;
const UPLOAD_RETRY_DELAY_MS = 1000;

function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

function isRetryableUploadError(err) {
  const msg = String((err && err.message) || err || '');
  return (
    /bad gateway/i.test(msg) ||
    /502|503|504/.test(msg) ||
    /ETIMEDOUT|ECONNRESET|ECONNREFUSED|ENOTFOUND|EAI_AGAIN/.test(msg) ||
    // VK API код 100 "photo is undefined" при photos.saveMessagesPhoto: upload-сервер
    // принял файл (server/hash в ответе реальные), но сам photo пуст — временный сбой
    // сохранения на стороне VK, повтор обычно проходит.
    /photo is undefined/i.test(msg) ||
    // VK API код 200 "Access denied" на photos.saveMessagesPhoto — почти всегда значит,
    // что hash/server из getMessagesUploadServer для этого peer_id уже "протух", потому
    // что для того же peer_id почти одновременно был запрошен ДРУГОЙ upload-тикет (см.
    // блокировку per-peer ниже — она устраняет первопричину, а этот retry подстраховывает
    // на случай гонки с чем-то вне нашего контроля, например другим процессом бота).
    (err && err.code === 200 && /access denied/i.test(msg))
  );
}

// Пишем PNG-буфер во временный файл и грузим в VK по пути (File Path source).
// Так надёжнее, чем передавать буфер напрямую: этот путь загрузки в vk-io
// самый простой и предсказуемый (без form-data/Blob-нюансов на стороне
// буферов/потоков), а заодно тут проверяем, что буфер действительно похож
// на валидный PNG — если рендер вернул пустоту/мусор, мы узнаем об этом
// сразу по логу, а не по невнятной ошибке VK "photo is undefined".
//
// Загрузка сфотографии для ОДНОГО peer_id сериализована через asyncLock: у VK тикет
// (server+hash), выданный photos.getMessagesUploadServer, привязан к peer_id, и если для
// того же peer_id почти одновременно запросить второй тикет (игрок дважды тапнул кнопку,
// либо параллельно рендерятся два разных мини-игры — работа/инспекция/карта зон), более
// ранний тикет становится недействительным. Это и даёт вперемешку "photo is undefined"
// (код 100) на упавшем сохранении и "Access denied" (код 200) на втором конкурентном
// сохранении. Лок по peerId гарантирует, что для одного игрока в любой момент времени
// идёт не больше одной загрузки фото, независимо от того, из какого хендлера она пришла.
async function uploadPngAsMessagePhoto(vk, buffer, peerId) {
  return asyncLock.withLock(`photo-upload:${peerId}`, () => uploadPngAsMessagePhotoLocked(vk, buffer, peerId));
}

async function uploadPngAsMessagePhotoLocked(vk, buffer, peerId) {
  if (!Buffer.isBuffer(buffer) || buffer.length === 0) {
    throw new Error(`[uploadImage] Пустой буфер изображения (length=${buffer ? buffer.length : 'null'})`);
  }
  if (!buffer.subarray(0, 8).equals(PNG_SIGNATURE)) {
    throw new Error(`[uploadImage] Буфер не похож на PNG (первые байты: ${buffer.subarray(0, 8).toString('hex')})`);
  }

  const tmpPath = path.join(os.tmpdir(), `round-${crypto.randomBytes(6).toString('hex')}.png`);
  await fs.promises.writeFile(tmpPath, buffer);

  try {
    let lastErr;
    for (let attempt = 1; attempt <= UPLOAD_RETRIES; attempt++) {
      try {
        return await vk.upload.messagePhoto({
          source: { value: tmpPath },
          peer_id: peerId,
        });
      } catch (err) {
        lastErr = err;
        if (attempt < UPLOAD_RETRIES && isRetryableUploadError(err)) {
          console.warn(
            `[uploadImage] Попытка ${attempt}/${UPLOAD_RETRIES} не удалась (${err.message}), повтор через ${UPLOAD_RETRY_DELAY_MS}мс...`
          );
          await sleep(UPLOAD_RETRY_DELAY_MS);
          continue;
        }
        throw err;
      }
    }
    throw lastErr;
  } finally {
    fs.promises.unlink(tmpPath).catch(() => {});
  }
}

module.exports = { uploadPngAsMessagePhoto };
