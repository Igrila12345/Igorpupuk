'use strict';
const test=require('node:test'),assert=require('node:assert/strict');
const C=require('../src/core.js');
const mk=(uid,name)=>{const S=C.newGame({uid,name});C.spawnCompanions(S.loc);C.syncLots(S);return S;};
test('shared world: lot from A can be bought by B, A is paid through mailbox',()=>{
  const w=C.newWorld();
  const A=mk('vk1','Alice'),B=mk('vk2','Bob');
  const i=A.inv.findIndex(x=>x.k==='ore:1');
  const r=C.OPS.listLot(A,i,10,4);assert.ok(r.ok,r.err);
  assert.equal(A.lots.length,1);
  const lot=w.market.find(l=>l.owner==='vk1');assert.ok(lot);
  assert.equal(lot.tax,5);
  B.credits=1000;
  const b=C.OPS.buyLot(B,lot.id);assert.ok(b.ok,b.err);
  assert.equal(B.credits,1000-40);
  assert.ok(C.OPS.buyLot(B,lot.id).err,'lot is gone');
  const before=A.credits;C.catchUp(A,Date.now());
  assert.equal(Math.round((A.credits-before)*100)/100,38);
  assert.equal(A.lots.length,0);
});
test('cannot buy own lot',()=>{
  const w=C.newWorld();const A=mk('vk1','Alice');
  C.OPS.listLot(A,A.inv.findIndex(x=>x.k==='ore:1'),5,4);
  const lot=w.market.find(l=>l.owner==='vk1');A.credits=1e6;
  assert.match(C.OPS.buyLot(A,lot.id).err,/ваш лот/);
});
test('expired lot returns items to owner',()=>{
  const w=C.newWorld();const A=mk('vk1','Alice');
  const n0=C.countKey(A,'ore:1');
  C.OPS.listLot(A,A.inv.findIndex(x=>x.k==='ore:1'),10,4);
  assert.equal(C.countKey(A,'ore:1'),n0-10);
  w.market.find(l=>l.owner==='vk1').exp=Date.now()-1;
  C.catchUp(A,Date.now());
  assert.equal(C.countKey(A,'ore:1'),n0);assert.equal(A.lots.length,0);
});
test('world step sells player lots by bot buyers through mailbox (only when bots are enabled)',()=>{
  const w=C.newWorld(Date.now(),{bots:true});const A=mk('vk1','Alice');
  C.OPS.listLot(A,A.inv.findIndex(x=>x.k==='ore:1'),10,1);
  const orig=Math.random;Math.random=()=>0.0001;
  try{C.worldCatchUp(Date.now()+10*60000);}finally{Math.random=orig;}
  assert.ok((w.mailbox.vk1||[]).length>=1,'mail delivered');
  const b=A.credits;C.catchUp(A,Date.now()+10*60000);assert.ok(A.credits>b);
});
test('with bots enabled captains spawn next to the player',()=>{
  const w=C.newWorld(Date.now(),{bots:true});const A=mk('vk1','Alice');
  assert.ok(C.crewAt(A,A.loc.t,A.loc.s).length>=3);
});
test('promo totals are global across players',()=>{
  C.newWorld();const A=mk('a','A'),B=mk('b','B');
  const g=C.PROMOS.FIRST1;g.uses_total=1;
  A.xp=B.xp=100;
  assert.ok(C.OPS.redeem(A,'FIRST1').ok);
  assert.match(C.OPS.redeem(B,'FIRST1').err,/Лимит/);
  g.uses_total=1;
});
test('ops whitelist has no dev/reset',()=>{
  assert.equal(C.OPS.dev,undefined);assert.equal(C.OPS.reset,undefined);
  assert.ok(C.OPS.doScan&&C.OPS.buyLot&&C.OPS.redeem);
});
test('top hides dev/admin (local world)',()=>{
  C.newWorld();const S=mk('a','A');S.is_dev=true;
  const t=C.top(S,'bal',50);assert.ok(!t.rows.some(p=>p.me||p.is_dev||p.is_admin));
});

test('default world has no bots: no captains, no bot lots, lots are not sold by bots',()=>{
  const w=C.newWorld();
  assert.equal(w.bots,false);assert.equal(w.npcs.length,0);assert.equal(w.market.length,0);
  const A=mk('vk1','Alice');
  assert.equal(C.crewAt(A,A.loc.t,A.loc.s).length,0);
  C.OPS.listLot(A,A.inv.findIndex(x=>x.k==='ore:1'),10,1);
  const orig=Math.random;Math.random=()=>0.0001;
  try{C.worldCatchUp(Date.now()+30*60000);}finally{Math.random=orig;}
  assert.equal((w.mailbox.vk1||[]).length,0,'no bot buyer');
  assert.equal(w.market.filter(l=>!l.owner).length,0,'no bot lots appear');
  assert.equal(w.market.filter(l=>l.owner==='vk1').length,1,'player lot still on the market');
  const t=C.top(A,'bal',50);assert.equal(t.rows.length,1);assert.ok(t.rows[0].me);
});
test('setBots(false) strips bots from an old world',()=>{
  const w=C.newWorld(Date.now(),{bots:true});
  assert.ok(w.npcs.length>0&&w.market.length>0);
  const A=mk('vk1','Alice');C.OPS.listLot(A,A.inv.findIndex(x=>x.k==='ore:1'),5,4);
  C.setBots(false);
  assert.equal(w.npcs.length,0);assert.equal(w.market.filter(l=>!l.owner).length,0);
  assert.equal(w.market.filter(l=>l.owner).length,1,'real lots are kept');
});

test('selling a building returns 25% of everything invested and frees the slot',()=>{
  C.newWorld();const S=mk('vk1','A');S.credits=1e7;
  const t=S.loc.t;
  assert.ok(C.OPS.build(S,0,'mine').ok);
  const b0=C.slots(S,t,S.loc.s)[0];assert.equal(b0.spent,5000,'first level costs 5000');
  const c2=C.buildCost(S,'mine',2,t);
  assert.ok(C.OPS.upBld(S,0).ok);
  assert.equal(Math.round(b0.spent),Math.round(5000+c2),'spent accumulates every upgrade');
  const before=S.credits,expected=Math.floor(b0.spent*0.25);
  const r=C.OPS.sellBld(S,0);
  assert.ok(r.ok);assert.equal(r.refund,expected);assert.equal(S.credits,before+expected);
  assert.equal(C.slots(S,t,S.loc.s)[0],null,'slot is free');
  assert.ok(C.OPS.build(S,0,'trade').ok,'a different building can be built in its place');
  assert.match(C.OPS.sellBld(S,2).err,/пуст/);
});
test('building resale: never profitable, blocked in flight, legacy buildings are estimated',()=>{
  C.newWorld();const S=mk('vk2','B');S.credits=1e9;
  const start=S.credits;C.OPS.build(S,0,'lab');C.OPS.sellBld(S,0);
  assert.ok(S.credits<start,'build then sell always loses money');
  assert.equal(Math.round(start-S.credits),Math.round(C.buildCost(S,'lab',1,S.loc.t)*0.75));
  const sl=C.slots(S,S.loc.t,S.loc.s);sl[1]={type:'mine',level:5};   // здание из старого сохранения без spent
  const est=C.sellRefund(sl[1],S.loc.t);
  let sum=0;for(let l=1;l<=5;l++)sum+=100*50*Math.pow(l,2.7)*C.Loc.P(S.loc.t);
  assert.equal(est,Math.floor(sum*0.25));
  S.travel={to:{t:0,s:1},from:S.loc,start:1,end:Date.now()+9e6,dist:1};
  assert.match(C.OPS.sellBld(S,1).err,/в пути/);
});
