'use strict';

const C = require('./constants');
const calc = require('./calc');
const players = require('../db/players');
const auctionsDb = require('../db/auctions');
const production = require('./production');

const FACTORY_KEY = 'FACTORY';
const FACTORY_DISPLAY_NAME = 'Завод';
const FACTORY_ALIASES = ['завод', 'заводы', 'завода', 'заводов', 'фабрика', 'фабрики'];

const SCIENCE_KEY = 'SCIENCE';
const SCIENCE_DISPLAY_NAME = 'Научный центр';
const SCIENCE_ALIASES = ['наука', 'научный', 'научныйцентр', 'нц', 'центр'];

// Донат-товары — не хранятся в инвентаре игрока/админа, создаются лотом "из воздуха"
// (только админ может их выставлять — см. handleCreate → isAdmin). При продаже победитель
// получает соответствующий бонус напрямую (см. grantDonateItem), а не предмет в арсенал.
// quantity для vip/miner — это количество ДНЕЙ, для superrobot — количество УРОВНЕЙ.
const VIP_KEY = 'VIP';
const VIP_DISPLAY_NAME = 'VIP-статус (дней)';
const VIP_ALIASES = ['vip', 'вип'];

const MINER_KEY = 'MINER';
const MINER_DISPLAY_NAME = 'Майнер (дней)';
const MINER_ALIASES = ['майнер', 'miner'];

const SUPERROBOT_KEY = 'SUPERROBOT';
const SUPERROBOT_DISPLAY_NAME = 'Суперробот (уровней)';
const SUPERROBOT_ALIASES = ['суперробот', 'sr'];

function isDonateItemType(type) {
  return type === 'vip' || type === 'miner' || type === 'superrobot';
}

function findItem(itemName) {
  const lower = itemName.toLowerCase();
  const weaponKey = Object.keys(C.WEAPONS).find((k) => k.toLowerCase() === lower);
  if (weaponKey) return { type: 'weapon', key: weaponKey };
  const adKey = Object.keys(C.AIR_DEFENSE).find((k) => k.toLowerCase() === lower);
  if (adKey) return { type: 'air_defense', key: adKey };
  if (FACTORY_ALIASES.includes(lower)) return { type: 'factory', key: FACTORY_KEY, displayName: FACTORY_DISPLAY_NAME };
  if (SCIENCE_ALIASES.includes(lower)) return { type: 'science', key: SCIENCE_KEY, displayName: SCIENCE_DISPLAY_NAME };
  if (VIP_ALIASES.includes(lower)) return { type: 'vip', key: VIP_KEY, displayName: VIP_DISPLAY_NAME };
  if (MINER_ALIASES.includes(lower)) return { type: 'miner', key: MINER_KEY, displayName: MINER_DISPLAY_NAME };
  if (SUPERROBOT_ALIASES.includes(lower))
    return { type: 'superrobot', key: SUPERROBOT_KEY, displayName: SUPERROBOT_DISPLAY_NAME };
  return null;
}

// Список продаваемых категорий — используется в подсказке команды "продать"
function listSellableTypes() {
  return {
    weapons: Object.keys(C.WEAPONS),
    airDefense: Object.keys(C.AIR_DEFENSE),
    factory: FACTORY_ALIASES[0],
    science: SCIENCE_ALIASES[0],
    donate: [VIP_ALIASES[0], MINER_ALIASES[0], SUPERROBOT_ALIASES[0]],
  };
}

// Сколько обычных (не золотых, не заблокированных, не занятых производством) заводов
// игрок может выставить на аукцион — золотые жилы и занятые заводы не продаются.
async function getSellableFactories(vkId, player) {
  const freeFactories = await production.getFreeFactories(vkId);
  const nonGold = Math.max((player.factories || 0) - (player.gold_mine_count || 0), 0);
  return Math.min(freeFactories, nonGold);
}

async function createLot(vkId, itemName, quantity, startPrice, minStep, durationHours) {
  const player = await players.getPlayer(vkId);
  if (!player) return { ok: false, reason: 'not_registered' };

  const item = findItem(itemName);
  if (!item) return { ok: false, reason: 'unknown_item' };

  if (!Number.isInteger(quantity) || quantity <= 0) return { ok: false, reason: 'invalid_quantity' };
  if (!Number.isInteger(startPrice) || startPrice <= 0) return { ok: false, reason: 'invalid_price' };
  if (!Number.isInteger(minStep) || minStep <= 0) return { ok: false, reason: 'invalid_step' };
  if (!Number.isFinite(durationHours) || durationHours <= 0 || durationHours > C.AUCTION_MAX_DURATION_HOURS) {
    return { ok: false, reason: 'invalid_duration', max: C.AUCTION_MAX_DURATION_HOURS };
  }

  let owned;
  if (item.type === 'weapon') owned = player.arsenal[item.key] || 0;
  else if (item.type === 'air_defense') owned = player.air_defense[item.key] || 0;
  else if (item.type === 'science') owned = player.science_centers || 0;
  else if (item.type === 'factory') owned = await getSellableFactories(vkId, player);
  // Донат-товары (vip/miner/superrobot): владение не проверяется — админ создаёт лот "из воздуха",
  // ничего не списывая ни с чьего аккаунта. Выдача происходит только победителю торгов.
  else owned = quantity;

  if (owned < quantity) {
    return { ok: false, reason: 'not_enough_items', have: owned };
  }

  // Забираем предмет на эскроу аукциона (для донат-товаров списывать нечего — см. выше)
  if (item.type === 'weapon') {
    await players.addToArsenal(vkId, item.key, -quantity);
  } else if (item.type === 'air_defense') {
    await players.addToAirDefense(vkId, item.key, -quantity);
  } else if (item.type === 'science') {
    await players.addScienceCenters(vkId, -quantity);
  } else if (item.type === 'factory') {
    await players.addFactories(vkId, -quantity, false);
  }

  const displayName =
    item.type === 'factory' || item.type === 'science' || isDonateItemType(item.type) ? item.displayName : item.key;
  const endTime = new Date(Date.now() + durationHours * 60 * 60 * 1000);
  const auction = await auctionsDb.createAuction(
    vkId,
    item.type,
    displayName,
    quantity,
    startPrice,
    minStep,
    endTime
  );

  return { ok: true, auction };
}

async function placeBid(vkId, auctionId, amount, bot) {
  const player = await players.getPlayer(vkId);
  if (!player) return { ok: false, reason: 'not_registered' };

  const auction = await auctionsDb.getAuctionById(auctionId);
  if (!auction || auction.status !== 'active') return { ok: false, reason: 'not_found' };
  if (new Date(auction.end_time) <= new Date()) return { ok: false, reason: 'ended' };
  if (auction.seller_id === vkId) return { ok: false, reason: 'own_lot' };

  const minRequired = auction.current_bid
    ? Number(auction.current_bid) + Number(auction.min_step)
    : Number(auction.start_price);

  if (!Number.isInteger(amount) || amount < minRequired) {
    return { ok: false, reason: 'bid_too_low', minRequired };
  }

  if (Number(player.balance) < amount) {
    return { ok: false, reason: 'not_enough_money', missing: amount - Number(player.balance) };
  }

  // Списываем ставку сразу (эскроу), возвращаем предыдущему ставившему
  await players.updateBalance(vkId, -amount);
  if (auction.current_bidder_id) {
    const refunded = Number(auction.current_bid);
    await players.updateBalance(auction.current_bidder_id, refunded);
    if (bot) {
      await bot
        .notifyUser(
          auction.current_bidder_id,
          `🔔 Тебя перебили на лоте №${auction.id} («${auction.item_name} x${auction.quantity}»). ` +
            `Тебе вернули ${calc.formatNumber(refunded)} вирт.`
        )
        .catch(() => {});
    }
  }

  let newEndTime = auction.end_time;
  const msLeft = new Date(auction.end_time).getTime() - Date.now();
  if (msLeft < C.AUCTION_EXTEND_WINDOW_MS) {
    newEndTime = new Date(Date.now() + C.AUCTION_EXTEND_BY_MS);
  }

  const updated = await auctionsDb.placeBid(auctionId, vkId, amount, newEndTime);
  return { ok: true, auction: updated, extended: newEndTime !== auction.end_time };
}

async function cancelLot(vkId, auctionId) {
  const auction = await auctionsDb.getAuctionById(auctionId);
  if (!auction || auction.status !== 'active') return { ok: false, reason: 'not_found' };
  if (auction.seller_id !== vkId) return { ok: false, reason: 'not_owner' };
  if (auction.current_bidder_id) return { ok: false, reason: 'has_bids' };

  await auctionsDb.setStatus(auctionId, 'cancelled');
  // Донат-товары ничего не списывали при выставлении — возвращать нечего.
  if (!isDonateItemType(auction.item_type)) {
    await returnItemToPlayer(vkId, auction);
  }

  return { ok: true, auction };
}

// Возврат/зачисление ОБЫЧНОГО (инвентарного) предмета лота игроку — используется и при отмене,
// и при возврате продавцу, если лот истёк без ставок. Для донат-товаров (vip/miner/superrobot)
// не вызывается — см. grantDonateItem ниже.
async function returnItemToPlayer(vkId, auction) {
  if (auction.item_type === 'weapon') {
    await players.addToArsenal(vkId, auction.item_name, auction.quantity);
  } else if (auction.item_type === 'air_defense') {
    await players.addToAirDefense(vkId, auction.item_name, auction.quantity);
  } else if (auction.item_type === 'factory') {
    await players.addFactories(vkId, auction.quantity, false);
  } else if (auction.item_type === 'science') {
    await players.addScienceCenters(vkId, auction.quantity);
  }
}

// Выдача донат-бонуса ПОБЕДИТЕЛЮ торгов (вызывается только при реальной продаже — не при отмене
// и не при отсутствии ставок, так как ничего не списывалось и возвращать/выдавать некому).
async function grantDonateItem(vkId, auction) {
  const player = await players.getPlayer(vkId);
  if (!player) return;
  const now = new Date();

  if (auction.item_type === 'vip') {
    const base = player.vip_until && new Date(player.vip_until) > now ? new Date(player.vip_until) : now;
    await players.setVipUntil(vkId, new Date(base.getTime() + auction.quantity * 24 * 60 * 60 * 1000));
  } else if (auction.item_type === 'miner') {
    const base = player.miner_until && new Date(player.miner_until) > now ? new Date(player.miner_until) : now;
    await players.setMinerUntil(vkId, new Date(base.getTime() + auction.quantity * 24 * 60 * 60 * 1000));
  } else if (auction.item_type === 'superrobot') {
    const newLevel = Math.min((player.super_robot_level || 0) + auction.quantity, C.SUPER_ROBOT_MAX_LEVEL);
    await players.setSuperRobotLevel(vkId, newLevel);
  }
}

// Обработка истёкших лотов: вызывается по расписанию
async function resolveExpiredAuctions(bot) {
  const due = await auctionsDb.getDueAuctions();
  for (const auction of due) {
    if (auction.current_bidder_id) {
      const commission = Math.round(Number(auction.current_bid) * C.AUCTION_COMMISSION_RATE);
      const payout = Number(auction.current_bid) - commission;
      await players.updateBalance(auction.seller_id, payout);
      if (isDonateItemType(auction.item_type)) {
        await grantDonateItem(auction.current_bidder_id, auction);
      } else {
        await returnItemToPlayer(auction.current_bidder_id, auction);
      }

      if (bot) {
        await bot
          .notifyUser(
            auction.seller_id,
            `🛎️ Ваш лот «${auction.item_name} x${auction.quantity}» продан за ${auction.current_bid} вирт (комиссия ${commission}). Зачислено: ${payout} вирт.`
          )
          .catch(() => {});
        await bot
          .notifyUser(
            auction.current_bidder_id,
            `🎉 Вы выиграли аукцион! «${auction.item_name} x${auction.quantity}» зачислено вам.`
          )
          .catch(() => {});
      }
    } else {
      // Никто не поставил ставку. Для обычных товаров — возвращаем продавцу.
      // Для донат-товаров при выставлении ничего не списывалось — возвращать нечего, лот просто истекает.
      if (!isDonateItemType(auction.item_type)) {
        await returnItemToPlayer(auction.seller_id, auction);
      }

      if (bot) {
        await bot
          .notifyUser(
            auction.seller_id,
            `📦 Аукцион «${auction.item_name} x${auction.quantity}» завершился без ставок. ${
              isDonateItemType(auction.item_type) ? 'Лот снят.' : 'Товар возвращён вам.'
            }`
          )
          .catch(() => {});
      }
    }
    await auctionsDb.setStatus(auction.id, 'completed');
  }
  return due;
}

module.exports = { createLot, placeBid, cancelLot, resolveExpiredAuctions, findItem, listSellableTypes };
