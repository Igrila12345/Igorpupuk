'use strict';

const parse = require('../utils/parse');
const profile = require('./profile');
const economyHandlers = require('./economyHandlers');
const productionHandlers = require('./productionHandlers');
const shopHandlers = require('./shopHandlers');
const combatHandlers = require('./combatHandlers');
const clanHandlers = require('./clanHandlers');
const ratingHandlers = require('./ratingHandlers');
const adminHandlers = require('./adminHandlers');
const robotHandlers = require('./robotHandlers');
const superRobotHandlers = require('./superRobotHandlers');
const minerHandlers = require('./minerHandlers');
const farmHandlers = require('./farmHandlers');
const workHandlers = require('./workHandlers');
const warehouseHandlers = require('./warehouseHandlers');
const scienceHandlers = require('./scienceHandlers');
const limitHandlers = require('./limitHandlers');
const auctionHandlers = require('./auctionHandlers');
const promoHandlers = require('./promoHandlers');
const donateHandlers = require('./donateHandlers');
const patrolHandlers = require('./patrolHandlers');
const eventHandlers = require('./eventHandlers');
const players = require('../db/players');
const C = require('../game/constants');

// Кулдаун между командами одного игрока (в памяти процесса)
const lastCommandAt = new Map();

function isOnCommandCooldown(vkId) {
  const now = Date.now();
  const last = lastCommandAt.get(vkId);
  if (last && now - last < C.COMMAND_COOLDOWN_MS) {
    return C.COMMAND_COOLDOWN_MS - (now - last);
  }
  lastCommandAt.set(vkId, now);
  return 0;
}

// Разрешаем вызывать команды и без "!" — по алиасам ключевых слов.
// В беседах (не ЛС) это особенно важно: реагируем только на точное совпадение
// первого слова с известной командой, остальной текст беседы игнорируем.
const COMMAND_ALIASES = {
  начать: 'старт',
  начало: 'старт',
  старт: 'старт',
  регистрация: 'старт',
  команды: 'помощь',
  помощь: 'помощь',
  справка: 'помощь',
  правила: 'помощь',
  питомец: 'робот',
  работать: 'работа',
  склады: 'склад',
  баланс: 'профиль',
  инвентарь: 'арсенал',
  атаковать: 'атака',
  переименовка: 'переименовать',
  донат: 'донат',
  прайс: 'донат',
  цены: 'донат',
  ценник: 'донат',
  оплата: 'донат',
  патруль: 'дозор',
  ивенты: 'ивент',
  событие: 'ивент',
  майнингферма: 'ферма',
};

const KNOWN_COMMANDS = new Set([
  'старт',
  'профиль',
  'переименовать',
  'построить',
  'бонус',
  'перевод',
  'магазин',
  'купить',
  'арсенал',
  'атака',
  'разведка',
  'произвести',
  'производство',
  'забрать',
  'разблокировать',
  'топ',
  'помощь',
  'гайд',
  'админ',
  'клан',
  'робот',
  'роботы',
  'суперробот',
  'суперроботы',
  'майнер',
  'отправить',
  'мой',
  'работа',
  'склад',
  'выбрать',
  'наука',
  'лимит',
  'аукцион',
  'продать',
  'ставка',
  'отмена',
  'лоты',
  'промо',
  'обменять',
  'оружие',
  'вооружение',
  'уведомления',
  'донат',
  'дозор',
  'ивент',
  'ферма',
]);

function isPrivateMessage(ctx) {
  // В VK личные сообщения имеют peer_id, равный user_id (< 2e9), беседы >= 2e9
  return ctx.peerId && ctx.peerId < 2000000000;
}

async function resolveMentionToId(text, tokens, index) {
  const token = tokens[index];
  if (!token) return null;
  let id = parse.extractMentionId(token);
  if (id) return id;

  // Возможно, это упоминание с пробелом в имени [id123|Имя Фамилия] — ищем в исходном тексте
  id = parse.findMentionInText(text);
  return id;
}

async function dispatch(ctx) {
  // ===== ЗАЩИТА ОТ ВЫПОЛНЕНИЯ "СТАРЫХ"/ЧУЖИХ СООБЩЕНИЙ КАК КОМАНД =====
  // Раньше здесь была только проверка на service-события (ctx.action). Как показала практика,
  // этого недостаточно: при закреплении сообщения VK всё равно может прислать апдейт,
  // который дальше по цепочке доходит до текста старого сообщения (например, "Построить 5",
  // отправленного 13 минут назад другим игроком), и бот выполняет его как только что введённую
  // команду. Поэтому теперь двойная защита:
  //
  // 1) Если апдейт помечен как служебное действие (закреп/откреп/кик/приглашение/смена
  //    названия беседы и т.п.) — независимо от того, как именно это поле называется в
  //    конкретной версии библиотеки, — игнорируем его.
  const rawPayload = (ctx.state && ctx.state.payload) || ctx.payload || {};
  const looksLikeServiceEvent = !!ctx.action || !!rawPayload.action;
  if (looksLikeServiceEvent) {
    console.log(
      `[Dispatcher] Пропущено служебное событие (закреп/кик/и т.п.) от senderId=${ctx.senderId}, peer=${ctx.peerId}`
    );
    return;
  }

  // 2) Главная защита: сообщение обязано быть СВЕЖИМ. Если время самого сообщения
  //    (message.date на стороне VK) старше разумного порога — это не живой ввод команды
  //    прямо сейчас, чем бы он ни был вызван (закреп, пересылка, повторная доставка апдейта
  //    и т.п.), и его нельзя исполнять. Единственная категория апдейтов, у которых
  //    createdAt может отсутствовать, — это клики по инлайн-кнопкам без обычного текста;
  //    для них проверка ниже просто не сработает (age будет 0/NaN и пропустится).
  const createdAtSec = typeof ctx.createdAt === 'number' ? ctx.createdAt : null;
  if (createdAtSec) {
    const ageMs = Date.now() - createdAtSec * 1000;
    if (ageMs > C.MAX_COMMAND_MESSAGE_AGE_MS) {
      console.log(
        `[Dispatcher] Пропущено устаревшее сообщение (возраст ${Math.round(ageMs / 1000)} сек) от senderId=${ctx.senderId}, текст="${(ctx.text || '').slice(0, 50)}"`
      );
      return;
    }
  }

  // Клики по инлайн-кнопкам мини-игры "работа" приходят с payload и обрабатываются
  // отдельно от текстовых команд (и без общего кулдауна команд — раунды короткие).
  const payload = ctx.messagePayload;
  if (payload && payload.cmd === 'work_pick') {
    return await workHandlers.handleWorkPick(ctx, payload.box, payload.round);
  }
  if (payload && payload.cmd === 'work_start') {
    return await workHandlers.handleWork(ctx);
  }
  if (payload && payload.cmd === 'help_section') {
    return await ratingHandlers.handleHelpSection(ctx, payload.section);
  }
  if (payload && payload.cmd === 'exchange_factory') {
    return await warehouseHandlers.handleExchangeFactory(ctx);
  }
  if (payload && payload.cmd === 'warehouse_show') {
    return await warehouseHandlers.handleShow(ctx);
  }
  if (payload && payload.cmd === 'farm_status') {
    return await farmHandlers.handleStatus(ctx);
  }
  if (payload && payload.cmd === 'farm_upgrade') {
    return await farmHandlers.handleUpgrade(ctx);
  }
  if (payload && payload.cmd === 'farm_enable') {
    return await farmHandlers.handleEnable(ctx);
  }
  if (payload && payload.cmd === 'farm_disable') {
    return await farmHandlers.handleDisable(ctx);
  }
  if (payload && payload.cmd === 'farm_withdraw') {
    return await farmHandlers.handleWithdraw(ctx);
  }
  if (payload && payload.cmd === 'farm_sell') {
    return await farmHandlers.handleSellPrompt(ctx);
  }
  if (payload && payload.cmd === 'farm_info') {
    return await farmHandlers.handleInfo(ctx);
  }
  if (payload && payload.cmd === 'farm_home') {
    return await ratingHandlers.handleHelp(ctx);
  }

  const text = (ctx.text || '').trim();
  if (!text) return;

  // Ввод названия государства при регистрации перехватываем только в ЛС,
  // чтобы обычные сообщения в беседе не ломали чужую регистрацию.
  if (isPrivateMessage(ctx)) {
    const handledName = await profile.handleNameInput(ctx);
    if (handledName) return;
  }

  const tokens = parse.splitArgs(text);
  let rawCommand = tokens[0].toLowerCase();
  if (rawCommand.startsWith('!')) rawCommand = rawCommand.slice(1);
  const normalized = COMMAND_ALIASES[rawCommand] || rawCommand;

  // И в ЛС, и в беседах реагируем только на точное совпадение с известной командой —
  // так бот не отвечает на посторонние сообщения в общем чате.
  if (!KNOWN_COMMANDS.has(normalized)) return;

  const remainingCooldownMs = isOnCommandCooldown(ctx.senderId);
  if (remainingCooldownMs > 0) {
    await ctx.send(`⏳ Не так быстро! Подождите ${(remainingCooldownMs / 1000).toFixed(1)} сек. между командами.`);
    return;
  }

  const command = '!' + normalized;

  try {
    switch (command) {
      case '!старт':
        return await profile.handleStart(ctx);

      case '!профиль': {
        const targetId = await resolveMentionToId(text, tokens, 1);
        return await profile.handleProfile(ctx, targetId);
      }

      case '!переименовать': {
        const newName = tokens.slice(1).join(' ');
        return await profile.handleRename(ctx, newName);
      }

      case '!построить':
        return await economyHandlers.handleBuild(ctx, tokens[1]);

      case '!бонус':
        return await economyHandlers.handleDailyBonus(ctx);

      case '!перевод': {
        const targetId = await resolveMentionToId(text, tokens, 1);
        const rest = tokens.slice(2);
        const amountArg = rest[rest.length - 1];
        return await economyHandlers.handleTransfer(ctx, targetId, amountArg);
      }

      case '!магазин':
        return await shopHandlers.handleShop(ctx);

      case '!купить': {
        // Название товара может состоять из нескольких слов, количество — последний токен если число
        const rest = tokens.slice(1);
        let quantity = 1;
        let nameTokens = rest;
        const last = rest[rest.length - 1];
        if (last && /^\d+$/.test(last)) {
          quantity = parseInt(last, 10);
          nameTokens = rest.slice(0, -1);
        }
        const itemName = nameTokens.join(' ');
        return await shopHandlers.handleBuy(ctx, itemName, String(quantity));
      }

      case '!арсенал':
        return await shopHandlers.handleArsenal(ctx);

      case '!атака': {
        const targetId = await resolveMentionToId(text, tokens, 1);
        const rest = tokens.slice(2);
        if (rest.length < 2) {
          await ctx.send('⛔ Формат: !атака @юзер [оружие] [количество]');
          return;
        }
        const qty = rest[rest.length - 1];
        const weapon = rest.slice(0, -1).join(' ');
        return await combatHandlers.handleAttack(ctx, targetId, weapon, qty, ctx.peerId);
      }

      case '!разведка': {
        const targetId = await resolveMentionToId(text, tokens, 1);
        return await combatHandlers.handleRecon(ctx, targetId);
      }

      case '!произвести': {
        const rest = tokens.slice(1);
        // формат: [оружие...] [количество] [заводов]
        if (rest.length < 3) {
          await ctx.send('⛔ Формат: !произвести [оружие] [количество] [заводов]');
          return;
        }
        const factoriesArg = rest[rest.length - 1];
        const qtyArg = rest[rest.length - 2];
        const weaponArg = rest.slice(0, -2).join(' ');
        return await productionHandlers.handleProduce(ctx, weaponArg, qtyArg, factoriesArg);
      }

      case '!производство':
        return await productionHandlers.handleProductionStatus(ctx);

      case '!забрать': {
        const rest = tokens.slice(1);
        if (rest.length < 2) {
          await ctx.send('⛔ Формат: !забрать [оружие] [количество]');
          return;
        }
        const qtyArg = rest[rest.length - 1];
        const weaponArg = rest.slice(0, -1).join(' ');
        return await productionHandlers.handleCollect(ctx, weaponArg, qtyArg);
      }

      case '!разблокировать': {
        return await economyHandlers.handleUnblock(ctx, tokens[1]);
      }

      case '!топ': {
        const sub = (tokens[1] || '').toLowerCase();
        if (sub === 'заводы') return await ratingHandlers.handleTopFactories(ctx);
        if (sub === 'вирты') return await ratingHandlers.handleTopBalance(ctx);
        if (sub === 'кланы') return await ratingHandlers.handleTopClans(ctx);
        if (sub === 'робот' || sub === 'роботы') return await ratingHandlers.handleTopRobot(ctx);
        if (sub === 'суперробот' || sub === 'суперроботы') return await ratingHandlers.handleTopSuperRobot(ctx);
        if (sub === 'доход') return await ratingHandlers.handleTopIncome(ctx);
        if (sub === 'ферма' || sub === 'фермы') return await ratingHandlers.handleTopFarmLevel(ctx);
        if (sub === 'фермадоход') return await ratingHandlers.handleTopFarmIncome(ctx);
        await ctx.send(
          '⛔ Формат: !топ заводы / !топ вирты / !топ кланы / !топ робот / !топ суперробот / ' +
            '!топ доход / !топ ферма / !топ фермадоход'
        );
        return;
      }

      case '!помощь':
        return await ratingHandlers.handleHelp(ctx);

      case '!гайд':
        return await ratingHandlers.handleHelpSection(ctx, 'guide');

      case '!робот': {
        // "робот прокачать" — повысить уровень. Любой другой вызов (включая просто "робот") —
        // мгновенная попытка собрать доход виртами (раз в час); если рано, покажет статус и кулдаун.
        const sub = (tokens[1] || '').toLowerCase();
        if (sub === 'прокачать') return await robotHandlers.handleUpgrade(ctx);
        return await robotHandlers.handleFarm(ctx);
      }

      case '!роботы':
        return await robotHandlers.handleLevelsList(ctx);

      case '!отправить':
        return await robotHandlers.handleSend(ctx);

      case '!дозор':
        return await patrolHandlers.handlePatrol(ctx);

      case '!суперробот': {
        // "суперробот прокачать" — прокачать уровень за жетоны.
        // "суперробот атака @юзер" — атаковать другого игрока (снос заводов).
        // Просто "суперробот" — статус.
        const sub = (tokens[1] || '').toLowerCase();
        if (sub === 'прокачать') return await superRobotHandlers.handleUpgrade(ctx);
        if (sub === 'атака') {
          const targetId = await resolveMentionToId(text, tokens, 2);
          return await superRobotHandlers.handleAttack(ctx, targetId, ctx.peerId);
        }
        return await superRobotHandlers.handleStatus(ctx);
      }

      case '!суперроботы':
        return await superRobotHandlers.handleLevelsList(ctx);

      case '!майнер':
        return await minerHandlers.handleStatus(ctx);

      case '!ферма': {
        // "ферма прокачать" — построить/прокачать уровень, "ферма включить"/"ферма выключить" —
        // переключить непрерывную добычу, "ферма снять" — перенести накопленное на кошелёк,
        // "ферма продать [число|всё]" — продать нанокоины за вирты. Просто "ферма" — статус (с кнопками).
        const sub = (tokens[1] || '').toLowerCase();
        if (sub === 'прокачать') return await farmHandlers.handleUpgrade(ctx);
        if (sub === 'включить' || sub === 'старт' || sub === 'запустить') return await farmHandlers.handleEnable(ctx);
        if (sub === 'выключить' || sub === 'стоп' || sub === 'остановить') return await farmHandlers.handleDisable(ctx);
        if (sub === 'снять') return await farmHandlers.handleWithdraw(ctx);
        if (sub === 'продать') return await farmHandlers.handleSell(ctx, tokens[2]);
        return await farmHandlers.handleStatus(ctx);
      }

      case '!донат':
        return await donateHandlers.handleDonate(ctx);

      case '!мой': {
        const sub = (tokens[1] || '').toLowerCase();
        if (sub === 'робот') return await robotHandlers.handleMyStats(ctx);
        await ctx.send('⛔ Формат: мой робот');
        return;
      }

      case '!админ': {
        const sub = (tokens[1] || '').toLowerCase();
        if (sub === 'помощь' || sub === 'рассылка' || sub === 'игроки' || sub === 'ивент' || sub === 'ивентмагазин') {
          const rest = tokens.slice(2);
          return await adminHandlers.handleAdmin(ctx, sub, null, rest);
        }
        if (sub === 'обнулить' && (tokens[2] || '').toLowerCase() === 'всех') {
          return await adminHandlers.handleAdmin(ctx, sub, 'всех', []);
        }
        if (sub === 'кланфото' || sub === 'кланвидео') {
          // Цель — не игрок по упоминанию, а клан по названию (может содержать пробелы).
          const rest = tokens.slice(2);
          return await adminHandlers.handleAdmin(ctx, sub, null, rest);
        }
        const targetId = await resolveMentionToId(text, tokens, 2);
        const rest = tokens.slice(3);
        return await adminHandlers.handleAdmin(ctx, sub, targetId, rest);
      }

      case '!клан': {
        const sub = (tokens[1] || '').toLowerCase();
        const rest = tokens.slice(2);

        if (!sub) {
          return await clanHandlers.handleInfo(ctx);
        }
        if (sub === 'создать') {
          return await clanHandlers.handleCreate(ctx, rest.join(' '));
        }
        if (sub === 'пригласить') {
          const targetId = await resolveMentionToId(text, tokens, 2);
          return await clanHandlers.handleInvite(ctx, targetId);
        }
        if (sub === 'вступить') {
          return await clanHandlers.handleJoin(ctx, rest.join(' '));
        }
        if (sub === 'кик') {
          const targetId = await resolveMentionToId(text, tokens, 2);
          return await clanHandlers.handleKick(ctx, targetId);
        }
        if (sub === 'зам') {
          const targetId = await resolveMentionToId(text, tokens, 2);
          return await clanHandlers.handlePromoteDeputy(ctx, targetId);
        }
        if (sub === 'снять_зама' || sub === 'разжаловать') {
          const targetId = await resolveMentionToId(text, tokens, 2);
          return await clanHandlers.handleDemoteDeputy(ctx, targetId);
        }
        if (sub === 'бонус') {
          return await clanHandlers.handleBonus(ctx, rest.join(' '));
        }
        if (sub === 'сейф' || sub === 'казна') {
          const action = (rest[0] || '').toLowerCase();
          if (['пополнить', 'внести', 'закинуть', 'положить'].includes(action)) {
            return await clanHandlers.handleDeposit(ctx, rest[1]);
          }
          if (['забрать', 'снять', 'вывести'].includes(action)) {
            return await clanHandlers.handleWithdraw(ctx, rest[1]);
          }
          return await clanHandlers.handleVault(ctx);
        }
        if (sub === 'инфо') {
          return await clanHandlers.handleInfo(ctx);
        }
        if (sub === 'покинуть') {
          return await clanHandlers.handleLeave(ctx);
        }
        if (sub === 'удалить' || sub === 'распустить') {
          return await clanHandlers.handleDisband(ctx, rest.join(' '));
        }

        await ctx.send('⛔ Неизвестная команда клана. Введите !помощь для списка команд.');
        return;
      }

      case '!работа':
        return await workHandlers.handleWorkMenu(ctx);

      case '!склад': {
        const sub = (tokens[1] || '').toLowerCase();
        if (sub === 'шансы') return await warehouseHandlers.handleRewardsInfo(ctx);
        return await warehouseHandlers.handleShow(ctx);
      }

      case '!выбрать':
        return await warehouseHandlers.handleSelect(ctx, tokens[1]);

      case '!наука': {
        const sub = (tokens[1] || '').toLowerCase();
        if (sub === 'построить') return await scienceHandlers.handleBuild(ctx);
        if (sub === 'расширить') return await scienceHandlers.handleExpand(ctx);
        if (sub === 'обменять') return await scienceHandlers.handleExchangeToFactories(ctx, tokens[2]);
        return await scienceHandlers.handleStatus(ctx);
      }

      case '!ивент': {
        const sub = (tokens[1] || '').toLowerCase();
        if (sub === 'магазин') return await eventHandlers.handleShop(ctx);
        if (sub === 'купить') {
          const itemArg = tokens[2];
          const qtyArg = tokens[3];
          return await eventHandlers.handlePurchase(ctx, itemArg, qtyArg);
        }
        return await eventHandlers.handleStatus(ctx);
      }

      case '!лимит': {
        const sub = (tokens[1] || '').toLowerCase();
        if (sub === 'расширить') return await limitHandlers.handleExpand(ctx);
        return await limitHandlers.handleStatus(ctx);
      }

      case '!аукцион': {
        if (tokens[1] && /^\d+$/.test(tokens[1])) {
          return await auctionHandlers.handleDetails(ctx, tokens[1]);
        }
        return await auctionHandlers.handleList(ctx);
      }

      case '!продать': {
        const [itemName, qty, start, step, hours] = tokens.slice(1);
        return await auctionHandlers.handleCreate(ctx, itemName, qty, start, step, hours);
      }

      case '!ставка':
        return await auctionHandlers.handleBid(ctx, tokens[1], tokens[2]);

      case '!отмена':
        return await auctionHandlers.handleCancel(ctx, tokens[1]);

      case '!лоты':
        return await auctionHandlers.handleMyLots(ctx);

      case '!обменять': {
        const sub = (tokens[1] || '').toLowerCase();
        if (sub === 'наука' || sub === 'науку') return await warehouseHandlers.handleExchangeScience(ctx);
        return await warehouseHandlers.handleExchangeFactory(ctx);
      }

      case '!оружие':
        return await shopHandlers.handleWeaponsInfo(ctx);

      case '!вооружение':
        return await shopHandlers.handleProductionGuide(ctx);

      case '!уведомления':
        return await combatHandlers.handleNotificationsToggle(ctx, tokens[1]);

      case '!промо': {
        const sub = (tokens[1] || '').toLowerCase();
        if (sub === 'создать') {
          return await promoHandlers.handleCreate(ctx, tokens.slice(2));
        }
        if (sub === 'список') {
          return await promoHandlers.handleList(ctx);
        }
        if (sub === 'удалить') {
          return await promoHandlers.handleDelete(ctx, tokens[2]);
        }
        // !промо WAR2025 — активация игроком
        return await promoHandlers.handleRedeem(ctx, tokens[1]);
      }

      default: {
        // Проверяем, зарегистрирован ли игрок вообще, для более полезной подсказки
        const player = await players.getPlayer(ctx.senderId);
        if (!player) {
          await ctx.send('⛔ Неизвестная команда. Начните с команды !старт');
        } else {
          await ctx.send('⛔ Неизвестная команда. Введите !помощь для списка всех команд.');
        }
      }
    }
  } catch (err) {
    console.error(`[Dispatcher] Ошибка при обработке команды "${command}":`, err);
    await ctx.send('⛔ Произошла ошибка при выполнении команды. Попробуйте позже.');
  }
}

module.exports = { dispatch };
