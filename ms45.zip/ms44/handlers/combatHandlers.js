'use strict';

const combat = require('../game/combat');
const players = require('../db/players');
const calc = require('../game/calc');
const C = require('../game/constants');
const msg = require('../utils/messages');
const events = require('../game/events');

const CATEGORY_LABEL = { drone: 'БПЛА', missile: 'ракет', nuke: 'ядерного оружия' };

// Рассылка лога "кто-кого атаковал" всем игрокам, кто не отключил уведомления
// (кроме самих участников боя — они уже получили личные уведомления).
// В конце сообщения всегда есть подсказка, как отключить эти уведомления.
//
// ВАЖНО: эта функция НЕ должна блокировать обработку входящего сообщения. При 100-150
// подписчиках рассылка может занять много секунд (VK ограничивает скорость отправки —
// vk-io сам ставит запросы в очередь и шлёт их с паузами). Если вызывающий код делает
// `await broadcastAttackLog(...)`, весь апдейт (а с ним и обработка следующих сообщений
// от других игроков в vk-io long-poll) зависает до конца рассылки — бот "лагает" для всех.
// Поэтому вызывающий код НЕ должен ждать эту функцию (см. вызовы ниже без await),
// а сама она ловит все ошибки внутри и никогда не бросает наружу.
async function broadcastAttackLog(bot, text, excludeIds) {
  if (!bot) return;
  try {
    const subscribers = await players.getAttackLogSubscribers(excludeIds);
    // Отправляем не через Promise.all "всё и сразу", а небольшими пачками — так рассылка
    // 100-150 сообщений не создаёт всплеск из полутора сотен одновременных запросов к VK API
    // (что всё равно упёрлось бы в rate-limit VK), а идёт ровным потоком в фоне.
    const BATCH_SIZE = 20;
    for (let i = 0; i < subscribers.length; i += BATCH_SIZE) {
      const batch = subscribers.slice(i, i + BATCH_SIZE);
      await Promise.all(
        batch.map((id) =>
          bot.notifyUser(id, `${text}\n\n🔕 Отключить эти уведомления: уведомления откл`).catch(() => {})
        )
      );
    }
  } catch (err) {
    console.error('[CombatHandlers] Ошибка рассылки лога атак:', err);
  }
}

function findWeaponKey(name) {
  const lower = (name || '').toLowerCase();
  return Object.keys(C.WEAPONS).find((k) => k.toLowerCase() === lower);
}

async function handleAttack(ctx, targetId, weaponArg, qtyArg, peerId) {
  const vkId = ctx.senderId;
  const player = await players.getPlayer(vkId);
  if (!player || player.registration_step !== 'done') {
    await ctx.send('⛔ Вы ещё не зарегистрированы. Напишите !старт');
    return;
  }

  if (!targetId) {
    await ctx.send('⛔ Укажите цель: !атака @юзер [оружие] [количество]');
    return;
  }

  const weaponKey = findWeaponKey(weaponArg);
  if (!weaponKey) {
    await ctx.send('⛔ Неизвестное оружие.');
    return;
  }

  const quantity = parseInt(qtyArg, 10) || 1;

  const result = await combat.launchAttack(vkId, targetId, weaponKey, quantity, peerId);

  if (!result.ok) {
    const reasons = {
      self_attack: '⛔ Нельзя атаковать самого себя.',
      not_registered: '⛔ Цель не зарегистрирована в игре.',
      attacker_too_small: `⛔ Для этого оружия нужно от ${result.minRequired || C.MIN_FACTORIES_TO_ATTACK} заводов. Сначала развейте экономику.`,
      defender_too_small: `⛔ Нельзя атаковать игрока с менее чем ${C.MIN_FACTORIES_TO_BE_ATTACKED} заводами.`,
      defender_inactive: `⛔ Игрок не заходил более ${C.INACTIVITY_ATTACK_BAN_DAYS} дней, атака запрещена.`,
      invalid_quantity: `⛔ Некорректное количество. Максимум за раз: ${result.max}.`,
      not_enough_weapons: `⛔ У вас недостаточно этого оружия (в наличии: ${result.have}).`,
      unknown_weapon: '⛔ Неизвестное оружие.',
    };
    if (result.reason === 'category_cooldown') {
      await ctx.send(
        `⏳ Кулдаун на запуск ${CATEGORY_LABEL[result.category] || 'этого оружия'}. Осталось: ${calc.formatDuration(
          result.remainingMs
        )}.`
      );
      return;
    }
    await ctx.send(reasons[result.reason] || '⛔ Атака невозможна.');
    return;
  }

  const weapon = C.WEAPONS[weaponKey];
  const effectText = msg.weaponEffectSummary(weapon);

  const attackerLink = msg.mentionLink(result.attackerId, result.attackerName);
  const defenderLink = msg.mentionLink(result.defenderId, result.defenderName);

  const drop = await events.awardDrop(vkId);

  await ctx.send(
    `🚀 ГОСУДАРСТВО «${attackerLink}» ЗАПУСТИЛО:\n` +
      `Оружие: ${weaponKey} (x${quantity})\n` +
      `Цель: ${defenderLink}\n` +
      `Расстояние: ${Math.round(result.distance)} км\n` +
      `Прилёт через: ${calc.formatDuration(result.flightMs)}\n\n` +
      `Эффект: ${effectText}` +
      events.dropSuffix(drop)
  );

  // Уведомление жертве — название атакующего кликабельно и ведёт на его страницу
  if (ctx.bot) {
    await ctx.bot
      .notifyUser(
        targetId,
        `⚠️ Государство «${attackerLink}» запустило ${weaponKey} по вашему городу! Прилёт через ${calc.formatDuration(
          result.flightMs
        )}.`
      )
      .catch(() => {});

    if (peerId) {
      await ctx.bot
        .sendToChat(
          peerId,
          `⚔️ «${attackerLink}» атакует «${defenderLink}» (${weaponKey}). Прилёт через ${calc.formatDuration(
            result.flightMs
          )}.`
        )
        .catch(() => {});
    }

    // Общий лог "кто-кого атаковал" — уходит всем игрокам, кроме атакующего и цели,
    // у кого не отключены такие уведомления (см. "уведомления откл"/"уведомления вкл").
    // НЕ ждём завершения (см. комментарий в broadcastAttackLog): рассылка 100-150
    // сообщениям не должна задерживать обработку команды атаки и следующих сообщений бота.
    broadcastAttackLog(
      ctx.bot,
      `⚔️ «${attackerLink}» запустил(а) ${weaponKey} (x${quantity}) по «${defenderLink}»! Прилёт через ${calc.formatDuration(
        result.flightMs
      )}.`,
      [result.attackerId, result.defenderId]
    ).catch(() => {});
  }
}

async function handleRecon(ctx, targetId) {
  const vkId = ctx.senderId;
  const player = await players.getPlayer(vkId);
  if (!player || player.registration_step !== 'done') {
    await ctx.send('⛔ Вы ещё не зарегистрированы. Напишите !старт');
    return;
  }

  if (!targetId) {
    await ctx.send('⛔ Укажите цель: !разведка @юзер');
    return;
  }

  const target = await players.getPlayer(targetId);
  if (!target || target.registration_step !== 'done') {
    await ctx.send('⛔ Эта цель не найдена.');
    return;
  }

  if (Number(player.balance) < C.RECON_COST) {
    await ctx.send(`⛔ Недостаточно вирт. Нужно ${C.RECON_COST}.`);
    return;
  }

  await players.updateBalance(vkId, -C.RECON_COST);

  const exact = calc.distanceKm(player.x, player.y, target.x, target.y);
  const lower = Math.max(0, Math.round(exact - 50));
  const upper = Math.round(exact + 50);

  await ctx.send(
    `🕵️ РАЗВЕДКА ДОЛОЖИЛА:\n` +
      `Цель: ${msg.mentionLink(target.vk_id, target.state_name)}\n` +
      `Расстояние: примерно ${lower}-${upper} км.\n` +
      `Стоимость: ${C.RECON_COST} вирт.`
  );
}

async function handleNotificationsToggle(ctx, sub) {
  const vkId = ctx.senderId;
  const player = await players.getPlayer(vkId);
  if (!player || player.registration_step !== 'done') {
    await ctx.send('⛔ Вы ещё не зарегистрированы. Напишите !старт');
    return;
  }

  const arg = (sub || '').toLowerCase();
  if (arg === 'вкл' || arg === 'включить') {
    await players.setAttackLogNotifications(vkId, true);
    await ctx.send('🔔 Уведомления о чужих атаках включены.');
    return;
  }
  if (arg === 'откл' || arg === 'выкл' || arg === 'отключить') {
    await players.setAttackLogNotifications(vkId, false);
    await ctx.send('🔕 Уведомления о чужих атаках отключены. Включить обратно: уведомления вкл');
    return;
  }

  await ctx.send(
    `🔔 Сейчас уведомления о чужих атаках: ${player.attack_log_notifications ? 'включены' : 'отключены'}.\n` +
      `Изменить: уведомления вкл / уведомления откл`
  );
}

module.exports = { handleAttack, handleRecon, handleNotificationsToggle, broadcastAttackLog };
